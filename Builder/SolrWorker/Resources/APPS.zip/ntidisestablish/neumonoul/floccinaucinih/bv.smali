.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/bv;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/bv$a;
    }
.end annotation


# static fields
.field public static final a:Lntidisestablish/neumonoul/floccinaucinih/bv$a;

.field public static final b:Lntidisestablish/neumonoul/floccinaucinih/bv;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/bv$a;->a:Lntidisestablish/neumonoul/floccinaucinih/bv$a;

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/bv;->a:Lntidisestablish/neumonoul/floccinaucinih/bv$a;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/bv$a$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/bv$a$a;-><init>()V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/bv;->b:Lntidisestablish/neumonoul/floccinaucinih/bv;

    return-void
.end method


# virtual methods
.method public abstract a(ILjava/util/List;)Z
.end method

.method public abstract b(ILjava/util/List;Z)Z
.end method

.method public abstract c(ILntidisestablish/neumonoul/floccinaucinih/jf;)V
.end method

.method public abstract d(ILntidisestablish/neumonoul/floccinaucinih/f6;IZ)Z
.end method
