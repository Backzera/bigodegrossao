.class public final enum Lntidisestablish/neumonoul/floccinaucinih/cc;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/cc$a;
    }
.end annotation


# static fields
.field public static final enum e:Lntidisestablish/neumonoul/floccinaucinih/cc;

.field public static final enum f:Lntidisestablish/neumonoul/floccinaucinih/cc;

.field public static final enum g:Lntidisestablish/neumonoul/floccinaucinih/cc;

.field public static final enum h:Lntidisestablish/neumonoul/floccinaucinih/cc;

.field private static final synthetic i:[Lntidisestablish/neumonoul/floccinaucinih/cc;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/cc;

    const-string v1, "DEFAULT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/cc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc;->e:Lntidisestablish/neumonoul/floccinaucinih/cc;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/cc;

    const-string v1, "LAZY"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/cc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc;->f:Lntidisestablish/neumonoul/floccinaucinih/cc;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/cc;

    const-string v1, "ATOMIC"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/cc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc;->g:Lntidisestablish/neumonoul/floccinaucinih/cc;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/cc;

    const-string v1, "UNDISPATCHED"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/cc;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc;->h:Lntidisestablish/neumonoul/floccinaucinih/cc;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/cc;->a()[Lntidisestablish/neumonoul/floccinaucinih/cc;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc;->i:[Lntidisestablish/neumonoul/floccinaucinih/cc;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static final synthetic a()[Lntidisestablish/neumonoul/floccinaucinih/cc;
    .locals 4

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc;->e:Lntidisestablish/neumonoul/floccinaucinih/cc;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/cc;->f:Lntidisestablish/neumonoul/floccinaucinih/cc;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/cc;->g:Lntidisestablish/neumonoul/floccinaucinih/cc;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/cc;->h:Lntidisestablish/neumonoul/floccinaucinih/cc;

    filled-new-array {v0, v1, v2, v3}, [Lntidisestablish/neumonoul/floccinaucinih/cc;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/cc;
    .locals 1

    .line 1
    const-class v0, Lntidisestablish/neumonoul/floccinaucinih/cc;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lntidisestablish/neumonoul/floccinaucinih/cc;

    return-object p0
.end method

.method public static values()[Lntidisestablish/neumonoul/floccinaucinih/cc;
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc;->i:[Lntidisestablish/neumonoul/floccinaucinih/cc;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lntidisestablish/neumonoul/floccinaucinih/cc;

    return-object v0
.end method


# virtual methods
.method public final b(Lntidisestablish/neumonoul/floccinaucinih/ni;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)V
    .locals 6

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc$a;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_3

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1

    const/4 p1, 0x4

    if-ne v0, p1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/nr;

    invoke-direct {p1}, Lntidisestablish/neumonoul/floccinaucinih/nr;-><init>()V

    throw p1

    :cond_1
    invoke-static {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/j60;->a(Lntidisestablish/neumonoul/floccinaucinih/ni;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    goto :goto_0

    :cond_2
    invoke-static {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/jb;->a(Lntidisestablish/neumonoul/floccinaucinih/ni;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    goto :goto_0

    :cond_3
    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    move-object v0, p1

    move-object v1, p2

    move-object v2, p3

    invoke-static/range {v0 .. v5}, Lntidisestablish/neumonoul/floccinaucinih/f7;->d(Lntidisestablish/neumonoul/floccinaucinih/ni;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;Lntidisestablish/neumonoul/floccinaucinih/zh;ILjava/lang/Object;)V

    :goto_0
    return-void
.end method

.method public final c()Z
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/cc;->f:Lntidisestablish/neumonoul/floccinaucinih/cc;

    if-ne p0, v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method
