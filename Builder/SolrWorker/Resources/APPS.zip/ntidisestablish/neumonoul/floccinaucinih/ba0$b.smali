.class Lntidisestablish/neumonoul/floccinaucinih/ba0$b;
.super Lntidisestablish/neumonoul/floccinaucinih/m00;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/ba0;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Lntidisestablish/neumonoul/floccinaucinih/ba0;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0$b;->d:Lntidisestablish/neumonoul/floccinaucinih/ba0;

    invoke-direct {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/m00;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    return-void
.end method


# virtual methods
.method public e()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "UPDATE workspec SET next_schedule_time_override=? WHERE id=?"

    return-object v0
.end method
