.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/c4$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/c4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(I)F
.end method

.method public abstract b(Lntidisestablish/neumonoul/floccinaucinih/u00;Z)F
.end method

.method public abstract c(Lntidisestablish/neumonoul/floccinaucinih/u00;)F
.end method

.method public abstract clear()V
.end method

.method public abstract d(Lntidisestablish/neumonoul/floccinaucinih/c4;Z)F
.end method

.method public abstract e(I)Lntidisestablish/neumonoul/floccinaucinih/u00;
.end method

.method public abstract f(F)V
.end method

.method public abstract g(Lntidisestablish/neumonoul/floccinaucinih/u00;)Z
.end method

.method public abstract h(Lntidisestablish/neumonoul/floccinaucinih/u00;FZ)V
.end method

.method public abstract i(Lntidisestablish/neumonoul/floccinaucinih/u00;F)V
.end method

.method public abstract j()V
.end method

.method public abstract k()I
.end method
