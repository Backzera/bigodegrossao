.class final Lntidisestablish/neumonoul/floccinaucinih/an$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/an;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "a"
.end annotation


# instance fields
.field private e:Ljava/lang/Runnable;

.field final synthetic f:Lntidisestablish/neumonoul/floccinaucinih/an;


# direct methods
.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/an;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->f:Lntidisestablish/neumonoul/floccinaucinih/an;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->e:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    :cond_0
    :try_start_0
    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->e:Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ve;->e:Lntidisestablish/neumonoul/floccinaucinih/ve;

    invoke-static {v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/wb;->a(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Throwable;)V

    :goto_0
    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->f:Lntidisestablish/neumonoul/floccinaucinih/an;

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/an;->x0(Lntidisestablish/neumonoul/floccinaucinih/an;)Ljava/lang/Runnable;

    move-result-object v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    iput-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->e:Ljava/lang/Runnable;

    add-int/lit8 v0, v0, 0x1

    const/16 v1, 0x10

    if-lt v0, v1, :cond_0

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->f:Lntidisestablish/neumonoul/floccinaucinih/an;

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/an;->w0(Lntidisestablish/neumonoul/floccinaucinih/an;)Lntidisestablish/neumonoul/floccinaucinih/sb;

    move-result-object v1

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->f:Lntidisestablish/neumonoul/floccinaucinih/an;

    invoke-virtual {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sb;->u0(Lntidisestablish/neumonoul/floccinaucinih/pb;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->f:Lntidisestablish/neumonoul/floccinaucinih/an;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/an;->w0(Lntidisestablish/neumonoul/floccinaucinih/an;)Lntidisestablish/neumonoul/floccinaucinih/sb;

    move-result-object v0

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/an$a;->f:Lntidisestablish/neumonoul/floccinaucinih/an;

    invoke-virtual {v0, v1, p0}, Lntidisestablish/neumonoul/floccinaucinih/sb;->s0(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Runnable;)V

    return-void
.end method
