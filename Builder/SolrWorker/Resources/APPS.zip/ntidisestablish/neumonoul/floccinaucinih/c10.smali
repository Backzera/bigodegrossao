.class Lntidisestablish/neumonoul/floccinaucinih/c10;
.super Lntidisestablish/neumonoul/floccinaucinih/i;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/pb;Z)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    invoke-direct {p0, p1, v0, p2}, Lntidisestablish/neumonoul/floccinaucinih/i;-><init>(Lntidisestablish/neumonoul/floccinaucinih/pb;ZZ)V

    return-void
.end method


# virtual methods
.method protected b0(Ljava/lang/Throwable;)Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/i;->i()Lntidisestablish/neumonoul/floccinaucinih/pb;

    move-result-object v0

    invoke-static {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/wb;->a(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Throwable;)V

    const/4 p1, 0x1

    return p1
.end method
