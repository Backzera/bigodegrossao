.class Lntidisestablish/neumonoul/floccinaucinih/az$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;
.implements Lntidisestablish/neumonoul/floccinaucinih/az$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/az;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "c"
.end annotation


# instance fields
.field private a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

.field private b:Z

.field final synthetic c:Lntidisestablish/neumonoul/floccinaucinih/az;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/az;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->c:Lntidisestablish/neumonoul/floccinaucinih/az;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x1

    iput-boolean p1, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->b:Z

    return-void
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/az$b;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-ne p1, v0, :cond_1

    iget-object p1, v0, Lntidisestablish/neumonoul/floccinaucinih/az$b;->d:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-boolean p1, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->b:Z

    :cond_1
    return-void
.end method

.method public b()Ljava/util/Map$Entry;
    .locals 1

    .line 1
    iget-boolean v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->b:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->b:Z

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->c:Lntidisestablish/neumonoul/floccinaucinih/az;

    iget-object v0, v0, Lntidisestablish/neumonoul/floccinaucinih/az;->e:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    :goto_0
    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-eqz v0, :cond_1

    iget-object v0, v0, Lntidisestablish/neumonoul/floccinaucinih/az$b;->c:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_0

    :goto_1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    return-object v0
.end method

.method public hasNext()Z
    .locals 3

    .line 1
    iget-boolean v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->b:Z

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->c:Lntidisestablish/neumonoul/floccinaucinih/az;

    iget-object v0, v0, Lntidisestablish/neumonoul/floccinaucinih/az;->e:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-eqz v0, :cond_0

    move v1, v2

    :cond_0
    return v1

    :cond_1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$c;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-eqz v0, :cond_2

    iget-object v0, v0, Lntidisestablish/neumonoul/floccinaucinih/az$b;->c:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-eqz v0, :cond_2

    move v1, v2

    :cond_2
    return v1
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/az$c;->b()Ljava/util/Map$Entry;

    move-result-object v0

    return-object v0
.end method
