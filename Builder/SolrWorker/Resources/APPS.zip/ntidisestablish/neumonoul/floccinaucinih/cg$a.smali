.class final Lntidisestablish/neumonoul/floccinaucinih/cg$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/vg$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/cg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;Landroid/graphics/Rect;)V
    .locals 0

    .line 1
    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/h1;

    invoke-virtual {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/cg$a;->b(Lntidisestablish/neumonoul/floccinaucinih/h1;Landroid/graphics/Rect;)V

    return-void
.end method

.method public b(Lntidisestablish/neumonoul/floccinaucinih/h1;Landroid/graphics/Rect;)V
    .locals 0

    .line 1
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/h1;->l(Landroid/graphics/Rect;)V

    return-void
.end method
