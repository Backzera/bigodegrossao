.class final Lntidisestablish/neumonoul/floccinaucinih/c6$b;
.super Lntidisestablish/neumonoul/floccinaucinih/sm;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/oi;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/c6;-><init>(ILntidisestablish/neumonoul/floccinaucinih/zh;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field final synthetic f:Lntidisestablish/neumonoul/floccinaucinih/c6;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/c6;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$b;->f:Lntidisestablish/neumonoul/floccinaucinih/c6;

    const/4 p1, 0x3

    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/sm;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Lntidisestablish/neumonoul/floccinaucinih/oz;Ljava/lang/Object;Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/zh;
    .locals 1

    .line 1
    new-instance p2, Lntidisestablish/neumonoul/floccinaucinih/c6$b$a;

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$b;->f:Lntidisestablish/neumonoul/floccinaucinih/c6;

    invoke-direct {p2, p3, v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6$b$a;-><init>(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/oz;)V

    return-object p2
.end method

.method public bridge synthetic n(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/i20;->a(Ljava/lang/Object;)V

    const/4 p1, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/c6$b;->a(Lntidisestablish/neumonoul/floccinaucinih/oz;Ljava/lang/Object;Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/zh;

    move-result-object p1

    return-object p1
.end method
