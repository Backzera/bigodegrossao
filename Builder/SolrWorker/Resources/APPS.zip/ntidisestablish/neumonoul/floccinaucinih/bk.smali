.class public abstract Lntidisestablish/neumonoul/floccinaucinih/bk;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Lntidisestablish/neumonoul/floccinaucinih/j6;

.field private static final b:Lntidisestablish/neumonoul/floccinaucinih/j6;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/j6;->h:Lntidisestablish/neumonoul/floccinaucinih/j6$a;

    const-string v1, "\"\\"

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/j6$a;->c(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/j6;

    move-result-object v1

    sput-object v1, Lntidisestablish/neumonoul/floccinaucinih/bk;->a:Lntidisestablish/neumonoul/floccinaucinih/j6;

    const-string v1, "\t ,="

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/j6$a;->c(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/j6;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/bk;->b:Lntidisestablish/neumonoul/floccinaucinih/j6;

    return-void
.end method

.method public static final a(Lntidisestablish/neumonoul/floccinaucinih/lj;Ljava/lang/String;)Ljava/util/List;
    .locals 7

    .line 1
    const-string v0, "<this>"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "headerName"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/lj;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    invoke-virtual {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/lj;->b(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-static {p1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/t10;->q(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    if-eqz v3, :cond_0

    new-instance v3, Lntidisestablish/neumonoul/floccinaucinih/a6;

    invoke-direct {v3}, Lntidisestablish/neumonoul/floccinaucinih/a6;-><init>()V

    invoke-virtual {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/lj;->d(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/a6;->N0(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/a6;

    move-result-object v3

    :try_start_0
    invoke-static {v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->c(Lntidisestablish/neumonoul/floccinaucinih/a6;Ljava/util/List;)V
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v3

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/jt;->a:Lntidisestablish/neumonoul/floccinaucinih/jt$a;

    invoke-virtual {v4}, Lntidisestablish/neumonoul/floccinaucinih/jt$a;->g()Lntidisestablish/neumonoul/floccinaucinih/jt;

    move-result-object v4

    const-string v5, "Unable to parse challenge"

    const/4 v6, 0x5

    invoke-virtual {v4, v5, v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/jt;->j(Ljava/lang/String;ILjava/lang/Throwable;)V

    :cond_0
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static final b(Lntidisestablish/neumonoul/floccinaucinih/dy;)Z
    .locals 8

    .line 1
    const-string v0, "<this>"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/dy;->e0()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx;->g()Ljava/lang/String;

    move-result-object v0

    const-string v1, "HEAD"

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/dy;->m()I

    move-result v0

    const/16 v2, 0x64

    const/4 v3, 0x1

    if-lt v0, v2, :cond_1

    const/16 v2, 0xc8

    if-lt v0, v2, :cond_2

    :cond_1
    const/16 v2, 0xcc

    if-eq v0, v2, :cond_2

    const/16 v2, 0x130

    if-eq v0, v2, :cond_2

    return v3

    :cond_2
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/s60;->v(Lntidisestablish/neumonoul/floccinaucinih/dy;)J

    move-result-wide v4

    const-wide/16 v6, -0x1

    cmp-long v0, v4, v6

    if-nez v0, :cond_4

    const-string v0, "Transfer-Encoding"

    const/4 v2, 0x2

    const/4 v4, 0x0

    invoke-static {p0, v0, v4, v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/dy;->w(Lntidisestablish/neumonoul/floccinaucinih/dy;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "chunked"

    invoke-static {v0, p0, v3}, Lntidisestablish/neumonoul/floccinaucinih/t10;->q(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p0

    if-eqz p0, :cond_3

    goto :goto_0

    :cond_3
    return v1

    :cond_4
    :goto_0
    return v3
.end method

.method private static final c(Lntidisestablish/neumonoul/floccinaucinih/a6;Ljava/util/List;)V
    .locals 7

    .line 1
    const/4 v0, 0x0

    :goto_0
    move-object v1, v0

    :goto_1
    if-nez v1, :cond_0

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->g(Lntidisestablish/neumonoul/floccinaucinih/a6;)Z

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->e(Lntidisestablish/neumonoul/floccinaucinih/a6;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    return-void

    :cond_0
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->g(Lntidisestablish/neumonoul/floccinaucinih/a6;)Z

    move-result v2

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->e(Lntidisestablish/neumonoul/floccinaucinih/a6;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_2

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->h0()Z

    move-result p0

    if-nez p0, :cond_1

    return-void

    :cond_1
    new-instance p0, Lntidisestablish/neumonoul/floccinaucinih/n7;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/mo;->g()Ljava/util/Map;

    move-result-object v0

    invoke-direct {p0, v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/n7;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void

    :cond_2
    const/16 v4, 0x3d

    invoke-static {p0, v4}, Lntidisestablish/neumonoul/floccinaucinih/s60;->J(Lntidisestablish/neumonoul/floccinaucinih/a6;B)I

    move-result v5

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->g(Lntidisestablish/neumonoul/floccinaucinih/a6;)Z

    move-result v6

    if-nez v2, :cond_4

    if-nez v6, :cond_3

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->h0()Z

    move-result v2

    if-eqz v2, :cond_4

    :cond_3
    new-instance v2, Lntidisestablish/neumonoul/floccinaucinih/n7;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "="

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/t10;->t(Ljava/lang/CharSequence;I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    move-result-object v3

    const-string v4, "singletonMap<String, Str\u2026ek + \"=\".repeat(eqCount))"

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v2, v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/n7;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-interface {p1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_4
    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-static {p0, v4}, Lntidisestablish/neumonoul/floccinaucinih/s60;->J(Lntidisestablish/neumonoul/floccinaucinih/a6;B)I

    move-result v6

    add-int/2addr v5, v6

    :goto_2
    if-nez v3, :cond_5

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->e(Lntidisestablish/neumonoul/floccinaucinih/a6;)Ljava/lang/String;

    move-result-object v3

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->g(Lntidisestablish/neumonoul/floccinaucinih/a6;)Z

    move-result v5

    if-nez v5, :cond_c

    invoke-static {p0, v4}, Lntidisestablish/neumonoul/floccinaucinih/s60;->J(Lntidisestablish/neumonoul/floccinaucinih/a6;B)I

    move-result v5

    :cond_5
    if-eqz v5, :cond_c

    const/4 v6, 0x1

    if-le v5, v6, :cond_6

    return-void

    :cond_6
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->g(Lntidisestablish/neumonoul/floccinaucinih/a6;)Z

    move-result v6

    if-eqz v6, :cond_7

    return-void

    :cond_7
    const/16 v6, 0x22

    invoke-static {p0, v6}, Lntidisestablish/neumonoul/floccinaucinih/bk;->h(Lntidisestablish/neumonoul/floccinaucinih/a6;B)Z

    move-result v6

    if-eqz v6, :cond_8

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->d(Lntidisestablish/neumonoul/floccinaucinih/a6;)Ljava/lang/String;

    move-result-object v6

    goto :goto_3

    :cond_8
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->e(Lntidisestablish/neumonoul/floccinaucinih/a6;)Ljava/lang/String;

    move-result-object v6

    :goto_3
    if-nez v6, :cond_9

    return-void

    :cond_9
    invoke-interface {v2, v3, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    if-eqz v3, :cond_a

    return-void

    :cond_a
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/bk;->g(Lntidisestablish/neumonoul/floccinaucinih/a6;)Z

    move-result v3

    if-nez v3, :cond_b

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->h0()Z

    move-result v3

    if-nez v3, :cond_b

    return-void

    :cond_b
    move-object v3, v0

    goto :goto_2

    :cond_c
    new-instance v4, Lntidisestablish/neumonoul/floccinaucinih/n7;

    invoke-direct {v4, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/n7;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-interface {p1, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-object v1, v3

    goto/16 :goto_1
.end method

.method private static final d(Lntidisestablish/neumonoul/floccinaucinih/a6;)Ljava/lang/String;
    .locals 12

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->p0()B

    move-result v0

    const/16 v1, 0x22

    if-ne v0, v1, :cond_3

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/a6;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/a6;-><init>()V

    :goto_0
    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/bk;->a:Lntidisestablish/neumonoul/floccinaucinih/j6;

    invoke-virtual {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/a6;->K(Lntidisestablish/neumonoul/floccinaucinih/j6;)J

    move-result-wide v2

    const-wide/16 v4, -0x1

    cmp-long v4, v2, v4

    const/4 v5, 0x0

    if-nez v4, :cond_0

    return-object v5

    :cond_0
    invoke-virtual {p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/a6;->F(J)B

    move-result v4

    if-ne v4, v1, :cond_1

    invoke-virtual {v0, p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/a6;->J(Lntidisestablish/neumonoul/floccinaucinih/a6;J)V

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->p0()B

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->w0()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->z0()J

    move-result-wide v6

    const-wide/16 v8, 0x1

    add-long v10, v2, v8

    cmp-long v4, v6, v10

    if-nez v4, :cond_2

    return-object v5

    :cond_2
    invoke-virtual {v0, p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/a6;->J(Lntidisestablish/neumonoul/floccinaucinih/a6;J)V

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->p0()B

    invoke-virtual {v0, p0, v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/a6;->J(Lntidisestablish/neumonoul/floccinaucinih/a6;J)V

    goto :goto_0

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Failed requirement."

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private static final e(Lntidisestablish/neumonoul/floccinaucinih/a6;)Ljava/lang/String;
    .locals 4

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/bk;->b:Lntidisestablish/neumonoul/floccinaucinih/j6;

    invoke-virtual {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->K(Lntidisestablish/neumonoul/floccinaucinih/j6;)J

    move-result-wide v0

    const-wide/16 v2, -0x1

    cmp-long v2, v0, v2

    if-nez v2, :cond_0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->z0()J

    move-result-wide v0

    :cond_0
    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-eqz v2, :cond_1

    invoke-virtual {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/a6;->x0(J)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method public static final f(Lntidisestablish/neumonoul/floccinaucinih/lb;Lntidisestablish/neumonoul/floccinaucinih/dk;Lntidisestablish/neumonoul/floccinaucinih/lj;)V
    .locals 1

    .line 1
    const-string v0, "<this>"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "url"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "headers"

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/lb;->b:Lntidisestablish/neumonoul/floccinaucinih/lb;

    if-ne p0, v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/kb;->j:Lntidisestablish/neumonoul/floccinaucinih/kb$a;

    invoke-virtual {v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/kb$a;->e(Lntidisestablish/neumonoul/floccinaucinih/dk;Lntidisestablish/neumonoul/floccinaucinih/lj;)Ljava/util/List;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    :cond_1
    invoke-interface {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/lb;->a(Lntidisestablish/neumonoul/floccinaucinih/dk;Ljava/util/List;)V

    return-void
.end method

.method private static final g(Lntidisestablish/neumonoul/floccinaucinih/a6;)Z
    .locals 3

    .line 1
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->h0()Z

    move-result v1

    if-nez v1, :cond_2

    const-wide/16 v1, 0x0

    invoke-virtual {p0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/a6;->F(J)B

    move-result v1

    const/16 v2, 0x2c

    if-ne v1, v2, :cond_0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->p0()B

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/16 v2, 0x20

    if-ne v1, v2, :cond_1

    goto :goto_1

    :cond_1
    const/16 v2, 0x9

    if-ne v1, v2, :cond_2

    :goto_1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->p0()B

    goto :goto_0

    :cond_2
    return v0
.end method

.method private static final h(Lntidisestablish/neumonoul/floccinaucinih/a6;B)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/a6;->h0()Z

    move-result v0

    if-nez v0, :cond_0

    const-wide/16 v0, 0x0

    invoke-virtual {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/a6;->F(J)B

    move-result p0

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method
