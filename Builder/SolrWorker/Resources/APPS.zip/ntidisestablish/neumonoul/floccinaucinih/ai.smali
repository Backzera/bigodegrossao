.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/ai;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/ji;
