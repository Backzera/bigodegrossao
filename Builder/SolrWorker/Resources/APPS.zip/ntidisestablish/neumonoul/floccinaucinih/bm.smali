.class public abstract Lntidisestablish/neumonoul/floccinaucinih/bm;
.super Lntidisestablish/neumonoul/floccinaucinih/gm;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/gm;-><init>()V

    return-void
.end method
