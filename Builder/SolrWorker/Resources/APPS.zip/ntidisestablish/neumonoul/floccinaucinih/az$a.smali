.class Lntidisestablish/neumonoul/floccinaucinih/az$a;
.super Lntidisestablish/neumonoul/floccinaucinih/az$d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/az;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/az$b;Lntidisestablish/neumonoul/floccinaucinih/az$b;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/az$d;-><init>(Lntidisestablish/neumonoul/floccinaucinih/az$b;Lntidisestablish/neumonoul/floccinaucinih/az$b;)V

    return-void
.end method


# virtual methods
.method b(Lntidisestablish/neumonoul/floccinaucinih/az$b;)Lntidisestablish/neumonoul/floccinaucinih/az$b;
    .locals 0

    .line 1
    iget-object p1, p1, Lntidisestablish/neumonoul/floccinaucinih/az$b;->d:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    return-object p1
.end method

.method c(Lntidisestablish/neumonoul/floccinaucinih/az$b;)Lntidisestablish/neumonoul/floccinaucinih/az$b;
    .locals 0

    .line 1
    iget-object p1, p1, Lntidisestablish/neumonoul/floccinaucinih/az$b;->c:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    return-object p1
.end method
