.class Lntidisestablish/neumonoul/floccinaucinih/b4$a;
.super Lntidisestablish/neumonoul/floccinaucinih/lo;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/b4;->m()Lntidisestablish/neumonoul/floccinaucinih/lo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Lntidisestablish/neumonoul/floccinaucinih/b4;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/b4;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/lo;-><init>()V

    return-void
.end method


# virtual methods
.method protected a()V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/o00;->clear()V

    return-void
.end method

.method protected b(II)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    iget-object v0, v0, Lntidisestablish/neumonoul/floccinaucinih/o00;->f:[Ljava/lang/Object;

    shl-int/lit8 p1, p1, 0x1

    add-int/2addr p1, p2

    aget-object p1, v0, p1

    return-object p1
.end method

.method protected c()Ljava/util/Map;
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    return-object v0
.end method

.method protected d()I
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    iget v0, v0, Lntidisestablish/neumonoul/floccinaucinih/o00;->g:I

    return v0
.end method

.method protected e(Ljava/lang/Object;)I
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/o00;->f(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method protected f(Ljava/lang/Object;)I
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/o00;->h(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method protected g(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    invoke-virtual {v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/o00;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method protected h(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/o00;->j(I)Ljava/lang/Object;

    return-void
.end method

.method protected i(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b4$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b4;

    invoke-virtual {v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/o00;->k(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
