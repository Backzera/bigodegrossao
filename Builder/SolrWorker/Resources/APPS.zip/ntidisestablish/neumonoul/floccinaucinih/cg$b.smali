.class final Lntidisestablish/neumonoul/floccinaucinih/cg$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/vg$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/cg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)I
    .locals 0

    .line 1
    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/x00;

    invoke-virtual {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/cg$b;->d(Lntidisestablish/neumonoul/floccinaucinih/x00;)I

    move-result p1

    return p1
.end method

.method public bridge synthetic b(Ljava/lang/Object;I)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/x00;

    invoke-virtual {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/cg$b;->c(Lntidisestablish/neumonoul/floccinaucinih/x00;I)Lntidisestablish/neumonoul/floccinaucinih/h1;

    move-result-object p1

    return-object p1
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/x00;I)Lntidisestablish/neumonoul/floccinaucinih/h1;
    .locals 0

    .line 1
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/x00;->l(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/h1;

    return-object p1
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/x00;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/x00;->k()I

    move-result p1

    return p1
.end method
