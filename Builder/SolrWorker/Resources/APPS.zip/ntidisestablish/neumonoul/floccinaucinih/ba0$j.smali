.class Lntidisestablish/neumonoul/floccinaucinih/ba0$j;
.super Lntidisestablish/neumonoul/floccinaucinih/ef;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/ba0;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Lntidisestablish/neumonoul/floccinaucinih/ba0;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0$j;->d:Lntidisestablish/neumonoul/floccinaucinih/ba0;

    invoke-direct {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/ef;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    return-void
.end method


# virtual methods
.method public e()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "UPDATE OR ABORT `WorkSpec` SET `id` = ?,`state` = ?,`worker_class_name` = ?,`input_merger_class_name` = ?,`input` = ?,`output` = ?,`initial_delay` = ?,`interval_duration` = ?,`flex_duration` = ?,`run_attempt_count` = ?,`backoff_policy` = ?,`backoff_delay_duration` = ?,`last_enqueue_time` = ?,`minimum_retention_duration` = ?,`schedule_requested_at` = ?,`run_in_foreground` = ?,`out_of_quota_policy` = ?,`period_count` = ?,`generation` = ?,`next_schedule_time_override` = ?,`next_schedule_time_override_generation` = ?,`stop_reason` = ?,`required_network_type` = ?,`requires_charging` = ?,`requires_device_idle` = ?,`requires_battery_not_low` = ?,`requires_storage_not_low` = ?,`trigger_content_update_delay` = ?,`trigger_max_content_delay` = ?,`content_uri_triggers` = ? WHERE `id` = ?"

    return-object v0
.end method
