.class Lntidisestablish/neumonoul/floccinaucinih/b40$b;
.super Lntidisestablish/neumonoul/floccinaucinih/d40;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/b40;->g(Landroid/content/Context;Landroid/text/TextPaint;Lntidisestablish/neumonoul/floccinaucinih/d40;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/text/TextPaint;

.field final synthetic b:Lntidisestablish/neumonoul/floccinaucinih/d40;

.field final synthetic c:Lntidisestablish/neumonoul/floccinaucinih/b40;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/b40;Landroid/text/TextPaint;Lntidisestablish/neumonoul/floccinaucinih/d40;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$b;->c:Lntidisestablish/neumonoul/floccinaucinih/b40;

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$b;->a:Landroid/text/TextPaint;

    iput-object p3, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$b;->b:Lntidisestablish/neumonoul/floccinaucinih/d40;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/d40;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$b;->b:Lntidisestablish/neumonoul/floccinaucinih/d40;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/d40;->a(I)V

    return-void
.end method

.method public b(Landroid/graphics/Typeface;Z)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$b;->c:Lntidisestablish/neumonoul/floccinaucinih/b40;

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$b;->a:Landroid/text/TextPaint;

    invoke-virtual {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/b40;->l(Landroid/text/TextPaint;Landroid/graphics/Typeface;)V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$b;->b:Lntidisestablish/neumonoul/floccinaucinih/d40;

    invoke-virtual {v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/d40;->b(Landroid/graphics/Typeface;Z)V

    return-void
.end method
