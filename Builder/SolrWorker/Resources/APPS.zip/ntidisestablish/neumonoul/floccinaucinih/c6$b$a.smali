.class final Lntidisestablish/neumonoul/floccinaucinih/c6$b$a;
.super Lntidisestablish/neumonoul/floccinaucinih/sm;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/zh;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/c6$b;->a(Lntidisestablish/neumonoul/floccinaucinih/oz;Ljava/lang/Object;Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/zh;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field final synthetic f:Ljava/lang/Object;

.field final synthetic g:Lntidisestablish/neumonoul/floccinaucinih/c6;


# direct methods
.method constructor <init>(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/oz;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$b$a;->f:Ljava/lang/Object;

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$b$a;->g:Lntidisestablish/neumonoul/floccinaucinih/c6;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/sm;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Throwable;)V
    .locals 1

    .line 1
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$b$a;->f:Ljava/lang/Object;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v0

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$b$a;->g:Lntidisestablish/neumonoul/floccinaucinih/c6;

    iget-object p1, p1, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    const/4 p1, 0x0

    throw p1
.end method

.method public bridge synthetic r(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Throwable;

    invoke-virtual {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6$b$a;->a(Ljava/lang/Throwable;)V

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    return-object p1
.end method
