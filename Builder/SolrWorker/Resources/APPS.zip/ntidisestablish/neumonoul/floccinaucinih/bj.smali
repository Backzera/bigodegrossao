.class public Lntidisestablish/neumonoul/floccinaucinih/bj;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/bz;
.implements Lntidisestablish/neumonoul/floccinaucinih/ps;
.implements Lntidisestablish/neumonoul/floccinaucinih/wf;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/bj$b;
    }
.end annotation


# static fields
.field private static final p:Ljava/lang/String;


# instance fields
.field private final b:Landroid/content/Context;

.field private final c:Ljava/util/Map;

.field private d:Lntidisestablish/neumonoul/floccinaucinih/gd;

.field private e:Z

.field private final f:Ljava/lang/Object;

.field private final g:Lntidisestablish/neumonoul/floccinaucinih/f10;

.field private final h:Lntidisestablish/neumonoul/floccinaucinih/pu;

.field private final i:Lntidisestablish/neumonoul/floccinaucinih/g90;

.field private final j:Landroidx/work/a;

.field private final k:Ljava/util/Map;

.field l:Ljava/lang/Boolean;

.field private final m:Lntidisestablish/neumonoul/floccinaucinih/t80;

.field private final n:Lntidisestablish/neumonoul/floccinaucinih/t30;

.field private final o:Lntidisestablish/neumonoul/floccinaucinih/z40;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "GreedyScheduler"

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/xn;->i(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/work/a;Lntidisestablish/neumonoul/floccinaucinih/p50;Lntidisestablish/neumonoul/floccinaucinih/pu;Lntidisestablish/neumonoul/floccinaucinih/g90;Lntidisestablish/neumonoul/floccinaucinih/t30;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->c:Ljava/util/Map;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->f:Ljava/lang/Object;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/f10;-><init>()V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->k:Ljava/util/Map;

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->b:Landroid/content/Context;

    invoke-virtual {p2}, Landroidx/work/a;->k()Lntidisestablish/neumonoul/floccinaucinih/xy;

    move-result-object p1

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/gd;

    invoke-virtual {p2}, Landroidx/work/a;->a()Lntidisestablish/neumonoul/floccinaucinih/l8;

    move-result-object v1

    invoke-direct {v0, p0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/gd;-><init>(Lntidisestablish/neumonoul/floccinaucinih/bz;Lntidisestablish/neumonoul/floccinaucinih/xy;Lntidisestablish/neumonoul/floccinaucinih/l8;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->d:Lntidisestablish/neumonoul/floccinaucinih/gd;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/z40;

    invoke-direct {v0, p1, p5}, Lntidisestablish/neumonoul/floccinaucinih/z40;-><init>(Lntidisestablish/neumonoul/floccinaucinih/xy;Lntidisestablish/neumonoul/floccinaucinih/g90;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->o:Lntidisestablish/neumonoul/floccinaucinih/z40;

    iput-object p6, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->n:Lntidisestablish/neumonoul/floccinaucinih/t30;

    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/t80;

    invoke-direct {p1, p3}, Lntidisestablish/neumonoul/floccinaucinih/t80;-><init>(Lntidisestablish/neumonoul/floccinaucinih/p50;)V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->m:Lntidisestablish/neumonoul/floccinaucinih/t80;

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->j:Landroidx/work/a;

    iput-object p4, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->h:Lntidisestablish/neumonoul/floccinaucinih/pu;

    iput-object p5, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->i:Lntidisestablish/neumonoul/floccinaucinih/g90;

    return-void
.end method

.method private f()V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->b:Landroid/content/Context;

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->j:Landroidx/work/a;

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/lu;->b(Landroid/content/Context;Landroidx/work/a;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->l:Ljava/lang/Boolean;

    return-void
.end method

.method private g()V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->e:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->h:Lntidisestablish/neumonoul/floccinaucinih/pu;

    invoke-virtual {v0, p0}, Lntidisestablish/neumonoul/floccinaucinih/pu;->e(Lntidisestablish/neumonoul/floccinaucinih/wf;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->e:Z

    :cond_0
    return-void
.end method

.method private h(Lntidisestablish/neumonoul/floccinaucinih/e90;)V
    .locals 5

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->c:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/zl;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Stopping tracking for "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, v2, p1}, Lntidisestablish/neumonoul/floccinaucinih/xn;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    invoke-interface {v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/zl;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_0
    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private i(Lntidisestablish/neumonoul/floccinaucinih/z90;)J
    .locals 7

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/ca0;->a(Lntidisestablish/neumonoul/floccinaucinih/z90;)Lntidisestablish/neumonoul/floccinaucinih/e90;

    move-result-object v1

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->k:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lntidisestablish/neumonoul/floccinaucinih/bj$b;

    if-nez v2, :cond_0

    new-instance v2, Lntidisestablish/neumonoul/floccinaucinih/bj$b;

    iget v3, p1, Lntidisestablish/neumonoul/floccinaucinih/z90;->k:I

    iget-object v4, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->j:Landroidx/work/a;

    invoke-virtual {v4}, Landroidx/work/a;->a()Lntidisestablish/neumonoul/floccinaucinih/l8;

    move-result-object v4

    invoke-interface {v4}, Lntidisestablish/neumonoul/floccinaucinih/l8;->a()J

    move-result-wide v4

    const/4 v6, 0x0

    invoke-direct {v2, v3, v4, v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/bj$b;-><init>(IJLntidisestablish/neumonoul/floccinaucinih/bj$a;)V

    iget-object v3, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->k:Ljava/util/Map;

    invoke-interface {v3, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    iget-wide v3, v2, Lntidisestablish/neumonoul/floccinaucinih/bj$b;->b:J

    iget p1, p1, Lntidisestablish/neumonoul/floccinaucinih/z90;->k:I

    iget v1, v2, Lntidisestablish/neumonoul/floccinaucinih/bj$b;->a:I

    sub-int/2addr p1, v1

    add-int/lit8 p1, p1, -0x5

    const/4 v1, 0x0

    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result p1

    int-to-long v1, p1

    const-wide/16 v5, 0x7530

    mul-long/2addr v1, v5

    add-long/2addr v3, v1

    monitor-exit v0

    return-wide v3

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/z90;Lntidisestablish/neumonoul/floccinaucinih/za;)V
    .locals 4

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/ca0;->a(Lntidisestablish/neumonoul/floccinaucinih/z90;)Lntidisestablish/neumonoul/floccinaucinih/e90;

    move-result-object p1

    instance-of v0, p2, Lntidisestablish/neumonoul/floccinaucinih/za$a;

    if-eqz v0, :cond_0

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-virtual {p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/f10;->a(Lntidisestablish/neumonoul/floccinaucinih/e90;)Z

    move-result p2

    if-nez p2, :cond_1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object p2

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Constraints met: Scheduling work ID "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/xn;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-virtual {p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/f10;->d(Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/e10;

    move-result-object p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->o:Lntidisestablish/neumonoul/floccinaucinih/z40;

    invoke-virtual {p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/z40;->c(Lntidisestablish/neumonoul/floccinaucinih/e10;)V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->i:Lntidisestablish/neumonoul/floccinaucinih/g90;

    invoke-interface {p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/g90;->b(Lntidisestablish/neumonoul/floccinaucinih/e10;)V

    goto :goto_0

    :cond_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Constraints not met: Cancelling work ID "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/xn;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/f10;->c(Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/e10;

    move-result-object p1

    if-eqz p1, :cond_1

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->o:Lntidisestablish/neumonoul/floccinaucinih/z40;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/z40;->b(Lntidisestablish/neumonoul/floccinaucinih/e10;)V

    check-cast p2, Lntidisestablish/neumonoul/floccinaucinih/za$b;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/za$b;->a()I

    move-result p2

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->i:Lntidisestablish/neumonoul/floccinaucinih/g90;

    invoke-interface {v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/g90;->c(Lntidisestablish/neumonoul/floccinaucinih/e10;I)V

    :cond_1
    :goto_0
    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->l:Ljava/lang/Boolean;

    if-nez v0, :cond_0

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/bj;->f()V

    :cond_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->l:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object p1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    const-string v1, "Ignoring schedule request in non-main process"

    invoke-virtual {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/xn;->f(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/bj;->g()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Cancelling work ID "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/xn;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->d:Lntidisestablish/neumonoul/floccinaucinih/gd;

    if-eqz v0, :cond_2

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/gd;->b(Ljava/lang/String;)V

    :cond_2
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/f10;->b(Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/e10;

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->o:Lntidisestablish/neumonoul/floccinaucinih/z40;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/z40;->b(Lntidisestablish/neumonoul/floccinaucinih/e10;)V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->i:Lntidisestablish/neumonoul/floccinaucinih/g90;

    invoke-interface {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/g90;->e(Lntidisestablish/neumonoul/floccinaucinih/e10;)V

    goto :goto_0

    :cond_3
    return-void
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/e90;Z)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/f10;->c(Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/e10;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->o:Lntidisestablish/neumonoul/floccinaucinih/z40;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/z40;->b(Lntidisestablish/neumonoul/floccinaucinih/e10;)V

    :cond_0
    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/bj;->h(Lntidisestablish/neumonoul/floccinaucinih/e90;)V

    if-nez p2, :cond_1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->f:Ljava/lang/Object;

    monitor-enter p2

    :try_start_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->k:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit p2

    goto :goto_0

    :catchall_0
    move-exception p1

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1

    :cond_1
    :goto_0
    return-void
.end method

.method public d()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public varargs e([Lntidisestablish/neumonoul/floccinaucinih/z90;)V
    .locals 11

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->l:Ljava/lang/Boolean;

    if-nez v0, :cond_0

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/bj;->f()V

    :cond_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->l:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object p1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    const-string v1, "Ignoring schedule request in a secondary process"

    invoke-virtual {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/xn;->f(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/bj;->g()V

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    array-length v2, p1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_8

    aget-object v4, p1, v3

    invoke-static {v4}, Lntidisestablish/neumonoul/floccinaucinih/ca0;->a(Lntidisestablish/neumonoul/floccinaucinih/z90;)Lntidisestablish/neumonoul/floccinaucinih/e90;

    move-result-object v5

    iget-object v6, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-virtual {v6, v5}, Lntidisestablish/neumonoul/floccinaucinih/f10;->a(Lntidisestablish/neumonoul/floccinaucinih/e90;)Z

    move-result v5

    if-eqz v5, :cond_2

    goto/16 :goto_2

    :cond_2
    invoke-direct {p0, v4}, Lntidisestablish/neumonoul/floccinaucinih/bj;->i(Lntidisestablish/neumonoul/floccinaucinih/z90;)J

    move-result-wide v5

    invoke-virtual {v4}, Lntidisestablish/neumonoul/floccinaucinih/z90;->a()J

    move-result-wide v7

    invoke-static {v7, v8, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v5

    iget-object v7, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->j:Landroidx/work/a;

    invoke-virtual {v7}, Landroidx/work/a;->a()Lntidisestablish/neumonoul/floccinaucinih/l8;

    move-result-object v7

    invoke-interface {v7}, Lntidisestablish/neumonoul/floccinaucinih/l8;->a()J

    move-result-wide v7

    iget-object v9, v4, Lntidisestablish/neumonoul/floccinaucinih/z90;->b:Lntidisestablish/neumonoul/floccinaucinih/f90;

    sget-object v10, Lntidisestablish/neumonoul/floccinaucinih/f90;->e:Lntidisestablish/neumonoul/floccinaucinih/f90;

    if-ne v9, v10, :cond_7

    cmp-long v7, v7, v5

    if-gez v7, :cond_3

    iget-object v7, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->d:Lntidisestablish/neumonoul/floccinaucinih/gd;

    if-eqz v7, :cond_7

    invoke-virtual {v7, v4, v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/gd;->a(Lntidisestablish/neumonoul/floccinaucinih/z90;J)V

    goto/16 :goto_2

    :cond_3
    invoke-virtual {v4}, Lntidisestablish/neumonoul/floccinaucinih/z90;->i()Z

    move-result v5

    if-eqz v5, :cond_6

    iget-object v5, v4, Lntidisestablish/neumonoul/floccinaucinih/z90;->j:Lntidisestablish/neumonoul/floccinaucinih/xa;

    invoke-virtual {v5}, Lntidisestablish/neumonoul/floccinaucinih/xa;->h()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object v5

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Ignoring "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v4, ". Requires device idle."

    :goto_1
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v6, v4}, Lntidisestablish/neumonoul/floccinaucinih/xn;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2

    :cond_4
    iget-object v5, v4, Lntidisestablish/neumonoul/floccinaucinih/z90;->j:Lntidisestablish/neumonoul/floccinaucinih/xa;

    invoke-virtual {v5}, Lntidisestablish/neumonoul/floccinaucinih/xa;->e()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object v5

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Ignoring "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v4, ". Requires ContentUri triggers."

    goto :goto_1

    :cond_5
    invoke-interface {v0, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    iget-object v4, v4, Lntidisestablish/neumonoul/floccinaucinih/z90;->a:Ljava/lang/String;

    invoke-interface {v1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_6
    iget-object v5, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-static {v4}, Lntidisestablish/neumonoul/floccinaucinih/ca0;->a(Lntidisestablish/neumonoul/floccinaucinih/z90;)Lntidisestablish/neumonoul/floccinaucinih/e90;

    move-result-object v6

    invoke-virtual {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/f10;->a(Lntidisestablish/neumonoul/floccinaucinih/e90;)Z

    move-result v5

    if-nez v5, :cond_7

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object v5

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Starting work for "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v8, v4, Lntidisestablish/neumonoul/floccinaucinih/z90;->a:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/xn;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v5, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->g:Lntidisestablish/neumonoul/floccinaucinih/f10;

    invoke-virtual {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/f10;->e(Lntidisestablish/neumonoul/floccinaucinih/z90;)Lntidisestablish/neumonoul/floccinaucinih/e10;

    move-result-object v4

    iget-object v5, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->o:Lntidisestablish/neumonoul/floccinaucinih/z40;

    invoke-virtual {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/z40;->c(Lntidisestablish/neumonoul/floccinaucinih/e10;)V

    iget-object v5, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->i:Lntidisestablish/neumonoul/floccinaucinih/g90;

    invoke-interface {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/g90;->b(Lntidisestablish/neumonoul/floccinaucinih/e10;)V

    :cond_7
    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :cond_8
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->f:Ljava/lang/Object;

    monitor-enter p1

    :try_start_0
    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_a

    const-string v2, ","

    invoke-static {v2, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object v2

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/bj;->p:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Starting tracking for "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/xn;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_9
    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/z90;

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ca0;->a(Lntidisestablish/neumonoul/floccinaucinih/z90;)Lntidisestablish/neumonoul/floccinaucinih/e90;

    move-result-object v2

    iget-object v3, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->c:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_9

    iget-object v3, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->m:Lntidisestablish/neumonoul/floccinaucinih/t80;

    iget-object v4, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->n:Lntidisestablish/neumonoul/floccinaucinih/t30;

    invoke-interface {v4}, Lntidisestablish/neumonoul/floccinaucinih/t30;->d()Lntidisestablish/neumonoul/floccinaucinih/sb;

    move-result-object v4

    invoke-static {v3, v1, v4, p0}, Lntidisestablish/neumonoul/floccinaucinih/u80;->b(Lntidisestablish/neumonoul/floccinaucinih/t80;Lntidisestablish/neumonoul/floccinaucinih/z90;Lntidisestablish/neumonoul/floccinaucinih/sb;Lntidisestablish/neumonoul/floccinaucinih/ps;)Lntidisestablish/neumonoul/floccinaucinih/zl;

    move-result-object v1

    iget-object v3, p0, Lntidisestablish/neumonoul/floccinaucinih/bj;->c:Ljava/util/Map;

    invoke-interface {v3, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3

    :catchall_0
    move-exception v0

    goto :goto_4

    :cond_a
    monitor-exit p1

    return-void

    :goto_4
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method
