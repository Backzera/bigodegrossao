.class public final Lntidisestablish/neumonoul/floccinaucinih/ah$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/ah$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/ah;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field private final a:[Lntidisestablish/neumonoul/floccinaucinih/ah$d;


# direct methods
.method public constructor <init>([Lntidisestablish/neumonoul/floccinaucinih/ah$d;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$c;->a:[Lntidisestablish/neumonoul/floccinaucinih/ah$d;

    return-void
.end method


# virtual methods
.method public a()[Lntidisestablish/neumonoul/floccinaucinih/ah$d;
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$c;->a:[Lntidisestablish/neumonoul/floccinaucinih/ah$d;

    return-object v0
.end method
