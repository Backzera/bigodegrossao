.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/bz;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method

.method public abstract d()Z
.end method

.method public varargs abstract e([Lntidisestablish/neumonoul/floccinaucinih/z90;)V
.end method
