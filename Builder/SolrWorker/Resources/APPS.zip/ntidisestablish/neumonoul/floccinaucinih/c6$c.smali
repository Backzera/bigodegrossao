.class final Lntidisestablish/neumonoul/floccinaucinih/c6$c;
.super Lntidisestablish/neumonoul/floccinaucinih/hb;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/c6;->p0(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field synthetic h:Ljava/lang/Object;

.field final synthetic i:Lntidisestablish/neumonoul/floccinaucinih/c6;

.field j:I


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/gb;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->i:Lntidisestablish/neumonoul/floccinaucinih/c6;

    invoke-direct {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/hb;-><init>(Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->h:Ljava/lang/Object;

    iget p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->j:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->j:I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->i:Lntidisestablish/neumonoul/floccinaucinih/c6;

    invoke-static {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->p0(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v0

    if-ne p1, v0, :cond_0

    return-object p1

    :cond_0
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/u7;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/u7;

    move-result-object p1

    return-object p1
.end method
