.class public final synthetic Lntidisestablish/neumonoul/floccinaucinih/b90;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic e:Lntidisestablish/neumonoul/floccinaucinih/c90;

.field public final synthetic f:Lntidisestablish/neumonoul/floccinaucinih/e00;


# direct methods
.method public synthetic constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/c90;Lntidisestablish/neumonoul/floccinaucinih/e00;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b90;->e:Lntidisestablish/neumonoul/floccinaucinih/c90;

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/b90;->f:Lntidisestablish/neumonoul/floccinaucinih/e00;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b90;->e:Lntidisestablish/neumonoul/floccinaucinih/c90;

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/b90;->f:Lntidisestablish/neumonoul/floccinaucinih/e00;

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c90;->a(Lntidisestablish/neumonoul/floccinaucinih/c90;Lntidisestablish/neumonoul/floccinaucinih/e00;)V

    return-void
.end method
