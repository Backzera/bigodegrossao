.class public Lntidisestablish/neumonoul/floccinaucinih/c90;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field static final k:Ljava/lang/String;


# instance fields
.field final e:Lntidisestablish/neumonoul/floccinaucinih/e00;

.field final f:Landroid/content/Context;

.field final g:Lntidisestablish/neumonoul/floccinaucinih/z90;

.field final h:Landroidx/work/c;

.field final i:Lntidisestablish/neumonoul/floccinaucinih/jh;

.field final j:Lntidisestablish/neumonoul/floccinaucinih/t30;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkForegroundRunnable"

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/xn;->i(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c90;->k:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lntidisestablish/neumonoul/floccinaucinih/z90;Landroidx/work/c;Lntidisestablish/neumonoul/floccinaucinih/jh;Lntidisestablish/neumonoul/floccinaucinih/t30;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/e00;->t()Lntidisestablish/neumonoul/floccinaucinih/e00;

    move-result-object v0

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->f:Landroid/content/Context;

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->g:Lntidisestablish/neumonoul/floccinaucinih/z90;

    iput-object p3, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->h:Landroidx/work/c;

    iput-object p4, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->i:Lntidisestablish/neumonoul/floccinaucinih/jh;

    iput-object p5, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->j:Lntidisestablish/neumonoul/floccinaucinih/t30;

    return-void
.end method

.method public static synthetic a(Lntidisestablish/neumonoul/floccinaucinih/c90;Lntidisestablish/neumonoul/floccinaucinih/e00;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c90;->c(Lntidisestablish/neumonoul/floccinaucinih/e00;)V

    return-void
.end method

.method private synthetic c(Lntidisestablish/neumonoul/floccinaucinih/e00;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/l;->isCancelled()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->h:Landroidx/work/c;

    invoke-virtual {v0}, Landroidx/work/c;->d()Lntidisestablish/neumonoul/floccinaucinih/ln;

    move-result-object v0

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/e00;->r(Lntidisestablish/neumonoul/floccinaucinih/ln;)Z

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/l;->cancel(Z)Z

    :goto_0
    return-void
.end method


# virtual methods
.method public b()Lntidisestablish/neumonoul/floccinaucinih/ln;
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    return-object v0
.end method

.method public run()V
    .locals 3

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->g:Lntidisestablish/neumonoul/floccinaucinih/z90;

    iget-boolean v0, v0, Lntidisestablish/neumonoul/floccinaucinih/z90;->q:Z

    if-eqz v0, :cond_1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    if-lt v0, v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/e00;->t()Lntidisestablish/neumonoul/floccinaucinih/e00;

    move-result-object v0

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->j:Lntidisestablish/neumonoul/floccinaucinih/t30;

    invoke-interface {v1}, Lntidisestablish/neumonoul/floccinaucinih/t30;->b()Ljava/util/concurrent/Executor;

    move-result-object v1

    new-instance v2, Lntidisestablish/neumonoul/floccinaucinih/b90;

    invoke-direct {v2, p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/b90;-><init>(Lntidisestablish/neumonoul/floccinaucinih/c90;Lntidisestablish/neumonoul/floccinaucinih/e00;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/c90$a;

    invoke-direct {v1, p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/c90$a;-><init>(Lntidisestablish/neumonoul/floccinaucinih/c90;Lntidisestablish/neumonoul/floccinaucinih/e00;)V

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->j:Lntidisestablish/neumonoul/floccinaucinih/t30;

    invoke-interface {v2}, Lntidisestablish/neumonoul/floccinaucinih/t30;->b()Ljava/util/concurrent/Executor;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/l;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void

    :cond_1
    :goto_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c90;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/e00;->p(Ljava/lang/Object;)Z

    return-void
.end method
