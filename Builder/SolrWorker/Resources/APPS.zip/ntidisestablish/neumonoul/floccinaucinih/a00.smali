.class public abstract Lntidisestablish/neumonoul/floccinaucinih/a00;
.super Lntidisestablish/neumonoul/floccinaucinih/d00;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Ljava/util/Set;)Ljava/util/Set;
    .locals 0

    .line 1
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/b00;->a(Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic b()Ljava/util/Set;
    .locals 1

    .line 1
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/b00;->b()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public static bridge synthetic c(Ljava/lang/Object;)Ljava/util/Set;
    .locals 0

    .line 1
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/b00;->c(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic d()Ljava/util/Set;
    .locals 1

    .line 1
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c00;->d()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public static bridge varargs synthetic e([Ljava/lang/Object;)Ljava/util/Set;
    .locals 0

    .line 1
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/c00;->e([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method
