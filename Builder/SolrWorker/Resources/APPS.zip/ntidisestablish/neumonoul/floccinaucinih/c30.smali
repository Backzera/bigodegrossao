.class public abstract Lntidisestablish/neumonoul/floccinaucinih/c30;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lntidisestablish/neumonoul/floccinaucinih/e90;I)Lntidisestablish/neumonoul/floccinaucinih/z20;
    .locals 2

    .line 1
    const-string v0, "generationalId"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/z20;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/e90;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/e90;->a()I

    move-result p0

    invoke-direct {v0, v1, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/z20;-><init>(Ljava/lang/String;II)V

    return-object v0
.end method
