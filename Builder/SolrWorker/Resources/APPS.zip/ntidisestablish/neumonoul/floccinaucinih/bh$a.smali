.class public Lntidisestablish/neumonoul/floccinaucinih/bh$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/bh;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final a:I

.field private final b:[Lntidisestablish/neumonoul/floccinaucinih/bh$b;


# direct methods
.method public constructor <init>(I[Lntidisestablish/neumonoul/floccinaucinih/bh$b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bh$a;->a:I

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/bh$a;->b:[Lntidisestablish/neumonoul/floccinaucinih/bh$b;

    return-void
.end method

.method static a(I[Lntidisestablish/neumonoul/floccinaucinih/bh$b;)Lntidisestablish/neumonoul/floccinaucinih/bh$a;
    .locals 1

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/bh$a;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/bh$a;-><init>(I[Lntidisestablish/neumonoul/floccinaucinih/bh$b;)V

    return-object v0
.end method


# virtual methods
.method public b()[Lntidisestablish/neumonoul/floccinaucinih/bh$b;
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bh$a;->b:[Lntidisestablish/neumonoul/floccinaucinih/bh$b;

    return-object v0
.end method

.method public c()I
    .locals 1

    .line 1
    iget v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bh$a;->a:I

    return v0
.end method
