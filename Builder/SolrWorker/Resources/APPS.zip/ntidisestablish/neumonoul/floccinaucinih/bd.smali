.class public final Lntidisestablish/neumonoul/floccinaucinih/bd;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/s00;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/bd$a;
    }
.end annotation


# instance fields
.field private final a:Lntidisestablish/neumonoul/floccinaucinih/bd$a;

.field private b:Lntidisestablish/neumonoul/floccinaucinih/s00;


# direct methods
.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/bd$a;)V
    .locals 1

    .line 1
    const-string v0, "socketAdapterFactory"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bd;->a:Lntidisestablish/neumonoul/floccinaucinih/bd$a;

    return-void
.end method

.method private final declared-synchronized e(Ljavax/net/ssl/SSLSocket;)Lntidisestablish/neumonoul/floccinaucinih/s00;
    .locals 1

    .line 1
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bd;->b:Lntidisestablish/neumonoul/floccinaucinih/s00;

    if-nez v0, :cond_0

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bd;->a:Lntidisestablish/neumonoul/floccinaucinih/bd$a;

    invoke-interface {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/bd$a;->a(Ljavax/net/ssl/SSLSocket;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bd;->a:Lntidisestablish/neumonoul/floccinaucinih/bd$a;

    invoke-interface {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/bd$a;->b(Ljavax/net/ssl/SSLSocket;)Lntidisestablish/neumonoul/floccinaucinih/s00;

    move-result-object p1

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bd;->b:Lntidisestablish/neumonoul/floccinaucinih/s00;

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bd;->b:Lntidisestablish/neumonoul/floccinaucinih/s00;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :goto_1
    monitor-exit p0

    throw p1
.end method


# virtual methods
.method public a(Ljavax/net/ssl/SSLSocket;)Z
    .locals 1

    .line 1
    const-string v0, "sslSocket"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bd;->a:Lntidisestablish/neumonoul/floccinaucinih/bd$a;

    invoke-interface {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/bd$a;->a(Ljavax/net/ssl/SSLSocket;)Z

    move-result p1

    return p1
.end method

.method public b(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "sslSocket"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/bd;->e(Ljavax/net/ssl/SSLSocket;)Lntidisestablish/neumonoul/floccinaucinih/s00;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/s00;->b(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return-object p1
.end method

.method public c()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    return v0
.end method

.method public d(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V
    .locals 1

    .line 1
    const-string v0, "sslSocket"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "protocols"

    invoke-static {p3, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/bd;->e(Ljavax/net/ssl/SSLSocket;)Lntidisestablish/neumonoul/floccinaucinih/s00;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/s00;->d(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V

    :cond_0
    return-void
.end method
