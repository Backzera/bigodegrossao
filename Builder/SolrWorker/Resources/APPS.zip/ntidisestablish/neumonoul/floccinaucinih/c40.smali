.class public abstract Lntidisestablish/neumonoul/floccinaucinih/c40;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static a:Z


# direct methods
.method public static a()Z
    .locals 1

    .line 1
    sget-boolean v0, Lntidisestablish/neumonoul/floccinaucinih/c40;->a:Z

    return v0
.end method
