.class Lntidisestablish/neumonoul/floccinaucinih/b30$a;
.super Lntidisestablish/neumonoul/floccinaucinih/ff;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/b30;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Lntidisestablish/neumonoul/floccinaucinih/b30;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/b30;Lntidisestablish/neumonoul/floccinaucinih/ny;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30$a;->d:Lntidisestablish/neumonoul/floccinaucinih/b30;

    invoke-direct {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/ff;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    return-void
.end method


# virtual methods
.method public e()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "INSERT OR REPLACE INTO `SystemIdInfo` (`work_spec_id`,`generation`,`system_id`) VALUES (?,?,?)"

    return-object v0
.end method

.method public bridge synthetic i(Lntidisestablish/neumonoul/floccinaucinih/t20;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Lntidisestablish/neumonoul/floccinaucinih/z20;

    invoke-virtual {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/b30$a;->k(Lntidisestablish/neumonoul/floccinaucinih/t20;Lntidisestablish/neumonoul/floccinaucinih/z20;)V

    return-void
.end method

.method public k(Lntidisestablish/neumonoul/floccinaucinih/t20;Lntidisestablish/neumonoul/floccinaucinih/z20;)V
    .locals 3

    .line 1
    iget-object v0, p2, Lntidisestablish/neumonoul/floccinaucinih/z20;->a:Ljava/lang/String;

    const/4 v1, 0x1

    if-nez v0, :cond_0

    invoke-interface {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {p1, v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/z20;->a()I

    move-result v0

    int-to-long v0, v0

    const/4 v2, 0x2

    invoke-interface {p1, v2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->C(IJ)V

    iget p2, p2, Lntidisestablish/neumonoul/floccinaucinih/z20;->c:I

    int-to-long v0, p2

    const/4 p2, 0x3

    invoke-interface {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->C(IJ)V

    return-void
.end method
