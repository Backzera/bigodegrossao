.class public final Lntidisestablish/neumonoul/floccinaucinih/an;
.super Lntidisestablish/neumonoul/floccinaucinih/sb;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/dd;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/an$a;
    }
.end annotation


# static fields
.field private static final l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;


# instance fields
.field private final g:Lntidisestablish/neumonoul/floccinaucinih/sb;

.field private final h:I

.field private final synthetic i:Lntidisestablish/neumonoul/floccinaucinih/dd;

.field private final j:Lntidisestablish/neumonoul/floccinaucinih/vn;

.field private final k:Ljava/lang/Object;

.field private volatile runningWorkers:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-class v0, Lntidisestablish/neumonoul/floccinaucinih/an;

    const-string v1, "runningWorkers"

    invoke-static {v0, v1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/an;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    return-void
.end method

.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/sb;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/sb;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->g:Lntidisestablish/neumonoul/floccinaucinih/sb;

    iput p2, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->h:I

    instance-of p2, p1, Lntidisestablish/neumonoul/floccinaucinih/dd;

    if-eqz p2, :cond_0

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/dd;

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    if-nez p1, :cond_1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/vc;->a()Lntidisestablish/neumonoul/floccinaucinih/dd;

    move-result-object p1

    :cond_1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->i:Lntidisestablish/neumonoul/floccinaucinih/dd;

    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/vn;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/vn;-><init>(Z)V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->j:Lntidisestablish/neumonoul/floccinaucinih/vn;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->k:Ljava/lang/Object;

    return-void
.end method

.method public static final synthetic w0(Lntidisestablish/neumonoul/floccinaucinih/an;)Lntidisestablish/neumonoul/floccinaucinih/sb;
    .locals 0

    .line 1
    iget-object p0, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->g:Lntidisestablish/neumonoul/floccinaucinih/sb;

    return-object p0
.end method

.method public static final synthetic x0(Lntidisestablish/neumonoul/floccinaucinih/an;)Ljava/lang/Runnable;
    .locals 0

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/an;->y0()Ljava/lang/Runnable;

    move-result-object p0

    return-object p0
.end method

.method private final y0()Ljava/lang/Runnable;
    .locals 3

    .line 1
    :goto_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->j:Lntidisestablish/neumonoul/floccinaucinih/vn;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/vn;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Runnable;

    if-nez v0, :cond_1

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->k:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/an;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->j:Lntidisestablish/neumonoul/floccinaucinih/vn;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/vn;->c()I

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_0

    monitor-exit v0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    :try_start_1
    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->incrementAndGet(Ljava/lang/Object;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v0

    goto :goto_0

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1

    :cond_1
    return-object v0
.end method

.method private final z0()Z
    .locals 4

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->k:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/an;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->get(Ljava/lang/Object;)I

    move-result v2

    iget v3, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->h:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-lt v2, v3, :cond_0

    monitor-exit v0

    const/4 v0, 0x0

    return v0

    :cond_0
    :try_start_1
    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->incrementAndGet(Ljava/lang/Object;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v0

    const/4 v0, 0x1

    return v0

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method


# virtual methods
.method public s0(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->j:Lntidisestablish/neumonoul/floccinaucinih/vn;

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/vn;->a(Ljava/lang/Object;)Z

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/an;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->get(Ljava/lang/Object;)I

    move-result p1

    iget p2, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->h:I

    if-ge p1, p2, :cond_1

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/an;->z0()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/an;->y0()Ljava/lang/Runnable;

    move-result-object p1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p2, Lntidisestablish/neumonoul/floccinaucinih/an$a;

    invoke-direct {p2, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/an$a;-><init>(Lntidisestablish/neumonoul/floccinaucinih/an;Ljava/lang/Runnable;)V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->g:Lntidisestablish/neumonoul/floccinaucinih/sb;

    invoke-virtual {p1, p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/sb;->s0(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Runnable;)V

    :cond_1
    :goto_0
    return-void
.end method

.method public t0(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->j:Lntidisestablish/neumonoul/floccinaucinih/vn;

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/vn;->a(Ljava/lang/Object;)Z

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/an;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->get(Ljava/lang/Object;)I

    move-result p1

    iget p2, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->h:I

    if-ge p1, p2, :cond_1

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/an;->z0()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/an;->y0()Ljava/lang/Runnable;

    move-result-object p1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p2, Lntidisestablish/neumonoul/floccinaucinih/an$a;

    invoke-direct {p2, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/an$a;-><init>(Lntidisestablish/neumonoul/floccinaucinih/an;Ljava/lang/Runnable;)V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/an;->g:Lntidisestablish/neumonoul/floccinaucinih/sb;

    invoke-virtual {p1, p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/sb;->t0(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Runnable;)V

    :cond_1
    :goto_0
    return-void
.end method
