.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/a30;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/a30$a;
    }
.end annotation


# direct methods
.method public static synthetic a(Lntidisestablish/neumonoul/floccinaucinih/a30;Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/z20;
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a30;->c(Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/z20;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic b(Lntidisestablish/neumonoul/floccinaucinih/a30;Lntidisestablish/neumonoul/floccinaucinih/e90;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a30;->h(Lntidisestablish/neumonoul/floccinaucinih/e90;)V

    return-void
.end method


# virtual methods
.method public c(Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/z20;
    .locals 1

    .line 1
    const-string v0, "id"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/e90;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/e90;->a()I

    move-result p1

    invoke-interface {p0, v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a30;->g(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/z20;

    move-result-object p1

    return-object p1
.end method

.method public abstract d(Ljava/lang/String;I)V
.end method

.method public abstract e()Ljava/util/List;
.end method

.method public abstract f(Ljava/lang/String;)V
.end method

.method public abstract g(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/z20;
.end method

.method public h(Lntidisestablish/neumonoul/floccinaucinih/e90;)V
    .locals 1

    .line 1
    const-string v0, "id"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/e90;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/e90;->a()I

    move-result p1

    invoke-interface {p0, v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a30;->d(Ljava/lang/String;I)V

    return-void
.end method

.method public abstract i(Lntidisestablish/neumonoul/floccinaucinih/z20;)V
.end method
