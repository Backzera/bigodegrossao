.class public final Lntidisestablish/neumonoul/floccinaucinih/ba;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/il;


# static fields
.field public static final a:Lntidisestablish/neumonoul/floccinaucinih/ba;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/ba;-><init>()V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/ba;->a:Lntidisestablish/neumonoul/floccinaucinih/ba;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/il$a;)Lntidisestablish/neumonoul/floccinaucinih/dy;
    .locals 10

    .line 1
    const-string v0, "chain"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/xw;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/xw;->e()Lntidisestablish/neumonoul/floccinaucinih/uw;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/uw;->s(Lntidisestablish/neumonoul/floccinaucinih/xw;)Lntidisestablish/neumonoul/floccinaucinih/tf;

    move-result-object v3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/16 v8, 0x3d

    const/4 v9, 0x0

    move-object v1, p1

    invoke-static/range {v1 .. v9}, Lntidisestablish/neumonoul/floccinaucinih/xw;->d(Lntidisestablish/neumonoul/floccinaucinih/xw;ILntidisestablish/neumonoul/floccinaucinih/tf;Lntidisestablish/neumonoul/floccinaucinih/kx;IIIILjava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/xw;

    move-result-object v0

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/xw;->i()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object p1

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/xw;->b(Lntidisestablish/neumonoul/floccinaucinih/kx;)Lntidisestablish/neumonoul/floccinaucinih/dy;

    move-result-object p1

    return-object p1
.end method
