.class public final Lntidisestablish/neumonoul/floccinaucinih/a7;
.super Lntidisestablish/neumonoul/floccinaucinih/d40;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/a7$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/graphics/Typeface;

.field private final b:Lntidisestablish/neumonoul/floccinaucinih/a7$a;

.field private c:Z


# direct methods
.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/a7$a;Landroid/graphics/Typeface;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/d40;-><init>()V

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/a7;->a:Landroid/graphics/Typeface;

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/a7;->b:Lntidisestablish/neumonoul/floccinaucinih/a7$a;

    return-void
.end method

.method private d(Landroid/graphics/Typeface;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lntidisestablish/neumonoul/floccinaucinih/a7;->c:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/a7;->b:Lntidisestablish/neumonoul/floccinaucinih/a7$a;

    invoke-interface {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a7$a;->a(Landroid/graphics/Typeface;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    .line 1
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/a7;->a:Landroid/graphics/Typeface;

    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a7;->d(Landroid/graphics/Typeface;)V

    return-void
.end method

.method public b(Landroid/graphics/Typeface;Z)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a7;->d(Landroid/graphics/Typeface;)V

    return-void
.end method

.method public c()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput-boolean v0, p0, Lntidisestablish/neumonoul/floccinaucinih/a7;->c:Z

    return-void
.end method
