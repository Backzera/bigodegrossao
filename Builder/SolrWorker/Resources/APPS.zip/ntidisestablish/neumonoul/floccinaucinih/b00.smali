.class abstract Lntidisestablish/neumonoul/floccinaucinih/b00;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/util/Set;)Ljava/util/Set;
    .locals 1

    .line 1
    const-string v0, "builder"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Lntidisestablish/neumonoul/floccinaucinih/zz;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/zz;->b()Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public static b()Ljava/util/Set;
    .locals 1

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/zz;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/zz;-><init>()V

    return-object v0
.end method

.method public static c(Ljava/lang/Object;)Ljava/util/Set;
    .locals 1

    .line 1
    invoke-static {p0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    const-string v0, "singleton(element)"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method
