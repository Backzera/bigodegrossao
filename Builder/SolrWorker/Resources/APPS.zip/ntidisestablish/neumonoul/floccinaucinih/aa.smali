.class public Lntidisestablish/neumonoul/floccinaucinih/aa;
.super Lntidisestablish/neumonoul/floccinaucinih/c6;
.source "SourceFile"


# instance fields
.field private final q:I

.field private final r:Lntidisestablish/neumonoul/floccinaucinih/b6;


# direct methods
.method public constructor <init>(ILntidisestablish/neumonoul/floccinaucinih/b6;Lntidisestablish/neumonoul/floccinaucinih/zh;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p3}, Lntidisestablish/neumonoul/floccinaucinih/c6;-><init>(ILntidisestablish/neumonoul/floccinaucinih/zh;)V

    iput p1, p0, Lntidisestablish/neumonoul/floccinaucinih/aa;->q:I

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/aa;->r:Lntidisestablish/neumonoul/floccinaucinih/b6;

    sget-object p3, Lntidisestablish/neumonoul/floccinaucinih/b6;->e:Lntidisestablish/neumonoul/floccinaucinih/b6;

    if-eq p2, p3, :cond_1

    const/4 p2, 0x1

    if-lt p1, p2, :cond_0

    return-void

    :cond_0
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Buffered channel capacity must be at least 1, but "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " was specified"

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "This implementation does not support suspension for senders, use "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-class p2, Lntidisestablish/neumonoul/floccinaucinih/c6;

    invoke-static {p2}, Lntidisestablish/neumonoul/floccinaucinih/fx;->b(Ljava/lang/Class;)Lntidisestablish/neumonoul/floccinaucinih/mm;

    move-result-object p2

    invoke-interface {p2}, Lntidisestablish/neumonoul/floccinaucinih/mm;->a()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, " instead"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method static synthetic J0(Lntidisestablish/neumonoul/floccinaucinih/aa;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 2

    .line 1
    const/4 p2, 0x1

    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/aa;->M0(Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p2

    instance-of v0, p2, Lntidisestablish/neumonoul/floccinaucinih/u7$a;

    if-eqz v0, :cond_1

    invoke-static {p2}, Lntidisestablish/neumonoul/floccinaucinih/u7;->e(Ljava/lang/Object;)Ljava/lang/Throwable;

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz p2, :cond_0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p2, p1, v1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/rs;->d(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/h60;ILjava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/h60;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object p0

    invoke-static {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/rf;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    throw p1

    :cond_0
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object p0

    throw p0

    :cond_1
    sget-object p0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    return-object p0
.end method

.method private final K0(Ljava/lang/Object;Z)Ljava/lang/Object;
    .locals 2

    .line 1
    invoke-super {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/u7;->i(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/u7;->h(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    if-eqz p2, :cond_2

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz p2, :cond_2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p2, p1, v1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/rs;->d(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/h60;ILjava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/h60;

    move-result-object p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    throw p1

    :cond_2
    :goto_0
    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    sget-object p2, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :cond_3
    :goto_1
    return-object v0
.end method

.method private final L0(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v8, p0

    sget-object v9, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->m()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :cond_0
    :goto_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->n()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v1

    invoke-virtual {v1, v8}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    move-result-wide v1

    const-wide v3, 0xfffffffffffffffL

    and-long v10, v1, v3

    invoke-static {v8, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->o(Lntidisestablish/neumonoul/floccinaucinih/c6;J)Z

    move-result v12

    sget v13, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v1, v13

    div-long v1, v10, v1

    int-to-long v3, v13

    rem-long v3, v10, v3

    long-to-int v14, v3

    iget-wide v3, v0, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v3, v3, v1

    if-eqz v3, :cond_2

    invoke-static {v8, v1, v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->e(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v1

    if-nez v1, :cond_1

    if-eqz v12, :cond_0

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual/range {p0 .. p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_1
    move-object v15, v1

    goto :goto_1

    :cond_2
    move-object v15, v0

    :goto_1
    move-object/from16 v0, p0

    move-object v1, v15

    move v2, v14

    move-object/from16 v3, p1

    move-wide v4, v10

    move-object v6, v9

    move v7, v12

    invoke-static/range {v0 .. v7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->x(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I

    move-result v0

    if-eqz v0, :cond_c

    const/4 v1, 0x1

    if-eq v0, v1, :cond_b

    const/4 v1, 0x2

    if-eq v0, v1, :cond_7

    const/4 v1, 0x3

    if-eq v0, v1, :cond_6

    const/4 v1, 0x4

    if-eq v0, v1, :cond_4

    const/4 v1, 0x5

    if-eq v0, v1, :cond_3

    goto :goto_2

    :cond_3
    invoke-virtual {v15}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :goto_2
    move-object v0, v15

    goto :goto_0

    :cond_4
    invoke-virtual/range {p0 .. p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v0

    cmp-long v0, v10, v0

    if-gez v0, :cond_5

    invoke-virtual {v15}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :cond_5
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual/range {p0 .. p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_6
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "unexpected"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7
    if-eqz v12, :cond_8

    invoke-virtual {v15}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual/range {p0 .. p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_8
    instance-of v0, v9, Lntidisestablish/neumonoul/floccinaucinih/i70;

    if-eqz v0, :cond_9

    check-cast v9, Lntidisestablish/neumonoul/floccinaucinih/i70;

    goto :goto_3

    :cond_9
    const/4 v9, 0x0

    :goto_3
    if-eqz v9, :cond_a

    invoke-static {v8, v9, v15, v14}, Lntidisestablish/neumonoul/floccinaucinih/c6;->u(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    :cond_a
    iget-wide v0, v15, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    int-to-long v2, v13

    mul-long/2addr v0, v2

    int-to-long v2, v14

    add-long/2addr v0, v2

    invoke-virtual {v8, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->G(J)V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_b
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_c
    invoke-virtual {v15}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method private final M0(Ljava/lang/Object;Z)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/aa;->r:Lntidisestablish/neumonoul/floccinaucinih/b6;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/b6;->g:Lntidisestablish/neumonoul/floccinaucinih/b6;

    if-ne v0, v1, :cond_0

    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/aa;->K0(Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    goto :goto_0

    :cond_0
    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/aa;->L0(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    :goto_0
    return-object p1
.end method


# virtual methods
.method protected a0()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/aa;->r:Lntidisestablish/neumonoul/floccinaucinih/b6;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/b6;->f:Lntidisestablish/neumonoul/floccinaucinih/b6;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public c(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/aa;->J0(Lntidisestablish/neumonoul/floccinaucinih/aa;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public l(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/aa;->M0(Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
