.class abstract Lntidisestablish/neumonoul/floccinaucinih/az$d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;
.implements Lntidisestablish/neumonoul/floccinaucinih/az$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/az;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x40a
    name = "d"
.end annotation


# instance fields
.field a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

.field b:Lntidisestablish/neumonoul/floccinaucinih/az$b;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/az$b;Lntidisestablish/neumonoul/floccinaucinih/az$b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    return-void
.end method

.method private e()Lntidisestablish/neumonoul/floccinaucinih/az$b;
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-eq v0, v1, :cond_1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/az$d;->c(Lntidisestablish/neumonoul/floccinaucinih/az$b;)Lntidisestablish/neumonoul/floccinaucinih/az$b;

    move-result-object v0

    return-object v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return-object v0
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/az$b;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-ne v0, p1, :cond_0

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-ne p1, v0, :cond_0

    const/4 v0, 0x0

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    :cond_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-ne v0, p1, :cond_1

    invoke-virtual {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b(Lntidisestablish/neumonoul/floccinaucinih/az$b;)Lntidisestablish/neumonoul/floccinaucinih/az$b;

    move-result-object v0

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->a:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    :cond_1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-ne v0, p1, :cond_2

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/az$d;->e()Lntidisestablish/neumonoul/floccinaucinih/az$b;

    move-result-object p1

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    :cond_2
    return-void
.end method

.method abstract b(Lntidisestablish/neumonoul/floccinaucinih/az$b;)Lntidisestablish/neumonoul/floccinaucinih/az$b;
.end method

.method abstract c(Lntidisestablish/neumonoul/floccinaucinih/az$b;)Lntidisestablish/neumonoul/floccinaucinih/az$b;
.end method

.method public d()Ljava/util/Map$Entry;
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/az$d;->e()Lntidisestablish/neumonoul/floccinaucinih/az$b;

    move-result-object v1

    iput-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    return-object v0
.end method

.method public hasNext()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/az$d;->b:Lntidisestablish/neumonoul/floccinaucinih/az$b;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/az$d;->d()Ljava/util/Map$Entry;

    move-result-object v0

    return-object v0
.end method
