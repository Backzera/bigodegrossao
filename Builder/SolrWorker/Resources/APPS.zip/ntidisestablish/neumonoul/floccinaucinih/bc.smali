.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/bc;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract g()Lntidisestablish/neumonoul/floccinaucinih/bc;
.end method
