.class public abstract Lntidisestablish/neumonoul/floccinaucinih/be;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lntidisestablish/neumonoul/floccinaucinih/ae;I)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ae;->c()Lntidisestablish/neumonoul/floccinaucinih/gb;

    move-result-object v0

    const/4 v1, 0x4

    if-ne p1, v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    if-nez v1, :cond_2

    instance-of v2, v0, Lntidisestablish/neumonoul/floccinaucinih/yd;

    if-eqz v2, :cond_2

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/be;->b(I)Z

    move-result p1

    iget v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ae;->g:I

    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/be;->b(I)Z

    move-result v2

    if-ne p1, v2, :cond_2

    move-object p1, v0

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/yd;

    iget-object p1, p1, Lntidisestablish/neumonoul/floccinaucinih/yd;->h:Lntidisestablish/neumonoul/floccinaucinih/sb;

    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/gb;->i()Lntidisestablish/neumonoul/floccinaucinih/pb;

    move-result-object v0

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/sb;->u0(Lntidisestablish/neumonoul/floccinaucinih/pb;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p1, v0, p0}, Lntidisestablish/neumonoul/floccinaucinih/sb;->s0(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Runnable;)V

    goto :goto_1

    :cond_1
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/be;->e(Lntidisestablish/neumonoul/floccinaucinih/ae;)V

    goto :goto_1

    :cond_2
    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/be;->d(Lntidisestablish/neumonoul/floccinaucinih/ae;Lntidisestablish/neumonoul/floccinaucinih/gb;Z)V

    :goto_1
    return-void
.end method

.method public static final b(I)Z
    .locals 2

    .line 1
    const/4 v0, 0x1

    if-eq p0, v0, :cond_1

    const/4 v1, 0x2

    if-ne p0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :cond_1
    :goto_0
    return v0
.end method

.method public static final c(I)Z
    .locals 1

    .line 1
    const/4 v0, 0x2

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static final d(Lntidisestablish/neumonoul/floccinaucinih/ae;Lntidisestablish/neumonoul/floccinaucinih/gb;Z)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ae;->h()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/ae;->d(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v1

    if-eqz v1, :cond_0

    sget-object p0, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/hy;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    :goto_0
    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_1

    :cond_0
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    invoke-virtual {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/ae;->e(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_0

    :goto_1
    if-eqz p2, :cond_2

    const-string p2, "null cannot be cast to non-null type kotlinx.coroutines.internal.DispatchedContinuation<T of kotlinx.coroutines.DispatchedTaskKt.resume>"

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/yd;

    iget-object p2, p1, Lntidisestablish/neumonoul/floccinaucinih/yd;->i:Lntidisestablish/neumonoul/floccinaucinih/gb;

    iget-object v0, p1, Lntidisestablish/neumonoul/floccinaucinih/yd;->k:Ljava/lang/Object;

    invoke-interface {p2}, Lntidisestablish/neumonoul/floccinaucinih/gb;->i()Lntidisestablish/neumonoul/floccinaucinih/pb;

    move-result-object v1

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/s40;->c(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/s40;->a:Lntidisestablish/neumonoul/floccinaucinih/v20;

    if-eq v0, v2, :cond_1

    invoke-static {p2, v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/qb;->f(Lntidisestablish/neumonoul/floccinaucinih/gb;Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/i60;

    :cond_1
    :try_start_0
    iget-object p1, p1, Lntidisestablish/neumonoul/floccinaucinih/yd;->i:Lntidisestablish/neumonoul/floccinaucinih/gb;

    invoke-interface {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/gb;->q(Ljava/lang/Object;)V

    sget-object p0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/s40;->a(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Object;)V

    goto :goto_2

    :catchall_0
    move-exception p0

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/s40;->a(Lntidisestablish/neumonoul/floccinaucinih/pb;Ljava/lang/Object;)V

    throw p0

    :cond_2
    invoke-interface {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/gb;->q(Ljava/lang/Object;)V

    :goto_2
    return-void
.end method

.method private static final e(Lntidisestablish/neumonoul/floccinaucinih/ae;)V
    .locals 4

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/t40;->a:Lntidisestablish/neumonoul/floccinaucinih/t40;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/t40;->a()Lntidisestablish/neumonoul/floccinaucinih/lf;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/lf;->C0()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0, p0}, Lntidisestablish/neumonoul/floccinaucinih/lf;->y0(Lntidisestablish/neumonoul/floccinaucinih/ae;)V

    goto :goto_1

    :cond_0
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/lf;->A0(Z)V

    :try_start_0
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ae;->c()Lntidisestablish/neumonoul/floccinaucinih/gb;

    move-result-object v2

    invoke-static {p0, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/be;->d(Lntidisestablish/neumonoul/floccinaucinih/ae;Lntidisestablish/neumonoul/floccinaucinih/gb;Z)V

    :cond_1
    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/lf;->E0()Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_1

    :goto_0
    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/lf;->w0(Z)V

    goto :goto_1

    :catchall_0
    move-exception v2

    const/4 v3, 0x0

    :try_start_1
    invoke-virtual {p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/ae;->f(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_0

    :goto_1
    return-void

    :catchall_1
    move-exception p0

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/lf;->w0(Z)V

    throw p0
.end method
