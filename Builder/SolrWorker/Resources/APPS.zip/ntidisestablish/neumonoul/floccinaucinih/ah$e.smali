.class public final Lntidisestablish/neumonoul/floccinaucinih/ah$e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/ah$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/ah;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# instance fields
.field private final a:Lntidisestablish/neumonoul/floccinaucinih/yg;

.field private final b:I

.field private final c:I

.field private final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/yg;IILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$e;->a:Lntidisestablish/neumonoul/floccinaucinih/yg;

    iput p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$e;->c:I

    iput p3, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$e;->b:I

    iput-object p4, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$e;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    .line 1
    iget v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$e;->c:I

    return v0
.end method

.method public b()Lntidisestablish/neumonoul/floccinaucinih/yg;
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$e;->a:Lntidisestablish/neumonoul/floccinaucinih/yg;

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$e;->d:Ljava/lang/String;

    return-object v0
.end method

.method public d()I
    .locals 1

    .line 1
    iget v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ah$e;->b:I

    return v0
.end method
