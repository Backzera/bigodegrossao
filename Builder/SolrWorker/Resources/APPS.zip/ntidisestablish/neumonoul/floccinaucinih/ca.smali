.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/ca;
.super Ljava/lang/Object;
.source "SourceFile"
