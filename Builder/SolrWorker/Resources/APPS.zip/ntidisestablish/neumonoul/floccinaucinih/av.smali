.class public final synthetic Lntidisestablish/neumonoul/floccinaucinih/av;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic e:Lcom/icontrol/protector/ProxyService;

.field public final synthetic f:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Lcom/icontrol/protector/ProxyService;Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/av;->e:Lcom/icontrol/protector/ProxyService;

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/av;->f:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/av;->e:Lcom/icontrol/protector/ProxyService;

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/av;->f:Landroid/content/Context;

    invoke-static {v0, v1}, Lcom/icontrol/protector/ProxyService;->a(Lcom/icontrol/protector/ProxyService;Landroid/content/Context;)V

    return-void
.end method
