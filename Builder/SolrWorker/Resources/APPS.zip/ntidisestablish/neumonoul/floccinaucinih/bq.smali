.class public final synthetic Lntidisestablish/neumonoul/floccinaucinih/bq;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic e:Lntidisestablish/neumonoul/floccinaucinih/dq;


# direct methods
.method public synthetic constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/dq;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bq;->e:Lntidisestablish/neumonoul/floccinaucinih/dq;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/bq;->e:Lntidisestablish/neumonoul/floccinaucinih/dq;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/dq;->a(Lntidisestablish/neumonoul/floccinaucinih/dq;)V

    return-void
.end method
