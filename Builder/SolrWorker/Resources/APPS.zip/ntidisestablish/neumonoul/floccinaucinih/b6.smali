.class public final enum Lntidisestablish/neumonoul/floccinaucinih/b6;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum e:Lntidisestablish/neumonoul/floccinaucinih/b6;

.field public static final enum f:Lntidisestablish/neumonoul/floccinaucinih/b6;

.field public static final enum g:Lntidisestablish/neumonoul/floccinaucinih/b6;

.field private static final synthetic h:[Lntidisestablish/neumonoul/floccinaucinih/b6;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/b6;

    const-string v1, "SUSPEND"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/b6;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/b6;->e:Lntidisestablish/neumonoul/floccinaucinih/b6;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/b6;

    const-string v1, "DROP_OLDEST"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/b6;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/b6;->f:Lntidisestablish/neumonoul/floccinaucinih/b6;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/b6;

    const-string v1, "DROP_LATEST"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/b6;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/b6;->g:Lntidisestablish/neumonoul/floccinaucinih/b6;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/b6;->a()[Lntidisestablish/neumonoul/floccinaucinih/b6;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/b6;->h:[Lntidisestablish/neumonoul/floccinaucinih/b6;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static final synthetic a()[Lntidisestablish/neumonoul/floccinaucinih/b6;
    .locals 3

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/b6;->e:Lntidisestablish/neumonoul/floccinaucinih/b6;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/b6;->f:Lntidisestablish/neumonoul/floccinaucinih/b6;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/b6;->g:Lntidisestablish/neumonoul/floccinaucinih/b6;

    filled-new-array {v0, v1, v2}, [Lntidisestablish/neumonoul/floccinaucinih/b6;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/b6;
    .locals 1

    .line 1
    const-class v0, Lntidisestablish/neumonoul/floccinaucinih/b6;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lntidisestablish/neumonoul/floccinaucinih/b6;

    return-object p0
.end method

.method public static values()[Lntidisestablish/neumonoul/floccinaucinih/b6;
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/b6;->h:[Lntidisestablish/neumonoul/floccinaucinih/b6;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lntidisestablish/neumonoul/floccinaucinih/b6;

    return-object v0
.end method
