.class public final Lntidisestablish/neumonoul/floccinaucinih/b30;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/a30;


# instance fields
.field private final a:Lntidisestablish/neumonoul/floccinaucinih/ny;

.field private final b:Lntidisestablish/neumonoul/floccinaucinih/ff;

.field private final c:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final d:Lntidisestablish/neumonoul/floccinaucinih/m00;


# direct methods
.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/b30$a;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/b30$a;-><init>(Lntidisestablish/neumonoul/floccinaucinih/b30;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->b:Lntidisestablish/neumonoul/floccinaucinih/ff;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/b30$b;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/b30$b;-><init>(Lntidisestablish/neumonoul/floccinaucinih/b30;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->c:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/b30$c;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/b30$c;-><init>(Lntidisestablish/neumonoul/floccinaucinih/b30;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->d:Lntidisestablish/neumonoul/floccinaucinih/m00;

    return-void
.end method

.method public static j()Ljava/util/List;
    .locals 1

    .line 1
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public c(Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/z20;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a30$a;->a(Lntidisestablish/neumonoul/floccinaucinih/a30;Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/z20;

    move-result-object p1

    return-object p1
.end method

.method public d(Ljava/lang/String;I)V
    .locals 3

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->c:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    if-nez p1, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    const/4 p1, 0x2

    int-to-long v1, p2

    invoke-interface {v0, p1, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->C(IJ)V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->c:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return-void

    :catchall_0
    move-exception p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->c:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public e()Ljava/util/List;
    .locals 6

    .line 1
    const-string v0, "SELECT DISTINCT work_spec_id FROM SystemIdInfo"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v0

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v3, 0x0

    invoke-static {v2, v0, v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v2

    :try_start_0
    new-instance v4, Ljava/util/ArrayList;

    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    :goto_0
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v2, v1}, Landroid/database/Cursor;->isNull(I)Z

    move-result v5

    if-eqz v5, :cond_0

    move-object v5, v3

    goto :goto_1

    :cond_0
    invoke-interface {v2, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    :goto_1
    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_2

    :cond_1
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v4

    :goto_2
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v1
.end method

.method public f(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->d:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    if-nez p1, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->d:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return-void

    :catchall_0
    move-exception p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->d:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public g(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/z20;
    .locals 5

    .line 1
    const-string v0, "SELECT * FROM SystemIdInfo WHERE work_spec_id=? AND generation=?"

    const/4 v1, 0x2

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v0

    const/4 v2, 0x1

    if-nez p1, :cond_0

    invoke-virtual {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/qy;->X(I)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v2, p1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->z(ILjava/lang/String;)V

    :goto_0
    int-to-long p1, p2

    invoke-virtual {v0, v1, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/qy;->C(IJ)V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 p2, 0x0

    const/4 v1, 0x0

    invoke-static {p1, v0, p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p1

    :try_start_0
    const-string p2, "work_spec_id"

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result p2

    const-string v2, "generation"

    invoke-static {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    const-string v3, "system_id"

    invoke-static {p1, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {p1, p2}, Landroid/database/Cursor;->isNull(I)Z

    move-result v4

    if-eqz v4, :cond_1

    goto :goto_1

    :cond_1
    invoke-interface {p1, p2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    :goto_1
    invoke-interface {p1, v2}, Landroid/database/Cursor;->getInt(I)I

    move-result p2

    invoke-interface {p1, v3}, Landroid/database/Cursor;->getInt(I)I

    move-result v2

    new-instance v3, Lntidisestablish/neumonoul/floccinaucinih/z20;

    invoke-direct {v3, v1, p2, v2}, Lntidisestablish/neumonoul/floccinaucinih/z20;-><init>(Ljava/lang/String;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v1, v3

    goto :goto_2

    :catchall_0
    move-exception p2

    goto :goto_3

    :cond_2
    :goto_2
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v1

    :goto_3
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw p2
.end method

.method public h(Lntidisestablish/neumonoul/floccinaucinih/e90;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a30$a;->b(Lntidisestablish/neumonoul/floccinaucinih/a30;Lntidisestablish/neumonoul/floccinaucinih/e90;)V

    return-void
.end method

.method public i(Lntidisestablish/neumonoul/floccinaucinih/z20;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->b:Lntidisestablish/neumonoul/floccinaucinih/ff;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ff;->j(Ljava/lang/Object;)V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    return-void

    :catchall_0
    move-exception p1

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b30;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    throw p1
.end method
