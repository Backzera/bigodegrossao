.class abstract Lntidisestablish/neumonoul/floccinaucinih/a9;
.super Lntidisestablish/neumonoul/floccinaucinih/z8;
.source "SourceFile"


# direct methods
.method public static r(Ljava/util/List;)V
    .locals 2

    .line 1
    const-string v0, "<this>"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x1

    if-le v0, v1, :cond_0

    invoke-static {p0}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    :cond_0
    return-void
.end method
