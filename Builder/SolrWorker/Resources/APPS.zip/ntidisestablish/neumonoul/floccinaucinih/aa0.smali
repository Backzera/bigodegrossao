.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/aa0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/String;)V
.end method

.method public abstract b(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/f90;
.end method

.method public abstract c(I)Ljava/util/List;
.end method

.method public abstract d(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/z90;
.end method

.method public abstract e(Ljava/lang/String;I)V
.end method

.method public abstract f(Ljava/lang/String;)I
.end method

.method public abstract g(Ljava/lang/String;J)V
.end method

.method public abstract h(Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;)I
.end method

.method public abstract i()Ljava/util/List;
.end method

.method public abstract j(Ljava/lang/String;)I
.end method

.method public abstract k(Ljava/lang/String;)Ljava/util/List;
.end method

.method public abstract l(Ljava/lang/String;)I
.end method

.method public abstract m(Ljava/lang/String;)V
.end method

.method public abstract n(Lntidisestablish/neumonoul/floccinaucinih/z90;)V
.end method

.method public abstract o()Z
.end method

.method public abstract p()I
.end method

.method public abstract q(Ljava/lang/String;J)I
.end method

.method public abstract r(Ljava/lang/String;I)V
.end method

.method public abstract s()Ljava/util/List;
.end method

.method public abstract t(I)Ljava/util/List;
.end method

.method public abstract u(Ljava/lang/String;Landroidx/work/b;)V
.end method

.method public abstract v(Ljava/lang/String;)Ljava/util/List;
.end method

.method public abstract w()I
.end method

.method public abstract x(Ljava/lang/String;)Ljava/util/List;
.end method

.method public abstract y()Ljava/util/List;
.end method

.method public abstract z(J)Ljava/util/List;
.end method
