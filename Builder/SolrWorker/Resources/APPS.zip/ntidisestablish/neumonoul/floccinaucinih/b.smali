.class public abstract Lntidisestablish/neumonoul/floccinaucinih/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:[B


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "0123456789abcdef"

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/pa0;->a(Ljava/lang/String;)[B

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/b;->a:[B

    return-void
.end method

.method public static final a(Lntidisestablish/neumonoul/floccinaucinih/a6;Lntidisestablish/neumonoul/floccinaucinih/a6$a;)Lntidisestablish/neumonoul/floccinaucinih/a6$a;
    .locals 1

    .line 1
    const-string v0, "<this>"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "unsafeCursor"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/e;->g(Lntidisestablish/neumonoul/floccinaucinih/a6$a;)Lntidisestablish/neumonoul/floccinaucinih/a6$a;

    move-result-object p1

    iget-object v0, p1, Lntidisestablish/neumonoul/floccinaucinih/a6$a;->e:Lntidisestablish/neumonoul/floccinaucinih/a6;

    if-nez v0, :cond_0

    iput-object p0, p1, Lntidisestablish/neumonoul/floccinaucinih/a6$a;->e:Lntidisestablish/neumonoul/floccinaucinih/a6;

    const/4 p0, 0x1

    iput-boolean p0, p1, Lntidisestablish/neumonoul/floccinaucinih/a6$a;->f:Z

    return-object p1

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "already attached to a buffer"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final b()[B
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/b;->a:[B

    return-object v0
.end method

.method public static final c(Lntidisestablish/neumonoul/floccinaucinih/a6;J)Ljava/lang/String;
    .locals 6

    .line 1
    const-string v0, "<this>"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    const-wide/16 v1, 0x1

    if-lez v0, :cond_0

    sub-long v3, p1, v1

    invoke-virtual {p0, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/a6;->F(J)B

    move-result v0

    const/16 v5, 0xd

    if-ne v0, v5, :cond_0

    invoke-virtual {p0, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/a6;->x0(J)Ljava/lang/String;

    move-result-object p1

    const-wide/16 v0, 0x2

    invoke-virtual {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/a6;->A(J)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/a6;->x0(J)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/a6;->A(J)V

    :goto_0
    return-object p1
.end method
