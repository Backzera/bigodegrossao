.class public abstract synthetic Lntidisestablish/neumonoul/floccinaucinih/af;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Lcom/icontrol/protector/EngineWorker;ILandroid/app/Notification;I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Landroid/app/IntentService;->startForeground(ILandroid/app/Notification;I)V

    return-void
.end method
