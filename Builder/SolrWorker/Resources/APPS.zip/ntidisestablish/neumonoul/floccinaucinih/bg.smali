.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/bg;
.super Ljava/lang/Object;
.source "SourceFile"
