.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/bi;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/ji;
