.class public final synthetic Lntidisestablish/neumonoul/floccinaucinih/ay;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic e:Lntidisestablish/neumonoul/floccinaucinih/yx$b;

.field public final synthetic f:I


# direct methods
.method public synthetic constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/yx$b;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ay;->e:Lntidisestablish/neumonoul/floccinaucinih/yx$b;

    iput p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ay;->f:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ay;->e:Lntidisestablish/neumonoul/floccinaucinih/yx$b;

    iget v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ay;->f:I

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/yx$b;->a(Lntidisestablish/neumonoul/floccinaucinih/yx$b;I)V

    return-void
.end method
