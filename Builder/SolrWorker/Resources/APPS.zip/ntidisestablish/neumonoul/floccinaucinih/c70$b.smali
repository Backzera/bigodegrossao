.class Lntidisestablish/neumonoul/floccinaucinih/c70$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/c70;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lntidisestablish/neumonoul/floccinaucinih/c70;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/c70;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c70$b;->e:Lntidisestablish/neumonoul/floccinaucinih/c70;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c70$b;->e:Lntidisestablish/neumonoul/floccinaucinih/c70;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c70;->E(I)V

    return-void
.end method
