.class Lntidisestablish/neumonoul/floccinaucinih/bj$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/bj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# instance fields
.field final a:I

.field final b:J


# direct methods
.method private constructor <init>(IJ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lntidisestablish/neumonoul/floccinaucinih/bj$b;->a:I

    iput-wide p2, p0, Lntidisestablish/neumonoul/floccinaucinih/bj$b;->b:J

    return-void
.end method

.method synthetic constructor <init>(IJLntidisestablish/neumonoul/floccinaucinih/bj$a;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/bj$b;-><init>(IJ)V

    return-void
.end method
