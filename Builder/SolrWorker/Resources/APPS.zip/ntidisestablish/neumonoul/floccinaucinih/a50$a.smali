.class public final Lntidisestablish/neumonoul/floccinaucinih/a50$a;
.super Lntidisestablish/neumonoul/floccinaucinih/a50;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/a50;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/a50;-><init>()V

    return-void
.end method


# virtual methods
.method public d(J)Lntidisestablish/neumonoul/floccinaucinih/a50;
    .locals 0

    .line 1
    return-object p0
.end method

.method public f()V
    .locals 0

    .line 1
    return-void
.end method

.method public g(JLjava/util/concurrent/TimeUnit;)Lntidisestablish/neumonoul/floccinaucinih/a50;
    .locals 0

    .line 1
    const-string p1, "unit"

    invoke-static {p3, p1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method
