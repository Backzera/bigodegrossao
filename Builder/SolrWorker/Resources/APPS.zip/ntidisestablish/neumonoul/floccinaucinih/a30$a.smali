.class public abstract Lntidisestablish/neumonoul/floccinaucinih/a30$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/a30;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Lntidisestablish/neumonoul/floccinaucinih/a30;Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/z20;
    .locals 1

    .line 1
    const-string v0, "id"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a30;->a(Lntidisestablish/neumonoul/floccinaucinih/a30;Lntidisestablish/neumonoul/floccinaucinih/e90;)Lntidisestablish/neumonoul/floccinaucinih/z20;

    move-result-object p0

    return-object p0
.end method

.method public static b(Lntidisestablish/neumonoul/floccinaucinih/a30;Lntidisestablish/neumonoul/floccinaucinih/e90;)V
    .locals 1

    .line 1
    const-string v0, "id"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/a30;->b(Lntidisestablish/neumonoul/floccinaucinih/a30;Lntidisestablish/neumonoul/floccinaucinih/e90;)V

    return-void
.end method
