.class public abstract Lntidisestablish/neumonoul/floccinaucinih/bh;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/bh$c;,
        Lntidisestablish/neumonoul/floccinaucinih/bh$a;,
        Lntidisestablish/neumonoul/floccinaucinih/bh$b;
    }
.end annotation


# direct methods
.method public static a(Landroid/content/Context;Lntidisestablish/neumonoul/floccinaucinih/yg;IZILandroid/os/Handler;Lntidisestablish/neumonoul/floccinaucinih/bh$c;)Landroid/graphics/Typeface;
    .locals 1

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/u6;

    invoke-direct {v0, p6, p5}, Lntidisestablish/neumonoul/floccinaucinih/u6;-><init>(Lntidisestablish/neumonoul/floccinaucinih/bh$c;Landroid/os/Handler;)V

    if-eqz p3, :cond_0

    invoke-static {p0, p1, v0, p2, p4}, Lntidisestablish/neumonoul/floccinaucinih/zg;->e(Landroid/content/Context;Lntidisestablish/neumonoul/floccinaucinih/yg;Lntidisestablish/neumonoul/floccinaucinih/u6;II)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p3, 0x0

    invoke-static {p0, p1, p2, p3, v0}, Lntidisestablish/neumonoul/floccinaucinih/zg;->d(Landroid/content/Context;Lntidisestablish/neumonoul/floccinaucinih/yg;ILjava/util/concurrent/Executor;Lntidisestablish/neumonoul/floccinaucinih/u6;)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0
.end method
