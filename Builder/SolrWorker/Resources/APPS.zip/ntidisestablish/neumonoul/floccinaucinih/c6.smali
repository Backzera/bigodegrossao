.class public Lntidisestablish/neumonoul/floccinaucinih/c6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/o7;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/c6$a;
    }
.end annotation


# static fields
.field private static final h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

.field private static final i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

.field private static final j:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

.field private static final k:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

.field private static final l:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field private static final m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field private static final n:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field private static final o:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field private static final p:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;


# instance fields
.field private volatile _closeCause:Ljava/lang/Object;

.field private volatile bufferEnd:J

.field private volatile bufferEndSegment:Ljava/lang/Object;

.field private volatile closeHandler:Ljava/lang/Object;

.field private volatile completedExpandBuffersAndPauseFlag:J

.field private final e:I

.field public final f:Lntidisestablish/neumonoul/floccinaucinih/zh;

.field private final g:Lntidisestablish/neumonoul/floccinaucinih/oi;

.field private volatile receiveSegment:Ljava/lang/Object;

.field private volatile receivers:J

.field private volatile sendSegment:Ljava/lang/Object;

.field private volatile sendersAndCloseStatus:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    const-string v0, "sendersAndCloseStatus"

    const-class v1, Lntidisestablish/neumonoul/floccinaucinih/c6;

    invoke-static {v1, v0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    const-string v0, "receivers"

    invoke-static {v1, v0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    const-string v0, "bufferEnd"

    invoke-static {v1, v0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->j:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    const-string v0, "completedExpandBuffersAndPauseFlag"

    invoke-static {v1, v0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->k:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    const-string v0, "sendSegment"

    const-class v2, Ljava/lang/Object;

    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->l:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const-string v0, "receiveSegment"

    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const-string v0, "bufferEndSegment"

    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->n:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const-string v0, "_closeCause"

    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->o:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const-string v0, "closeHandler"

    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->p:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    return-void
.end method

.method public constructor <init>(ILntidisestablish/neumonoul/floccinaucinih/zh;)V
    .locals 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->e:I

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-ltz p1, :cond_2

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/d6;->t(I)J

    move-result-wide v0

    iput-wide v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->bufferEnd:J

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v0

    iput-wide v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->completedExpandBuffersAndPauseFlag:J

    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    const-wide/16 v3, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x3

    move-object v2, p1

    move-object v6, p0

    invoke-direct/range {v2 .. v7}, Lntidisestablish/neumonoul/floccinaucinih/w7;-><init>(JLntidisestablish/neumonoul/floccinaucinih/w7;Lntidisestablish/neumonoul/floccinaucinih/c6;I)V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->sendSegment:Ljava/lang/Object;

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->receiveSegment:Ljava/lang/Object;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->b0()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->n()Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object p1

    const-string v0, "null cannot be cast to non-null type kotlinx.coroutines.channels.ChannelSegment<E of kotlinx.coroutines.channels.BufferedChannel>"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_0
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->bufferEndSegment:Ljava/lang/Object;

    if-eqz p2, :cond_1

    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/c6$b;

    invoke-direct {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/c6$b;-><init>(Lntidisestablish/neumonoul/floccinaucinih/c6;)V

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->g:Lntidisestablish/neumonoul/floccinaucinih/oi;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->l()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->_closeCause:Ljava/lang/Object;

    return-void

    :cond_2
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Invalid channel capacity: "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ", should be >=0"

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method private final A(Lntidisestablish/neumonoul/floccinaucinih/w7;J)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {v0, v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/uk;->b(Ljava/lang/Object;ILntidisestablish/neumonoul/floccinaucinih/tc;)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    const/4 v2, -0x1

    if-eqz p1, :cond_6

    sget v3, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    sub-int/2addr v3, v1

    :goto_1
    if-ge v2, v3, :cond_5

    iget-wide v4, p1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    sget v6, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v6, v6

    mul-long/2addr v4, v6

    int-to-long v6, v3

    add-long/2addr v4, v6

    cmp-long v4, v4, p2

    if-ltz v4, :cond_6

    :cond_0
    invoke-virtual {p1, v3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_3

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->k()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v5

    if-ne v4, v5, :cond_1

    goto :goto_3

    :cond_1
    instance-of v5, v4, Lntidisestablish/neumonoul/floccinaucinih/j70;

    if-eqz v5, :cond_2

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v5

    invoke-virtual {p1, v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    check-cast v4, Lntidisestablish/neumonoul/floccinaucinih/j70;

    iget-object v4, v4, Lntidisestablish/neumonoul/floccinaucinih/j70;->a:Lntidisestablish/neumonoul/floccinaucinih/i70;

    :goto_2
    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/uk;->c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->x(IZ)V

    goto :goto_4

    :cond_2
    instance-of v5, v4, Lntidisestablish/neumonoul/floccinaucinih/i70;

    if-eqz v5, :cond_4

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v5

    invoke-virtual {p1, v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    goto :goto_2

    :cond_3
    :goto_3
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v5

    invoke-virtual {p1, v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    :cond_4
    :goto_4
    add-int/lit8 v3, v3, -0x1

    goto :goto_1

    :cond_5
    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->g()Lntidisestablish/neumonoul/floccinaucinih/x9;

    move-result-object p1

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    goto :goto_0

    :cond_6
    if-eqz v0, :cond_8

    instance-of p1, v0, Ljava/util/ArrayList;

    if-nez p1, :cond_7

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/i70;

    invoke-direct {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->s0(Lntidisestablish/neumonoul/floccinaucinih/i70;)V

    goto :goto_6

    :cond_7
    const-string p1, "null cannot be cast to non-null type java.util.ArrayList<E of kotlinx.coroutines.internal.InlineList>{ kotlin.collections.TypeAliasesKt.ArrayList<E of kotlinx.coroutines.internal.InlineList> }"

    invoke-static {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    sub-int/2addr p1, v1

    :goto_5
    if-ge v2, p1, :cond_8

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lntidisestablish/neumonoul/floccinaucinih/i70;

    invoke-direct {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->s0(Lntidisestablish/neumonoul/floccinaucinih/i70;)V

    add-int/lit8 p1, p1, -0x1

    goto :goto_5

    :cond_8
    :goto_6
    return-void
.end method

.method private final A0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJ)Z
    .locals 3

    .line 1
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lntidisestablish/neumonoul/floccinaucinih/i70;

    if-eqz v1, :cond_1

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v1

    cmp-long v1, p3, v1

    if-ltz v1, :cond_1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->p()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-direct {p0, v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->z0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/w7;I)Z

    move-result p3

    if-eqz p3, :cond_0

    sget-object p3, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->A(ILjava/lang/Object;)V

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->A(ILjava/lang/Object;)V

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->x(IZ)V

    move p1, p3

    :goto_0
    return p1

    :cond_1
    invoke-direct {p0, p1, p2, p3, p4}, Lntidisestablish/neumonoul/floccinaucinih/c6;->B0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJ)Z

    move-result p1

    return p1
.end method

.method private final B()Lntidisestablish/neumonoul/floccinaucinih/w7;
    .locals 6

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->n:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->l:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v2, v1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    move-object v4, v0

    check-cast v4, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v4, v4, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v2, v2, v4

    if-lez v2, :cond_0

    move-object v0, v1

    :cond_0
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v2, v1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    move-object v4, v0

    check-cast v4, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v4, v4, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v2, v2, v4

    if-lez v2, :cond_1

    move-object v0, v1

    :cond_1
    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/x9;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/w9;->b(Lntidisestablish/neumonoul/floccinaucinih/x9;)Lntidisestablish/neumonoul/floccinaucinih/x9;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/w7;

    return-object v0
.end method

.method private final B0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJ)Z
    .locals 6

    .line 1
    :cond_0
    :goto_0
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lntidisestablish/neumonoul/floccinaucinih/i70;

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_3

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v4

    cmp-long v1, p3, v4

    if-gez v1, :cond_1

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/j70;

    move-object v2, v0

    check-cast v2, Lntidisestablish/neumonoul/floccinaucinih/i70;

    invoke-direct {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/j70;-><init>(Lntidisestablish/neumonoul/floccinaucinih/i70;)V

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v3

    :cond_1
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->p()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-direct {p0, v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->z0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/w7;I)Z

    move-result p3

    if-eqz p3, :cond_2

    sget-object p3, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->A(ILjava/lang/Object;)V

    move v2, v3

    goto :goto_1

    :cond_2
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->A(ILjava/lang/Object;)V

    invoke-virtual {p1, p2, v2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->x(IZ)V

    :goto_1
    return v2

    :cond_3
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-ne v0, v1, :cond_4

    return v2

    :cond_4
    if-nez v0, :cond_5

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->k()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v3

    :cond_5
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    if-ne v0, v1, :cond_6

    return v3

    :cond_6
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->o()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-eq v0, v1, :cond_a

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-eq v0, v1, :cond_a

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->i()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-ne v0, v1, :cond_7

    goto :goto_2

    :cond_7
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-ne v0, v1, :cond_8

    return v3

    :cond_8
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->q()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-ne v0, v1, :cond_9

    goto :goto_0

    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Unexpected cell state: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_a
    :goto_2
    return v3
.end method

.method private final C0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_1

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v1

    const-wide v3, 0xfffffffffffffffL

    and-long/2addr v1, v3

    cmp-long v1, p3, v1

    if-ltz v1, :cond_2

    if-nez p5, :cond_0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->s()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    return-object p1

    :cond_0
    invoke-virtual {p1, p2, v0, p5}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->r()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    return-object p1

    :cond_1
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    if-ne v0, v1, :cond_2

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->y(I)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :cond_2
    invoke-direct/range {p0 .. p5}, Lntidisestablish/neumonoul/floccinaucinih/c6;->D0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method private final D(J)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->E(J)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object p1

    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->r0(Lntidisestablish/neumonoul/floccinaucinih/w7;)V

    return-void
.end method

.method private final D0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    :cond_0
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_9

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->k()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-ne v0, v1, :cond_1

    goto/16 :goto_1

    :cond_1
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    if-ne v0, v1, :cond_2

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->y(I)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :cond_2
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-ne v0, v1, :cond_3

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    return-object p1

    :cond_3
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->o()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-ne v0, v1, :cond_4

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    return-object p1

    :cond_4
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-ne v0, v1, :cond_5

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    return-object p1

    :cond_5
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->p()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    if-eq v0, v1, :cond_0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->q()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    instance-of p3, v0, Lntidisestablish/neumonoul/floccinaucinih/j70;

    if-eqz p3, :cond_6

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/j70;

    iget-object v0, v0, Lntidisestablish/neumonoul/floccinaucinih/j70;->a:Lntidisestablish/neumonoul/floccinaucinih/i70;

    :cond_6
    invoke-direct {p0, v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->z0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/w7;I)Z

    move-result p4

    if-eqz p4, :cond_7

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->A(ILjava/lang/Object;)V

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->y(I)Ljava/lang/Object;

    move-result-object p1

    goto :goto_0

    :cond_7
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p4

    invoke-virtual {p1, p2, p4}, Lntidisestablish/neumonoul/floccinaucinih/w7;->A(ILjava/lang/Object;)V

    const/4 p4, 0x0

    invoke-virtual {p1, p2, p4}, Lntidisestablish/neumonoul/floccinaucinih/w7;->x(IZ)V

    if-eqz p3, :cond_8

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    :cond_8
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    :goto_0
    return-object p1

    :cond_9
    :goto_1
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v1

    const-wide v3, 0xfffffffffffffffL

    and-long/2addr v1, v3

    cmp-long v1, p3, v1

    if-gez v1, :cond_a

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->o()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    return-object p1

    :cond_a
    if-nez p5, :cond_b

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->s()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    return-object p1

    :cond_b
    invoke-virtual {p1, p2, v0, p5}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->r()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    return-object p1
.end method

.method private final E(J)Lntidisestablish/neumonoul/floccinaucinih/w7;
    .locals 5

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->B()Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->a0()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-direct {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->c0(Lntidisestablish/neumonoul/floccinaucinih/w7;)J

    move-result-wide v1

    const-wide/16 v3, -0x1

    cmp-long v3, v1, v3

    if-eqz v3, :cond_0

    invoke-virtual {p0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->G(J)V

    :cond_0
    invoke-direct {p0, v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->A(Lntidisestablish/neumonoul/floccinaucinih/w7;J)V

    return-object v0
.end method

.method private final E0(Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I
    .locals 3

    .line 1
    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->B(ILjava/lang/Object;)V

    if-eqz p7, :cond_0

    invoke-direct/range {p0 .. p7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->F0(Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I

    move-result p1

    return p1

    :cond_0
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    if-nez v0, :cond_3

    invoke-direct {p0, p4, p5}, Lntidisestablish/neumonoul/floccinaucinih/c6;->y(J)Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    invoke-virtual {p1, p2, v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    return v1

    :cond_1
    if-nez p6, :cond_2

    const/4 p1, 0x3

    return p1

    :cond_2
    invoke-virtual {p1, p2, v2, p6}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    const/4 p1, 0x2

    return p1

    :cond_3
    instance-of v2, v0, Lntidisestablish/neumonoul/floccinaucinih/i70;

    if-eqz v2, :cond_6

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->s(I)V

    invoke-direct {p0, v0, p3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->y0(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_4

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->A(ILjava/lang/Object;)V

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->l0()V

    const/4 p1, 0x0

    goto :goto_0

    :cond_4
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->i()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->t(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->i()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p4

    if-eq p3, p4, :cond_5

    invoke-virtual {p1, p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->x(IZ)V

    :cond_5
    const/4 p1, 0x5

    :goto_0
    return p1

    :cond_6
    invoke-direct/range {p0 .. p7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->F0(Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I

    move-result p1

    return p1
.end method

.method private final F()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->r()Z

    return-void
.end method

.method private final F0(Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I
    .locals 5

    .line 1
    :cond_0
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_4

    invoke-direct {p0, p4, p5}, Lntidisestablish/neumonoul/floccinaucinih/c6;->y(J)Z

    move-result v0

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    if-nez p7, :cond_1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    invoke-virtual {p1, p2, v4, v0}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v3

    :cond_1
    if-eqz p7, :cond_2

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v0

    invoke-virtual {p1, p2, v4, v0}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1, p2, v2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->x(IZ)V

    return v1

    :cond_2
    if-nez p6, :cond_3

    const/4 p1, 0x3

    return p1

    :cond_3
    invoke-virtual {p1, p2, v4, p6}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x2

    return p1

    :cond_4
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->k()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v4

    if-ne v0, v4, :cond_5

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    invoke-virtual {p1, p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v3

    :cond_5
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->i()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p4

    const/4 p5, 0x5

    if-ne v0, p4, :cond_6

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->s(I)V

    return p5

    :cond_6
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->o()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p4

    if-ne v0, p4, :cond_7

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->s(I)V

    return p5

    :cond_7
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p4

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->s(I)V

    if-ne v0, p4, :cond_8

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->F()V

    return v1

    :cond_8
    instance-of p4, v0, Lntidisestablish/neumonoul/floccinaucinih/j70;

    if-eqz p4, :cond_9

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/j70;

    iget-object v0, v0, Lntidisestablish/neumonoul/floccinaucinih/j70;->a:Lntidisestablish/neumonoul/floccinaucinih/i70;

    :cond_9
    invoke-direct {p0, v0, p3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->y0(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_a

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->A(ILjava/lang/Object;)V

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->l0()V

    goto :goto_0

    :cond_a
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->i()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->t(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->i()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p4

    if-eq p3, p4, :cond_b

    invoke-virtual {p1, p2, v3}, Lntidisestablish/neumonoul/floccinaucinih/w7;->x(IZ)V

    :cond_b
    move v2, p5

    :goto_0
    return v2
.end method

.method private final G0(J)V
    .locals 7

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    :cond_0
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v3

    cmp-long v1, v3, p1

    if-ltz v1, :cond_1

    return-void

    :cond_1
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-object v2, p0

    move-wide v5, p1

    invoke-virtual/range {v1 .. v6}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void
.end method

.method private final H()V
    .locals 14

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->b0()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->n:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :cond_1
    :goto_0
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->j:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    move-result-wide v7

    sget v9, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v1, v9

    div-long v2, v7, v1

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v4

    cmp-long v1, v4, v7

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-wide/16 v12, 0x0

    iget-wide v4, v0, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    if-gtz v1, :cond_3

    cmp-long v1, v4, v2

    if-gez v1, :cond_2

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/x9;->e()Lntidisestablish/neumonoul/floccinaucinih/x9;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-direct {p0, v2, v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->g0(JLntidisestablish/neumonoul/floccinaucinih/w7;)V

    :cond_2
    invoke-static {p0, v12, v13, v11, v10}, Lntidisestablish/neumonoul/floccinaucinih/c6;->T(Lntidisestablish/neumonoul/floccinaucinih/c6;JILjava/lang/Object;)V

    return-void

    :cond_3
    cmp-long v1, v4, v2

    if-eqz v1, :cond_5

    move-object v1, p0

    move-object v4, v0

    move-wide v5, v7

    invoke-direct/range {v1 .. v6}, Lntidisestablish/neumonoul/floccinaucinih/c6;->I(JLntidisestablish/neumonoul/floccinaucinih/w7;J)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v1

    if-nez v1, :cond_4

    goto :goto_0

    :cond_4
    move-object v0, v1

    :cond_5
    int-to-long v1, v9

    rem-long v1, v7, v1

    long-to-int v1, v1

    invoke-direct {p0, v0, v1, v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/c6;->A0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJ)Z

    move-result v1

    invoke-static {p0, v12, v13, v11, v10}, Lntidisestablish/neumonoul/floccinaucinih/c6;->T(Lntidisestablish/neumonoul/floccinaucinih/c6;JILjava/lang/Object;)V

    if-eqz v1, :cond_1

    return-void
.end method

.method private final H0(J)V
    .locals 7

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    :cond_0
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v3

    const-wide v1, 0xfffffffffffffffL

    and-long/2addr v1, v3

    cmp-long v5, v1, p1

    if-ltz v5, :cond_1

    return-void

    :cond_1
    const/16 v5, 0x3c

    shr-long v5, v3, v5

    long-to-int v5, v5

    invoke-static {v1, v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/d6;->b(JI)J

    move-result-wide v5

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-object v2, p0

    invoke-virtual/range {v1 .. v6}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void
.end method

.method private final I(JLntidisestablish/neumonoul/floccinaucinih/w7;J)Lntidisestablish/neumonoul/floccinaucinih/w7;
    .locals 15

    .line 1
    move-object v6, p0

    move-wide/from16 v0, p1

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/c6;->n:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->y()Lntidisestablish/neumonoul/floccinaucinih/om;

    move-result-object v3

    check-cast v3, Lntidisestablish/neumonoul/floccinaucinih/ni;

    move-object/from16 v4, p3

    :goto_0
    invoke-static {v4, v0, v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/w9;->c(Lntidisestablish/neumonoul/floccinaucinih/kz;JLntidisestablish/neumonoul/floccinaucinih/ni;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v5}, Lntidisestablish/neumonoul/floccinaucinih/lz;->c(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_4

    invoke-static {v5}, Lntidisestablish/neumonoul/floccinaucinih/lz;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/kz;

    move-result-object v7

    :cond_0
    :goto_1
    invoke-virtual {v2, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lntidisestablish/neumonoul/floccinaucinih/kz;

    iget-wide v9, v8, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    iget-wide v11, v7, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v9, v9, v11

    if-ltz v9, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v7}, Lntidisestablish/neumonoul/floccinaucinih/kz;->q()Z

    move-result v9

    if-nez v9, :cond_2

    goto :goto_0

    :cond_2
    invoke-static {v2, p0, v8, v7}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_3

    invoke-virtual {v8}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-virtual {v8}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_2

    :cond_3
    invoke-virtual {v7}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result v8

    if-eqz v8, :cond_0

    invoke-virtual {v7}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_1

    :cond_4
    :goto_2
    invoke-static {v5}, Lntidisestablish/neumonoul/floccinaucinih/lz;->c(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x1

    const-wide/16 v8, 0x0

    const/4 v10, 0x0

    if-eqz v2, :cond_6

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->F()V

    invoke-direct/range {p0 .. p3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->g0(JLntidisestablish/neumonoul/floccinaucinih/w7;)V

    :cond_5
    invoke-static {p0, v8, v9, v7, v10}, Lntidisestablish/neumonoul/floccinaucinih/c6;->T(Lntidisestablish/neumonoul/floccinaucinih/c6;JILjava/lang/Object;)V

    goto :goto_3

    :cond_6
    invoke-static {v5}, Lntidisestablish/neumonoul/floccinaucinih/lz;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/kz;

    move-result-object v2

    move-object v11, v2

    check-cast v11, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v2, v11, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v0, v2, v0

    if-lez v0, :cond_7

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->j:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    const-wide/16 v4, 0x1

    add-long v4, p4, v4

    sget v12, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v13, v12

    mul-long/2addr v13, v2

    move-object v1, p0

    move-wide v2, v4

    move-wide v4, v13

    invoke-virtual/range {v0 .. v5}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-wide v0, v11, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    int-to-long v2, v12

    mul-long/2addr v0, v2

    sub-long v0, v0, p4

    invoke-direct {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->S(J)V

    goto :goto_3

    :cond_7
    move-object v10, v11

    :goto_3
    return-object v10
.end method

.method private final J(JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;
    .locals 9

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->y()Lntidisestablish/neumonoul/floccinaucinih/om;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/ni;

    :goto_0
    invoke-static {p3, p1, p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/w9;->c(Lntidisestablish/neumonoul/floccinaucinih/kz;JLntidisestablish/neumonoul/floccinaucinih/ni;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/lz;->c(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/lz;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/kz;

    move-result-object v3

    :cond_0
    :goto_1
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lntidisestablish/neumonoul/floccinaucinih/kz;

    iget-wide v5, v4, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    iget-wide v7, v3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v5, v5, v7

    if-ltz v5, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->q()Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_0

    :cond_2
    invoke-static {v0, p0, v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-virtual {v4}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {v4}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_2

    :cond_3
    invoke-virtual {v3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_1

    :cond_4
    :goto_2
    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/lz;->c(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_5

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->F()V

    iget-wide p1, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v2, v0

    mul-long/2addr p1, v2

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v2

    cmp-long p1, p1, v2

    if-gez p1, :cond_a

    :goto_3
    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    goto :goto_6

    :cond_5
    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/lz;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/kz;

    move-result-object p3

    check-cast p3, Lntidisestablish/neumonoul/floccinaucinih/w7;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->b0()Z

    move-result v0

    if-nez v0, :cond_8

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v2

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v4, v0

    div-long/2addr v2, v4

    cmp-long v0, p1, v2

    if-gtz v0, :cond_8

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->n:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    :cond_6
    :goto_4
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lntidisestablish/neumonoul/floccinaucinih/kz;

    iget-wide v3, v2, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    iget-wide v5, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v3, v3, v5

    if-gez v3, :cond_8

    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->q()Z

    move-result v3

    if-eqz v3, :cond_8

    invoke-static {v0, p0, v2, p3}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_7

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_5

    :cond_7
    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_4

    :cond_8
    :goto_5
    iget-wide v2, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long p1, v2, p1

    if-lez p1, :cond_9

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v4, p1

    mul-long/2addr v2, v4

    invoke-direct {p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->G0(J)V

    iget-wide v2, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    int-to-long p1, p1

    mul-long/2addr v2, p1

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide p1

    cmp-long p1, v2, p1

    if-gez p1, :cond_a

    goto :goto_3

    :cond_9
    move-object v1, p3

    :cond_a
    :goto_6
    return-object v1
.end method

.method private final K(JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;
    .locals 9

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->l:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->y()Lntidisestablish/neumonoul/floccinaucinih/om;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/ni;

    :goto_0
    invoke-static {p3, p1, p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/w9;->c(Lntidisestablish/neumonoul/floccinaucinih/kz;JLntidisestablish/neumonoul/floccinaucinih/ni;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/lz;->c(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/lz;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/kz;

    move-result-object v3

    :cond_0
    :goto_1
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lntidisestablish/neumonoul/floccinaucinih/kz;

    iget-wide v5, v4, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    iget-wide v7, v3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v5, v5, v7

    if-ltz v5, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->q()Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_0

    :cond_2
    invoke-static {v0, p0, v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-virtual {v4}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {v4}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_2

    :cond_3
    invoke-virtual {v3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_1

    :cond_4
    :goto_2
    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/lz;->c(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_5

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->F()V

    iget-wide p1, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v2, v0

    mul-long/2addr p1, v2

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v2

    cmp-long p1, p1, v2

    if-gez p1, :cond_7

    :goto_3
    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    goto :goto_4

    :cond_5
    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/lz;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/kz;

    move-result-object p3

    check-cast p3, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v2, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long p1, v2, p1

    if-lez p1, :cond_6

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v4, p1

    mul-long/2addr v2, v4

    invoke-direct {p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H0(J)V

    iget-wide v2, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    int-to-long p1, p1

    mul-long/2addr v2, p1

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide p1

    cmp-long p1, v2, p1

    if-gez p1, :cond_7

    goto :goto_3

    :cond_6
    move-object v1, p3

    :cond_7
    :goto_4
    return-object v1
.end method

.method private final L()J
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->j:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v0

    return-wide v0
.end method

.method private final N()Ljava/lang/Throwable;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object v0

    if-nez v0, :cond_0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/o8;

    const-string v1, "Channel was closed"

    invoke-direct {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/o8;-><init>(Ljava/lang/String;)V

    :cond_0
    return-object v0
.end method

.method private final S(J)V
    .locals 4

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->k:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v0, p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->addAndGet(Ljava/lang/Object;J)J

    move-result-wide p1

    const-wide/high16 v0, 0x4000000000000000L    # 2.0

    and-long/2addr p1, v0

    const-wide/16 v2, 0x0

    cmp-long p1, p1, v2

    if-eqz p1, :cond_0

    :goto_0
    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/c6;->k:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide p1

    and-long/2addr p1, v0

    cmp-long p1, p1, v2

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    return-void
.end method

.method static synthetic T(Lntidisestablish/neumonoul/floccinaucinih/c6;JILjava/lang/Object;)V
    .locals 0

    .line 1
    if-nez p4, :cond_1

    and-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_0

    const-wide/16 p1, 0x1

    :cond_0
    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->S(J)V

    return-void

    :cond_1
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Super calls with default arguments not supported in this target, function: incCompletedExpandBufferAttempts"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final U()V
    .locals 3

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->p:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    :cond_0
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->d()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    goto :goto_0

    :cond_1
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->e()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    :goto_0
    invoke-static {v0, p0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    if-nez v1, :cond_2

    return-void

    :cond_2
    const/4 v0, 0x1

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/w50;->a(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/zh;

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/zh;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object v0

    invoke-interface {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/zh;->r(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private final V(Lntidisestablish/neumonoul/floccinaucinih/w7;IJ)Z
    .locals 4

    .line 1
    :cond_0
    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->k()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    if-ne v0, v2, :cond_1

    goto :goto_0

    :cond_1
    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    const/4 p2, 0x1

    if-ne v0, p1, :cond_2

    return p2

    :cond_2
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    if-ne v0, p1, :cond_3

    return v1

    :cond_3
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    if-ne v0, p1, :cond_4

    return v1

    :cond_4
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    if-ne v0, p1, :cond_5

    return v1

    :cond_5
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->o()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    if-ne v0, p1, :cond_6

    return v1

    :cond_6
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->p()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    if-ne v0, p1, :cond_7

    return p2

    :cond_7
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->q()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    if-ne v0, p1, :cond_8

    return v1

    :cond_8
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v2

    cmp-long p1, p3, v2

    if-nez p1, :cond_9

    move v1, p2

    :cond_9
    return v1

    :cond_a
    :goto_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->o()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    invoke-virtual {p1, p2, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->H()V

    return v1
.end method

.method private final W(JZ)Z
    .locals 6

    .line 1
    const/16 v0, 0x3c

    shr-long v0, p1, v0

    long-to-int v0, v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    const/4 v2, 0x1

    if-eq v0, v2, :cond_3

    const/4 v3, 0x2

    const-wide v4, 0xfffffffffffffffL

    if-eq v0, v3, :cond_2

    const/4 p3, 0x3

    if-ne v0, p3, :cond_1

    and-long/2addr p1, v4

    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->D(J)V

    :cond_0
    :goto_0
    move v1, v2

    goto :goto_1

    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "unexpected close status: "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_2
    and-long/2addr p1, v4

    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->E(J)Lntidisestablish/neumonoul/floccinaucinih/w7;

    if-eqz p3, :cond_0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->R()Z

    move-result p1

    if-nez p1, :cond_3

    goto :goto_0

    :cond_3
    :goto_1
    return v1
.end method

.method private final Y(J)Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    invoke-direct {p0, p1, p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->W(JZ)Z

    move-result p1

    return p1
.end method

.method private final Z(J)Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->W(JZ)Z

    move-result p1

    return p1
.end method

.method public static final synthetic b(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->J(JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object p0

    return-object p0
.end method

.method private final b0()Z
    .locals 4

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-eqz v2, :cond_1

    const-wide v2, 0x7fffffffffffffffL

    cmp-long v0, v0, v2

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method private final c0(Lntidisestablish/neumonoul/floccinaucinih/w7;)J
    .locals 7

    .line 1
    :cond_0
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const-wide/16 v1, -0x1

    const/4 v3, -0x1

    if-ge v3, v0, :cond_5

    iget-wide v3, p1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    sget v5, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v5, v5

    mul-long/2addr v3, v5

    int-to-long v5, v0

    add-long/2addr v3, v5

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v5

    cmp-long v5, v3, v5

    if-gez v5, :cond_1

    return-wide v1

    :cond_1
    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->k()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    if-ne v1, v2, :cond_2

    goto :goto_1

    :cond_2
    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    if-ne v1, v2, :cond_4

    return-wide v3

    :cond_3
    :goto_1
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    invoke-virtual {p1, v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    :cond_4
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_5
    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->g()Lntidisestablish/neumonoul/floccinaucinih/x9;

    move-result-object p1

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    if-nez p1, :cond_0

    return-wide v1
.end method

.method private final d0()V
    .locals 7

    .line 1
    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    :cond_0
    invoke-virtual {v6, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v2

    const/16 v0, 0x3c

    shr-long v0, v2, v0

    long-to-int v0, v0

    if-nez v0, :cond_1

    const-wide v0, 0xfffffffffffffffL

    and-long/2addr v0, v2

    const/4 v4, 0x1

    invoke-static {v0, v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/d6;->b(JI)J

    move-result-wide v4

    move-object v0, v6

    move-object v1, p0

    invoke-virtual/range {v0 .. v5}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result v0

    if-eqz v0, :cond_0

    :cond_1
    return-void
.end method

.method public static final synthetic e(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->K(JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object p0

    return-object p0
.end method

.method private final e0()V
    .locals 7

    .line 1
    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    :cond_0
    invoke-virtual {v6, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v2

    const-wide v0, 0xfffffffffffffffL

    and-long/2addr v0, v2

    const/4 v4, 0x3

    invoke-static {v0, v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/d6;->b(JI)J

    move-result-wide v4

    move-object v0, v6

    move-object v1, p0

    invoke-virtual/range {v0 .. v5}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void
.end method

.method private final f0()V
    .locals 7

    .line 1
    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    :cond_0
    invoke-virtual {v6, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v2

    const/16 v0, 0x3c

    shr-long v0, v2, v0

    long-to-int v0, v0

    const-wide v4, 0xfffffffffffffffL

    if-eqz v0, :cond_2

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    return-void

    :cond_1
    and-long v0, v2, v4

    const/4 v4, 0x3

    :goto_0
    invoke-static {v0, v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/d6;->b(JI)J

    move-result-wide v0

    move-wide v4, v0

    goto :goto_1

    :cond_2
    and-long v0, v2, v4

    const/4 v4, 0x2

    goto :goto_0

    :goto_1
    move-object v0, v6

    move-object v1, p0

    invoke-virtual/range {v0 .. v5}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void
.end method

.method public static final synthetic g(Lntidisestablish/neumonoul/floccinaucinih/c6;)Ljava/lang/Throwable;
    .locals 0

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->N()Ljava/lang/Throwable;

    move-result-object p0

    return-object p0
.end method

.method private final g0(JLntidisestablish/neumonoul/floccinaucinih/w7;)V
    .locals 4

    .line 1
    :goto_0
    iget-wide v0, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v0, v0, p1

    if-gez v0, :cond_1

    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->e()Lntidisestablish/neumonoul/floccinaucinih/x9;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/w7;

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    move-object p3, v0

    goto :goto_0

    :cond_1
    :goto_1
    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->h()Z

    move-result p1

    if-eqz p1, :cond_3

    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->e()Lntidisestablish/neumonoul/floccinaucinih/x9;

    move-result-object p1

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    if-nez p1, :cond_2

    goto :goto_2

    :cond_2
    move-object p3, p1

    goto :goto_1

    :cond_3
    :goto_2
    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/c6;->n:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    :cond_4
    :goto_3
    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lntidisestablish/neumonoul/floccinaucinih/kz;

    iget-wide v0, p2, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    iget-wide v2, p3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v0, v0, v2

    if-ltz v0, :cond_5

    goto :goto_4

    :cond_5
    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->q()Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_1

    :cond_6
    invoke-static {p1, p0, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result p1

    if-eqz p1, :cond_7

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    :cond_7
    :goto_4
    return-void

    :cond_8
    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/kz;->m()Z

    move-result p2

    if-eqz p2, :cond_4

    invoke-virtual {p3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->k()V

    goto :goto_3
.end method

.method public static final synthetic i()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    return-object v0
.end method

.method private final i0(Lntidisestablish/neumonoul/floccinaucinih/b7;)V
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/u7;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/u7;

    move-result-object v0

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-interface {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/gb;->q(Ljava/lang/Object;)V

    return-void
.end method

.method public static final synthetic j()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    return-object v0
.end method

.method private final j0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 4

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/c7;

    invoke-static {p2}, Lntidisestablish/neumonoul/floccinaucinih/kl;->b(Lntidisestablish/neumonoul/floccinaucinih/gb;)Lntidisestablish/neumonoul/floccinaucinih/gb;

    move-result-object v1

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/c7;-><init>(Lntidisestablish/neumonoul/floccinaucinih/gb;I)V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/c7;->A()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz v1, :cond_0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v1, p1, v3, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/rs;->d(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/h60;ILjava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/h60;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object v1

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/rf;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :goto_0
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/hy;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-interface {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/gb;->q(Ljava/lang/Object;)V

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object p1

    goto :goto_0

    :goto_1
    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/c7;->x()Ljava/lang/Object;

    move-result-object p1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v0

    if-ne p1, v0, :cond_1

    invoke-static {p2}, Lntidisestablish/neumonoul/floccinaucinih/qc;->c(Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    :cond_1
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object p2

    if-ne p1, p2, :cond_2

    return-object p1

    :cond_2
    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    return-object p1
.end method

.method private final k0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/b7;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz v0, :cond_0

    invoke-interface {p2}, Lntidisestablish/neumonoul/floccinaucinih/gb;->i()Lntidisestablish/neumonoul/floccinaucinih/pb;

    move-result-object v1

    invoke-static {v0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/rs;->b(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/pb;)V

    :cond_0
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object p1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/hy;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-interface {p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/gb;->q(Ljava/lang/Object;)V

    return-void
.end method

.method public static final synthetic m()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->l:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    return-object v0
.end method

.method public static final synthetic n()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    return-object v0
.end method

.method private final n0(Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->m0()V

    invoke-interface {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/i70;->b(Lntidisestablish/neumonoul/floccinaucinih/kz;I)V

    return-void
.end method

.method public static final synthetic o(Lntidisestablish/neumonoul/floccinaucinih/c6;J)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Z(J)Z

    move-result p0

    return p0
.end method

.method private final o0(Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V
    .locals 1

    .line 1
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    add-int/2addr p3, v0

    invoke-interface {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/i70;->b(Lntidisestablish/neumonoul/floccinaucinih/kz;I)V

    return-void
.end method

.method public static final synthetic p(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/b7;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->i0(Lntidisestablish/neumonoul/floccinaucinih/b7;)V

    return-void
.end method

.method static synthetic p0(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 14

    .line 1
    instance-of v0, p1, Lntidisestablish/neumonoul/floccinaucinih/c6$c;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;

    iget v1, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->j:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->j:I

    :goto_0
    move-object v6, v0

    goto :goto_1

    :cond_0
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/c6$c;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6$c;-><init>(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    goto :goto_0

    :goto_1
    iget-object p1, v6, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->h:Ljava/lang/Object;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v0

    iget v1, v6, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->j:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    if-ne v1, v2, :cond_1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/hy;->b(Ljava/lang/Object;)V

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/u7;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/u7;->k()Ljava/lang/Object;

    move-result-object p0

    goto/16 :goto_4

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/hy;->b(Ljava/lang/Object;)V

    const/4 p1, 0x0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->i()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :goto_2
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->X()Z

    move-result v3

    if-eqz v3, :cond_3

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object p0

    invoke-virtual {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    goto/16 :goto_4

    :cond_3
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->j()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v3

    invoke-virtual {v3, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    move-result-wide v4

    sget v3, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v7, v3

    div-long v7, v4, v7

    int-to-long v9, v3

    rem-long v9, v4, v9

    long-to-int v3, v9

    iget-wide v9, v1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v9, v9, v7

    if-eqz v9, :cond_5

    invoke-static {p0, v7, v8, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->b(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v7

    if-nez v7, :cond_4

    goto :goto_2

    :cond_4
    move-object v13, v7

    goto :goto_3

    :cond_5
    move-object v13, v1

    :goto_3
    move-object v7, p0

    move-object v8, v13

    move v9, v3

    move-wide v10, v4

    move-object v12, p1

    invoke-static/range {v7 .. v12}, Lntidisestablish/neumonoul/floccinaucinih/c6;->w(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->r()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    if-eq v1, v7, :cond_a

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    if-ne v1, v7, :cond_7

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v7

    cmp-long v1, v4, v7

    if-gez v1, :cond_6

    invoke-virtual {v13}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :cond_6
    move-object v1, v13

    goto :goto_2

    :cond_7
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->s()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    if-ne v1, p1, :cond_8

    iput v2, v6, Lntidisestablish/neumonoul/floccinaucinih/c6$c;->j:I

    move-object v1, p0

    move-object v2, v13

    invoke-direct/range {v1 .. v6}, Lntidisestablish/neumonoul/floccinaucinih/c6;->q0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_9

    return-object v0

    :cond_8
    invoke-virtual {v13}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    sget-object p0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    :cond_9
    :goto_4
    return-object p0

    :cond_a
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "unexpected"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final synthetic q(Lntidisestablish/neumonoul/floccinaucinih/c6;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/b7;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->k0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/b7;)V

    return-void
.end method

.method private final q0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 10

    .line 1
    instance-of v0, p5, Lntidisestablish/neumonoul/floccinaucinih/c6$d;

    if-eqz v0, :cond_0

    move-object v0, p5

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;

    iget v1, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->n:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->n:I

    goto :goto_0

    :cond_0
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;

    invoke-direct {v0, p0, p5}, Lntidisestablish/neumonoul/floccinaucinih/c6$d;-><init>(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    :goto_0
    iget-object p5, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->l:Ljava/lang/Object;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v1

    iget v2, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->n:I

    const/4 v3, 0x1

    if-eqz v2, :cond_2

    if-ne v2, v3, :cond_1

    iget-object p1, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->i:Ljava/lang/Object;

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-object p1, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->h:Ljava/lang/Object;

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/c6;

    invoke-static {p5}, Lntidisestablish/neumonoul/floccinaucinih/hy;->b(Ljava/lang/Object;)V

    goto/16 :goto_4

    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    invoke-static {p5}, Lntidisestablish/neumonoul/floccinaucinih/hy;->b(Ljava/lang/Object;)V

    iput-object p0, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->h:Ljava/lang/Object;

    iput-object p1, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->i:Ljava/lang/Object;

    iput p2, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->j:I

    iput-wide p3, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->k:J

    iput v3, v0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->n:I

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/kl;->b(Lntidisestablish/neumonoul/floccinaucinih/gb;)Lntidisestablish/neumonoul/floccinaucinih/gb;

    move-result-object p5

    invoke-static {p5}, Lntidisestablish/neumonoul/floccinaucinih/e7;->a(Lntidisestablish/neumonoul/floccinaucinih/gb;)Lntidisestablish/neumonoul/floccinaucinih/c7;

    move-result-object p5

    :try_start_0
    new-instance v8, Lntidisestablish/neumonoul/floccinaucinih/ax;

    const-string v2, "null cannot be cast to non-null type kotlinx.coroutines.CancellableContinuationImpl<kotlinx.coroutines.channels.ChannelResult<E of kotlinx.coroutines.channels.BufferedChannel.receiveCatchingOnNoWaiterSuspend_GKJJFZk$lambda$35>>"

    invoke-static {p5, v2}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v8, p5}, Lntidisestablish/neumonoul/floccinaucinih/ax;-><init>(Lntidisestablish/neumonoul/floccinaucinih/c7;)V

    move-object v2, p0

    move-object v3, p1

    move v4, p2

    move-wide v5, p3

    move-object v7, v8

    invoke-static/range {v2 .. v7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->w(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->r()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v3

    if-ne v2, v3, :cond_3

    invoke-static {p0, v8, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->t(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    goto/16 :goto_3

    :catchall_0
    move-exception p1

    goto/16 :goto_5

    :cond_3
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p2

    const/4 v9, 0x0

    if-ne v2, p2, :cond_d

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v2

    cmp-long p2, p3, v2

    if-gez p2, :cond_4

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :cond_4
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->i()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :cond_5
    :goto_1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->X()Z

    move-result p2

    if-eqz p2, :cond_6

    invoke-static {p0, p5}, Lntidisestablish/neumonoul/floccinaucinih/c6;->p(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/b7;)V

    goto/16 :goto_3

    :cond_6
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->j()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    move-result-wide p2

    sget p4, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v2, p4

    div-long v2, p2, v2

    int-to-long v4, p4

    rem-long v4, p2, v4

    long-to-int p4, v4

    iget-wide v4, p1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v4, v4, v2

    if-eqz v4, :cond_8

    invoke-static {p0, v2, v3, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->b(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v2

    if-nez v2, :cond_7

    goto :goto_1

    :cond_7
    move-object p1, v2

    :cond_8
    move-object v2, p0

    move-object v3, p1

    move v4, p4

    move-wide v5, p2

    move-object v7, v8

    invoke-static/range {v2 .. v7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->w(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->r()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v3

    if-ne v2, v3, :cond_9

    invoke-static {p0, v8, p1, p4}, Lntidisestablish/neumonoul/floccinaucinih/c6;->t(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    goto :goto_3

    :cond_9
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p4

    if-ne v2, p4, :cond_a

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v2

    cmp-long p2, p2, v2

    if-gez p2, :cond_5

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    goto :goto_1

    :cond_a
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->s()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p2

    if-eq v2, p2, :cond_c

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/u7;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/u7;

    move-result-object p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz p2, :cond_b

    invoke-virtual {p5}, Lntidisestablish/neumonoul/floccinaucinih/c7;->i()Lntidisestablish/neumonoul/floccinaucinih/pb;

    move-result-object p3

    invoke-static {p2, v2, p3}, Lntidisestablish/neumonoul/floccinaucinih/rs;->a(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/pb;)Lntidisestablish/neumonoul/floccinaucinih/zh;

    move-result-object v9

    :cond_b
    :goto_2
    invoke-virtual {p5, p1, v9}, Lntidisestablish/neumonoul/floccinaucinih/c7;->K(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/zh;)V

    goto :goto_3

    :cond_c
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "unexpected"

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_d
    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/u7;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/u7;

    move-result-object p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz p2, :cond_b

    invoke-virtual {p5}, Lntidisestablish/neumonoul/floccinaucinih/c7;->i()Lntidisestablish/neumonoul/floccinaucinih/pb;

    move-result-object p3

    invoke-static {p2, v2, p3}, Lntidisestablish/neumonoul/floccinaucinih/rs;->a(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/pb;)Lntidisestablish/neumonoul/floccinaucinih/zh;

    move-result-object v9
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    :goto_3
    invoke-virtual {p5}, Lntidisestablish/neumonoul/floccinaucinih/c7;->x()Ljava/lang/Object;

    move-result-object p5

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object p1

    if-ne p5, p1, :cond_e

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/qc;->c(Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    :cond_e
    if-ne p5, v1, :cond_f

    return-object v1

    :cond_f
    :goto_4
    check-cast p5, Lntidisestablish/neumonoul/floccinaucinih/u7;

    invoke-virtual {p5}, Lntidisestablish/neumonoul/floccinaucinih/u7;->k()Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :goto_5
    invoke-virtual {p5}, Lntidisestablish/neumonoul/floccinaucinih/c7;->I()V

    throw p1
.end method

.method private final r0(Lntidisestablish/neumonoul/floccinaucinih/w7;)V
    .locals 11

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v1, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/uk;->b(Ljava/lang/Object;ILntidisestablish/neumonoul/floccinaucinih/tc;)Ljava/lang/Object;

    move-result-object v3

    :cond_0
    sget v4, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    sub-int/2addr v4, v2

    :goto_0
    const/4 v5, -0x1

    if-ge v5, v4, :cond_b

    iget-wide v6, p1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    sget v8, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v8, v8

    mul-long/2addr v6, v8

    int-to-long v8, v4

    add-long/2addr v6, v8

    :cond_1
    invoke-virtual {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v8

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v9

    if-eq v8, v9, :cond_c

    sget-object v9, Lntidisestablish/neumonoul/floccinaucinih/d6;->d:Lntidisestablish/neumonoul/floccinaucinih/v20;

    if-ne v8, v9, :cond_3

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v9

    cmp-long v9, v6, v9

    if-ltz v9, :cond_c

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v9

    invoke-virtual {p1, v4, v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    if-eqz v0, :cond_2

    invoke-virtual {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/w7;->v(I)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v0, v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/rs;->c(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/h60;)Lntidisestablish/neumonoul/floccinaucinih/h60;

    move-result-object v1

    :cond_2
    :goto_1
    invoke-virtual {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/w7;->s(I)V

    :goto_2
    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    goto :goto_6

    :cond_3
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->k()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v9

    if-eq v8, v9, :cond_a

    if-nez v8, :cond_4

    goto :goto_5

    :cond_4
    instance-of v9, v8, Lntidisestablish/neumonoul/floccinaucinih/i70;

    if-nez v9, :cond_7

    instance-of v9, v8, Lntidisestablish/neumonoul/floccinaucinih/j70;

    if-eqz v9, :cond_5

    goto :goto_3

    :cond_5
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->p()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v9

    if-eq v8, v9, :cond_c

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->q()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v9

    if-ne v8, v9, :cond_6

    goto :goto_7

    :cond_6
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->p()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v9

    if-eq v8, v9, :cond_1

    goto :goto_6

    :cond_7
    :goto_3
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v9

    cmp-long v9, v6, v9

    if-ltz v9, :cond_c

    instance-of v9, v8, Lntidisestablish/neumonoul/floccinaucinih/j70;

    if-eqz v9, :cond_8

    move-object v9, v8

    check-cast v9, Lntidisestablish/neumonoul/floccinaucinih/j70;

    iget-object v9, v9, Lntidisestablish/neumonoul/floccinaucinih/j70;->a:Lntidisestablish/neumonoul/floccinaucinih/i70;

    goto :goto_4

    :cond_8
    move-object v9, v8

    check-cast v9, Lntidisestablish/neumonoul/floccinaucinih/i70;

    :goto_4
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v10

    invoke-virtual {p1, v4, v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    if-eqz v0, :cond_9

    invoke-virtual {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/w7;->v(I)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v0, v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/rs;->c(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/h60;)Lntidisestablish/neumonoul/floccinaucinih/h60;

    move-result-object v1

    :cond_9
    invoke-static {v3, v9}, Lntidisestablish/neumonoul/floccinaucinih/uk;->c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    goto :goto_1

    :cond_a
    :goto_5
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v9

    invoke-virtual {p1, v4, v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/w7;->r(ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    goto :goto_2

    :goto_6
    add-int/lit8 v4, v4, -0x1

    goto/16 :goto_0

    :cond_b
    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->g()Lntidisestablish/neumonoul/floccinaucinih/x9;

    move-result-object p1

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    if-nez p1, :cond_0

    :cond_c
    :goto_7
    if-eqz v3, :cond_e

    instance-of p1, v3, Ljava/util/ArrayList;

    if-nez p1, :cond_d

    check-cast v3, Lntidisestablish/neumonoul/floccinaucinih/i70;

    invoke-direct {p0, v3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->t0(Lntidisestablish/neumonoul/floccinaucinih/i70;)V

    goto :goto_9

    :cond_d
    const-string p1, "null cannot be cast to non-null type java.util.ArrayList<E of kotlinx.coroutines.internal.InlineList>{ kotlin.collections.TypeAliasesKt.ArrayList<E of kotlinx.coroutines.internal.InlineList> }"

    invoke-static {v3, p1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result p1

    sub-int/2addr p1, v2

    :goto_8
    if-ge v5, p1, :cond_e

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/i70;

    invoke-direct {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->t0(Lntidisestablish/neumonoul/floccinaucinih/i70;)V

    add-int/lit8 p1, p1, -0x1

    goto :goto_8

    :cond_e
    :goto_9
    if-nez v1, :cond_f

    return-void

    :cond_f
    throw v1
.end method

.method private final s0(Lntidisestablish/neumonoul/floccinaucinih/i70;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->u0(Lntidisestablish/neumonoul/floccinaucinih/i70;Z)V

    return-void
.end method

.method public static final synthetic t(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->n0(Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    return-void
.end method

.method private final t0(Lntidisestablish/neumonoul/floccinaucinih/i70;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->u0(Lntidisestablish/neumonoul/floccinaucinih/i70;Z)V

    return-void
.end method

.method public static final synthetic u(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->o0(Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    return-void
.end method

.method private final u0(Lntidisestablish/neumonoul/floccinaucinih/i70;Z)V
    .locals 2

    .line 1
    instance-of v0, p1, Lntidisestablish/neumonoul/floccinaucinih/b7;

    if-eqz v0, :cond_1

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/gb;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    if-eqz p2, :cond_0

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->N()Ljava/lang/Throwable;

    move-result-object p2

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object p2

    :goto_0
    invoke-static {p2}, Lntidisestablish/neumonoul/floccinaucinih/hy;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p2

    :goto_1
    invoke-static {p2}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    invoke-interface {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/gb;->q(Ljava/lang/Object;)V

    goto :goto_2

    :cond_1
    instance-of p2, p1, Lntidisestablish/neumonoul/floccinaucinih/ax;

    if-eqz p2, :cond_2

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/ax;

    iget-object p1, p1, Lntidisestablish/neumonoul/floccinaucinih/ax;->e:Lntidisestablish/neumonoul/floccinaucinih/c7;

    sget-object p2, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    sget-object p2, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object v0

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p2

    invoke-static {p2}, Lntidisestablish/neumonoul/floccinaucinih/u7;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/u7;

    move-result-object p2

    goto :goto_1

    :cond_2
    instance-of p2, p1, Lntidisestablish/neumonoul/floccinaucinih/c6$a;

    if-eqz p2, :cond_3

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/c6$a;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/c6$a;->j()V

    :goto_2
    return-void

    :cond_3
    new-instance p2, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Unexpected waiter: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public static final synthetic v(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;IJLntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-direct/range {p0 .. p5}, Lntidisestablish/neumonoul/floccinaucinih/c6;->q0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method static synthetic v0(Lntidisestablish/neumonoul/floccinaucinih/c6;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 15

    .line 1
    move-object v8, p0

    const/4 v9, 0x0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->m()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :cond_0
    :goto_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->n()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    move-result-wide v1

    const-wide v3, 0xfffffffffffffffL

    and-long v10, v1, v3

    invoke-static {p0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->o(Lntidisestablish/neumonoul/floccinaucinih/c6;J)Z

    move-result v12

    sget v1, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v2, v1

    div-long v2, v10, v2

    int-to-long v4, v1

    rem-long v4, v10, v4

    long-to-int v13, v4

    iget-wide v4, v0, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v1, v4, v2

    if-eqz v1, :cond_2

    invoke-static {p0, v2, v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->e(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v1

    if-nez v1, :cond_1

    if-eqz v12, :cond_0

    invoke-direct/range {p0 .. p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->j0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_9

    return-object v0

    :cond_1
    move-object v14, v1

    goto :goto_1

    :cond_2
    move-object v14, v0

    :goto_1
    move-object v0, p0

    move-object v1, v14

    move v2, v13

    move-object/from16 v3, p1

    move-wide v4, v10

    move-object v6, v9

    move v7, v12

    invoke-static/range {v0 .. v7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->x(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I

    move-result v0

    if-eqz v0, :cond_8

    const/4 v1, 0x1

    if-eq v0, v1, :cond_9

    const/4 v1, 0x2

    if-eq v0, v1, :cond_7

    const/4 v1, 0x3

    if-eq v0, v1, :cond_6

    const/4 v1, 0x4

    if-eq v0, v1, :cond_4

    const/4 v1, 0x5

    if-eq v0, v1, :cond_3

    goto :goto_2

    :cond_3
    invoke-virtual {v14}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :goto_2
    move-object v0, v14

    goto :goto_0

    :cond_4
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v0

    cmp-long v0, v10, v0

    if-gez v0, :cond_5

    invoke-virtual {v14}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :cond_5
    invoke-direct/range {p0 .. p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->j0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_9

    return-object v0

    :cond_6
    move-object v0, p0

    move-object v1, v14

    move v2, v13

    move-object/from16 v3, p1

    move-wide v4, v10

    move-object/from16 v6, p2

    invoke-direct/range {v0 .. v6}, Lntidisestablish/neumonoul/floccinaucinih/c6;->w0(Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_9

    return-object v0

    :cond_7
    if-eqz v12, :cond_9

    invoke-virtual {v14}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    invoke-direct/range {p0 .. p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->j0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_9

    return-object v0

    :cond_8
    invoke-virtual {v14}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :cond_9
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    return-object v0
.end method

.method public static final synthetic w(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-direct/range {p0 .. p5}, Lntidisestablish/neumonoul/floccinaucinih/c6;->C0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method private final w0(Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v9, p0

    move-object/from16 v0, p3

    invoke-static/range {p6 .. p6}, Lntidisestablish/neumonoul/floccinaucinih/kl;->b(Lntidisestablish/neumonoul/floccinaucinih/gb;)Lntidisestablish/neumonoul/floccinaucinih/gb;

    move-result-object v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/e7;->a(Lntidisestablish/neumonoul/floccinaucinih/gb;)Lntidisestablish/neumonoul/floccinaucinih/c7;

    move-result-object v10

    const/4 v8, 0x0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move-wide/from16 v5, p4

    move-object v7, v10

    :try_start_0
    invoke-static/range {v1 .. v8}, Lntidisestablish/neumonoul/floccinaucinih/c6;->x(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_10

    const/4 v11, 0x1

    if-eq v1, v11, :cond_f

    const/4 v12, 0x2

    if-eq v1, v12, :cond_e

    const/4 v13, 0x4

    if-eq v1, v13, :cond_d

    const-string v14, "unexpected"

    const/4 v15, 0x5

    if-ne v1, v15, :cond_c

    :try_start_1
    invoke-virtual/range {p1 .. p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->m()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v1

    invoke-virtual {v1, v9}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :cond_0
    :goto_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->n()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v2

    invoke-virtual {v2, v9}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    move-result-wide v2

    const-wide v4, 0xfffffffffffffffL

    and-long v16, v2, v4

    invoke-static {v9, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->o(Lntidisestablish/neumonoul/floccinaucinih/c6;J)Z

    move-result v18

    sget v2, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v3, v2

    div-long v3, v16, v3

    int-to-long v5, v2

    rem-long v5, v16, v5

    long-to-int v8, v5

    iget-wide v5, v1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v2, v5, v3

    if-eqz v2, :cond_3

    invoke-static {v9, v3, v4, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->e(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v2

    if-nez v2, :cond_2

    if-eqz v18, :cond_0

    :cond_1
    :goto_1
    invoke-static {v9, v0, v10}, Lntidisestablish/neumonoul/floccinaucinih/c6;->q(Lntidisestablish/neumonoul/floccinaucinih/c6;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/b7;)V

    goto/16 :goto_6

    :catchall_0
    move-exception v0

    goto/16 :goto_7

    :cond_2
    move-object v7, v2

    goto :goto_2

    :cond_3
    move-object v7, v1

    :goto_2
    move-object/from16 v1, p0

    move-object v2, v7

    move v3, v8

    move-object/from16 v4, p3

    move-wide/from16 v5, v16

    move-object/from16 p1, v7

    move-object v7, v10

    move/from16 v19, v8

    move/from16 v8, v18

    invoke-static/range {v1 .. v8}, Lntidisestablish/neumonoul/floccinaucinih/c6;->x(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I

    move-result v1

    if-eqz v1, :cond_b

    if-eq v1, v11, :cond_a

    if-eq v1, v12, :cond_7

    const/4 v2, 0x3

    if-eq v1, v2, :cond_6

    if-eq v1, v13, :cond_5

    if-eq v1, v15, :cond_4

    goto :goto_3

    :cond_4
    invoke-virtual/range {p1 .. p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :goto_3
    move-object/from16 v1, p1

    goto :goto_0

    :cond_5
    invoke-virtual/range {p0 .. p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v1

    cmp-long v1, v16, v1

    if-gez v1, :cond_1

    invoke-virtual/range {p1 .. p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    goto :goto_1

    :cond_6
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v14}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7
    if-eqz v18, :cond_8

    invoke-virtual/range {p1 .. p1}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    goto :goto_1

    :cond_8
    instance-of v0, v10, Lntidisestablish/neumonoul/floccinaucinih/i70;

    if-eqz v0, :cond_9

    move-object v0, v10

    goto :goto_4

    :cond_9
    const/4 v0, 0x0

    :goto_4
    if-eqz v0, :cond_11

    move-object/from16 v2, p1

    move/from16 v1, v19

    invoke-static {v9, v0, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->u(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    goto :goto_6

    :cond_a
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_5
    invoke-interface {v10, v0}, Lntidisestablish/neumonoul/floccinaucinih/gb;->q(Ljava/lang/Object;)V

    goto :goto_6

    :cond_b
    move-object/from16 v2, p1

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    goto :goto_5

    :cond_c
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v14}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_d
    invoke-virtual/range {p0 .. p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v1

    cmp-long v1, p4, v1

    if-gez v1, :cond_1

    invoke-virtual/range {p1 .. p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    goto/16 :goto_1

    :cond_e
    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-static {v9, v10, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->u(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    goto :goto_6

    :cond_f
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    goto :goto_5

    :cond_10
    move-object/from16 v0, p1

    invoke-virtual/range {p1 .. p1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/gy;->e:Lntidisestablish/neumonoul/floccinaucinih/gy$a;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/gy;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_5

    :cond_11
    :goto_6
    invoke-virtual {v10}, Lntidisestablish/neumonoul/floccinaucinih/c7;->x()Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_12

    invoke-static/range {p6 .. p6}, Lntidisestablish/neumonoul/floccinaucinih/qc;->c(Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    :cond_12
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_13

    return-object v0

    :cond_13
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    return-object v0

    :goto_7
    invoke-virtual {v10}, Lntidisestablish/neumonoul/floccinaucinih/c7;->I()V

    throw v0
.end method

.method public static final synthetic x(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I
    .locals 0

    .line 1
    invoke-direct/range {p0 .. p7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->E0(Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I

    move-result p0

    return p0
.end method

.method private final x0(J)Z
    .locals 2

    .line 1
    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Z(J)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    const-wide v0, 0xfffffffffffffffL

    and-long/2addr p1, v0

    invoke-direct {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->y(J)Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    return p1
.end method

.method private final y(J)Z
    .locals 4

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v0

    cmp-long v0, p1, v0

    if-ltz v0, :cond_1

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v0

    iget v2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->e:I

    int-to-long v2, v2

    add-long/2addr v0, v2

    cmp-long p1, p1, v0

    if-gez p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method

.method private final y0(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 4

    .line 1
    instance-of v0, p1, Lntidisestablish/neumonoul/floccinaucinih/ax;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    const-string v0, "null cannot be cast to non-null type kotlinx.coroutines.channels.ReceiveCatching<E of kotlinx.coroutines.channels.BufferedChannel>"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/ax;

    iget-object v0, p1, Lntidisestablish/neumonoul/floccinaucinih/ax;->e:Lntidisestablish/neumonoul/floccinaucinih/c7;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {v2, p2}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/u7;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/u7;

    move-result-object v2

    iget-object v3, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz v3, :cond_0

    iget-object p1, p1, Lntidisestablish/neumonoul/floccinaucinih/ax;->e:Lntidisestablish/neumonoul/floccinaucinih/c7;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/c7;->i()Lntidisestablish/neumonoul/floccinaucinih/pb;

    move-result-object p1

    invoke-static {v3, p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/rs;->a(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/pb;)Lntidisestablish/neumonoul/floccinaucinih/zh;

    move-result-object v1

    :cond_0
    invoke-static {v0, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/d6;->u(Lntidisestablish/neumonoul/floccinaucinih/b7;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/zh;)Z

    move-result p1

    goto :goto_0

    :cond_1
    instance-of v0, p1, Lntidisestablish/neumonoul/floccinaucinih/c6$a;

    if-eqz v0, :cond_2

    const-string v0, "null cannot be cast to non-null type kotlinx.coroutines.channels.BufferedChannel.BufferedChannelIterator<E of kotlinx.coroutines.channels.BufferedChannel>"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/c6$a;

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6$a;->i(Ljava/lang/Object;)Z

    move-result p1

    goto :goto_0

    :cond_2
    instance-of v0, p1, Lntidisestablish/neumonoul/floccinaucinih/b7;

    if-eqz v0, :cond_4

    const-string v0, "null cannot be cast to non-null type kotlinx.coroutines.CancellableContinuation<E of kotlinx.coroutines.channels.BufferedChannel>"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/b7;

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz v0, :cond_3

    invoke-interface {p1}, Lntidisestablish/neumonoul/floccinaucinih/gb;->i()Lntidisestablish/neumonoul/floccinaucinih/pb;

    move-result-object v1

    invoke-static {v0, p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/rs;->a(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/pb;)Lntidisestablish/neumonoul/floccinaucinih/zh;

    move-result-object v1

    :cond_3
    invoke-static {p1, p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/d6;->u(Lntidisestablish/neumonoul/floccinaucinih/b7;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/zh;)Z

    move-result p1

    :goto_0
    return p1

    :cond_4
    new-instance p2, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Unexpected receiver type: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method private final z0(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/w7;I)Z
    .locals 1

    .line 1
    instance-of p2, p1, Lntidisestablish/neumonoul/floccinaucinih/b7;

    if-eqz p2, :cond_0

    const-string p2, "null cannot be cast to non-null type kotlinx.coroutines.CancellableContinuation<kotlin.Unit>"

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/jl;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lntidisestablish/neumonoul/floccinaucinih/b7;

    sget-object p2, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    const/4 p3, 0x2

    const/4 v0, 0x0

    invoke-static {p1, p2, v0, p3, v0}, Lntidisestablish/neumonoul/floccinaucinih/d6;->C(Lntidisestablish/neumonoul/floccinaucinih/b7;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/zh;ILjava/lang/Object;)Z

    move-result p1

    return p1

    :cond_0
    new-instance p2, Ljava/lang/IllegalStateException;

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Unexpected waiter: "

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2
.end method


# virtual methods
.method protected C(Ljava/lang/Throwable;Z)Z
    .locals 2

    .line 1
    if-eqz p2, :cond_0

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->d0()V

    :cond_0
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->o:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->l()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v1

    invoke-static {v0, p0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p2, :cond_1

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->e0()V

    goto :goto_0

    :cond_1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->f0()V

    :goto_0
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->F()V

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->h0()V

    if-eqz p1, :cond_2

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->U()V

    :cond_2
    return p1
.end method

.method protected final G(J)V
    .locals 10

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :cond_0
    :goto_0
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v8

    iget v2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->e:I

    int-to-long v2, v2

    add-long/2addr v2, v8

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v4

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v2

    cmp-long v2, p1, v2

    if-gez v2, :cond_1

    return-void

    :cond_1
    const-wide/16 v2, 0x1

    add-long v5, v8, v2

    move-object v2, p0

    move-wide v3, v8

    invoke-virtual/range {v1 .. v6}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result v1

    if-eqz v1, :cond_0

    sget v1, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v2, v1

    div-long v2, v8, v2

    int-to-long v4, v1

    rem-long v4, v8, v4

    long-to-int v4, v4

    iget-wide v5, v0, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v1, v5, v2

    if-eqz v1, :cond_3

    invoke-direct {p0, v2, v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->J(JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    move-object v0, v1

    :cond_3
    const/4 v7, 0x0

    move-object v2, p0

    move-object v3, v0

    move-wide v5, v8

    invoke-direct/range {v2 .. v7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->C0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    if-ne v1, v2, :cond_4

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v1

    cmp-long v1, v8, v1

    if-gez v1, :cond_0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    goto :goto_0

    :cond_4
    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/c6;->f:Lntidisestablish/neumonoul/floccinaucinih/zh;

    if-eqz v2, :cond_0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v2, v1, v4, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/rs;->d(Lntidisestablish/neumonoul/floccinaucinih/zh;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/h60;ILjava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/h60;

    move-result-object v1

    if-nez v1, :cond_5

    goto :goto_0

    :cond_5
    throw v1
.end method

.method public final I0(J)V
    .locals 13

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->b0()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v0

    cmp-long v0, v0, p1

    if-lez v0, :cond_0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->g()I

    move-result p1

    const/4 v0, 0x0

    move p2, v0

    :goto_0
    const-wide v1, 0x3fffffffffffffffL    # 1.9999999999999998

    if-ge p2, p1, :cond_2

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v3

    sget-object v5, Lntidisestablish/neumonoul/floccinaucinih/c6;->k:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v5, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v5

    and-long/2addr v1, v5

    cmp-long v1, v3, v1

    if-nez v1, :cond_1

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v1

    cmp-long v1, v3, v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_2
    sget-object v9, Lntidisestablish/neumonoul/floccinaucinih/c6;->k:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    :cond_3
    invoke-virtual {v9, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v5

    and-long p1, v5, v1

    const/4 v10, 0x1

    invoke-static {p1, p2, v10}, Lntidisestablish/neumonoul/floccinaucinih/d6;->a(JZ)J

    move-result-wide v7

    move-object v3, v9

    move-object v4, p0

    invoke-virtual/range {v3 .. v8}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result p1

    if-eqz p1, :cond_3

    :cond_4
    :goto_1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide p1

    sget-object v9, Lntidisestablish/neumonoul/floccinaucinih/c6;->k:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v9, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v5

    and-long v3, v5, v1

    const-wide/high16 v7, 0x4000000000000000L    # 2.0

    and-long/2addr v7, v5

    const-wide/16 v11, 0x0

    cmp-long v7, v7, v11

    if-eqz v7, :cond_5

    move v7, v10

    goto :goto_2

    :cond_5
    move v7, v0

    :goto_2
    cmp-long v8, p1, v3

    if-nez v8, :cond_7

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->L()J

    move-result-wide v11

    cmp-long p1, p1, v11

    if-nez p1, :cond_7

    :cond_6
    invoke-virtual {v9, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v5

    and-long p1, v5, v1

    invoke-static {p1, p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/d6;->a(JZ)J

    move-result-wide v7

    move-object v3, v9

    move-object v4, p0

    invoke-virtual/range {v3 .. v8}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    move-result p1

    if-eqz p1, :cond_6

    return-void

    :cond_7
    if-nez v7, :cond_4

    invoke-static {v3, v4, v10}, Lntidisestablish/neumonoul/floccinaucinih/d6;->a(JZ)J

    move-result-wide v7

    move-object v3, v9

    move-object v4, p0

    invoke-virtual/range {v3 .. v8}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    goto :goto_1
.end method

.method protected final M()Ljava/lang/Throwable;
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->o:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Throwable;

    return-object v0
.end method

.method public final O()J
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v0

    return-wide v0
.end method

.method protected final P()Ljava/lang/Throwable;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object v0

    if-nez v0, :cond_0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/p8;

    const-string v1, "Channel was closed"

    invoke-direct {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/p8;-><init>(Ljava/lang/String;)V

    :cond_0
    return-object v0
.end method

.method public final Q()J
    .locals 4

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v0

    const-wide v2, 0xfffffffffffffffL

    and-long/2addr v0, v2

    return-wide v0
.end method

.method public final R()Z
    .locals 10

    .line 1
    :cond_0
    :goto_0
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v4

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v2

    cmp-long v2, v2, v4

    const/4 v3, 0x0

    if-gtz v2, :cond_1

    return v3

    :cond_1
    sget v2, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v6, v2

    div-long v6, v4, v6

    iget-wide v8, v1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v8, v8, v6

    if-eqz v8, :cond_2

    invoke-direct {p0, v6, v7, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->J(JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v1

    if-nez v1, :cond_2

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v0, v0, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v0, v0, v6

    if-gez v0, :cond_0

    return v3

    :cond_2
    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    int-to-long v2, v2

    rem-long v2, v4, v2

    long-to-int v0, v2

    invoke-direct {p0, v1, v0, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/c6;->V(Lntidisestablish/neumonoul/floccinaucinih/w7;IJ)Z

    move-result v0

    if-eqz v0, :cond_3

    const/4 v0, 0x1

    return v0

    :cond_3
    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    const-wide/16 v0, 0x1

    add-long v6, v4, v0

    move-object v3, p0

    invoke-virtual/range {v2 .. v7}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    goto :goto_0
.end method

.method public X()Z
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Y(J)Z

    move-result v0

    return v0
.end method

.method public final a(Ljava/util/concurrent/CancellationException;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->z(Ljava/lang/Throwable;)Z

    return-void
.end method

.method protected a0()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public c(Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->v0(Lntidisestablish/neumonoul/floccinaucinih/c6;Ljava/lang/Object;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->p0(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public f(Lntidisestablish/neumonoul/floccinaucinih/zh;)V
    .locals 4

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->p:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v1, 0x0

    invoke-static {v0, p0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->d()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    if-ne v1, v2, :cond_1

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/c6;->p:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->d()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->e()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v3

    invoke-static {v1, p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/m;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object v0

    invoke-interface {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/zh;->r(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->e()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object p1

    if-ne v1, p1, :cond_2

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Another handler was already registered and successfully invoked"

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Another handler is already registered: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public h()Ljava/lang/Object;
    .locals 11

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->i:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v2, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v2

    invoke-direct {p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Y(J)Z

    move-result v4

    if-eqz v4, :cond_0

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_0
    const-wide v4, 0xfffffffffffffffL

    and-long/2addr v2, v4

    cmp-long v0, v0, v2

    if-ltz v0, :cond_1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->b()Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_1
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->i()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->i()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :goto_0
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->X()Z

    move-result v2

    if-eqz v2, :cond_2

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->M()Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    goto/16 :goto_3

    :cond_2
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->j()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v2

    invoke-virtual {v2, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    move-result-wide v7

    sget v2, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v3, v2

    div-long v3, v7, v3

    int-to-long v5, v2

    rem-long v5, v7, v5

    long-to-int v9, v5

    iget-wide v5, v1, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v2, v5, v3

    if-eqz v2, :cond_4

    invoke-static {p0, v3, v4, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->b(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v2

    if-nez v2, :cond_3

    goto :goto_0

    :cond_3
    move-object v10, v2

    goto :goto_1

    :cond_4
    move-object v10, v1

    :goto_1
    move-object v1, p0

    move-object v2, v10

    move v3, v9

    move-wide v4, v7

    move-object v6, v0

    invoke-static/range {v1 .. v6}, Lntidisestablish/neumonoul/floccinaucinih/c6;->w(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;IJLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->r()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    if-ne v1, v2, :cond_7

    instance-of v1, v0, Lntidisestablish/neumonoul/floccinaucinih/i70;

    if-eqz v1, :cond_5

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/i70;

    goto :goto_2

    :cond_5
    const/4 v0, 0x0

    :goto_2
    if-eqz v0, :cond_6

    invoke-static {p0, v0, v10, v9}, Lntidisestablish/neumonoul/floccinaucinih/c6;->t(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    :cond_6
    invoke-virtual {p0, v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/c6;->I0(J)V

    invoke-virtual {v10}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->b()Ljava/lang/Object;

    move-result-object v0

    goto :goto_3

    :cond_7
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->h()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v2

    if-ne v1, v2, :cond_9

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v1

    cmp-long v1, v7, v1

    if-gez v1, :cond_8

    invoke-virtual {v10}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :cond_8
    move-object v1, v10

    goto :goto_0

    :cond_9
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->s()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v0

    if-eq v1, v0, :cond_a

    invoke-virtual {v10}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_3
    return-object v0

    :cond_a
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "unexpected"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method protected h0()V
    .locals 0

    .line 1
    return-void
.end method

.method public iterator()Lntidisestablish/neumonoul/floccinaucinih/s7;
    .locals 1

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/c6$a;

    invoke-direct {v0, p0}, Lntidisestablish/neumonoul/floccinaucinih/c6$a;-><init>(Lntidisestablish/neumonoul/floccinaucinih/c6;)V

    return-object v0
.end method

.method public k(Ljava/lang/Throwable;)Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->C(Ljava/lang/Throwable;Z)Z

    move-result p1

    return p1
.end method

.method public l(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->x0(J)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->b()Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :cond_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v8

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->m()Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/w7;

    :cond_1
    :goto_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/c6;->n()Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    move-result-wide v1

    const-wide v3, 0xfffffffffffffffL

    and-long v9, v1, v3

    invoke-static {p0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/c6;->o(Lntidisestablish/neumonoul/floccinaucinih/c6;J)Z

    move-result v11

    sget v1, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v2, v1

    div-long v2, v9, v2

    int-to-long v4, v1

    rem-long v4, v9, v4

    long-to-int v12, v4

    iget-wide v4, v0, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v1, v4, v2

    if-eqz v1, :cond_4

    invoke-static {p0, v2, v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->e(Lntidisestablish/neumonoul/floccinaucinih/c6;JLntidisestablish/neumonoul/floccinaucinih/w7;)Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v1

    if-nez v1, :cond_3

    if-eqz v11, :cond_1

    :cond_2
    :goto_1
    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->P()Ljava/lang/Throwable;

    move-result-object v0

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    goto/16 :goto_6

    :cond_3
    move-object v13, v1

    goto :goto_2

    :cond_4
    move-object v13, v0

    :goto_2
    move-object v0, p0

    move-object v1, v13

    move v2, v12

    move-object v3, p1

    move-wide v4, v9

    move-object v6, v8

    move v7, v11

    invoke-static/range {v0 .. v7}, Lntidisestablish/neumonoul/floccinaucinih/c6;->x(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;ILjava/lang/Object;JLjava/lang/Object;Z)I

    move-result v0

    if-eqz v0, :cond_d

    const/4 v1, 0x1

    if-eq v0, v1, :cond_c

    const/4 v1, 0x2

    if-eq v0, v1, :cond_8

    const/4 v1, 0x3

    if-eq v0, v1, :cond_7

    const/4 v1, 0x4

    if-eq v0, v1, :cond_6

    const/4 v1, 0x5

    if-eq v0, v1, :cond_5

    goto :goto_3

    :cond_5
    invoke-virtual {v13}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    :goto_3
    move-object v0, v13

    goto :goto_0

    :cond_6
    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v0

    cmp-long p1, v9, v0

    if-gez p1, :cond_2

    invoke-virtual {v13}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    goto :goto_1

    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "unexpected"

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_8
    if-eqz v11, :cond_9

    invoke-virtual {v13}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    goto :goto_1

    :cond_9
    instance-of p1, v8, Lntidisestablish/neumonoul/floccinaucinih/i70;

    if-eqz p1, :cond_a

    check-cast v8, Lntidisestablish/neumonoul/floccinaucinih/i70;

    goto :goto_4

    :cond_a
    const/4 v8, 0x0

    :goto_4
    if-eqz v8, :cond_b

    invoke-static {p0, v8, v13, v12}, Lntidisestablish/neumonoul/floccinaucinih/c6;->u(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/i70;Lntidisestablish/neumonoul/floccinaucinih/w7;I)V

    :cond_b
    invoke-virtual {v13}, Lntidisestablish/neumonoul/floccinaucinih/kz;->p()V

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->b()Ljava/lang/Object;

    move-result-object p1

    goto :goto_6

    :cond_c
    :goto_5
    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/u7;->b:Lntidisestablish/neumonoul/floccinaucinih/u7$b;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/m60;->a:Lntidisestablish/neumonoul/floccinaucinih/m60;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/u7$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    goto :goto_6

    :cond_d
    invoke-virtual {v13}, Lntidisestablish/neumonoul/floccinaucinih/x9;->b()V

    goto :goto_5

    :goto_6
    return-object p1
.end method

.method protected l0()V
    .locals 0

    .line 1
    return-void
.end method

.method protected m0()V
    .locals 0

    .line 1
    return-void
.end method

.method public r()Z
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Z(J)Z

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/c6;->h:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {v2, v0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    move-result-wide v2

    const/16 v4, 0x3c

    shr-long/2addr v2, v4

    long-to-int v2, v2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eq v2, v4, :cond_1

    if-eq v2, v3, :cond_0

    goto :goto_1

    :cond_0
    const-string v2, "cancelled,"

    :goto_0
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_1
    const-string v2, "closed,"

    goto :goto_0

    :goto_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "capacity="

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v5, v0, Lntidisestablish/neumonoul/floccinaucinih/c6;->e:I

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v5, 0x2c

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "data=["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v3, [Lntidisestablish/neumonoul/floccinaucinih/w7;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/c6;->m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v3, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    aput-object v3, v2, v6

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/c6;->l:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v3, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    aput-object v3, v2, v7

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/c6;->n:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-virtual {v3, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v2}, Lntidisestablish/neumonoul/floccinaucinih/u8;->j([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v8, v4

    check-cast v8, Lntidisestablish/neumonoul/floccinaucinih/w7;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->n()Lntidisestablish/neumonoul/floccinaucinih/w7;

    move-result-object v9

    if-eq v8, v9, :cond_2

    invoke-interface {v3, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_3
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_4

    goto :goto_3

    :cond_4
    move-object v4, v3

    check-cast v4, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v8, v4, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    :cond_5
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v10, v4

    check-cast v10, Lntidisestablish/neumonoul/floccinaucinih/w7;

    iget-wide v10, v10, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    cmp-long v12, v8, v10

    if-lez v12, :cond_6

    move-object v3, v4

    move-wide v8, v10

    :cond_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_5

    :goto_3
    check-cast v3, Lntidisestablish/neumonoul/floccinaucinih/w7;

    invoke-virtual/range {p0 .. p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->O()J

    move-result-wide v10

    invoke-virtual/range {p0 .. p0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->Q()J

    move-result-wide v12

    :goto_4
    sget v2, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    move v4, v6

    :goto_5
    if-ge v4, v2, :cond_17

    iget-wide v8, v3, Lntidisestablish/neumonoul/floccinaucinih/kz;->g:J

    sget v14, Lntidisestablish/neumonoul/floccinaucinih/d6;->b:I

    int-to-long v14, v14

    mul-long/2addr v8, v14

    int-to-long v14, v4

    add-long/2addr v8, v14

    cmp-long v14, v8, v12

    if-ltz v14, :cond_7

    cmp-long v15, v8, v10

    if-gez v15, :cond_18

    :cond_7
    invoke-virtual {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/w7;->w(I)Ljava/lang/Object;

    move-result-object v15

    invoke-virtual {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/w7;->v(I)Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v15, Lntidisestablish/neumonoul/floccinaucinih/b7;

    if-eqz v7, :cond_a

    cmp-long v7, v8, v10

    if-gez v7, :cond_8

    if-ltz v14, :cond_8

    const-string v7, "receive"

    goto/16 :goto_7

    :cond_8
    if-gez v14, :cond_9

    if-ltz v7, :cond_9

    const-string v7, "send"

    goto/16 :goto_7

    :cond_9
    const-string v7, "cont"

    goto/16 :goto_7

    :cond_a
    instance-of v7, v15, Lntidisestablish/neumonoul/floccinaucinih/ax;

    if-eqz v7, :cond_b

    const-string v7, "receiveCatching"

    goto/16 :goto_7

    :cond_b
    instance-of v7, v15, Lntidisestablish/neumonoul/floccinaucinih/j70;

    if-eqz v7, :cond_c

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "EB("

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v8, 0x29

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    goto :goto_7

    :cond_c
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->q()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_d

    goto :goto_6

    :cond_d
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->p()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_e

    :goto_6
    const-string v7, "resuming_sender"

    goto :goto_7

    :cond_e
    if-nez v15, :cond_f

    goto/16 :goto_9

    :cond_f
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->k()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_10

    goto/16 :goto_9

    :cond_10
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->f()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_11

    goto :goto_9

    :cond_11
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->o()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_12

    goto :goto_9

    :cond_12
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->i()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_13

    goto :goto_9

    :cond_13
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->j()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_14

    goto :goto_9

    :cond_14
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/d6;->z()Lntidisestablish/neumonoul/floccinaucinih/v20;

    move-result-object v7

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/jl;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_16

    invoke-virtual {v15}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    :goto_7
    if-eqz v6, :cond_15

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v9, 0x28

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, "),"

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    :goto_8
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_9

    :cond_15
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    goto :goto_8

    :cond_16
    :goto_9
    add-int/lit8 v4, v4, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_5

    :cond_17
    invoke-virtual {v3}, Lntidisestablish/neumonoul/floccinaucinih/x9;->e()Lntidisestablish/neumonoul/floccinaucinih/x9;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Lntidisestablish/neumonoul/floccinaucinih/w7;

    if-nez v3, :cond_1a

    :cond_18
    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/t10;->E0(Ljava/lang/CharSequence;)C

    move-result v2

    if-ne v2, v5, :cond_19

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    const/4 v4, 0x1

    sub-int/2addr v2, v4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "this.deleteCharAt(index)"

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_19
    const-string v2, "]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    :cond_1a
    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_4

    :cond_1b
    new-instance v1, Ljava/util/NoSuchElementException;

    invoke-direct {v1}, Ljava/util/NoSuchElementException;-><init>()V

    throw v1
.end method

.method public z(Ljava/lang/Throwable;)Z
    .locals 1

    .line 1
    if-nez p1, :cond_0

    new-instance p1, Ljava/util/concurrent/CancellationException;

    const-string v0, "Channel was cancelled"

    invoke-direct {p1, v0}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    :cond_0
    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/c6;->C(Ljava/lang/Throwable;Z)Z

    move-result p1

    return p1
.end method
