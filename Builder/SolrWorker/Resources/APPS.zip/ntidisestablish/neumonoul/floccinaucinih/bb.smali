.class public interface abstract Lntidisestablish/neumonoul/floccinaucinih/bb;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/Object;)V
.end method
