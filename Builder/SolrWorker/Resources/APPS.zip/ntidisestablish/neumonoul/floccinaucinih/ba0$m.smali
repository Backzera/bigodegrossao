.class Lntidisestablish/neumonoul/floccinaucinih/ba0$m;
.super Lntidisestablish/neumonoul/floccinaucinih/m00;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/ba0;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Lntidisestablish/neumonoul/floccinaucinih/ba0;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0$m;->d:Lntidisestablish/neumonoul/floccinaucinih/ba0;

    invoke-direct {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/m00;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    return-void
.end method


# virtual methods
.method public e()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "UPDATE workspec SET stop_reason = CASE WHEN state=1 THEN 1 ELSE -256 END, state=5 WHERE id=?"

    return-object v0
.end method
