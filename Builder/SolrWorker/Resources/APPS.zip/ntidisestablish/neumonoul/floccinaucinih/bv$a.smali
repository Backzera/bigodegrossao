.class public final Lntidisestablish/neumonoul/floccinaucinih/bv$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lntidisestablish/neumonoul/floccinaucinih/bv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/bv$a$a;
    }
.end annotation


# static fields
.field static final synthetic a:Lntidisestablish/neumonoul/floccinaucinih/bv$a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/bv$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/bv$a;-><init>()V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/bv$a;->a:Lntidisestablish/neumonoul/floccinaucinih/bv$a;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
