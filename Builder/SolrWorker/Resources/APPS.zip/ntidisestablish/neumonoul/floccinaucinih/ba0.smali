.class public final Lntidisestablish/neumonoul/floccinaucinih/ba0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/aa0;


# instance fields
.field private final a:Lntidisestablish/neumonoul/floccinaucinih/ny;

.field private final b:Lntidisestablish/neumonoul/floccinaucinih/ff;

.field private final c:Lntidisestablish/neumonoul/floccinaucinih/ef;

.field private final d:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final e:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final f:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final g:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final h:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final i:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final j:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final k:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final l:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final m:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final n:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final o:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final p:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final q:Lntidisestablish/neumonoul/floccinaucinih/m00;

.field private final r:Lntidisestablish/neumonoul/floccinaucinih/m00;


# direct methods
.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/ny;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$i;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$i;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->b:Lntidisestablish/neumonoul/floccinaucinih/ff;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$j;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$j;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->c:Lntidisestablish/neumonoul/floccinaucinih/ef;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$k;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$k;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->d:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$l;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$l;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->e:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$m;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$m;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->f:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$n;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$n;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->g:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$o;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$o;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->h:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$p;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$p;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->i:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$q;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$q;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->j:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$a;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$a;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->k:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$b;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$b;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->l:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$c;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$c;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->m:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$d;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$d;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->n:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$e;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$e;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->o:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$f;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$f;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->p:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$g;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$g;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->q:Lntidisestablish/neumonoul/floccinaucinih/m00;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ba0$h;

    invoke-direct {v0, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ba0$h;-><init>(Lntidisestablish/neumonoul/floccinaucinih/ba0;Lntidisestablish/neumonoul/floccinaucinih/ny;)V

    iput-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->r:Lntidisestablish/neumonoul/floccinaucinih/m00;

    return-void
.end method

.method public static A()Ljava/util/List;
    .locals 1

    .line 1
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->d:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    if-nez p1, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->d:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return-void

    :catchall_0
    move-exception p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->d:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public b(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/f90;
    .locals 4

    .line 1
    const-string v0, "SELECT state FROM workspec WHERE id=?"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v0

    if-nez p1, :cond_0

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->X(I)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p1

    :try_start_0
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {p1, v1}, Landroid/database/Cursor;->isNull(I)Z

    move-result v3

    if-eqz v3, :cond_1

    move-object v1, v2

    goto :goto_1

    :cond_1
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    :goto_1
    if-nez v1, :cond_2

    goto :goto_2

    :cond_2
    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ha0;->a:Lntidisestablish/neumonoul/floccinaucinih/ha0;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    :catchall_0
    move-exception v1

    goto :goto_3

    :cond_3
    :goto_2
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v2

    :goto_3
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v1
.end method

.method public c(I)Ljava/util/List;
    .locals 77

    .line 1
    move-object/from16 v1, p0

    const-string v0, "SELECT * FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY last_enqueue_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND LENGTH(content_uri_triggers)=0 AND state NOT IN (2, 3, 5))"

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v3

    move/from16 v0, p1

    int-to-long v4, v0

    invoke-virtual {v3, v2, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/qy;->C(IJ)V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v6

    :try_start_0
    const-string v0, "id"

    invoke-static {v6, v0}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v0

    const-string v7, "state"

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    const-string v8, "worker_class_name"

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v8

    const-string v9, "input_merger_class_name"

    invoke-static {v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v9

    const-string v10, "input"

    invoke-static {v6, v10}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v10

    const-string v11, "output"

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v11

    const-string v12, "initial_delay"

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v12

    const-string v13, "interval_duration"

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v13

    const-string v14, "flex_duration"

    invoke-static {v6, v14}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v14

    const-string v15, "run_attempt_count"

    invoke-static {v6, v15}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v15

    const-string v2, "backoff_policy"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    const-string v4, "backoff_delay_duration"

    invoke-static {v6, v4}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v5, "last_enqueue_time"

    invoke-static {v6, v5}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v5

    const-string v1, "minimum_retention_duration"

    invoke-static {v6, v1}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v16, v3

    :try_start_1
    const-string v3, "schedule_requested_at"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v17, v3

    const-string v3, "run_in_foreground"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v18, v3

    const-string v3, "out_of_quota_policy"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v19, v3

    const-string v3, "period_count"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v20, v3

    const-string v3, "generation"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v21, v3

    const-string v3, "next_schedule_time_override"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v22, v3

    const-string v3, "next_schedule_time_override_generation"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v23, v3

    const-string v3, "stop_reason"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v24, v3

    const-string v3, "required_network_type"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v25, v3

    const-string v3, "requires_charging"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v26, v3

    const-string v3, "requires_device_idle"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v27, v3

    const-string v3, "requires_battery_not_low"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v28, v3

    const-string v3, "requires_storage_not_low"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v29, v3

    const-string v3, "trigger_content_update_delay"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v30, v3

    const-string v3, "trigger_max_content_delay"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v31, v3

    const-string v3, "content_uri_triggers"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v32, v3

    new-instance v3, Ljava/util/ArrayList;

    move/from16 v33, v1

    invoke-interface {v6}, Landroid/database/Cursor;->getCount()I

    move-result v1

    invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_0
    invoke-interface {v6}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-interface {v6, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v35, 0x0

    goto :goto_1

    :cond_0
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v35, v1

    :goto_1
    invoke-interface {v6, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v36

    invoke-interface {v6, v8}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v37, 0x0

    goto :goto_2

    :cond_1
    invoke-interface {v6, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v37, v1

    :goto_2
    invoke-interface {v6, v9}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 v38, 0x0

    goto :goto_3

    :cond_2
    invoke-interface {v6, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v38, v1

    :goto_3
    invoke-interface {v6, v10}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x0

    goto :goto_4

    :cond_3
    invoke-interface {v6, v10}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_4
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v39

    invoke-interface {v6, v11}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, 0x0

    goto :goto_5

    :cond_4
    invoke-interface {v6, v11}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_5
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v40

    invoke-interface {v6, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v41

    invoke-interface {v6, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v43

    invoke-interface {v6, v14}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v45

    invoke-interface {v6, v15}, Landroid/database/Cursor;->getInt(I)I

    move-result v48

    invoke-interface {v6, v2}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->c(I)Lntidisestablish/neumonoul/floccinaucinih/a5;

    move-result-object v49

    invoke-interface {v6, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v50

    invoke-interface {v6, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v52

    move/from16 v1, v33

    invoke-interface {v6, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v54

    move/from16 v33, v0

    move/from16 v0, v17

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v56

    move/from16 v17, v0

    move/from16 v0, v18

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v18

    if-eqz v18, :cond_5

    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x1

    goto :goto_6

    :cond_5
    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x0

    :goto_6
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v19

    invoke-static/range {v19 .. v19}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->e(I)Lntidisestablish/neumonoul/floccinaucinih/zs;

    move-result-object v59

    move/from16 v19, v0

    move/from16 v0, v20

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v60

    move/from16 v20, v0

    move/from16 v0, v21

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v61

    move/from16 v21, v0

    move/from16 v0, v22

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v62

    move/from16 v22, v0

    move/from16 v0, v23

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v64

    move/from16 v23, v0

    move/from16 v0, v24

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v65

    move/from16 v24, v0

    move/from16 v0, v25

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v25

    invoke-static/range {v25 .. v25}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->d(I)Lntidisestablish/neumonoul/floccinaucinih/kr;

    move-result-object v67

    move/from16 v25, v0

    move/from16 v0, v26

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v26

    if-eqz v26, :cond_6

    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x1

    goto :goto_7

    :cond_6
    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x0

    :goto_7
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v27

    if-eqz v27, :cond_7

    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x1

    goto :goto_8

    :cond_7
    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x0

    :goto_8
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v28

    if-eqz v28, :cond_8

    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x1

    goto :goto_9

    :cond_8
    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x0

    :goto_9
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v29

    if-eqz v29, :cond_9

    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x1

    goto :goto_a

    :cond_9
    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x0

    :goto_a
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v72

    move/from16 v30, v0

    move/from16 v0, v31

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v74

    move/from16 v31, v0

    move/from16 v0, v32

    invoke-interface {v6, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v32

    if-eqz v32, :cond_a

    const/16 v32, 0x0

    goto :goto_b

    :cond_a
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v32

    :goto_b
    invoke-static/range {v32 .. v32}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->b([B)Ljava/util/Set;

    move-result-object v76

    new-instance v47, Lntidisestablish/neumonoul/floccinaucinih/xa;

    move-object/from16 v66, v47

    invoke-direct/range {v66 .. v76}, Lntidisestablish/neumonoul/floccinaucinih/xa;-><init>(Lntidisestablish/neumonoul/floccinaucinih/kr;ZZZZJJLjava/util/Set;)V

    move/from16 v32, v0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/z90;

    move-object/from16 v34, v0

    invoke-direct/range {v34 .. v65}, Lntidisestablish/neumonoul/floccinaucinih/z90;-><init>(Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;Ljava/lang/String;Landroidx/work/b;Landroidx/work/b;JJJLntidisestablish/neumonoul/floccinaucinih/xa;ILntidisestablish/neumonoul/floccinaucinih/a5;JJJJZLntidisestablish/neumonoul/floccinaucinih/zs;IIJII)V

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move/from16 v0, v33

    move/from16 v33, v1

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    goto :goto_c

    :cond_b
    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v3

    :catchall_1
    move-exception v0

    move-object/from16 v16, v3

    :goto_c
    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v0
.end method

.method public d(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/z90;
    .locals 75

    .line 1
    move-object/from16 v1, p0

    move-object/from16 v0, p1

    const-string v2, "SELECT * FROM workspec WHERE id=?"

    const/4 v3, 0x1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v2

    if-nez v0, :cond_0

    invoke-virtual {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/qy;->X(I)V

    goto :goto_0

    :cond_0
    invoke-virtual {v2, v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->z(ILjava/lang/String;)V

    :goto_0
    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v2, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v6

    :try_start_0
    const-string v0, "id"

    invoke-static {v6, v0}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v0

    const-string v7, "state"

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    const-string v8, "worker_class_name"

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v8

    const-string v9, "input_merger_class_name"

    invoke-static {v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v9

    const-string v10, "input"

    invoke-static {v6, v10}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v10

    const-string v11, "output"

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v11

    const-string v12, "initial_delay"

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v12

    const-string v13, "interval_duration"

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v13

    const-string v14, "flex_duration"

    invoke-static {v6, v14}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v14

    const-string v15, "run_attempt_count"

    invoke-static {v6, v15}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v15

    const-string v3, "backoff_policy"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    const-string v4, "backoff_delay_duration"

    invoke-static {v6, v4}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v5, "last_enqueue_time"

    invoke-static {v6, v5}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v5

    const-string v1, "minimum_retention_duration"

    invoke-static {v6, v1}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v16, v2

    :try_start_1
    const-string v2, "schedule_requested_at"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v17, v2

    const-string v2, "run_in_foreground"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v18, v2

    const-string v2, "out_of_quota_policy"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v19, v2

    const-string v2, "period_count"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v20, v2

    const-string v2, "generation"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v21, v2

    const-string v2, "next_schedule_time_override"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v22, v2

    const-string v2, "next_schedule_time_override_generation"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v23, v2

    const-string v2, "stop_reason"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v24, v2

    const-string v2, "required_network_type"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v25, v2

    const-string v2, "requires_charging"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v26, v2

    const-string v2, "requires_device_idle"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v27, v2

    const-string v2, "requires_battery_not_low"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v28, v2

    const-string v2, "requires_storage_not_low"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v29, v2

    const-string v2, "trigger_content_update_delay"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v30, v2

    const-string v2, "trigger_max_content_delay"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    move/from16 v31, v2

    const-string v2, "content_uri_triggers"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    invoke-interface {v6}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v32

    if-eqz v32, :cond_c

    invoke-interface {v6, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v32

    if-eqz v32, :cond_1

    const/16 v33, 0x0

    goto :goto_1

    :cond_1
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v33, v0

    :goto_1
    invoke-interface {v6, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v34

    invoke-interface {v6, v8}, Landroid/database/Cursor;->isNull(I)Z

    move-result v0

    if-eqz v0, :cond_2

    const/16 v35, 0x0

    goto :goto_2

    :cond_2
    invoke-interface {v6, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v35, v0

    :goto_2
    invoke-interface {v6, v9}, Landroid/database/Cursor;->isNull(I)Z

    move-result v0

    if-eqz v0, :cond_3

    const/16 v36, 0x0

    goto :goto_3

    :cond_3
    invoke-interface {v6, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v36, v0

    :goto_3
    invoke-interface {v6, v10}, Landroid/database/Cursor;->isNull(I)Z

    move-result v0

    if-eqz v0, :cond_4

    const/4 v0, 0x0

    goto :goto_4

    :cond_4
    invoke-interface {v6, v10}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v0

    :goto_4
    invoke-static {v0}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v37

    invoke-interface {v6, v11}, Landroid/database/Cursor;->isNull(I)Z

    move-result v0

    if-eqz v0, :cond_5

    const/4 v0, 0x0

    goto :goto_5

    :cond_5
    invoke-interface {v6, v11}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v0

    :goto_5
    invoke-static {v0}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v38

    invoke-interface {v6, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v39

    invoke-interface {v6, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v41

    invoke-interface {v6, v14}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v43

    invoke-interface {v6, v15}, Landroid/database/Cursor;->getInt(I)I

    move-result v46

    invoke-interface {v6, v3}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->c(I)Lntidisestablish/neumonoul/floccinaucinih/a5;

    move-result-object v47

    invoke-interface {v6, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v48

    invoke-interface {v6, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v50

    invoke-interface {v6, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v52

    move/from16 v0, v17

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v54

    move/from16 v0, v18

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    if-eqz v0, :cond_6

    move/from16 v0, v19

    const/16 v56, 0x1

    goto :goto_6

    :cond_6
    move/from16 v0, v19

    const/16 v56, 0x0

    :goto_6
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->e(I)Lntidisestablish/neumonoul/floccinaucinih/zs;

    move-result-object v57

    move/from16 v0, v20

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v58

    move/from16 v0, v21

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v59

    move/from16 v0, v22

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v60

    move/from16 v0, v23

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v62

    move/from16 v0, v24

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v63

    move/from16 v0, v25

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->d(I)Lntidisestablish/neumonoul/floccinaucinih/kr;

    move-result-object v65

    move/from16 v0, v26

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    if-eqz v0, :cond_7

    move/from16 v0, v27

    const/16 v66, 0x1

    goto :goto_7

    :cond_7
    move/from16 v0, v27

    const/16 v66, 0x0

    :goto_7
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    if-eqz v0, :cond_8

    move/from16 v0, v28

    const/16 v67, 0x1

    goto :goto_8

    :cond_8
    move/from16 v0, v28

    const/16 v67, 0x0

    :goto_8
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    if-eqz v0, :cond_9

    move/from16 v0, v29

    const/16 v68, 0x1

    goto :goto_9

    :cond_9
    move/from16 v0, v29

    const/16 v68, 0x0

    :goto_9
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    if-eqz v0, :cond_a

    move/from16 v0, v30

    const/16 v69, 0x1

    goto :goto_a

    :cond_a
    move/from16 v0, v30

    const/16 v69, 0x0

    :goto_a
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v70

    move/from16 v0, v31

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v72

    invoke-interface {v6, v2}, Landroid/database/Cursor;->isNull(I)Z

    move-result v0

    if-eqz v0, :cond_b

    const/4 v5, 0x0

    goto :goto_b

    :cond_b
    invoke-interface {v6, v2}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v5

    :goto_b
    invoke-static {v5}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->b([B)Ljava/util/Set;

    move-result-object v74

    new-instance v45, Lntidisestablish/neumonoul/floccinaucinih/xa;

    move-object/from16 v64, v45

    invoke-direct/range {v64 .. v74}, Lntidisestablish/neumonoul/floccinaucinih/xa;-><init>(Lntidisestablish/neumonoul/floccinaucinih/kr;ZZZZJJLjava/util/Set;)V

    new-instance v5, Lntidisestablish/neumonoul/floccinaucinih/z90;

    move-object/from16 v32, v5

    invoke-direct/range {v32 .. v63}, Lntidisestablish/neumonoul/floccinaucinih/z90;-><init>(Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;Ljava/lang/String;Landroidx/work/b;Landroidx/work/b;JJJLntidisestablish/neumonoul/floccinaucinih/xa;ILntidisestablish/neumonoul/floccinaucinih/a5;JJJJZLntidisestablish/neumonoul/floccinaucinih/zs;IIJII)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_c

    :catchall_0
    move-exception v0

    goto :goto_d

    :cond_c
    const/4 v5, 0x0

    :goto_c
    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v5

    :catchall_1
    move-exception v0

    move-object/from16 v16, v2

    :goto_d
    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v0
.end method

.method public e(Ljava/lang/String;I)V
    .locals 4

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->r:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    int-to-long v2, p2

    invoke-interface {v0, v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r20;->C(IJ)V

    const/4 p2, 0x2

    if-nez p1, :cond_0

    invoke-interface {v0, p2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->r:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return-void

    :catchall_0
    move-exception p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->r:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public f(Ljava/lang/String;)I
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->k:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    if-nez p1, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    move-result p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->k:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return p1

    :catchall_0
    move-exception p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->k:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public g(Ljava/lang/String;J)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->i:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    invoke-interface {v0, v1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r20;->C(IJ)V

    const/4 p2, 0x2

    if-nez p1, :cond_0

    invoke-interface {v0, p2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->i:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return-void

    :catchall_0
    move-exception p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->i:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public h(Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;)I
    .locals 3

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->e:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->j(Lntidisestablish/neumonoul/floccinaucinih/f90;)I

    move-result p1

    int-to-long v1, p1

    const/4 p1, 0x1

    invoke-interface {v0, p1, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->C(IJ)V

    const/4 p1, 0x2

    if-nez p2, :cond_0

    invoke-interface {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    move-result p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->e:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return p1

    :catchall_0
    move-exception p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->e:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public i()Ljava/util/List;
    .locals 77

    .line 1
    move-object/from16 v1, p0

    const-string v0, "SELECT * FROM workspec WHERE state=1"

    const/4 v2, 0x0

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v3

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v4, 0x0

    invoke-static {v0, v3, v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v5

    :try_start_0
    const-string v0, "id"

    invoke-static {v5, v0}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v0

    const-string v6, "state"

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v6

    const-string v7, "worker_class_name"

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    const-string v8, "input_merger_class_name"

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v8

    const-string v9, "input"

    invoke-static {v5, v9}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v9

    const-string v10, "output"

    invoke-static {v5, v10}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v10

    const-string v11, "initial_delay"

    invoke-static {v5, v11}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v11

    const-string v12, "interval_duration"

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v12

    const-string v13, "flex_duration"

    invoke-static {v5, v13}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v13

    const-string v14, "run_attempt_count"

    invoke-static {v5, v14}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v14

    const-string v15, "backoff_policy"

    invoke-static {v5, v15}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v15

    const-string v2, "backoff_delay_duration"

    invoke-static {v5, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    const-string v4, "last_enqueue_time"

    invoke-static {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v1, "minimum_retention_duration"

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v16, v3

    :try_start_1
    const-string v3, "schedule_requested_at"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v17, v3

    const-string v3, "run_in_foreground"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v18, v3

    const-string v3, "out_of_quota_policy"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v19, v3

    const-string v3, "period_count"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v20, v3

    const-string v3, "generation"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v21, v3

    const-string v3, "next_schedule_time_override"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v22, v3

    const-string v3, "next_schedule_time_override_generation"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v23, v3

    const-string v3, "stop_reason"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v24, v3

    const-string v3, "required_network_type"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v25, v3

    const-string v3, "requires_charging"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v26, v3

    const-string v3, "requires_device_idle"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v27, v3

    const-string v3, "requires_battery_not_low"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v28, v3

    const-string v3, "requires_storage_not_low"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v29, v3

    const-string v3, "trigger_content_update_delay"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v30, v3

    const-string v3, "trigger_max_content_delay"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v31, v3

    const-string v3, "content_uri_triggers"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v32, v3

    new-instance v3, Ljava/util/ArrayList;

    move/from16 v33, v1

    invoke-interface {v5}, Landroid/database/Cursor;->getCount()I

    move-result v1

    invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_0
    invoke-interface {v5}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-interface {v5, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v35, 0x0

    goto :goto_1

    :cond_0
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v35, v1

    :goto_1
    invoke-interface {v5, v6}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v36

    invoke-interface {v5, v7}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v37, 0x0

    goto :goto_2

    :cond_1
    invoke-interface {v5, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v37, v1

    :goto_2
    invoke-interface {v5, v8}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 v38, 0x0

    goto :goto_3

    :cond_2
    invoke-interface {v5, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v38, v1

    :goto_3
    invoke-interface {v5, v9}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x0

    goto :goto_4

    :cond_3
    invoke-interface {v5, v9}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_4
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v39

    invoke-interface {v5, v10}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, 0x0

    goto :goto_5

    :cond_4
    invoke-interface {v5, v10}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_5
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v40

    invoke-interface {v5, v11}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v41

    invoke-interface {v5, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v43

    invoke-interface {v5, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v45

    invoke-interface {v5, v14}, Landroid/database/Cursor;->getInt(I)I

    move-result v48

    invoke-interface {v5, v15}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->c(I)Lntidisestablish/neumonoul/floccinaucinih/a5;

    move-result-object v49

    invoke-interface {v5, v2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v50

    invoke-interface {v5, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v52

    move/from16 v1, v33

    invoke-interface {v5, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v54

    move/from16 v33, v0

    move/from16 v0, v17

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v56

    move/from16 v17, v0

    move/from16 v0, v18

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v18

    const/16 v34, 0x1

    if-eqz v18, :cond_5

    move/from16 v18, v0

    move/from16 v0, v19

    move/from16 v58, v34

    goto :goto_6

    :cond_5
    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x0

    :goto_6
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v19

    invoke-static/range {v19 .. v19}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->e(I)Lntidisestablish/neumonoul/floccinaucinih/zs;

    move-result-object v59

    move/from16 v19, v0

    move/from16 v0, v20

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v60

    move/from16 v20, v0

    move/from16 v0, v21

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v61

    move/from16 v21, v0

    move/from16 v0, v22

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v62

    move/from16 v22, v0

    move/from16 v0, v23

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v64

    move/from16 v23, v0

    move/from16 v0, v24

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v65

    move/from16 v24, v0

    move/from16 v0, v25

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v25

    invoke-static/range {v25 .. v25}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->d(I)Lntidisestablish/neumonoul/floccinaucinih/kr;

    move-result-object v67

    move/from16 v25, v0

    move/from16 v0, v26

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v26

    if-eqz v26, :cond_6

    move/from16 v26, v0

    move/from16 v0, v27

    move/from16 v68, v34

    goto :goto_7

    :cond_6
    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x0

    :goto_7
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v27

    if-eqz v27, :cond_7

    move/from16 v27, v0

    move/from16 v0, v28

    move/from16 v69, v34

    goto :goto_8

    :cond_7
    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x0

    :goto_8
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v28

    if-eqz v28, :cond_8

    move/from16 v28, v0

    move/from16 v0, v29

    move/from16 v70, v34

    goto :goto_9

    :cond_8
    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x0

    :goto_9
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v29

    if-eqz v29, :cond_9

    move/from16 v29, v0

    move/from16 v0, v30

    move/from16 v71, v34

    goto :goto_a

    :cond_9
    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x0

    :goto_a
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v72

    move/from16 v30, v0

    move/from16 v0, v31

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v74

    move/from16 v31, v0

    move/from16 v0, v32

    invoke-interface {v5, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v32

    if-eqz v32, :cond_a

    const/16 v32, 0x0

    goto :goto_b

    :cond_a
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v32

    :goto_b
    invoke-static/range {v32 .. v32}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->b([B)Ljava/util/Set;

    move-result-object v76

    new-instance v47, Lntidisestablish/neumonoul/floccinaucinih/xa;

    move-object/from16 v66, v47

    invoke-direct/range {v66 .. v76}, Lntidisestablish/neumonoul/floccinaucinih/xa;-><init>(Lntidisestablish/neumonoul/floccinaucinih/kr;ZZZZJJLjava/util/Set;)V

    move/from16 v32, v0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/z90;

    move-object/from16 v34, v0

    invoke-direct/range {v34 .. v65}, Lntidisestablish/neumonoul/floccinaucinih/z90;-><init>(Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;Ljava/lang/String;Landroidx/work/b;Landroidx/work/b;JJJLntidisestablish/neumonoul/floccinaucinih/xa;ILntidisestablish/neumonoul/floccinaucinih/a5;JJJJZLntidisestablish/neumonoul/floccinaucinih/zs;IIJII)V

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move/from16 v0, v33

    move/from16 v33, v1

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    goto :goto_c

    :cond_b
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v3

    :catchall_1
    move-exception v0

    move-object/from16 v16, v3

    :goto_c
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v0
.end method

.method public j(Ljava/lang/String;)I
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->f:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    if-nez p1, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    move-result p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->f:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return p1

    :catchall_0
    move-exception p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->f:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public k(Ljava/lang/String;)Ljava/util/List;
    .locals 5

    .line 1
    const-string v0, "SELECT output FROM workspec WHERE id IN\n             (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v0

    if-nez p1, :cond_0

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->X(I)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p1

    :try_start_0
    new-instance v3, Ljava/util/ArrayList;

    invoke-interface {p1}, Landroid/database/Cursor;->getCount()I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {p1, v1}, Landroid/database/Cursor;->isNull(I)Z

    move-result v4

    if-eqz v4, :cond_1

    move-object v4, v2

    goto :goto_2

    :cond_1
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v4

    :goto_2
    invoke-static {v4}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v1

    goto :goto_3

    :cond_2
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v3

    :goto_3
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v1
.end method

.method public l(Ljava/lang/String;)I
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->j:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    if-nez p1, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    move-result p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->j:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return p1

    :catchall_0
    move-exception p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->j:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public m(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->g:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    if-nez p1, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->g:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return-void

    :catchall_0
    move-exception p1

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->g:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public n(Lntidisestablish/neumonoul/floccinaucinih/z90;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->b:Lntidisestablish/neumonoul/floccinaucinih/ff;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/ff;->j(Ljava/lang/Object;)V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    return-void

    :catchall_0
    move-exception p1

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    throw p1
.end method

.method public o()Z
    .locals 4

    .line 1
    const-string v0, "SELECT COUNT(*) > 0 FROM workspec WHERE state NOT IN (2, 3, 5) LIMIT 1"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v0

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v3, 0x0

    invoke-static {v2, v0, v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v2

    :try_start_0
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v3, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    :goto_0
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return v1

    :goto_1
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v1
.end method

.method public p()I
    .locals 4

    .line 1
    const-string v0, "Select COUNT(*) FROM workspec WHERE LENGTH(content_uri_triggers)<>0 AND state NOT IN (2, 3, 5)"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v0

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v3, 0x0

    invoke-static {v2, v0, v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v2

    :try_start_0
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    :goto_0
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return v1

    :goto_1
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v1
.end method

.method public q(Ljava/lang/String;J)I
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->n:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    invoke-interface {v0, v1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r20;->C(IJ)V

    const/4 p2, 0x2

    if-nez p1, :cond_0

    invoke-interface {v0, p2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    move-result p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->n:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return p1

    :catchall_0
    move-exception p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->n:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public r(Ljava/lang/String;I)V
    .locals 3

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->m:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    const/4 v1, 0x1

    if-nez p1, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_0
    const/4 p1, 0x2

    int-to-long v1, p2

    invoke-interface {v0, p1, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->C(IJ)V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->m:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return-void

    :catchall_0
    move-exception p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->m:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public s()Ljava/util/List;
    .locals 77

    .line 1
    move-object/from16 v1, p0

    const-string v0, "SELECT * FROM workspec WHERE state=0 AND schedule_requested_at<>-1"

    const/4 v2, 0x0

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v3

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v4, 0x0

    invoke-static {v0, v3, v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v5

    :try_start_0
    const-string v0, "id"

    invoke-static {v5, v0}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v0

    const-string v6, "state"

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v6

    const-string v7, "worker_class_name"

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    const-string v8, "input_merger_class_name"

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v8

    const-string v9, "input"

    invoke-static {v5, v9}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v9

    const-string v10, "output"

    invoke-static {v5, v10}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v10

    const-string v11, "initial_delay"

    invoke-static {v5, v11}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v11

    const-string v12, "interval_duration"

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v12

    const-string v13, "flex_duration"

    invoke-static {v5, v13}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v13

    const-string v14, "run_attempt_count"

    invoke-static {v5, v14}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v14

    const-string v15, "backoff_policy"

    invoke-static {v5, v15}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v15

    const-string v2, "backoff_delay_duration"

    invoke-static {v5, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    const-string v4, "last_enqueue_time"

    invoke-static {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v1, "minimum_retention_duration"

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v16, v3

    :try_start_1
    const-string v3, "schedule_requested_at"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v17, v3

    const-string v3, "run_in_foreground"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v18, v3

    const-string v3, "out_of_quota_policy"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v19, v3

    const-string v3, "period_count"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v20, v3

    const-string v3, "generation"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v21, v3

    const-string v3, "next_schedule_time_override"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v22, v3

    const-string v3, "next_schedule_time_override_generation"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v23, v3

    const-string v3, "stop_reason"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v24, v3

    const-string v3, "required_network_type"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v25, v3

    const-string v3, "requires_charging"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v26, v3

    const-string v3, "requires_device_idle"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v27, v3

    const-string v3, "requires_battery_not_low"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v28, v3

    const-string v3, "requires_storage_not_low"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v29, v3

    const-string v3, "trigger_content_update_delay"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v30, v3

    const-string v3, "trigger_max_content_delay"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v31, v3

    const-string v3, "content_uri_triggers"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v32, v3

    new-instance v3, Ljava/util/ArrayList;

    move/from16 v33, v1

    invoke-interface {v5}, Landroid/database/Cursor;->getCount()I

    move-result v1

    invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_0
    invoke-interface {v5}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-interface {v5, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v35, 0x0

    goto :goto_1

    :cond_0
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v35, v1

    :goto_1
    invoke-interface {v5, v6}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v36

    invoke-interface {v5, v7}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v37, 0x0

    goto :goto_2

    :cond_1
    invoke-interface {v5, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v37, v1

    :goto_2
    invoke-interface {v5, v8}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 v38, 0x0

    goto :goto_3

    :cond_2
    invoke-interface {v5, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v38, v1

    :goto_3
    invoke-interface {v5, v9}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x0

    goto :goto_4

    :cond_3
    invoke-interface {v5, v9}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_4
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v39

    invoke-interface {v5, v10}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, 0x0

    goto :goto_5

    :cond_4
    invoke-interface {v5, v10}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_5
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v40

    invoke-interface {v5, v11}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v41

    invoke-interface {v5, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v43

    invoke-interface {v5, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v45

    invoke-interface {v5, v14}, Landroid/database/Cursor;->getInt(I)I

    move-result v48

    invoke-interface {v5, v15}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->c(I)Lntidisestablish/neumonoul/floccinaucinih/a5;

    move-result-object v49

    invoke-interface {v5, v2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v50

    invoke-interface {v5, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v52

    move/from16 v1, v33

    invoke-interface {v5, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v54

    move/from16 v33, v0

    move/from16 v0, v17

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v56

    move/from16 v17, v0

    move/from16 v0, v18

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v18

    const/16 v34, 0x1

    if-eqz v18, :cond_5

    move/from16 v18, v0

    move/from16 v0, v19

    move/from16 v58, v34

    goto :goto_6

    :cond_5
    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x0

    :goto_6
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v19

    invoke-static/range {v19 .. v19}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->e(I)Lntidisestablish/neumonoul/floccinaucinih/zs;

    move-result-object v59

    move/from16 v19, v0

    move/from16 v0, v20

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v60

    move/from16 v20, v0

    move/from16 v0, v21

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v61

    move/from16 v21, v0

    move/from16 v0, v22

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v62

    move/from16 v22, v0

    move/from16 v0, v23

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v64

    move/from16 v23, v0

    move/from16 v0, v24

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v65

    move/from16 v24, v0

    move/from16 v0, v25

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v25

    invoke-static/range {v25 .. v25}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->d(I)Lntidisestablish/neumonoul/floccinaucinih/kr;

    move-result-object v67

    move/from16 v25, v0

    move/from16 v0, v26

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v26

    if-eqz v26, :cond_6

    move/from16 v26, v0

    move/from16 v0, v27

    move/from16 v68, v34

    goto :goto_7

    :cond_6
    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x0

    :goto_7
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v27

    if-eqz v27, :cond_7

    move/from16 v27, v0

    move/from16 v0, v28

    move/from16 v69, v34

    goto :goto_8

    :cond_7
    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x0

    :goto_8
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v28

    if-eqz v28, :cond_8

    move/from16 v28, v0

    move/from16 v0, v29

    move/from16 v70, v34

    goto :goto_9

    :cond_8
    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x0

    :goto_9
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v29

    if-eqz v29, :cond_9

    move/from16 v29, v0

    move/from16 v0, v30

    move/from16 v71, v34

    goto :goto_a

    :cond_9
    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x0

    :goto_a
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v72

    move/from16 v30, v0

    move/from16 v0, v31

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v74

    move/from16 v31, v0

    move/from16 v0, v32

    invoke-interface {v5, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v32

    if-eqz v32, :cond_a

    const/16 v32, 0x0

    goto :goto_b

    :cond_a
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v32

    :goto_b
    invoke-static/range {v32 .. v32}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->b([B)Ljava/util/Set;

    move-result-object v76

    new-instance v47, Lntidisestablish/neumonoul/floccinaucinih/xa;

    move-object/from16 v66, v47

    invoke-direct/range {v66 .. v76}, Lntidisestablish/neumonoul/floccinaucinih/xa;-><init>(Lntidisestablish/neumonoul/floccinaucinih/kr;ZZZZJJLjava/util/Set;)V

    move/from16 v32, v0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/z90;

    move-object/from16 v34, v0

    invoke-direct/range {v34 .. v65}, Lntidisestablish/neumonoul/floccinaucinih/z90;-><init>(Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;Ljava/lang/String;Landroidx/work/b;Landroidx/work/b;JJJLntidisestablish/neumonoul/floccinaucinih/xa;ILntidisestablish/neumonoul/floccinaucinih/a5;JJJJZLntidisestablish/neumonoul/floccinaucinih/zs;IIJII)V

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move/from16 v0, v33

    move/from16 v33, v1

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    goto :goto_c

    :cond_b
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v3

    :catchall_1
    move-exception v0

    move-object/from16 v16, v3

    :goto_c
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v0
.end method

.method public t(I)Ljava/util/List;
    .locals 77

    .line 1
    move-object/from16 v1, p0

    const-string v0, "SELECT * FROM workspec WHERE state=0 ORDER BY last_enqueue_time LIMIT ?"

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v3

    move/from16 v0, p1

    int-to-long v4, v0

    invoke-virtual {v3, v2, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/qy;->C(IJ)V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v6

    :try_start_0
    const-string v0, "id"

    invoke-static {v6, v0}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v0

    const-string v7, "state"

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    const-string v8, "worker_class_name"

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v8

    const-string v9, "input_merger_class_name"

    invoke-static {v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v9

    const-string v10, "input"

    invoke-static {v6, v10}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v10

    const-string v11, "output"

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v11

    const-string v12, "initial_delay"

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v12

    const-string v13, "interval_duration"

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v13

    const-string v14, "flex_duration"

    invoke-static {v6, v14}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v14

    const-string v15, "run_attempt_count"

    invoke-static {v6, v15}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v15

    const-string v2, "backoff_policy"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    const-string v4, "backoff_delay_duration"

    invoke-static {v6, v4}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v5, "last_enqueue_time"

    invoke-static {v6, v5}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v5

    const-string v1, "minimum_retention_duration"

    invoke-static {v6, v1}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v16, v3

    :try_start_1
    const-string v3, "schedule_requested_at"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v17, v3

    const-string v3, "run_in_foreground"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v18, v3

    const-string v3, "out_of_quota_policy"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v19, v3

    const-string v3, "period_count"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v20, v3

    const-string v3, "generation"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v21, v3

    const-string v3, "next_schedule_time_override"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v22, v3

    const-string v3, "next_schedule_time_override_generation"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v23, v3

    const-string v3, "stop_reason"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v24, v3

    const-string v3, "required_network_type"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v25, v3

    const-string v3, "requires_charging"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v26, v3

    const-string v3, "requires_device_idle"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v27, v3

    const-string v3, "requires_battery_not_low"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v28, v3

    const-string v3, "requires_storage_not_low"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v29, v3

    const-string v3, "trigger_content_update_delay"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v30, v3

    const-string v3, "trigger_max_content_delay"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v31, v3

    const-string v3, "content_uri_triggers"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v32, v3

    new-instance v3, Ljava/util/ArrayList;

    move/from16 v33, v1

    invoke-interface {v6}, Landroid/database/Cursor;->getCount()I

    move-result v1

    invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_0
    invoke-interface {v6}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-interface {v6, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v35, 0x0

    goto :goto_1

    :cond_0
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v35, v1

    :goto_1
    invoke-interface {v6, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v36

    invoke-interface {v6, v8}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v37, 0x0

    goto :goto_2

    :cond_1
    invoke-interface {v6, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v37, v1

    :goto_2
    invoke-interface {v6, v9}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 v38, 0x0

    goto :goto_3

    :cond_2
    invoke-interface {v6, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v38, v1

    :goto_3
    invoke-interface {v6, v10}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x0

    goto :goto_4

    :cond_3
    invoke-interface {v6, v10}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_4
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v39

    invoke-interface {v6, v11}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, 0x0

    goto :goto_5

    :cond_4
    invoke-interface {v6, v11}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_5
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v40

    invoke-interface {v6, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v41

    invoke-interface {v6, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v43

    invoke-interface {v6, v14}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v45

    invoke-interface {v6, v15}, Landroid/database/Cursor;->getInt(I)I

    move-result v48

    invoke-interface {v6, v2}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->c(I)Lntidisestablish/neumonoul/floccinaucinih/a5;

    move-result-object v49

    invoke-interface {v6, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v50

    invoke-interface {v6, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v52

    move/from16 v1, v33

    invoke-interface {v6, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v54

    move/from16 v33, v0

    move/from16 v0, v17

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v56

    move/from16 v17, v0

    move/from16 v0, v18

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v18

    if-eqz v18, :cond_5

    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x1

    goto :goto_6

    :cond_5
    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x0

    :goto_6
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v19

    invoke-static/range {v19 .. v19}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->e(I)Lntidisestablish/neumonoul/floccinaucinih/zs;

    move-result-object v59

    move/from16 v19, v0

    move/from16 v0, v20

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v60

    move/from16 v20, v0

    move/from16 v0, v21

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v61

    move/from16 v21, v0

    move/from16 v0, v22

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v62

    move/from16 v22, v0

    move/from16 v0, v23

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v64

    move/from16 v23, v0

    move/from16 v0, v24

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v65

    move/from16 v24, v0

    move/from16 v0, v25

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v25

    invoke-static/range {v25 .. v25}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->d(I)Lntidisestablish/neumonoul/floccinaucinih/kr;

    move-result-object v67

    move/from16 v25, v0

    move/from16 v0, v26

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v26

    if-eqz v26, :cond_6

    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x1

    goto :goto_7

    :cond_6
    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x0

    :goto_7
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v27

    if-eqz v27, :cond_7

    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x1

    goto :goto_8

    :cond_7
    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x0

    :goto_8
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v28

    if-eqz v28, :cond_8

    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x1

    goto :goto_9

    :cond_8
    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x0

    :goto_9
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v29

    if-eqz v29, :cond_9

    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x1

    goto :goto_a

    :cond_9
    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x0

    :goto_a
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v72

    move/from16 v30, v0

    move/from16 v0, v31

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v74

    move/from16 v31, v0

    move/from16 v0, v32

    invoke-interface {v6, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v32

    if-eqz v32, :cond_a

    const/16 v32, 0x0

    goto :goto_b

    :cond_a
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v32

    :goto_b
    invoke-static/range {v32 .. v32}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->b([B)Ljava/util/Set;

    move-result-object v76

    new-instance v47, Lntidisestablish/neumonoul/floccinaucinih/xa;

    move-object/from16 v66, v47

    invoke-direct/range {v66 .. v76}, Lntidisestablish/neumonoul/floccinaucinih/xa;-><init>(Lntidisestablish/neumonoul/floccinaucinih/kr;ZZZZJJLjava/util/Set;)V

    move/from16 v32, v0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/z90;

    move-object/from16 v34, v0

    invoke-direct/range {v34 .. v65}, Lntidisestablish/neumonoul/floccinaucinih/z90;-><init>(Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;Ljava/lang/String;Landroidx/work/b;Landroidx/work/b;JJJLntidisestablish/neumonoul/floccinaucinih/xa;ILntidisestablish/neumonoul/floccinaucinih/a5;JJJJZLntidisestablish/neumonoul/floccinaucinih/zs;IIJII)V

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move/from16 v0, v33

    move/from16 v33, v1

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    goto :goto_c

    :cond_b
    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v3

    :catchall_1
    move-exception v0

    move-object/from16 v16, v3

    :goto_c
    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v0
.end method

.method public u(Ljava/lang/String;Landroidx/work/b;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->h:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    invoke-static {p2}, Landroidx/work/b;->k(Landroidx/work/b;)[B

    move-result-object p2

    const/4 v1, 0x1

    if-nez p2, :cond_0

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->W(I[B)V

    :goto_0
    const/4 p2, 0x2

    if-nez p1, :cond_1

    invoke-interface {v0, p2}, Lntidisestablish/neumonoul/floccinaucinih/r20;->X(I)V

    goto :goto_1

    :cond_1
    invoke-interface {v0, p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/r20;->z(ILjava/lang/String;)V

    :goto_1
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->h:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return-void

    :catchall_0
    move-exception p1

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->h:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw p1
.end method

.method public v(Ljava/lang/String;)Ljava/util/List;
    .locals 5

    .line 1
    const-string v0, "SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v0

    if-nez p1, :cond_0

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->X(I)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p1

    :try_start_0
    new-instance v3, Ljava/util/ArrayList;

    invoke-interface {p1}, Landroid/database/Cursor;->getCount()I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {p1, v1}, Landroid/database/Cursor;->isNull(I)Z

    move-result v4

    if-eqz v4, :cond_1

    move-object v4, v2

    goto :goto_2

    :cond_1
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    :goto_2
    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v1

    goto :goto_3

    :cond_2
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v3

    :goto_3
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v1
.end method

.method public w()I
    .locals 3

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->o:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->b()Lntidisestablish/neumonoul/floccinaucinih/t20;

    move-result-object v0

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->e()V

    :try_start_0
    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/t20;->O()I

    move-result v1

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->o:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    return v1

    :catchall_0
    move-exception v1

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/ny;->i()V

    iget-object v2, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->o:Lntidisestablish/neumonoul/floccinaucinih/m00;

    invoke-virtual {v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/m00;->h(Lntidisestablish/neumonoul/floccinaucinih/t20;)V

    throw v1
.end method

.method public x(Ljava/lang/String;)Ljava/util/List;
    .locals 8

    .line 1
    const-string v0, "SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v0

    if-nez p1, :cond_0

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->X(I)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/qy;->z(ILjava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1, v0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p1

    :try_start_0
    new-instance v4, Ljava/util/ArrayList;

    invoke-interface {p1}, Landroid/database/Cursor;->getCount()I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {p1, v2}, Landroid/database/Cursor;->isNull(I)Z

    move-result v5

    if-eqz v5, :cond_1

    move-object v5, v3

    goto :goto_2

    :cond_1
    invoke-interface {p1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    :goto_2
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v6

    invoke-static {v6}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v6

    new-instance v7, Lntidisestablish/neumonoul/floccinaucinih/z90$b;

    invoke-direct {v7, v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/z90$b;-><init>(Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/f90;)V

    invoke-interface {v4, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v1

    goto :goto_3

    :cond_2
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v4

    :goto_3
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v1
.end method

.method public y()Ljava/util/List;
    .locals 77

    .line 1
    move-object/from16 v1, p0

    const-string v0, "SELECT * FROM workspec WHERE state=0 AND schedule_requested_at=-1 AND LENGTH(content_uri_triggers)<>0 ORDER BY last_enqueue_time"

    const/4 v2, 0x0

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v3

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v4, 0x0

    invoke-static {v0, v3, v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v5

    :try_start_0
    const-string v0, "id"

    invoke-static {v5, v0}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v0

    const-string v6, "state"

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v6

    const-string v7, "worker_class_name"

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    const-string v8, "input_merger_class_name"

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v8

    const-string v9, "input"

    invoke-static {v5, v9}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v9

    const-string v10, "output"

    invoke-static {v5, v10}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v10

    const-string v11, "initial_delay"

    invoke-static {v5, v11}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v11

    const-string v12, "interval_duration"

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v12

    const-string v13, "flex_duration"

    invoke-static {v5, v13}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v13

    const-string v14, "run_attempt_count"

    invoke-static {v5, v14}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v14

    const-string v15, "backoff_policy"

    invoke-static {v5, v15}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v15

    const-string v2, "backoff_delay_duration"

    invoke-static {v5, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    const-string v4, "last_enqueue_time"

    invoke-static {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v1, "minimum_retention_duration"

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v16, v3

    :try_start_1
    const-string v3, "schedule_requested_at"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v17, v3

    const-string v3, "run_in_foreground"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v18, v3

    const-string v3, "out_of_quota_policy"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v19, v3

    const-string v3, "period_count"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v20, v3

    const-string v3, "generation"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v21, v3

    const-string v3, "next_schedule_time_override"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v22, v3

    const-string v3, "next_schedule_time_override_generation"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v23, v3

    const-string v3, "stop_reason"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v24, v3

    const-string v3, "required_network_type"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v25, v3

    const-string v3, "requires_charging"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v26, v3

    const-string v3, "requires_device_idle"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v27, v3

    const-string v3, "requires_battery_not_low"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v28, v3

    const-string v3, "requires_storage_not_low"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v29, v3

    const-string v3, "trigger_content_update_delay"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v30, v3

    const-string v3, "trigger_max_content_delay"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v31, v3

    const-string v3, "content_uri_triggers"

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v32, v3

    new-instance v3, Ljava/util/ArrayList;

    move/from16 v33, v1

    invoke-interface {v5}, Landroid/database/Cursor;->getCount()I

    move-result v1

    invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_0
    invoke-interface {v5}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-interface {v5, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v35, 0x0

    goto :goto_1

    :cond_0
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v35, v1

    :goto_1
    invoke-interface {v5, v6}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v36

    invoke-interface {v5, v7}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v37, 0x0

    goto :goto_2

    :cond_1
    invoke-interface {v5, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v37, v1

    :goto_2
    invoke-interface {v5, v8}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 v38, 0x0

    goto :goto_3

    :cond_2
    invoke-interface {v5, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v38, v1

    :goto_3
    invoke-interface {v5, v9}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x0

    goto :goto_4

    :cond_3
    invoke-interface {v5, v9}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_4
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v39

    invoke-interface {v5, v10}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, 0x0

    goto :goto_5

    :cond_4
    invoke-interface {v5, v10}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_5
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v40

    invoke-interface {v5, v11}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v41

    invoke-interface {v5, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v43

    invoke-interface {v5, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v45

    invoke-interface {v5, v14}, Landroid/database/Cursor;->getInt(I)I

    move-result v48

    invoke-interface {v5, v15}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->c(I)Lntidisestablish/neumonoul/floccinaucinih/a5;

    move-result-object v49

    invoke-interface {v5, v2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v50

    invoke-interface {v5, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v52

    move/from16 v1, v33

    invoke-interface {v5, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v54

    move/from16 v33, v0

    move/from16 v0, v17

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v56

    move/from16 v17, v0

    move/from16 v0, v18

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v18

    const/16 v34, 0x1

    if-eqz v18, :cond_5

    move/from16 v18, v0

    move/from16 v0, v19

    move/from16 v58, v34

    goto :goto_6

    :cond_5
    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x0

    :goto_6
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v19

    invoke-static/range {v19 .. v19}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->e(I)Lntidisestablish/neumonoul/floccinaucinih/zs;

    move-result-object v59

    move/from16 v19, v0

    move/from16 v0, v20

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v60

    move/from16 v20, v0

    move/from16 v0, v21

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v61

    move/from16 v21, v0

    move/from16 v0, v22

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v62

    move/from16 v22, v0

    move/from16 v0, v23

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v64

    move/from16 v23, v0

    move/from16 v0, v24

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v65

    move/from16 v24, v0

    move/from16 v0, v25

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v25

    invoke-static/range {v25 .. v25}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->d(I)Lntidisestablish/neumonoul/floccinaucinih/kr;

    move-result-object v67

    move/from16 v25, v0

    move/from16 v0, v26

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v26

    if-eqz v26, :cond_6

    move/from16 v26, v0

    move/from16 v0, v27

    move/from16 v68, v34

    goto :goto_7

    :cond_6
    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x0

    :goto_7
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v27

    if-eqz v27, :cond_7

    move/from16 v27, v0

    move/from16 v0, v28

    move/from16 v69, v34

    goto :goto_8

    :cond_7
    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x0

    :goto_8
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v28

    if-eqz v28, :cond_8

    move/from16 v28, v0

    move/from16 v0, v29

    move/from16 v70, v34

    goto :goto_9

    :cond_8
    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x0

    :goto_9
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v29

    if-eqz v29, :cond_9

    move/from16 v29, v0

    move/from16 v0, v30

    move/from16 v71, v34

    goto :goto_a

    :cond_9
    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x0

    :goto_a
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v72

    move/from16 v30, v0

    move/from16 v0, v31

    invoke-interface {v5, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v74

    move/from16 v31, v0

    move/from16 v0, v32

    invoke-interface {v5, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v32

    if-eqz v32, :cond_a

    const/16 v32, 0x0

    goto :goto_b

    :cond_a
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v32

    :goto_b
    invoke-static/range {v32 .. v32}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->b([B)Ljava/util/Set;

    move-result-object v76

    new-instance v47, Lntidisestablish/neumonoul/floccinaucinih/xa;

    move-object/from16 v66, v47

    invoke-direct/range {v66 .. v76}, Lntidisestablish/neumonoul/floccinaucinih/xa;-><init>(Lntidisestablish/neumonoul/floccinaucinih/kr;ZZZZJJLjava/util/Set;)V

    move/from16 v32, v0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/z90;

    move-object/from16 v34, v0

    invoke-direct/range {v34 .. v65}, Lntidisestablish/neumonoul/floccinaucinih/z90;-><init>(Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;Ljava/lang/String;Landroidx/work/b;Landroidx/work/b;JJJLntidisestablish/neumonoul/floccinaucinih/xa;ILntidisestablish/neumonoul/floccinaucinih/a5;JJJJZLntidisestablish/neumonoul/floccinaucinih/zs;IIJII)V

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move/from16 v0, v33

    move/from16 v33, v1

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    goto :goto_c

    :cond_b
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v3

    :catchall_1
    move-exception v0

    move-object/from16 v16, v3

    :goto_c
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v0
.end method

.method public z(J)Ljava/util/List;
    .locals 77

    .line 1
    move-object/from16 v1, p0

    const-string v0, "SELECT * FROM workspec WHERE last_enqueue_time >= ? AND state IN (2, 3, 5) ORDER BY last_enqueue_time DESC"

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/qy;->e(Ljava/lang/String;I)Lntidisestablish/neumonoul/floccinaucinih/qy;

    move-result-object v3

    move-wide/from16 v4, p1

    invoke-virtual {v3, v2, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/qy;->C(IJ)V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ny;->d()V

    iget-object v0, v1, Lntidisestablish/neumonoul/floccinaucinih/ba0;->a:Lntidisestablish/neumonoul/floccinaucinih/ny;

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/kc;->b(Lntidisestablish/neumonoul/floccinaucinih/ny;Lntidisestablish/neumonoul/floccinaucinih/s20;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v6

    :try_start_0
    const-string v0, "id"

    invoke-static {v6, v0}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v0

    const-string v7, "state"

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v7

    const-string v8, "worker_class_name"

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v8

    const-string v9, "input_merger_class_name"

    invoke-static {v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v9

    const-string v10, "input"

    invoke-static {v6, v10}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v10

    const-string v11, "output"

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v11

    const-string v12, "initial_delay"

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v12

    const-string v13, "interval_duration"

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v13

    const-string v14, "flex_duration"

    invoke-static {v6, v14}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v14

    const-string v15, "run_attempt_count"

    invoke-static {v6, v15}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v15

    const-string v2, "backoff_policy"

    invoke-static {v6, v2}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v2

    const-string v4, "backoff_delay_duration"

    invoke-static {v6, v4}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v4

    const-string v5, "last_enqueue_time"

    invoke-static {v6, v5}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v5

    const-string v1, "minimum_retention_duration"

    invoke-static {v6, v1}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v16, v3

    :try_start_1
    const-string v3, "schedule_requested_at"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v17, v3

    const-string v3, "run_in_foreground"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v18, v3

    const-string v3, "out_of_quota_policy"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v19, v3

    const-string v3, "period_count"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v20, v3

    const-string v3, "generation"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v21, v3

    const-string v3, "next_schedule_time_override"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v22, v3

    const-string v3, "next_schedule_time_override_generation"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v23, v3

    const-string v3, "stop_reason"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v24, v3

    const-string v3, "required_network_type"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v25, v3

    const-string v3, "requires_charging"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v26, v3

    const-string v3, "requires_device_idle"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v27, v3

    const-string v3, "requires_battery_not_low"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v28, v3

    const-string v3, "requires_storage_not_low"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v29, v3

    const-string v3, "trigger_content_update_delay"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v30, v3

    const-string v3, "trigger_max_content_delay"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v31, v3

    const-string v3, "content_uri_triggers"

    invoke-static {v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/ic;->e(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v3

    move/from16 v32, v3

    new-instance v3, Ljava/util/ArrayList;

    move/from16 v33, v1

    invoke-interface {v6}, Landroid/database/Cursor;->getCount()I

    move-result v1

    invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_0
    invoke-interface {v6}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-interface {v6, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v35, 0x0

    goto :goto_1

    :cond_0
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v35, v1

    :goto_1
    invoke-interface {v6, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->f(I)Lntidisestablish/neumonoul/floccinaucinih/f90;

    move-result-object v36

    invoke-interface {v6, v8}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v37, 0x0

    goto :goto_2

    :cond_1
    invoke-interface {v6, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v37, v1

    :goto_2
    invoke-interface {v6, v9}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 v38, 0x0

    goto :goto_3

    :cond_2
    invoke-interface {v6, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v38, v1

    :goto_3
    invoke-interface {v6, v10}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x0

    goto :goto_4

    :cond_3
    invoke-interface {v6, v10}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_4
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v39

    invoke-interface {v6, v11}, Landroid/database/Cursor;->isNull(I)Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, 0x0

    goto :goto_5

    :cond_4
    invoke-interface {v6, v11}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v1

    :goto_5
    invoke-static {v1}, Landroidx/work/b;->g([B)Landroidx/work/b;

    move-result-object v40

    invoke-interface {v6, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v41

    invoke-interface {v6, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v43

    invoke-interface {v6, v14}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v45

    invoke-interface {v6, v15}, Landroid/database/Cursor;->getInt(I)I

    move-result v48

    invoke-interface {v6, v2}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->c(I)Lntidisestablish/neumonoul/floccinaucinih/a5;

    move-result-object v49

    invoke-interface {v6, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v50

    invoke-interface {v6, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v52

    move/from16 v1, v33

    invoke-interface {v6, v1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v54

    move/from16 v33, v0

    move/from16 v0, v17

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v56

    move/from16 v17, v0

    move/from16 v0, v18

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v18

    if-eqz v18, :cond_5

    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x1

    goto :goto_6

    :cond_5
    move/from16 v18, v0

    move/from16 v0, v19

    const/16 v58, 0x0

    :goto_6
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v19

    invoke-static/range {v19 .. v19}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->e(I)Lntidisestablish/neumonoul/floccinaucinih/zs;

    move-result-object v59

    move/from16 v19, v0

    move/from16 v0, v20

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v60

    move/from16 v20, v0

    move/from16 v0, v21

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v61

    move/from16 v21, v0

    move/from16 v0, v22

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v62

    move/from16 v22, v0

    move/from16 v0, v23

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v64

    move/from16 v23, v0

    move/from16 v0, v24

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v65

    move/from16 v24, v0

    move/from16 v0, v25

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v25

    invoke-static/range {v25 .. v25}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->d(I)Lntidisestablish/neumonoul/floccinaucinih/kr;

    move-result-object v67

    move/from16 v25, v0

    move/from16 v0, v26

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v26

    if-eqz v26, :cond_6

    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x1

    goto :goto_7

    :cond_6
    move/from16 v26, v0

    move/from16 v0, v27

    const/16 v68, 0x0

    :goto_7
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v27

    if-eqz v27, :cond_7

    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x1

    goto :goto_8

    :cond_7
    move/from16 v27, v0

    move/from16 v0, v28

    const/16 v69, 0x0

    :goto_8
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v28

    if-eqz v28, :cond_8

    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x1

    goto :goto_9

    :cond_8
    move/from16 v28, v0

    move/from16 v0, v29

    const/16 v70, 0x0

    :goto_9
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v29

    if-eqz v29, :cond_9

    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x1

    goto :goto_a

    :cond_9
    move/from16 v29, v0

    move/from16 v0, v30

    const/16 v71, 0x0

    :goto_a
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v72

    move/from16 v30, v0

    move/from16 v0, v31

    invoke-interface {v6, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v74

    move/from16 v31, v0

    move/from16 v0, v32

    invoke-interface {v6, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v32

    if-eqz v32, :cond_a

    const/16 v32, 0x0

    goto :goto_b

    :cond_a
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v32

    :goto_b
    invoke-static/range {v32 .. v32}, Lntidisestablish/neumonoul/floccinaucinih/ha0;->b([B)Ljava/util/Set;

    move-result-object v76

    new-instance v47, Lntidisestablish/neumonoul/floccinaucinih/xa;

    move-object/from16 v66, v47

    invoke-direct/range {v66 .. v76}, Lntidisestablish/neumonoul/floccinaucinih/xa;-><init>(Lntidisestablish/neumonoul/floccinaucinih/kr;ZZZZJJLjava/util/Set;)V

    move/from16 v32, v0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/z90;

    move-object/from16 v34, v0

    invoke-direct/range {v34 .. v65}, Lntidisestablish/neumonoul/floccinaucinih/z90;-><init>(Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/f90;Ljava/lang/String;Ljava/lang/String;Landroidx/work/b;Landroidx/work/b;JJJLntidisestablish/neumonoul/floccinaucinih/xa;ILntidisestablish/neumonoul/floccinaucinih/a5;JJJJZLntidisestablish/neumonoul/floccinaucinih/zs;IIJII)V

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move/from16 v0, v33

    move/from16 v33, v1

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    goto :goto_c

    :cond_b
    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    return-object v3

    :catchall_1
    move-exception v0

    move-object/from16 v16, v3

    :goto_c
    invoke-interface {v6}, Landroid/database/Cursor;->close()V

    invoke-virtual/range {v16 .. v16}, Lntidisestablish/neumonoul/floccinaucinih/qy;->n()V

    throw v0
.end method
