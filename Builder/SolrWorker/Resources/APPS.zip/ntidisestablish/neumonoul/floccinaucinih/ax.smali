.class final Lntidisestablish/neumonoul/floccinaucinih/ax;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/i70;


# instance fields
.field public final e:Lntidisestablish/neumonoul/floccinaucinih/c7;


# direct methods
.method public constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/c7;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/ax;->e:Lntidisestablish/neumonoul/floccinaucinih/c7;

    return-void
.end method


# virtual methods
.method public b(Lntidisestablish/neumonoul/floccinaucinih/kz;I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/ax;->e:Lntidisestablish/neumonoul/floccinaucinih/c7;

    invoke-virtual {v0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/c7;->b(Lntidisestablish/neumonoul/floccinaucinih/kz;I)V

    return-void
.end method
