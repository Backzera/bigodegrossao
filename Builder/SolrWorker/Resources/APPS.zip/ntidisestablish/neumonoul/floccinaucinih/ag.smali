.class public final enum Lntidisestablish/neumonoul/floccinaucinih/ag;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum e:Lntidisestablish/neumonoul/floccinaucinih/ag;

.field public static final enum f:Lntidisestablish/neumonoul/floccinaucinih/ag;

.field public static final enum g:Lntidisestablish/neumonoul/floccinaucinih/ag;

.field public static final enum h:Lntidisestablish/neumonoul/floccinaucinih/ag;

.field private static final synthetic i:[Lntidisestablish/neumonoul/floccinaucinih/ag;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ag;

    const-string v1, "REPLACE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/ag;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/ag;->e:Lntidisestablish/neumonoul/floccinaucinih/ag;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ag;

    const-string v1, "KEEP"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/ag;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/ag;->f:Lntidisestablish/neumonoul/floccinaucinih/ag;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ag;

    const-string v1, "APPEND"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/ag;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/ag;->g:Lntidisestablish/neumonoul/floccinaucinih/ag;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ag;

    const-string v1, "APPEND_OR_REPLACE"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/ag;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/ag;->h:Lntidisestablish/neumonoul/floccinaucinih/ag;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ag;->a()[Lntidisestablish/neumonoul/floccinaucinih/ag;

    move-result-object v0

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/ag;->i:[Lntidisestablish/neumonoul/floccinaucinih/ag;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static final synthetic a()[Lntidisestablish/neumonoul/floccinaucinih/ag;
    .locals 4

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ag;->e:Lntidisestablish/neumonoul/floccinaucinih/ag;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ag;->f:Lntidisestablish/neumonoul/floccinaucinih/ag;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ag;->g:Lntidisestablish/neumonoul/floccinaucinih/ag;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ag;->h:Lntidisestablish/neumonoul/floccinaucinih/ag;

    filled-new-array {v0, v1, v2, v3}, [Lntidisestablish/neumonoul/floccinaucinih/ag;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/ag;
    .locals 1

    .line 1
    const-class v0, Lntidisestablish/neumonoul/floccinaucinih/ag;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lntidisestablish/neumonoul/floccinaucinih/ag;

    return-object p0
.end method

.method public static values()[Lntidisestablish/neumonoul/floccinaucinih/ag;
    .locals 1

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ag;->i:[Lntidisestablish/neumonoul/floccinaucinih/ag;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lntidisestablish/neumonoul/floccinaucinih/ag;

    return-object v0
.end method
