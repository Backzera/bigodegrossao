.class public final Lntidisestablish/neumonoul/floccinaucinih/a2;
.super Lntidisestablish/neumonoul/floccinaucinih/jt;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lntidisestablish/neumonoul/floccinaucinih/a2$a;
    }
.end annotation


# static fields
.field public static final e:Lntidisestablish/neumonoul/floccinaucinih/a2$a;

.field private static final f:Z


# instance fields
.field private final d:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/a2$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/a2$a;-><init>(Lntidisestablish/neumonoul/floccinaucinih/tc;)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/a2;->e:Lntidisestablish/neumonoul/floccinaucinih/a2$a;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/jt;->a:Lntidisestablish/neumonoul/floccinaucinih/jt$a;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/jt$a;->h()Z

    move-result v0

    if-eqz v0, :cond_0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-lt v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    sput-boolean v0, Lntidisestablish/neumonoul/floccinaucinih/a2;->f:Z

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 1
    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/jt;-><init>()V

    const/4 v0, 0x4

    new-array v0, v0, [Lntidisestablish/neumonoul/floccinaucinih/s00;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/d2;->a:Lntidisestablish/neumonoul/floccinaucinih/d2$a;

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/d2$a;->a()Lntidisestablish/neumonoul/floccinaucinih/s00;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/bd;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/l2;->f:Lntidisestablish/neumonoul/floccinaucinih/l2$a;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/l2$a;->d()Lntidisestablish/neumonoul/floccinaucinih/bd$a;

    move-result-object v2

    invoke-direct {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/bd;-><init>(Lntidisestablish/neumonoul/floccinaucinih/bd$a;)V

    const/4 v2, 0x1

    aput-object v1, v0, v2

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/bd;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ja;->a:Lntidisestablish/neumonoul/floccinaucinih/ja$b;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/ja$b;->a()Lntidisestablish/neumonoul/floccinaucinih/bd$a;

    move-result-object v2

    invoke-direct {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/bd;-><init>(Lntidisestablish/neumonoul/floccinaucinih/bd$a;)V

    const/4 v2, 0x2

    aput-object v1, v0, v2

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/bd;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/v5;->a:Lntidisestablish/neumonoul/floccinaucinih/v5$b;

    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/v5$b;->a()Lntidisestablish/neumonoul/floccinaucinih/bd$a;

    move-result-object v2

    invoke-direct {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/bd;-><init>(Lntidisestablish/neumonoul/floccinaucinih/bd$a;)V

    const/4 v2, 0x3

    aput-object v1, v0, v2

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/u8;->k([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Lntidisestablish/neumonoul/floccinaucinih/s00;

    invoke-interface {v3}, Lntidisestablish/neumonoul/floccinaucinih/s00;->c()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    iput-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/a2;->d:Ljava/util/List;

    return-void
.end method

.method public static final synthetic p()Z
    .locals 1

    .line 1
    sget-boolean v0, Lntidisestablish/neumonoul/floccinaucinih/a2;->f:Z

    return v0
.end method


# virtual methods
.method public c(Ljavax/net/ssl/X509TrustManager;)Lntidisestablish/neumonoul/floccinaucinih/i7;
    .locals 1

    .line 1
    const-string v0, "trustManager"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/e2;->d:Lntidisestablish/neumonoul/floccinaucinih/e2$a;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/e2$a;->a(Ljavax/net/ssl/X509TrustManager;)Lntidisestablish/neumonoul/floccinaucinih/e2;

    move-result-object v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-super {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/jt;->c(Ljavax/net/ssl/X509TrustManager;)Lntidisestablish/neumonoul/floccinaucinih/i7;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public e(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V
    .locals 3

    .line 1
    const-string v0, "sslSocket"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "protocols"

    invoke-static {p3, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/a2;->d:Ljava/util/List;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Lntidisestablish/neumonoul/floccinaucinih/s00;

    invoke-interface {v2, p1}, Lntidisestablish/neumonoul/floccinaucinih/s00;->a(Ljavax/net/ssl/SSLSocket;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/s00;

    if-eqz v1, :cond_2

    invoke-interface {v1, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/s00;->d(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V

    :cond_2
    return-void
.end method

.method public g(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;
    .locals 4

    .line 1
    const-string v0, "sslSocket"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/a2;->d:Ljava/util/List;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lntidisestablish/neumonoul/floccinaucinih/s00;

    invoke-interface {v3, p1}, Lntidisestablish/neumonoul/floccinaucinih/s00;->a(Ljavax/net/ssl/SSLSocket;)Z

    move-result v3

    if-eqz v3, :cond_0

    goto :goto_0

    :cond_1
    move-object v1, v2

    :goto_0
    check-cast v1, Lntidisestablish/neumonoul/floccinaucinih/s00;

    if-eqz v1, :cond_2

    invoke-interface {v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/s00;->b(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;

    move-result-object v2

    :cond_2
    return-object v2
.end method

.method public i(Ljava/lang/String;)Z
    .locals 1

    .line 1
    const-string v0, "hostname"

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Landroid/security/NetworkSecurityPolicy;->getInstance()Landroid/security/NetworkSecurityPolicy;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/security/NetworkSecurityPolicy;->isCleartextTrafficPermitted(Ljava/lang/String;)Z

    move-result p1

    return p1
.end method
