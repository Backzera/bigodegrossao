.class final Lntidisestablish/neumonoul/floccinaucinih/c6$d;
.super Lntidisestablish/neumonoul/floccinaucinih/hb;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/c6;->q0(Lntidisestablish/neumonoul/floccinaucinih/w7;IJLntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field h:Ljava/lang/Object;

.field i:Ljava/lang/Object;

.field j:I

.field k:J

.field synthetic l:Ljava/lang/Object;

.field final synthetic m:Lntidisestablish/neumonoul/floccinaucinih/c6;

.field n:I


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/gb;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->m:Lntidisestablish/neumonoul/floccinaucinih/c6;

    invoke-direct {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/hb;-><init>(Lntidisestablish/neumonoul/floccinaucinih/gb;)V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->l:Ljava/lang/Object;

    iget p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->n:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->n:I

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c6$d;->m:Lntidisestablish/neumonoul/floccinaucinih/c6;

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-wide/16 v3, 0x0

    move-object v5, p0

    invoke-static/range {v0 .. v5}, Lntidisestablish/neumonoul/floccinaucinih/c6;->v(Lntidisestablish/neumonoul/floccinaucinih/c6;Lntidisestablish/neumonoul/floccinaucinih/w7;IJLntidisestablish/neumonoul/floccinaucinih/gb;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kl;->c()Ljava/lang/Object;

    move-result-object v0

    if-ne p1, v0, :cond_0

    return-object p1

    :cond_0
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/u7;->b(Ljava/lang/Object;)Lntidisestablish/neumonoul/floccinaucinih/u7;

    move-result-object p1

    return-object p1
.end method
