.class public final Lntidisestablish/neumonoul/floccinaucinih/c8;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lntidisestablish/neumonoul/floccinaucinih/c8;

.field public static final b:Ljava/nio/charset/Charset;

.field public static final c:Ljava/nio/charset/Charset;

.field public static final d:Ljava/nio/charset/Charset;

.field public static final e:Ljava/nio/charset/Charset;

.field public static final f:Ljava/nio/charset/Charset;

.field public static final g:Ljava/nio/charset/Charset;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/c8;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/c8;-><init>()V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c8;->a:Lntidisestablish/neumonoul/floccinaucinih/c8;

    const-string v0, "UTF-8"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const-string v1, "forName(\"UTF-8\")"

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c8;->b:Ljava/nio/charset/Charset;

    const-string v0, "UTF-16"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const-string v1, "forName(\"UTF-16\")"

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c8;->c:Ljava/nio/charset/Charset;

    const-string v0, "UTF-16BE"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const-string v1, "forName(\"UTF-16BE\")"

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c8;->d:Ljava/nio/charset/Charset;

    const-string v0, "UTF-16LE"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const-string v1, "forName(\"UTF-16LE\")"

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c8;->e:Ljava/nio/charset/Charset;

    const-string v0, "US-ASCII"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const-string v1, "forName(\"US-ASCII\")"

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c8;->f:Ljava/nio/charset/Charset;

    const-string v0, "ISO-8859-1"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const-string v1, "forName(\"ISO-8859-1\")"

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/jl;->d(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lntidisestablish/neumonoul/floccinaucinih/c8;->g:Ljava/nio/charset/Charset;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
