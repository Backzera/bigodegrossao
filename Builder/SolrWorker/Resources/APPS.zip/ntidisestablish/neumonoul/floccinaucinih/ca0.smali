.class public abstract Lntidisestablish/neumonoul/floccinaucinih/ca0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lntidisestablish/neumonoul/floccinaucinih/z90;)Lntidisestablish/neumonoul/floccinaucinih/e90;
    .locals 2

    .line 1
    const-string v0, "<this>"

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/jl;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/e90;

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/z90;->a:Ljava/lang/String;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/z90;->d()I

    move-result p0

    invoke-direct {v0, v1, p0}, Lntidisestablish/neumonoul/floccinaucinih/e90;-><init>(Ljava/lang/String;I)V

    return-object v0
.end method
