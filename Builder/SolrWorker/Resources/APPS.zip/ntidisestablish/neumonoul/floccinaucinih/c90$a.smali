.class Lntidisestablish/neumonoul/floccinaucinih/c90$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/c90;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lntidisestablish/neumonoul/floccinaucinih/e00;

.field final synthetic f:Lntidisestablish/neumonoul/floccinaucinih/c90;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/c90;Lntidisestablish/neumonoul/floccinaucinih/e00;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/c90$a;->f:Lntidisestablish/neumonoul/floccinaucinih/c90;

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/c90$a;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c90$a;->f:Lntidisestablish/neumonoul/floccinaucinih/c90;

    iget-object v0, v0, Lntidisestablish/neumonoul/floccinaucinih/c90;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/l;->isCancelled()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    :try_start_0
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/c90$a;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/l;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/gh;

    if-eqz v0, :cond_1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/xn;->e()Lntidisestablish/neumonoul/floccinaucinih/xn;

    move-result-object v1

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/c90;->k:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Updating notification for "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lntidisestablish/neumonoul/floccinaucinih/c90$a;->f:Lntidisestablish/neumonoul/floccinaucinih/c90;

    iget-object v4, v4, Lntidisestablish/neumonoul/floccinaucinih/c90;->g:Lntidisestablish/neumonoul/floccinaucinih/z90;

    iget-object v4, v4, Lntidisestablish/neumonoul/floccinaucinih/z90;->c:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/xn;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/c90$a;->f:Lntidisestablish/neumonoul/floccinaucinih/c90;

    iget-object v2, v1, Lntidisestablish/neumonoul/floccinaucinih/c90;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    iget-object v3, v1, Lntidisestablish/neumonoul/floccinaucinih/c90;->i:Lntidisestablish/neumonoul/floccinaucinih/jh;

    iget-object v4, v1, Lntidisestablish/neumonoul/floccinaucinih/c90;->f:Landroid/content/Context;

    iget-object v1, v1, Lntidisestablish/neumonoul/floccinaucinih/c90;->h:Landroidx/work/c;

    invoke-virtual {v1}, Landroidx/work/c;->e()Ljava/util/UUID;

    move-result-object v1

    invoke-interface {v3, v4, v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/jh;->a(Landroid/content/Context;Ljava/util/UUID;Lntidisestablish/neumonoul/floccinaucinih/gh;)Lntidisestablish/neumonoul/floccinaucinih/ln;

    move-result-object v0

    invoke-virtual {v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/e00;->r(Lntidisestablish/neumonoul/floccinaucinih/ln;)Z

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Worker was marked important ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/c90$a;->f:Lntidisestablish/neumonoul/floccinaucinih/c90;

    iget-object v1, v1, Lntidisestablish/neumonoul/floccinaucinih/c90;->g:Lntidisestablish/neumonoul/floccinaucinih/z90;

    iget-object v1, v1, Lntidisestablish/neumonoul/floccinaucinih/z90;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ") but did not provide ForegroundInfo"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    iget-object v1, p0, Lntidisestablish/neumonoul/floccinaucinih/c90$a;->f:Lntidisestablish/neumonoul/floccinaucinih/c90;

    iget-object v1, v1, Lntidisestablish/neumonoul/floccinaucinih/c90;->e:Lntidisestablish/neumonoul/floccinaucinih/e00;

    invoke-virtual {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/e00;->q(Ljava/lang/Throwable;)Z

    :goto_1
    return-void
.end method
