.class Lntidisestablish/neumonoul/floccinaucinih/b40$a;
.super Lntidisestablish/neumonoul/floccinaucinih/yx$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lntidisestablish/neumonoul/floccinaucinih/b40;->h(Landroid/content/Context;Lntidisestablish/neumonoul/floccinaucinih/d40;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lntidisestablish/neumonoul/floccinaucinih/d40;

.field final synthetic b:Lntidisestablish/neumonoul/floccinaucinih/b40;


# direct methods
.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/b40;Lntidisestablish/neumonoul/floccinaucinih/d40;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$a;->b:Lntidisestablish/neumonoul/floccinaucinih/b40;

    iput-object p2, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$a;->a:Lntidisestablish/neumonoul/floccinaucinih/d40;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/yx$b;-><init>()V

    return-void
.end method


# virtual methods
.method public h(I)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$a;->b:Lntidisestablish/neumonoul/floccinaucinih/b40;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/b40;->c(Lntidisestablish/neumonoul/floccinaucinih/b40;Z)Z

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$a;->a:Lntidisestablish/neumonoul/floccinaucinih/d40;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/d40;->a(I)V

    return-void
.end method

.method public i(Landroid/graphics/Typeface;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$a;->b:Lntidisestablish/neumonoul/floccinaucinih/b40;

    iget v1, v0, Lntidisestablish/neumonoul/floccinaucinih/b40;->f:I

    invoke-static {p1, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object p1

    invoke-static {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/b40;->b(Lntidisestablish/neumonoul/floccinaucinih/b40;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$a;->b:Lntidisestablish/neumonoul/floccinaucinih/b40;

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/b40;->c(Lntidisestablish/neumonoul/floccinaucinih/b40;Z)Z

    iget-object p1, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$a;->a:Lntidisestablish/neumonoul/floccinaucinih/d40;

    iget-object v0, p0, Lntidisestablish/neumonoul/floccinaucinih/b40$a;->b:Lntidisestablish/neumonoul/floccinaucinih/b40;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/b40;->a(Lntidisestablish/neumonoul/floccinaucinih/b40;)Landroid/graphics/Typeface;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/d40;->b(Landroid/graphics/Typeface;Z)V

    return-void
.end method
