.class Lcom/icontrol/protector/WorkServices$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/hardware/SensorEventListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WorkServices;->x()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/WorkServices;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/WorkServices;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAccuracyChanged(Landroid/hardware/Sensor;I)V
    .locals 0

    return-void
.end method

.method public onSensorChanged(Landroid/hardware/SensorEvent;)V
    .locals 12

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2}, Lcom/icontrol/protector/WorkServices;->c(Lcom/icontrol/protector/WorkServices;)J

    move-result-wide v2

    sub-long v2, v0, v2

    const-wide/16 v4, 0x1388

    cmp-long v2, v2, v4

    if-ltz v2, :cond_14

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2, v0, v1}, Lcom/icontrol/protector/WorkServices;->d(Lcom/icontrol/protector/WorkServices;J)J

    iget-object p1, p1, Landroid/hardware/SensorEvent;->values:[F

    const/4 v0, 0x0

    aget p1, p1, v0

    const/high16 v1, 0x3f800000    # 1.0f

    cmpg-float v1, p1, v1

    const/16 v2, 0xb

    const/4 v3, 0x5

    const/16 v4, 0x8

    if-gez v1, :cond_0

    new-array v1, v2, [B

    fill-array-data v1, :array_0

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_0

    :cond_0
    const/high16 v1, 0x41200000    # 10.0f

    cmpg-float v1, p1, v1

    const/16 v5, 0x9

    if-gez v1, :cond_1

    new-array v1, v5, [B

    fill-array-data v1, :array_2

    new-array v5, v4, [B

    fill-array-data v5, :array_3

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_0

    :cond_1
    const/high16 v1, 0x42480000    # 50.0f

    cmpg-float v1, p1, v1

    if-gez v1, :cond_2

    new-array v1, v5, [B

    fill-array-data v1, :array_4

    new-array v5, v4, [B

    fill-array-data v5, :array_5

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_2
    const/high16 v1, 0x43480000    # 200.0f

    cmpg-float v1, p1, v1

    const/4 v5, 0x6

    if-gez v1, :cond_3

    new-array v1, v5, [B

    fill-array-data v1, :array_6

    new-array v5, v4, [B

    fill-array-data v5, :array_7

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_3
    const/high16 v1, 0x447a0000    # 1000.0f

    cmpg-float v1, p1, v1

    if-gez v1, :cond_4

    const/16 v1, 0xd

    new-array v1, v1, [B

    fill-array-data v1, :array_8

    new-array v5, v4, [B

    fill-array-data v5, :array_9

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_4
    const v1, 0x461c4000    # 10000.0f

    cmpg-float v1, p1, v1

    if-gez v1, :cond_5

    new-array v1, v5, [B

    fill-array-data v1, :array_a

    new-array v5, v4, [B

    fill-array-data v5, :array_b

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_5
    const v1, 0x46ea6000    # 30000.0f

    cmpg-float v1, p1, v1

    if-gez v1, :cond_6

    new-array v1, v3, [B

    fill-array-data v1, :array_c

    new-array v5, v4, [B

    fill-array-data v5, :array_d

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_6
    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_e

    new-array v5, v4, [B

    fill-array-data v5, :array_f

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    :goto_0
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    move-result v6

    const/16 v7, 0xc31

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-eq v6, v7, :cond_c

    const/16 v0, 0xcae

    if-eq v6, v0, :cond_b

    const/16 v0, 0xe04

    if-eq v6, v0, :cond_a

    const/16 v0, 0xe43

    if-eq v6, v0, :cond_9

    const/16 v0, 0xe7e

    if-eq v6, v0, :cond_8

    const/16 v0, 0xf2e

    if-eq v6, v0, :cond_7

    goto/16 :goto_1

    :cond_7
    new-array v0, v11, [B

    fill-array-data v0, :array_10

    new-array v6, v4, [B

    fill-array-data v6, :array_11

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    move v0, v9

    goto/16 :goto_2

    :cond_8
    new-array v0, v11, [B

    fill-array-data v0, :array_12

    new-array v6, v4, [B

    fill-array-data v6, :array_13

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    move v0, v11

    goto :goto_2

    :cond_9
    new-array v0, v11, [B

    fill-array-data v0, :array_14

    new-array v6, v4, [B

    fill-array-data v6, :array_15

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    move v0, v10

    goto :goto_2

    :cond_a
    new-array v0, v11, [B

    fill-array-data v0, :array_16

    new-array v6, v4, [B

    fill-array-data v6, :array_17

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    move v0, v8

    goto :goto_2

    :cond_b
    new-array v0, v11, [B

    fill-array-data v0, :array_18

    new-array v6, v4, [B

    fill-array-data v6, :array_19

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    move v0, v3

    goto :goto_2

    :cond_c
    new-array v6, v11, [B

    fill-array-data v6, :array_1a

    new-array v7, v4, [B

    fill-array-data v7, :array_1b

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_d

    goto :goto_2

    :cond_d
    :goto_1
    const/4 v0, -0x1

    :goto_2
    if-eqz v0, :cond_13

    if-eq v0, v9, :cond_12

    if-eq v0, v11, :cond_11

    if-eq v0, v8, :cond_10

    if-eq v0, v10, :cond_f

    if-eq v0, v3, :cond_e

    iget-object v0, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v1}, Lcom/icontrol/protector/WorkServices;->t(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_e
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v1}, Lcom/icontrol/protector/WorkServices;->s(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_f
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v1}, Lcom/icontrol/protector/WorkServices;->r(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_10
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v1}, Lcom/icontrol/protector/WorkServices;->q(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_11
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v1}, Lcom/icontrol/protector/WorkServices;->p(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_12
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v1}, Lcom/icontrol/protector/WorkServices;->o(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_13
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices$a;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v1}, Lcom/icontrol/protector/WorkServices;->e(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_3
    new-array v1, v2, [B

    fill-array-data v1, :array_1c

    new-array v2, v4, [B

    fill-array-data v2, :array_1d

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v11, [B

    fill-array-data v2, :array_1e

    new-array v3, v4, [B

    fill-array-data v3, :array_1f

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    new-array v2, v10, [B

    fill-array-data v2, :array_20

    new-array v3, v4, [B

    fill-array-data v3, :array_21

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v0, v11, [B

    fill-array-data v0, :array_22

    new-array v2, v4, [B

    fill-array-data v2, :array_23

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    new-array p1, v10, [B

    fill-array-data p1, :array_24

    new-array v0, v4, [B

    fill-array-data v0, :array_25

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sput-object p1, Lcom/icontrol/protector/WorkServices;->s:Ljava/lang/String;

    :cond_14
    return-void

    :array_0
    .array-data 1
        0x22t
        -0x44t
        -0x5t
        -0x40t
        0x76t
        0x7at
        -0x3ct
        -0x12t
        0x33t
        -0x4at
        -0x1ct
    .end array-data

    :array_1
    .array-data 1
        0x52t
        -0x2bt
        -0x71t
        -0x5dt
        0x1et
        0x25t
        -0x5at
        -0x7et
    .end array-data

    :array_2
    .array-data 1
        -0x4et
        -0xbt
        0x35t
        -0x4et
        -0x72t
        0x1t
        -0x13t
        -0x71t
        -0x51t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x3ct
        -0x70t
        0x47t
        -0x35t
        -0x2ft
        0x65t
        -0x74t
        -0x3t
    .end array-data

    :array_4
    .array-data 1
        -0x53t
        0x4ct
        0xdt
        -0x40t
        0x6at
        -0x17t
        -0x34t
        -0x25t
        -0x43t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x37t
        0x25t
        0x60t
        -0x61t
        0x6t
        -0x80t
        -0x55t
        -0x4dt
    .end array-data

    :array_6
    .array-data 1
        0x4dt
        0x8t
        -0x34t
        -0x6at
        -0x12t
        -0x47t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x24t
        0x66t
        -0x58t
        -0x7t
        -0x7ft
        -0x35t
        0x31t
        0x9t
    .end array-data

    :array_8
    .array-data 1
        0x39t
        -0x14t
        0x10t
        -0x1et
        -0x38t
        -0x53t
        0x36t
        0x3at
        0x35t
        -0x6t
        0x16t
        -0x16t
        -0x2et
    .end array-data

    nop

    :array_9
    .array-data 1
        0x5bt
        -0x62t
        0x79t
        -0x7bt
        -0x60t
        -0x27t
        0x69t
        0x53t
    .end array-data

    :array_a
    .array-data 1
        -0x60t
        -0x80t
        -0x3at
        0x43t
        0x13t
        0x5at
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x3dt
        -0x14t
        -0x57t
        0x36t
        0x77t
        0x23t
        0x25t
        0x11t
    .end array-data

    :array_c
    .array-data 1
        -0x51t
        -0xct
        0x4ct
        0x6ct
        0x76t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x24t
        -0x7ft
        0x22t
        0x2t
        0xft
        0x38t
        0x1ct
        -0x55t
    .end array-data

    :array_e
    .array-data 1
        -0x47t
        0x78t
        0x6ft
        0x5ft
        -0x3et
        0x75t
        -0x22t
        -0x68t
        -0x58t
        0x7ft
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x23t
        0x11t
        0x1dt
        0x3at
        -0x5ft
        0x1t
        -0x7ft
        -0x15t
    .end array-data

    :array_10
    .array-data 1
        0x79t
        -0xat
    .end array-data

    nop

    :array_11
    .array-data 1
        0x3t
        -0x62t
        -0x5et
        0x2ct
        0x60t
        -0x2at
        -0x5at
        -0x3ct
    .end array-data

    :array_12
    .array-data 1
        -0x23t
        0x37t
    .end array-data

    nop

    :array_13
    .array-data 1
        -0x57t
        0x45t
        -0x6t
        0x31t
        -0xct
        0x2t
        0x3ft
        0x68t
    .end array-data

    :array_14
    .array-data 1
        0x12t
        0x30t
    .end array-data

    nop

    :array_15
    .array-data 1
        0x60t
        0x45t
        -0x7ct
        -0x42t
        -0x67t
        -0x49t
        0xat
        -0x1dt
    .end array-data

    :array_16
    .array-data 1
        0x28t
        -0x37t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x58t
        -0x43t
        -0x3at
        0x62t
        0x5et
        -0x58t
        0x5et
        0x18t
    .end array-data

    :array_18
    .array-data 1
        -0x6et
        0x62t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x9t
        0x11t
        -0xbt
        -0x67t
        0x7ct
        0x65t
        0x19t
        -0x76t
    .end array-data

    :array_1a
    .array-data 1
        -0x4ct
        -0x55t
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x2bt
        -0x27t
        0x2et
        -0x48t
        -0x4ft
        0x46t
        -0x5t
        0x1ft
    .end array-data

    :array_1c
    .array-data 1
        -0xat
        -0x67t
        0x16t
        -0x7ft
        -0x57t
        0x2dt
        -0x3et
        0x3ct
        -0x37t
        -0x61t
        0x3t
    .end array-data

    :array_1d
    .array-data 1
        -0x46t
        -0x10t
        0x71t
        -0x17t
        -0x23t
        0x7et
        -0x59t
        0x52t
    .end array-data

    :array_1e
    .array-data 1
        -0x69t
        0x75t
    .end array-data

    nop

    :array_1f
    .array-data 1
        -0x49t
        0x5dt
        -0x6et
        -0x7ct
        0x68t
        -0x67t
        -0x25t
        0x39t
    .end array-data

    :array_20
    .array-data 1
        -0x4ft
        -0x2bt
        -0x5ct
        -0x2ft
    .end array-data

    :array_21
    .array-data 1
        -0x6ft
        -0x47t
        -0x24t
        -0x8t
        0x66t
        0x7et
        0x6ct
        -0x59t
    .end array-data

    :array_22
    .array-data 1
        -0x62t
        0x51t
    .end array-data

    nop

    :array_23
    .array-data 1
        -0x42t
        0x79t
        -0x5et
        0x75t
        -0xct
        -0x64t
        -0x30t
        -0x52t
    .end array-data

    :array_24
    .array-data 1
        0x48t
        0x1ct
        0x6bt
        -0x71t
    .end array-data

    :array_25
    .array-data 1
        0x68t
        0x70t
        0x13t
        -0x5at
        -0x3et
        0x6ct
        -0x7ct
        -0x15t
    .end array-data
.end method
