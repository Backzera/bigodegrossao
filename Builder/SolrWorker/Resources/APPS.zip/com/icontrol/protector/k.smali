.class public abstract Lcom/icontrol/protector/k;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/k$a;
    }
.end annotation


# direct methods
.method public static a()[Ljava/lang/String;
    .locals 7

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/y9;->a()Lntidisestablish/neumonoul/floccinaucinih/y9;

    move-result-object v1

    iget-boolean v2, v1, Lntidisestablish/neumonoul/floccinaucinih/y9;->n:Z

    const/16 v3, 0x8

    if-eqz v2, :cond_0

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1e

    if-gt v2, v4, :cond_0

    const/16 v2, 0x29

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x28

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v4, v3, [B

    fill-array-data v4, :array_3

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    iget-boolean v2, v1, Lntidisestablish/neumonoul/floccinaucinih/y9;->x:Z

    if-eqz v2, :cond_1

    const/16 v2, 0x20

    new-array v2, v2, [B

    fill-array-data v2, :array_4

    new-array v4, v3, [B

    fill-array-data v4, :array_5

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x21

    new-array v2, v2, [B

    fill-array-data v2, :array_6

    new-array v4, v3, [B

    fill-array-data v4, :array_7

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x25

    new-array v2, v2, [B

    fill-array-data v2, :array_8

    new-array v4, v3, [B

    fill-array-data v4, :array_9

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    iget-boolean v2, v1, Lntidisestablish/neumonoul/floccinaucinih/y9;->t:Z

    const/16 v4, 0x1b

    if-eqz v2, :cond_2

    new-array v2, v4, [B

    fill-array-data v2, :array_a

    new-array v5, v3, [B

    fill-array-data v5, :array_b

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    iget-boolean v2, v1, Lntidisestablish/neumonoul/floccinaucinih/y9;->v:Z

    if-eqz v2, :cond_3

    new-array v2, v4, [B

    fill-array-data v2, :array_c

    new-array v5, v3, [B

    fill-array-data v5, :array_d

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    iget-boolean v2, v1, Lntidisestablish/neumonoul/floccinaucinih/y9;->p:Z

    if-eqz v2, :cond_4

    const/16 v2, 0x19

    new-array v2, v2, [B

    fill-array-data v2, :array_e

    new-array v5, v3, [B

    fill-array-data v5, :array_f

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    const/16 v2, 0x23

    new-array v2, v2, [B

    fill-array-data v2, :array_10

    new-array v5, v3, [B

    fill-array-data v5, :array_11

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-boolean v2, v1, Lntidisestablish/neumonoul/floccinaucinih/y9;->z:Z

    const/16 v5, 0x1f

    if-eqz v2, :cond_5

    new-array v2, v5, [B

    fill-array-data v2, :array_12

    new-array v6, v3, [B

    fill-array-data v6, :array_13

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_5
    iget-boolean v1, v1, Lntidisestablish/neumonoul/floccinaucinih/y9;->r:Z

    if-eqz v1, :cond_6

    new-array v1, v5, [B

    fill-array-data v1, :array_14

    new-array v2, v3, [B

    fill-array-data v2, :array_15

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    const/16 v1, 0x24

    new-array v2, v1, [B

    fill-array-data v2, :array_16

    new-array v5, v3, [B

    fill-array-data v5, :array_17

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-array v1, v1, [B

    fill-array-data v1, :array_18

    new-array v2, v3, [B

    fill-array-data v2, :array_19

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v1, 0x27

    new-array v1, v1, [B

    fill-array-data v1, :array_1a

    new-array v2, v3, [B

    fill-array-data v2, :array_1b

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v1, 0x1c

    new-array v1, v1, [B

    fill-array-data v1, :array_1c

    new-array v2, v3, [B

    fill-array-data v2, :array_1d

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-array v1, v4, [B

    fill-array-data v1, :array_1e

    new-array v2, v3, [B

    fill-array-data v2, :array_1f

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    return-object v0

    nop

    :array_0
    .array-data 1
        -0x58t
        -0x14t
        0x8t
        -0x26t
        0xat
        0x5et
        0x36t
        -0x4ct
        -0x47t
        -0x19t
        0x1et
        -0x3bt
        0xct
        0x44t
        0x21t
        -0xdt
        -0x5at
        -0x14t
        0x42t
        -0x1t
        0x37t
        0x7et
        0x6t
        -0x21t
        -0x6at
        -0x39t
        0x34t
        -0x4t
        0x20t
        0x65t
        0x1ct
        -0x25t
        -0x7bt
        -0x23t
        0x3ft
        -0x4t
        0x2at
        0x65t
        0x13t
        -0x23t
        -0x74t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x37t
        -0x7et
        0x6ct
        -0x58t
        0x65t
        0x37t
        0x52t
        -0x66t
    .end array-data

    :array_2
    .array-data 1
        0x67t
        0x6at
        -0x4ft
        0x6et
        0x57t
        0x52t
        0x5et
        -0xft
        0x76t
        0x61t
        -0x59t
        0x71t
        0x51t
        0x48t
        0x49t
        -0x4at
        0x69t
        0x6at
        -0x5t
        0x4et
        0x7dt
        0x7at
        0x7et
        -0x80t
        0x43t
        0x5ct
        -0x7ft
        0x59t
        0x6at
        0x75t
        0x7bt
        -0x6dt
        0x59t
        0x57t
        -0x7ft
        0x53t
        0x6at
        0x7at
        0x7dt
        -0x66t
    .end array-data

    :array_3
    .array-data 1
        0x6t
        0x4t
        -0x2bt
        0x1ct
        0x38t
        0x3bt
        0x3at
        -0x21t
    .end array-data

    :array_4
    .array-data 1
        -0x25t
        -0x7at
        -0x10t
        -0x5at
        -0x1bt
        -0x1ft
        -0x44t
        -0x5at
        -0x36t
        -0x73t
        -0x1at
        -0x47t
        -0x1dt
        -0x5t
        -0x55t
        -0x1ft
        -0x2bt
        -0x7at
        -0x46t
        -0x7at
        -0x31t
        -0x37t
        -0x64t
        -0x29t
        -0x7t
        -0x59t
        -0x26t
        -0x80t
        -0x35t
        -0x35t
        -0x74t
        -0x25t
    .end array-data

    :array_5
    .array-data 1
        -0x46t
        -0x18t
        -0x6ct
        -0x2ct
        -0x76t
        -0x78t
        -0x28t
        -0x78t
    .end array-data

    :array_6
    .array-data 1
        -0x33t
        0x73t
        -0x2bt
        0x63t
        -0x4et
        -0x68t
        -0x7bt
        0x6t
        -0x24t
        0x78t
        -0x3dt
        0x7ct
        -0x4ct
        -0x7et
        -0x6et
        0x41t
        -0x3dt
        0x73t
        -0x61t
        0x46t
        -0x71t
        -0x48t
        -0x4bt
        0x6dt
        -0xdt
        0x5et
        -0x2t
        0x5ft
        -0x77t
        -0x50t
        -0x5et
        0x7ct
        -0x1t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x54t
        0x1dt
        -0x4ft
        0x11t
        -0x23t
        -0xft
        -0x1ft
        0x28t
    .end array-data

    :array_8
    .array-data 1
        -0x11t
        -0x29t
        -0x5dt
        0x8t
        -0x12t
        -0x1dt
        -0x59t
        -0x72t
        -0x2t
        -0x24t
        -0x4bt
        0x17t
        -0x18t
        -0x7t
        -0x50t
        -0x37t
        -0x1ft
        -0x29t
        -0x17t
        0x28t
        -0x3ct
        -0x35t
        -0x79t
        -0x1t
        -0x22t
        -0xft
        -0x78t
        0x34t
        -0x3ct
        -0x2bt
        -0x73t
        -0xbt
        -0x3dt
        -0x5t
        -0x7et
        0x28t
        -0x2et
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x72t
        -0x47t
        -0x39t
        0x7at
        -0x7ft
        -0x76t
        -0x3dt
        -0x60t
    .end array-data

    :array_a
    .array-data 1
        -0x32t
        -0x20t
        -0x70t
        -0x7dt
        0x38t
        0x5ft
        -0xat
        -0x54t
        -0x21t
        -0x15t
        -0x7at
        -0x64t
        0x3et
        0x45t
        -0x1ft
        -0x15t
        -0x40t
        -0x20t
        -0x26t
        -0x5dt
        0x12t
        0x77t
        -0x2at
        -0x23t
        -0x4t
        -0x3dt
        -0x59t
    .end array-data

    :array_b
    .array-data 1
        -0x51t
        -0x72t
        -0xct
        -0xft
        0x57t
        0x36t
        -0x6et
        -0x7et
    .end array-data

    :array_c
    .array-data 1
        -0xat
        0x1et
        -0x10t
        0x3t
        -0x3ct
        0x67t
        -0x1et
        -0x3t
        -0x19t
        0x15t
        -0x1at
        0x1ct
        -0x3et
        0x7dt
        -0xbt
        -0x46t
        -0x8t
        0x1et
        -0x46t
        0x22t
        -0x12t
        0x40t
        -0x3et
        -0x74t
        -0x3ct
        0x3dt
        -0x39t
    .end array-data

    :array_d
    .array-data 1
        -0x69t
        0x70t
        -0x6ct
        0x71t
        -0x55t
        0xet
        -0x7at
        -0x2dt
    .end array-data

    :array_e
    .array-data 1
        -0x6ct
        -0x30t
        0x78t
        0x1bt
        -0x2ct
        -0x19t
        -0x2et
        0x3at
        -0x7bt
        -0x25t
        0x6et
        0x4t
        -0x2et
        -0x3t
        -0x3bt
        0x7dt
        -0x66t
        -0x30t
        0x32t
        0x2at
        -0x6t
        -0x3dt
        -0xdt
        0x46t
        -0x4ct
    .end array-data

    nop

    :array_f
    .array-data 1
        -0xbt
        -0x42t
        0x1ct
        0x69t
        -0x45t
        -0x72t
        -0x4at
        0x14t
    .end array-data

    :array_10
    .array-data 1
        -0x16t
        0x7dt
        0x14t
        -0x19t
        0x6bt
        -0x26t
        -0x51t
        0x55t
        -0x5t
        0x76t
        0x2t
        -0x8t
        0x6dt
        -0x40t
        -0x48t
        0x12t
        -0x1ct
        0x7dt
        0x5et
        -0x39t
        0x41t
        -0xet
        -0x71t
        0x24t
        -0x25t
        0x5bt
        0x3ft
        -0x25t
        0x41t
        -0x14t
        -0x68t
        0x2ft
        -0x36t
        0x47t
        0x35t
    .end array-data

    :array_11
    .array-data 1
        -0x75t
        0x13t
        0x70t
        -0x6bt
        0x4t
        -0x4dt
        -0x35t
        0x7bt
    .end array-data

    :array_12
    .array-data 1
        0x56t
        0x76t
        0x37t
        0x73t
        -0x39t
        0x30t
        0x2t
        -0x1bt
        0x47t
        0x7dt
        0x21t
        0x6ct
        -0x3ft
        0x2at
        0x15t
        -0x5et
        0x58t
        0x76t
        0x7dt
        0x46t
        -0x13t
        0xdt
        0x39t
        -0x76t
        0x74t
        0x5bt
        0x1ct
        0x54t
        -0x1at
        0xdt
        0x35t
    .end array-data

    :array_13
    .array-data 1
        0x37t
        0x18t
        0x53t
        0x1t
        -0x58t
        0x59t
        0x66t
        -0x35t
    .end array-data

    :array_14
    .array-data 1
        0x6ct
        0x71t
        0x7dt
        0x5at
        -0x2ft
        0x62t
        -0x52t
        -0x47t
        0x7dt
        0x7at
        0x6bt
        0x45t
        -0x29t
        0x78t
        -0x47t
        -0x2t
        0x62t
        0x71t
        0x37t
        0x7at
        -0x5t
        0x48t
        -0x7bt
        -0x3bt
        0x49t
        0x40t
        0x58t
        0x7dt
        -0x6t
        0x42t
        -0x7bt
    .end array-data

    :array_15
    .array-data 1
        0xdt
        0x1ft
        0x19t
        0x28t
        -0x42t
        0xbt
        -0x36t
        -0x69t
    .end array-data

    :array_16
    .array-data 1
        0x5t
        -0x64t
        -0x2at
        0x6dt
        -0x2dt
        -0x55t
        -0x53t
        0x3dt
        0x14t
        -0x69t
        -0x40t
        0x72t
        -0x2bt
        -0x4ft
        -0x46t
        0x7at
        0xbt
        -0x64t
        -0x64t
        0x5ct
        -0xct
        -0x7dt
        -0x79t
        0x54t
        0x21t
        -0x53t
        -0x1bt
        0x56t
        -0x6t
        -0x75t
        -0x6at
        0x40t
        0x30t
        -0x4dt
        -0x1at
        0x5at
    .end array-data

    :array_17
    .array-data 1
        0x64t
        -0xet
        -0x4et
        0x1ft
        -0x44t
        -0x3et
        -0x37t
        0x13t
    .end array-data

    :array_18
    .array-data 1
        0x5dt
        0x47t
        0x54t
        0x10t
        0x44t
        -0xft
        0x18t
        0x44t
        0x4ct
        0x4ct
        0x42t
        0xft
        0x42t
        -0x15t
        0xft
        0x3t
        0x53t
        0x47t
        0x1et
        0x23t
        0x68t
        -0x25t
        0x39t
        0x39t
        0x6ft
        0x76t
        0x67t
        0x2bt
        0x6dt
        -0x2ft
        0x23t
        0x39t
        0x68t
        0x68t
        0x64t
        0x27t
    .end array-data

    :array_19
    .array-data 1
        0x3ct
        0x29t
        0x30t
        0x62t
        0x2bt
        -0x68t
        0x7ct
        0x6at
    .end array-data

    :array_1a
    .array-data 1
        -0x56t
        0x5et
        0x57t
        0x5ct
        0x78t
        -0x18t
        -0x34t
        0x79t
        -0x45t
        0x55t
        0x41t
        0x43t
        0x7et
        -0xet
        -0x25t
        0x3et
        -0x5ct
        0x5et
        0x1dt
        0x6ft
        0x54t
        -0x3et
        -0x13t
        0x4t
        -0x68t
        0x6ft
        0x7dt
        0x6bt
        0x43t
        -0x2at
        -0x19t
        0x5t
        -0x80t
        0x6ft
        0x60t
        0x7at
        0x56t
        -0x2bt
        -0x13t
    .end array-data

    :array_1b
    .array-data 1
        -0x35t
        0x30t
        0x33t
        0x2et
        0x17t
        -0x7ft
        -0x58t
        0x57t
    .end array-data

    :array_1c
    .array-data 1
        0x49t
        -0x3dt
        0x53t
        -0x4at
        -0x40t
        -0x1et
        0x48t
        0x5at
        0x58t
        -0x38t
        0x45t
        -0x57t
        -0x3at
        -0x8t
        0x5ft
        0x1dt
        0x47t
        -0x3dt
        0x19t
        -0x6dt
        -0x12t
        -0x40t
        0x69t
        0x2bt
        0x64t
        -0x1et
        0x74t
        -0x71t
    .end array-data

    :array_1d
    .array-data 1
        0x28t
        -0x53t
        0x37t
        -0x3ct
        -0x51t
        -0x75t
        0x2ct
        0x74t
    .end array-data

    :array_1e
    .array-data 1
        0x77t
        -0x3t
        -0x10t
        -0x32t
        -0x37t
        0x72t
        -0x6ct
        0x2at
        0x66t
        -0xat
        -0x1at
        -0x2ft
        -0x31t
        0x68t
        -0x7dt
        0x6dt
        0x79t
        -0x3t
        -0x46t
        -0xbt
        -0x18t
        0x4ft
        -0x4bt
        0x56t
        0x58t
        -0x2at
        -0x40t
    .end array-data

    :array_1f
    .array-data 1
        0x16t
        -0x6dt
        -0x6ct
        -0x44t
        -0x5at
        0x1bt
        -0x10t
        0x4t
    .end array-data
.end method

.method public static b(Lcom/icontrol/protector/k$a;)[Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    const/16 v1, 0x8

    if-eqz p0, :cond_4

    const/4 v2, 0x1

    if-eq p0, v2, :cond_3

    const/4 v2, 0x2

    if-eq p0, v2, :cond_2

    const/4 v2, 0x3

    if-eq p0, v2, :cond_1

    const/4 v2, 0x4

    if-eq p0, v2, :cond_0

    goto :goto_1

    :cond_0
    const/16 p0, 0x20

    new-array p0, p0, [B

    fill-array-data p0, :array_0

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    :goto_0
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    const/16 p0, 0x1b

    new-array p0, p0, [B

    fill-array-data p0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_2
    const/16 p0, 0x1f

    new-array p0, p0, [B

    fill-array-data p0, :array_4

    new-array v1, v1, [B

    fill-array-data v1, :array_5

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_3
    const/16 p0, 0x19

    new-array p0, p0, [B

    fill-array-data p0, :array_6

    new-array v1, v1, [B

    fill-array-data v1, :array_7

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_4
    const/16 p0, 0x29

    new-array p0, p0, [B

    fill-array-data p0, :array_8

    new-array v2, v1, [B

    fill-array-data v2, :array_9

    invoke-static {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 p0, 0x28

    new-array p0, p0, [B

    fill-array-data p0, :array_a

    new-array v1, v1, [B

    fill-array-data v1, :array_b

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p0

    new-array p0, p0, [Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Ljava/lang/String;

    return-object p0

    :array_0
    .array-data 1
        0x59t
        -0x6at
        -0x26t
        -0x43t
        0x3t
        -0x5et
        -0x65t
        0x62t
        0x48t
        -0x63t
        -0x34t
        -0x5et
        0x5t
        -0x48t
        -0x74t
        0x25t
        0x57t
        -0x6at
        -0x70t
        -0x63t
        0x29t
        -0x76t
        -0x45t
        0x13t
        0x7bt
        -0x49t
        -0x10t
        -0x65t
        0x2dt
        -0x78t
        -0x55t
        0x1ft
    .end array-data

    :array_1
    .array-data 1
        0x38t
        -0x8t
        -0x42t
        -0x31t
        0x6ct
        -0x35t
        -0x1t
        0x4ct
    .end array-data

    :array_2
    .array-data 1
        0xbt
        -0x5et
        -0x15t
        0x41t
        -0x5ct
        -0x74t
        -0x45t
        -0xat
        0x1at
        -0x57t
        -0x3t
        0x5et
        -0x5et
        -0x6at
        -0x54t
        -0x4ft
        0x5t
        -0x5et
        -0x5ft
        0x61t
        -0x72t
        -0x5ct
        -0x65t
        -0x79t
        0x39t
        -0x7ft
        -0x24t
    .end array-data

    :array_3
    .array-data 1
        0x6at
        -0x34t
        -0x71t
        0x33t
        -0x35t
        -0x1bt
        -0x21t
        -0x28t
    .end array-data

    :array_4
    .array-data 1
        0x13t
        -0x5dt
        0x2t
        -0x58t
        -0x12t
        0xat
        0x3bt
        0x5ct
        0x2t
        -0x58t
        0x14t
        -0x49t
        -0x18t
        0x10t
        0x2ct
        0x1bt
        0x1dt
        -0x5dt
        0x48t
        -0x78t
        -0x3ct
        0x20t
        0x10t
        0x20t
        0x36t
        -0x6et
        0x27t
        -0x71t
        -0x3bt
        0x2at
        0x10t
    .end array-data

    :array_5
    .array-data 1
        0x72t
        -0x33t
        0x66t
        -0x26t
        -0x7ft
        0x63t
        0x5ft
        0x72t
    .end array-data

    :array_6
    .array-data 1
        0x4et
        0x4at
        0x45t
        0x7bt
        -0x7et
        0x50t
        0x3at
        0x4ct
        0x5ft
        0x41t
        0x53t
        0x64t
        -0x7ct
        0x4at
        0x2dt
        0xbt
        0x40t
        0x4at
        0xft
        0x4at
        -0x54t
        0x74t
        0x1bt
        0x30t
        0x6et
    .end array-data

    nop

    :array_7
    .array-data 1
        0x2ft
        0x24t
        0x21t
        0x9t
        -0x13t
        0x39t
        0x5et
        0x62t
    .end array-data

    :array_8
    .array-data 1
        0x75t
        0x1ct
        0x35t
        -0x5ft
        -0x56t
        -0x2at
        -0x4t
        0x4bt
        0x64t
        0x17t
        0x23t
        -0x42t
        -0x54t
        -0x34t
        -0x15t
        0xct
        0x7bt
        0x1ct
        0x7ft
        -0x7ct
        -0x69t
        -0xat
        -0x34t
        0x20t
        0x4bt
        0x37t
        0x9t
        -0x79t
        -0x80t
        -0x13t
        -0x2at
        0x24t
        0x58t
        0x2dt
        0x2t
        -0x79t
        -0x76t
        -0x13t
        -0x27t
        0x22t
        0x51t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x14t
        0x72t
        0x51t
        -0x2dt
        -0x3bt
        -0x41t
        -0x68t
        0x65t
    .end array-data

    :array_a
    .array-data 1
        -0x24t
        -0x76t
        0x69t
        0x4bt
        0x4et
        -0x69t
        -0x72t
        0x47t
        -0x33t
        -0x7ft
        0x7ft
        0x54t
        0x48t
        -0x73t
        -0x67t
        0x0t
        -0x2et
        -0x76t
        0x23t
        0x6bt
        0x64t
        -0x41t
        -0x52t
        0x36t
        -0x8t
        -0x44t
        0x59t
        0x7ct
        0x73t
        -0x50t
        -0x55t
        0x25t
        -0x1et
        -0x49t
        0x59t
        0x76t
        0x73t
        -0x41t
        -0x53t
        0x2ct
    .end array-data

    :array_b
    .array-data 1
        -0x43t
        -0x1ct
        0xdt
        0x39t
        0x21t
        -0x2t
        -0x16t
        0x69t
    .end array-data
.end method

.method public static c(Ljava/lang/String;)[Ljava/lang/String;
    .locals 8

    .line 1
    const/4 v0, 0x2

    const/16 v1, 0x8

    :try_start_0
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-array v3, v0, [B

    fill-array-data v3, :array_0

    new-array v4, v1, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/16 v3, 0x28

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v4, v1, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v3, 0x29

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v4, v1, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :catch_0
    move-exception p0

    goto/16 :goto_1

    :cond_0
    :goto_0
    new-array v3, v0, [B

    fill-array-data v3, :array_6

    new-array v4, v1, [B

    fill-array-data v4, :array_7

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_1

    const/16 v3, 0x19

    new-array v3, v3, [B

    fill-array-data v3, :array_8

    new-array v4, v1, [B

    fill-array-data v4, :array_9

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    new-array v3, v0, [B

    fill-array-data v3, :array_a

    new-array v4, v1, [B

    fill-array-data v4, :array_b

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/16 v4, 0x1f

    if-eqz v3, :cond_2

    new-array v3, v4, [B

    fill-array-data v3, :array_c

    new-array v5, v1, [B

    fill-array-data v5, :array_d

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    new-array v3, v0, [B

    fill-array-data v3, :array_e

    new-array v5, v1, [B

    fill-array-data v5, :array_f

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/16 v5, 0x1b

    if-eqz v3, :cond_3

    new-array v3, v5, [B

    fill-array-data v3, :array_10

    new-array v6, v1, [B

    fill-array-data v6, :array_11

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    new-array v3, v0, [B

    fill-array-data v3, :array_12

    new-array v6, v1, [B

    fill-array-data v6, :array_13

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/16 v6, 0x20

    if-eqz v3, :cond_4

    new-array v3, v6, [B

    fill-array-data v3, :array_14

    new-array v7, v1, [B

    fill-array-data v7, :array_15

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    new-array v3, v0, [B

    fill-array-data v3, :array_16

    new-array v7, v1, [B

    fill-array-data v7, :array_17

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_5

    new-array v3, v5, [B

    fill-array-data v3, :array_18

    new-array v5, v1, [B

    fill-array-data v5, :array_19

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    const/4 v3, 0x3

    new-array v5, v3, [B

    fill-array-data v5, :array_1a

    new-array v7, v1, [B

    fill-array-data v7, :array_1b

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_6

    new-array v5, v6, [B

    fill-array-data v5, :array_1c

    new-array v7, v1, [B

    fill-array-data v7, :array_1d

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    new-array v3, v3, [B

    fill-array-data v3, :array_1e

    new-array v5, v1, [B

    fill-array-data v5, :array_1f

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_7

    new-array v3, v6, [B

    fill-array-data v3, :array_20

    new-array v5, v1, [B

    fill-array-data v5, :array_21

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    new-array v3, v0, [B

    fill-array-data v3, :array_22

    new-array v5, v1, [B

    fill-array-data v5, :array_23

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_8

    new-array p0, v4, [B

    fill-array-data p0, :array_24

    new-array v3, v1, [B

    fill-array-data v3, :array_25

    invoke-static {p0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result p0

    new-array p0, p0, [Ljava/lang/String;

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :goto_1
    new-array v0, v0, [B

    fill-array-data v0, :array_26

    new-array v1, v1, [B

    fill-array-data v1, :array_27

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    filled-new-array {v0, p0}, [Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :array_0
    .array-data 1
        -0x47t
        -0x1t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x1t
        -0x42t
        -0x31t
        -0x75t
        -0x1ft
        0x33t
        0x5t
        -0x60t
    .end array-data

    :array_2
    .array-data 1
        -0x7t
        -0x22t
        -0x71t
        -0x9t
        0x73t
        0x3et
        0x67t
        0x2dt
        -0x18t
        -0x2bt
        -0x67t
        -0x18t
        0x75t
        0x24t
        0x70t
        0x6at
        -0x9t
        -0x22t
        -0x3bt
        -0x29t
        0x59t
        0x16t
        0x47t
        0x5ct
        -0x23t
        -0x18t
        -0x41t
        -0x40t
        0x4et
        0x19t
        0x42t
        0x4ft
        -0x39t
        -0x1dt
        -0x41t
        -0x36t
        0x4et
        0x16t
        0x44t
        0x46t
    .end array-data

    :array_3
    .array-data 1
        -0x68t
        -0x50t
        -0x15t
        -0x7bt
        0x1ct
        0x57t
        0x3t
        0x3t
    .end array-data

    :array_4
    .array-data 1
        0x3ct
        -0x5et
        -0x1ct
        0x5bt
        0x22t
        -0x47t
        -0x12t
        0xft
        0x2dt
        -0x57t
        -0xet
        0x44t
        0x24t
        -0x5dt
        -0x7t
        0x48t
        0x32t
        -0x5et
        -0x52t
        0x7et
        0x1ft
        -0x67t
        -0x22t
        0x64t
        0x2t
        -0x77t
        -0x28t
        0x7dt
        0x8t
        -0x7et
        -0x3ct
        0x60t
        0x11t
        -0x6dt
        -0x2dt
        0x7dt
        0x2t
        -0x7et
        -0x35t
        0x66t
        0x18t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x5dt
        -0x34t
        -0x80t
        0x29t
        0x4dt
        -0x30t
        -0x76t
        0x21t
    .end array-data

    :array_6
    .array-data 1
        0xdt
        -0x1t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x4et
        -0x42t
        0x26t
        -0x3at
        0x8t
        -0x33t
        -0x57t
        0x38t
    .end array-data

    :array_8
    .array-data 1
        -0x54t
        -0x6bt
        0xbt
        -0x23t
        -0x6t
        -0xat
        -0x7dt
        0x70t
        -0x43t
        -0x62t
        0x1dt
        -0x3et
        -0x4t
        -0x14t
        -0x6ct
        0x37t
        -0x5et
        -0x6bt
        0x41t
        -0x14t
        -0x2ct
        -0x2et
        -0x5et
        0xct
        -0x74t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x33t
        -0x5t
        0x6ft
        -0x51t
        -0x6bt
        -0x61t
        -0x19t
        0x5et
    .end array-data

    :array_a
    .array-data 1
        -0x40t
        -0x16t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x73t
        -0x57t
        0x5dt
        0x69t
        0x54t
        -0x80t
        0x73t
        0x24t
    .end array-data

    :array_c
    .array-data 1
        0xdt
        0x54t
        -0x4ct
        -0x19t
        -0x45t
        -0x2at
        -0x78t
        0x2dt
        0x1ct
        0x5ft
        -0x5et
        -0x8t
        -0x43t
        -0x34t
        -0x61t
        0x6at
        0x3t
        0x54t
        -0x2t
        -0x39t
        -0x6ft
        -0x4t
        -0x5dt
        0x51t
        0x28t
        0x65t
        -0x6ft
        -0x40t
        -0x70t
        -0xat
        -0x5dt
    .end array-data

    :array_d
    .array-data 1
        0x6ct
        0x3at
        -0x30t
        -0x6bt
        -0x2ct
        -0x41t
        -0x14t
        0x3t
    .end array-data

    :array_e
    .array-data 1
        0x5ft
        -0x7ft
    .end array-data

    nop

    :array_f
    .array-data 1
        0xct
        -0x2et
        -0x26t
        0xbt
        0x7et
        -0x79t
        0x6at
        -0x2dt
    .end array-data

    :array_10
    .array-data 1
        0x3dt
        -0x6at
        0x44t
        -0x19t
        -0x55t
        -0x5et
        0x38t
        -0x23t
        0x2ct
        -0x63t
        0x52t
        -0x8t
        -0x53t
        -0x48t
        0x2ft
        -0x66t
        0x33t
        -0x6at
        0xet
        -0x3at
        -0x7ft
        -0x7bt
        0x18t
        -0x54t
        0xft
        -0x4bt
        0x73t
    .end array-data

    :array_11
    .array-data 1
        0x5ct
        -0x8t
        0x20t
        -0x6bt
        -0x3ct
        -0x35t
        0x5ct
        -0xdt
    .end array-data

    :array_12
    .array-data 1
        0x42t
        -0x51t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x11t
        -0x8t
        0xct
        0x44t
        -0x67t
        -0x4dt
        -0x7et
        0x8t
    .end array-data

    :array_14
    .array-data 1
        0x67t
        0x2bt
        -0x27t
        -0x28t
        -0x63t
        -0x2ft
        -0x35t
        0x5bt
        0x76t
        0x20t
        -0x31t
        -0x39t
        -0x65t
        -0x35t
        -0x24t
        0x1ct
        0x69t
        0x2bt
        -0x6dt
        -0x7t
        -0x49t
        -0x14t
        -0x10t
        0x22t
        0x47t
        0x9t
        -0xft
        -0x6t
        -0x4dt
        -0x18t
        -0x16t
        0x27t
    .end array-data

    :array_15
    .array-data 1
        0x6t
        0x45t
        -0x43t
        -0x56t
        -0xet
        -0x48t
        -0x51t
        0x75t
    .end array-data

    :array_16
    .array-data 1
        0x1dt
        -0x49t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x4ft
        -0x1ct
        0x3t
        -0x6bt
        0x49t
        -0x50t
        0x48t
        -0x67t
    .end array-data

    :array_18
    .array-data 1
        0xdt
        -0x49t
        0x4t
        0x14t
        -0x70t
        -0x15t
        0x22t
        0x2t
        0x1ct
        -0x44t
        0x12t
        0xbt
        -0x6at
        -0xft
        0x35t
        0x45t
        0x3t
        -0x49t
        0x4et
        0x34t
        -0x46t
        -0x3dt
        0x2t
        0x73t
        0x3ft
        -0x6ct
        0x33t
    .end array-data

    :array_19
    .array-data 1
        0x6ct
        -0x27t
        0x60t
        0x66t
        -0x1t
        -0x7et
        0x46t
        0x2ct
    .end array-data

    :array_1a
    .array-data 1
        0x4ft
        0x51t
        -0x16t
    .end array-data

    :array_1b
    .array-data 1
        0x1dt
        0x12t
        -0x53t
        -0x31t
        -0x24t
        0x22t
        -0x50t
        -0x7bt
    .end array-data

    :array_1c
    .array-data 1
        0x10t
        -0x3et
        0x7t
        -0x1t
        0x19t
        -0x1ft
        0x2t
        -0x2dt
        0x1t
        -0x37t
        0x11t
        -0x20t
        0x1ft
        -0x5t
        0x15t
        -0x6ct
        0x1et
        -0x3et
        0x4dt
        -0x21t
        0x33t
        -0x37t
        0x22t
        -0x5et
        0x32t
        -0x13t
        0x2ft
        -0x3ft
        0x29t
        -0x3ct
        0x29t
        -0x46t
    .end array-data

    :array_1d
    .array-data 1
        0x71t
        -0x54t
        0x63t
        -0x73t
        0x76t
        -0x78t
        0x66t
        -0x3t
    .end array-data

    :array_1e
    .array-data 1
        0x66t
        0x13t
        0x3bt
    .end array-data

    :array_1f
    .array-data 1
        0x25t
        0x41t
        0x78t
        0x25t
        -0x54t
        -0x4ft
        0x53t
        -0x66t
    .end array-data

    :array_20
    .array-data 1
        -0x55t
        0x71t
        0x32t
        -0x23t
        -0x2t
        0x4ft
        0x10t
        -0x30t
        -0x46t
        0x7at
        0x24t
        -0x3et
        -0x8t
        0x55t
        0x7t
        -0x69t
        -0x5bt
        0x71t
        0x78t
        -0x3t
        -0x2ct
        0x67t
        0x30t
        -0x5ft
        -0x77t
        0x50t
        0x18t
        -0x5t
        -0x30t
        0x65t
        0x20t
        -0x53t
    .end array-data

    :array_21
    .array-data 1
        -0x36t
        0x1ft
        0x56t
        -0x51t
        -0x6ft
        0x26t
        0x74t
        -0x2t
    .end array-data

    :array_22
    .array-data 1
        0x1et
        -0x3dt
    .end array-data

    nop

    :array_23
    .array-data 1
        0x59t
        -0x7et
        0x26t
        -0x20t
        -0x2ft
        -0x77t
        0x17t
        -0x77t
    .end array-data

    :array_24
    .array-data 1
        -0x29t
        -0x7ct
        -0x7ct
        -0x5dt
        0x5at
        -0x38t
        0x5bt
        0x8t
        -0x3at
        -0x71t
        -0x6et
        -0x44t
        0x5ct
        -0x2et
        0x4ct
        0x4ft
        -0x27t
        -0x7ct
        -0x32t
        -0x6at
        0x70t
        -0xbt
        0x60t
        0x67t
        -0xbt
        -0x57t
        -0x51t
        -0x7ct
        0x7bt
        -0xbt
        0x6ct
    .end array-data

    :array_25
    .array-data 1
        -0x4at
        -0x16t
        -0x20t
        -0x2ft
        0x35t
        -0x5ft
        0x3ft
        0x26t
    .end array-data

    :array_26
    .array-data 1
        -0x40t
        0x30t
    .end array-data

    nop

    :array_27
    .array-data 1
        -0x7bt
        0x68t
        0x3dt
        0x40t
        -0x3dt
        -0x57t
        0x2bt
        -0x68t
    .end array-data
.end method

.method public static d(Landroid/content/Context;)Ljava/lang/String;
    .locals 10

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->l0:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/n;->f()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->m0:Ljava/lang/String;

    const-class v2, Lcom/icontrol/protector/AccessServices;

    invoke-static {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/q8;->b(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->n0:Ljava/lang/String;

    const/16 v2, 0x20

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v3, :cond_0

    move v3, v5

    goto :goto_0

    :cond_0
    move v3, v6

    :goto_0
    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->o0:Ljava/lang/String;

    const/16 v3, 0x1b

    new-array v7, v3, [B

    fill-array-data v7, :array_2

    new-array v8, v4, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0, v7}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v7

    if-nez v7, :cond_1

    move v7, v5

    goto :goto_1

    :cond_1
    move v7, v6

    :goto_1
    invoke-virtual {v0, v1, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->p0:Ljava/lang/String;

    new-array v7, v2, [B

    fill-array-data v7, :array_4

    new-array v8, v4, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0, v7}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v7

    if-nez v7, :cond_2

    move v7, v5

    goto :goto_2

    :cond_2
    move v7, v6

    :goto_2
    invoke-virtual {v0, v1, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->q0:Ljava/lang/String;

    const/16 v7, 0x19

    new-array v7, v7, [B

    fill-array-data v7, :array_6

    new-array v8, v4, [B

    fill-array-data v8, :array_7

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0, v7}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v7

    if-nez v7, :cond_3

    move v7, v5

    goto :goto_3

    :cond_3
    move v7, v6

    :goto_3
    invoke-virtual {v0, v1, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->r0:Ljava/lang/String;

    const/16 v7, 0x1f

    new-array v8, v7, [B

    fill-array-data v8, :array_8

    new-array v9, v4, [B

    fill-array-data v9, :array_9

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p0, v8}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v8

    if-nez v8, :cond_4

    move v8, v5

    goto :goto_4

    :cond_4
    move v8, v6

    :goto_4
    invoke-virtual {v0, v1, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->s0:Ljava/lang/String;

    new-array v7, v7, [B

    fill-array-data v7, :array_a

    new-array v8, v4, [B

    fill-array-data v8, :array_b

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0, v7}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v7

    if-nez v7, :cond_5

    move v7, v5

    goto :goto_5

    :cond_5
    move v7, v6

    :goto_5
    invoke-virtual {v0, v1, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    new-array v1, v4, [B

    fill-array-data v1, :array_c

    new-array v7, v4, [B

    fill-array-data v7, :array_d

    invoke-static {v1, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->w0:Ljava/lang/String;

    const/16 v7, 0x1d

    new-array v7, v7, [B

    fill-array-data v7, :array_e

    new-array v8, v4, [B

    fill-array-data v8, :array_f

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0, v7}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v7

    if-nez v7, :cond_6

    move v7, v5

    goto :goto_6

    :cond_6
    move v7, v6

    :goto_6
    invoke-virtual {v0, v1, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->x0:Ljava/lang/String;

    invoke-virtual {v0, v1, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->y0:Ljava/lang/String;

    new-array v3, v3, [B

    fill-array-data v3, :array_10

    new-array v7, v4, [B

    fill-array-data v7, :array_11

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v3

    if-nez v3, :cond_7

    move v3, v5

    goto :goto_7

    :cond_7
    move v3, v6

    :goto_7
    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->z0:Ljava/lang/String;

    new-array v2, v2, [B

    fill-array-data v2, :array_12

    new-array v3, v4, [B

    fill-array-data v3, :array_13

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-nez v2, :cond_8

    move v2, v5

    goto :goto_8

    :cond_8
    move v2, v6

    :goto_8
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->A0:Ljava/lang/String;

    invoke-static {p0}, Lcom/icontrol/protector/n;->h(Landroid/content/Context;)Z

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->B0:Ljava/lang/String;

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v3

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->C0:Ljava/lang/String;

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-static {v3}, Lntidisestablish/neumonoul/floccinaucinih/qq;->a(Landroid/content/pm/PackageManager;)Z

    move-result v3

    if-eqz v3, :cond_9

    goto :goto_9

    :cond_9
    move v5, v6

    goto :goto_9

    :catch_0
    move-exception p0

    goto :goto_c

    :cond_a
    :goto_9
    invoke-virtual {v0, v1, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->D0:Ljava/lang/String;

    invoke-static {p0}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    move-result v3

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    sget-object v1, Lcom/icontrol/protector/k$a;->e:Lcom/icontrol/protector/k$a;

    invoke-static {v1}, Lcom/icontrol/protector/k;->b(Lcom/icontrol/protector/k$a;)[Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x21

    if-lt v2, v3, :cond_b

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/e0;->a()Z

    move-result p0

    :goto_a
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    goto :goto_b

    :cond_b
    invoke-static {p0, v1}, Lcom/icontrol/protector/k;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p0

    goto :goto_a

    :goto_b
    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->E0:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/Boolean;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_d

    :goto_c
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_d
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :array_0
    .array-data 1
        0x36t
        -0x50t
        -0xet
        -0x2bt
        -0x5ft
        -0x7ct
        0x8t
        0x7at
        0x27t
        -0x45t
        -0x1ct
        -0x36t
        -0x59t
        -0x62t
        0x1ft
        0x3dt
        0x38t
        -0x50t
        -0x48t
        -0xbt
        -0x75t
        -0x54t
        0x28t
        0xbt
        0x14t
        -0x6ft
        -0x28t
        -0xdt
        -0x71t
        -0x52t
        0x38t
        0x7t
    .end array-data

    :array_1
    .array-data 1
        0x57t
        -0x22t
        -0x6at
        -0x59t
        -0x32t
        -0x13t
        0x6ct
        0x54t
    .end array-data

    :array_2
    .array-data 1
        0x2ft
        0x6et
        -0x21t
        -0x9t
        -0x75t
        0x6dt
        -0xet
        -0x73t
        0x3et
        0x65t
        -0x37t
        -0x18t
        -0x73t
        0x77t
        -0x1bt
        -0x36t
        0x21t
        0x6et
        -0x6bt
        -0x29t
        -0x5ft
        0x45t
        -0x2et
        -0x4t
        0x1dt
        0x4dt
        -0x18t
    .end array-data

    :array_3
    .array-data 1
        0x4et
        0x0t
        -0x45t
        -0x7bt
        -0x1ct
        0x4t
        -0x6at
        -0x5dt
    .end array-data

    :array_4
    .array-data 1
        0x3ct
        -0x4at
        -0x2ft
        -0x7ct
        0x6et
        0x70t
        -0x7t
        0x4at
        0x2dt
        -0x43t
        -0x39t
        -0x65t
        0x68t
        0x6at
        -0x12t
        0xdt
        0x32t
        -0x4at
        -0x65t
        -0x5ct
        0x44t
        0x58t
        -0x27t
        0x3bt
        0x1et
        -0x67t
        -0x7t
        -0x46t
        0x5et
        0x55t
        -0x2et
        0x23t
    .end array-data

    :array_5
    .array-data 1
        0x5dt
        -0x28t
        -0x4bt
        -0xat
        0x1t
        0x19t
        -0x63t
        0x64t
    .end array-data

    :array_6
    .array-data 1
        -0x3t
        0x3ct
        0x7et
        -0xct
        0x45t
        -0xdt
        -0x6t
        -0x4ct
        -0x14t
        0x37t
        0x68t
        -0x15t
        0x43t
        -0x17t
        -0x13t
        -0xdt
        -0xdt
        0x3ct
        0x34t
        -0x3bt
        0x6bt
        -0x29t
        -0x25t
        -0x38t
        -0x23t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x64t
        0x52t
        0x1at
        -0x7at
        0x2at
        -0x66t
        -0x62t
        -0x66t
    .end array-data

    :array_8
    .array-data 1
        0x6t
        -0x25t
        0x32t
        -0x77t
        0xat
        -0xdt
        0x17t
        -0x17t
        0x17t
        -0x30t
        0x24t
        -0x6at
        0xct
        -0x17t
        0x0t
        -0x52t
        0x8t
        -0x25t
        0x78t
        -0x44t
        0x20t
        -0x32t
        0x2ct
        -0x7at
        0x24t
        -0xat
        0x19t
        -0x52t
        0x2bt
        -0x32t
        0x20t
    .end array-data

    :array_9
    .array-data 1
        0x67t
        -0x4bt
        0x56t
        -0x5t
        0x65t
        -0x66t
        0x73t
        -0x39t
    .end array-data

    :array_a
    .array-data 1
        -0x39t
        -0x49t
        -0x20t
        -0x67t
        -0x3at
        -0x1t
        0x2bt
        0x12t
        -0x2at
        -0x44t
        -0xat
        -0x7at
        -0x40t
        -0x1bt
        0x3ct
        0x55t
        -0x37t
        -0x49t
        -0x56t
        -0x47t
        -0x14t
        -0x2bt
        0x0t
        0x6et
        -0x1et
        -0x7at
        -0x3bt
        -0x42t
        -0x13t
        -0x21t
        0x0t
    .end array-data

    :array_b
    .array-data 1
        -0x5at
        -0x27t
        -0x7ct
        -0x15t
        -0x57t
        -0x6at
        0x4ft
        0x3ct
    .end array-data

    :array_c
    .array-data 1
        -0xbt
        -0x7dt
        0x58t
        0x28t
        -0x3bt
        0x7dt
        0x75t
        0x20t
    .end array-data

    :array_d
    .array-data 1
        -0x47t
        -0x14t
        0x3bt
        0x49t
        -0x4ft
        0x14t
        0x1at
        0x4et
    .end array-data

    :array_e
    .array-data 1
        -0x7at
        0x1at
        -0x2dt
        -0x3t
        -0x5bt
        0x3at
        -0x51t
        -0x24t
        -0x69t
        0x11t
        -0x3bt
        -0x1et
        -0x5dt
        0x20t
        -0x48t
        -0x65t
        -0x78t
        0x1at
        -0x67t
        -0x34t
        -0x75t
        0x1ft
        -0x79t
        -0x53t
        -0x49t
        0x3ct
        -0x8t
        -0x3ft
        -0x71t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x19t
        0x74t
        -0x49t
        -0x71t
        -0x36t
        0x53t
        -0x35t
        -0xet
    .end array-data

    :array_10
    .array-data 1
        0x1ft
        -0x61t
        -0x3bt
        -0xdt
        -0x47t
        -0x58t
        -0x79t
        0x1et
        0xet
        -0x6ct
        -0x2dt
        -0x14t
        -0x41t
        -0x4et
        -0x70t
        0x59t
        0x11t
        -0x61t
        -0x71t
        -0x2et
        -0x6dt
        -0x71t
        -0x59t
        0x6ft
        0x2dt
        -0x44t
        -0xet
    .end array-data

    :array_11
    .array-data 1
        0x7et
        -0xft
        -0x5ft
        -0x7ft
        -0x2at
        -0x3ft
        -0x1dt
        0x30t
    .end array-data

    :array_12
    .array-data 1
        0x43t
        0x7bt
        -0x2et
        -0x4bt
        -0xct
        -0x26t
        -0x54t
        -0x61t
        0x52t
        0x70t
        -0x3ct
        -0x56t
        -0xet
        -0x40t
        -0x45t
        -0x28t
        0x4dt
        0x7bt
        -0x68t
        -0x6ct
        -0x22t
        -0x19t
        -0x69t
        -0x1at
        0x63t
        0x59t
        -0x6t
        -0x69t
        -0x26t
        -0x1dt
        -0x73t
        -0x1dt
    .end array-data

    :array_13
    .array-data 1
        0x22t
        0x15t
        -0x4at
        -0x39t
        -0x65t
        -0x4dt
        -0x38t
        -0x4ft
    .end array-data
.end method

.method public static varargs e(Landroid/content/Context;[Ljava/lang/String;)Z
    .locals 4

    .line 1
    if-eqz p0, :cond_1

    if-eqz p1, :cond_1

    array-length v0, p1

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    aget-object v3, p1, v2

    invoke-static {p0, v3}, Lntidisestablish/neumonoul/floccinaucinih/db;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    if-eqz v3, :cond_0

    return v1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x1

    return p0
.end method
