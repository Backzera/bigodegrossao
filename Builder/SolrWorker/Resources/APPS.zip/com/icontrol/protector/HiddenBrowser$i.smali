.class public Lcom/icontrol/protector/HiddenBrowser$i;
.super Landroid/webkit/WebChromeClient;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/HiddenBrowser;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "i"
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/HiddenBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/HiddenBrowser;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$i;->a:Lcom/icontrol/protector/HiddenBrowser;

    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    return-void
.end method
