.class Lcom/icontrol/protector/LiveChat$d;
.super Lntidisestablish/neumonoul/floccinaucinih/o70;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/LiveChat;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Lntidisestablish/neumonoul/floccinaucinih/ks;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/ks;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$d;->a:Landroid/content/Context;

    iput-object p2, p0, Lcom/icontrol/protector/LiveChat$d;->b:Ljava/lang/String;

    iput-object p3, p0, Lcom/icontrol/protector/LiveChat$d;->c:Ljava/lang/String;

    iput-object p4, p0, Lcom/icontrol/protector/LiveChat$d;->d:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/o70;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V
    .locals 0

    .line 1
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$d;->d:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    return-void
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V
    .locals 4

    .line 1
    invoke-super {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/o70;->d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V

    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x4

    new-array v0, p2, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-array p2, p2, [B

    fill-array-data p2, :array_4

    new-array v0, v1, [B

    fill-array-data v0, :array_5

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_0

    const/16 p2, 0x13

    new-array p2, p2, [B

    fill-array-data p2, :array_6

    new-array v0, v1, [B

    fill-array-data v0, :array_7

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$d;->d:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    return-void

    :array_0
    .array-data 1
        -0x5dt
        0x12t
        -0x3et
        -0x27t
    .end array-data

    :array_1
    .array-data 1
        -0x29t
        0x6bt
        -0x4et
        -0x44t
        -0x33t
        -0x3bt
        0x61t
        -0x74t
    .end array-data

    :array_2
    .array-data 1
        0x74t
        0x5ft
        -0x61t
        -0x7ct
        0x6ct
    .end array-data

    nop

    :array_3
    .array-data 1
        0x11t
        0x32t
        -0x11t
        -0x10t
        0x15t
        -0x6at
        -0x61t
        -0x47t
    .end array-data

    :array_4
    .array-data 1
        -0x35t
        0x4ct
        0x77t
        0x29t
    .end array-data

    :array_5
    .array-data 1
        -0x48t
        0x38t
        0x18t
        0x59t
        -0x50t
        0x70t
        -0x48t
        0x71t
    .end array-data

    :array_6
    .array-data 1
        0x48t
        0x35t
        0x61t
        0x33t
        0x11t
        0x3bt
        0x4et
        0x3dt
        0x74t
        0x21t
        0x65t
        0x22t
        0x45t
        0x32t
        0x42t
        0x2ct
        0x78t
        0x28t
        0x73t
    .end array-data

    :array_7
    .array-data 1
        0x1dt
        0x5bt
        0x0t
        0x46t
        0x65t
        0x53t
        0x21t
        0x4ft
    .end array-data
.end method

.method public f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    new-instance p2, Lcom/icontrol/protector/LiveChat$d$a;

    invoke-direct {p2, p0, p1}, Lcom/icontrol/protector/LiveChat$d$a;-><init>(Lcom/icontrol/protector/LiveChat$d;Lntidisestablish/neumonoul/floccinaucinih/m70;)V

    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    return-void
.end method
