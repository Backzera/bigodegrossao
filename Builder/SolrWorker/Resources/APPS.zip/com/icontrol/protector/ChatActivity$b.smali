.class Lcom/icontrol/protector/ChatActivity$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/ChatActivity;->c(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Ljava/lang/String;

.field final synthetic g:Lcom/icontrol/protector/ChatActivity;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/ChatActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/ChatActivity$b;->g:Lcom/icontrol/protector/ChatActivity;

    iput-object p2, p0, Lcom/icontrol/protector/ChatActivity$b;->e:Ljava/lang/String;

    iput-object p3, p0, Lcom/icontrol/protector/ChatActivity$b;->f:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lcom/icontrol/protector/ChatActivity$b;->g:Lcom/icontrol/protector/ChatActivity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    iget-object v2, p0, Lcom/icontrol/protector/ChatActivity$b;->e:Ljava/lang/String;

    const/4 v3, 0x3

    new-array v4, v3, [B

    fill-array-data v4, :array_0

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_1

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const v2, 0x800005

    :goto_0
    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    goto :goto_1

    :cond_0
    const v2, 0x800003

    goto :goto_0

    :goto_1
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x7

    invoke-virtual {v0, v1, v1, v1, v1}, Landroid/view/View;->setPadding(IIII)V

    new-instance v2, Landroid/widget/TextView;

    iget-object v4, p0, Lcom/icontrol/protector/ChatActivity$b;->g:Lcom/icontrol/protector/ChatActivity;

    invoke-direct {v2, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iget-object v4, p0, Lcom/icontrol/protector/ChatActivity$b;->f:Ljava/lang/String;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, -0x1

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v4, 0x10

    invoke-virtual {v2, v4, v5, v4, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v6, 0x0

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    iget-object v6, p0, Lcom/icontrol/protector/ChatActivity$b;->e:Ljava/lang/String;

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v7, v5, [B

    fill-array-data v7, :array_3

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    new-array v1, v1, [B

    if-eqz v3, :cond_1

    fill-array-data v1, :array_4

    new-array v3, v5, [B

    fill-array-data v3, :array_5

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    :goto_2
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v4, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_3

    :cond_1
    fill-array-data v1, :array_6

    new-array v3, v5, [B

    fill-array-data v3, :array_7

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_2

    :goto_3
    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {v4, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v1, p0, Lcom/icontrol/protector/ChatActivity$b;->g:Lcom/icontrol/protector/ChatActivity;

    sget v2, Lntidisestablish/neumonoul/floccinaucinih/uv;->c:I

    invoke-virtual {v1, v2}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v0, p0, Lcom/icontrol/protector/ChatActivity$b;->g:Lcom/icontrol/protector/ChatActivity;

    invoke-static {v0}, Lcom/icontrol/protector/ChatActivity;->b(Lcom/icontrol/protector/ChatActivity;)Landroid/widget/ScrollView;

    move-result-object v0

    new-instance v1, Lcom/icontrol/protector/ChatActivity$b$a;

    invoke-direct {v1, p0}, Lcom/icontrol/protector/ChatActivity$b$a;-><init>(Lcom/icontrol/protector/ChatActivity$b;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void

    nop

    :array_0
    .array-data 1
        -0x5et
        0x60t
        -0x3ft
    .end array-data

    :array_1
    .array-data 1
        -0x5t
        0xft
        -0x4ct
        -0x12t
        -0x21t
        -0x44t
        -0x5at
        -0x49t
    .end array-data

    :array_2
    .array-data 1
        0x33t
        -0x29t
        0x27t
    .end array-data

    :array_3
    .array-data 1
        0x6at
        -0x48t
        0x52t
        0x29t
        -0x7at
        -0x56t
        -0x67t
        0x26t
    .end array-data

    :array_4
    .array-data 1
        0x77t
        -0x3ct
        -0x5at
        0x7dt
        0x14t
        0x2ft
        0x50t
    .end array-data

    :array_5
    .array-data 1
        0x54t
        -0xat
        -0x61t
        0x4at
        0x2dt
        0x69t
        0x16t
        0x18t
    .end array-data

    :array_6
    .array-data 1
        0x34t
        0x73t
        -0x49t
        -0x49t
        0x22t
        0x67t
        0x41t
    .end array-data

    :array_7
    .array-data 1
        0x17t
        0x47t
        -0xct
        -0xat
        0x64t
        0x52t
        0x71t
        -0x1dt
    .end array-data
.end method
