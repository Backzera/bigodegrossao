.class Lcom/icontrol/protector/ChatActivity$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/ChatActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:Lcom/icontrol/protector/ChatActivity;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/ChatActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/ChatActivity$a;->b:Lcom/icontrol/protector/ChatActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6

    iget-object p1, p0, Lcom/icontrol/protector/ChatActivity$a;->b:Lcom/icontrol/protector/ChatActivity;

    invoke-static {p1}, Lcom/icontrol/protector/ChatActivity;->a(Lcom/icontrol/protector/ChatActivity;)Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/icontrol/protector/ChatActivity$a;->b:Lcom/icontrol/protector/ChatActivity;

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Lcom/icontrol/protector/ChatActivity;->c(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/icontrol/protector/ChatActivity$a;->b:Lcom/icontrol/protector/ChatActivity;

    invoke-static {v0}, Lcom/icontrol/protector/ChatActivity;->a(Lcom/icontrol/protector/ChatActivity;)Landroid/widget/EditText;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v1, 0x4

    new-array v3, v1, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v1, [B

    fill-array-data v4, :array_4

    new-array v5, v2, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v2, v2, [B

    fill-array-data v2, :array_7

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/icontrol/protector/ChatActivity$a;->b:Lcom/icontrol/protector/ChatActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void

    nop

    :array_0
    .array-data 1
        0x53t
        -0x36t
        0x31t
    .end array-data

    :array_1
    .array-data 1
        0xat
        -0x5bt
        0x44t
        0x6dt
        0x76t
        -0x5ft
        0x69t
        0x4ct
    .end array-data

    :array_2
    .array-data 1
        -0x3ft
        0x4at
        0x16t
        0x53t
    .end array-data

    :array_3
    .array-data 1
        -0x4bt
        0x33t
        0x66t
        0x36t
        0x2bt
        0x7ft
        0x2dt
        0x1ft
    .end array-data

    :array_4
    .array-data 1
        -0x3ft
        -0x21t
        0x54t
        -0x24t
    .end array-data

    :array_5
    .array-data 1
        -0x5et
        -0x49t
        0x35t
        -0x58t
        0x5at
        -0x52t
        0x3et
        0x26t
    .end array-data

    :array_6
    .array-data 1
        0x60t
        0x77t
        -0x37t
        -0x69t
    .end array-data

    :array_7
    .array-data 1
        0x4t
        0x16t
        -0x43t
        -0xat
        -0x7t
        -0x73t
        0x33t
        -0x39t
    .end array-data
.end method
