.class public Lcom/icontrol/protector/WebBrowser$d;
.super Landroid/webkit/WebChromeClient;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/WebBrowser;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/WebBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/WebBrowser;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser$d;->a:Lcom/icontrol/protector/WebBrowser;

    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    return-void
.end method
