.class public Lcom/icontrol/protector/RestrectionActivity$d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/RestrectionActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field a:Landroid/content/Context;

.field final synthetic b:Lcom/icontrol/protector/RestrectionActivity;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/RestrectionActivity;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/RestrectionActivity$d;->b:Lcom/icontrol/protector/RestrectionActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/icontrol/protector/RestrectionActivity$d;->a:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public OK()V
    .locals 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/RestrectionActivity$d;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/icontrol/protector/n;->j(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method
