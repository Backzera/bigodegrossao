.class public Lcom/icontrol/protector/RequestDataUsage;
.super Landroid/app/Activity;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/RequestDataUsage$b;
    }
.end annotation


# instance fields
.field b:Z

.field private c:Lcom/icontrol/protector/RequestDataUsage$b;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/RequestDataUsage;->b:Z

    new-instance v0, Lcom/icontrol/protector/RequestDataUsage$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/icontrol/protector/RequestDataUsage$b;-><init>(Lcom/icontrol/protector/RequestDataUsage$a;)V

    iput-object v0, p0, Lcom/icontrol/protector/RequestDataUsage;->c:Lcom/icontrol/protector/RequestDataUsage$b;

    return-void
.end method


# virtual methods
.method public a()V
    .locals 11

    .line 1
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Landroid/app/AlertDialog$Builder;

    const v2, 0x10302d1

    invoke-direct {v1, p0, v2}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    const/4 v2, 0x2

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/16 v6, 0xc31

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eq v5, v6, :cond_4

    const/16 v6, 0xca9

    if-eq v5, v6, :cond_3

    const/16 v6, 0xe43

    if-eq v5, v6, :cond_2

    const/16 v6, 0xe7e

    if-eq v5, v6, :cond_1

    const/16 v6, 0xf2e

    if-eq v5, v6, :cond_0

    goto/16 :goto_0

    :cond_0
    new-array v5, v2, [B

    fill-array-data v5, :array_2

    new-array v6, v4, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    move v0, v2

    goto :goto_1

    :cond_1
    new-array v5, v2, [B

    fill-array-data v5, :array_4

    new-array v6, v4, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    move v0, v9

    goto :goto_1

    :cond_2
    new-array v5, v2, [B

    fill-array-data v5, :array_6

    new-array v6, v4, [B

    fill-array-data v6, :array_7

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    move v0, v8

    goto :goto_1

    :cond_3
    new-array v5, v2, [B

    fill-array-data v5, :array_8

    new-array v6, v4, [B

    fill-array-data v6, :array_9

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    const/4 v0, 0x0

    goto :goto_1

    :cond_4
    new-array v5, v2, [B

    fill-array-data v5, :array_a

    new-array v6, v4, [B

    fill-array-data v6, :array_b

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    move v0, v7

    goto :goto_1

    :cond_5
    :goto_0
    const/4 v0, -0x1

    :goto_1
    const/16 v5, 0x13

    const/16 v6, 0x24

    const/4 v10, 0x6

    if-eqz v0, :cond_a

    if-eq v0, v7, :cond_9

    if-eq v0, v2, :cond_8

    if-eq v0, v9, :cond_7

    if-eq v0, v8, :cond_6

    new-array v0, v2, [B

    fill-array-data v0, :array_c

    new-array v2, v4, [B

    fill-array-data v2, :array_d

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v7, v10, [B

    fill-array-data v7, :array_e

    new-array v8, v4, [B

    fill-array-data v8, :array_f

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v6, v6, [B

    fill-array-data v6, :array_10

    new-array v7, v4, [B

    fill-array-data v7, :array_11

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    :goto_2
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    goto/16 :goto_3

    :cond_6
    const/16 v0, 0x10

    new-array v0, v0, [B

    fill-array-data v0, :array_12

    new-array v2, v4, [B

    fill-array-data v2, :array_13

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v6, v5, [B

    fill-array-data v6, :array_14

    new-array v7, v4, [B

    fill-array-data v7, :array_15

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x62

    new-array v6, v6, [B

    fill-array-data v6, :array_16

    new-array v7, v4, [B

    fill-array-data v7, :array_17

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto :goto_2

    :cond_7
    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_18

    new-array v2, v4, [B

    fill-array-data v2, :array_19

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x50

    new-array v6, v6, [B

    fill-array-data v6, :array_1a

    new-array v7, v4, [B

    fill-array-data v7, :array_1b

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto :goto_2

    :cond_8
    new-array v0, v10, [B

    fill-array-data v0, :array_1c

    new-array v2, v4, [B

    fill-array-data v2, :array_1d

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    new-array v6, v6, [B

    fill-array-data v6, :array_1e

    new-array v7, v4, [B

    fill-array-data v7, :array_1f

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x28

    new-array v6, v6, [B

    fill-array-data v6, :array_20

    new-array v7, v4, [B

    fill-array-data v7, :array_21

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto/16 :goto_2

    :cond_9
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_22

    new-array v2, v4, [B

    fill-array-data v2, :array_23

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0xe

    new-array v6, v6, [B

    fill-array-data v6, :array_24

    new-array v7, v4, [B

    fill-array-data v7, :array_25

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x4a

    new-array v6, v6, [B

    fill-array-data v6, :array_26

    new-array v7, v4, [B

    fill-array-data v7, :array_27

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto/16 :goto_2

    :cond_a
    new-array v0, v10, [B

    fill-array-data v0, :array_28

    new-array v2, v4, [B

    fill-array-data v2, :array_29

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v7, v10, [B

    fill-array-data v7, :array_2a

    new-array v8, v4, [B

    fill-array-data v8, :array_2b

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v6, v6, [B

    fill-array-data v6, :array_2c

    new-array v7, v4, [B

    fill-array-data v7, :array_2d

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto/16 :goto_2

    :goto_3
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    new-array v5, v5, [B

    fill-array-data v5, :array_2e

    new-array v6, v4, [B

    fill-array-data v6, :array_2f

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/app/AlertDialog$Builder;

    const/16 v2, 0xb

    new-array v2, v2, [B

    fill-array-data v2, :array_30

    new-array v5, v4, [B

    fill-array-data v5, :array_31

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    :catch_0
    :try_start_1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/16 v5, 0x14

    new-array v5, v5, [B

    fill-array-data v5, :array_32

    new-array v6, v4, [B

    fill-array-data v6, :array_33

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/app/AlertDialog$Builder;

    new-array v2, v4, [B

    fill-array-data v2, :array_34

    new-array v4, v4, [B

    fill-array-data v4, :array_35

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_4

    :catch_1
    :try_start_2
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_4

    :catch_2
    move-exception v2

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/app/AlertDialog$Builder;

    const-string v2, ""

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    :goto_4
    new-instance v2, Lcom/icontrol/protector/RequestDataUsage$a;

    invoke-direct {v2, p0}, Lcom/icontrol/protector/RequestDataUsage$a;-><init>(Lcom/icontrol/protector/RequestDataUsage;)V

    invoke-virtual {v1, v0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    :array_0
    .array-data 1
        -0xbt
        -0x44t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x46t
        -0x9t
        -0x42t
        -0x24t
        0x6bt
        -0x68t
        0x4ct
        -0x35t
    .end array-data

    :array_2
    .array-data 1
        0xat
        0x6ft
    .end array-data

    nop

    :array_3
    .array-data 1
        0x70t
        0x7t
        -0xat
        -0x6ct
        0x53t
        -0x45t
        0x59t
        0x27t
    .end array-data

    :array_4
    .array-data 1
        -0x25t
        0xat
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x51t
        0x78t
        -0x12t
        0x25t
        -0x34t
        0x69t
        0x34t
        -0x21t
    .end array-data

    :array_6
    .array-data 1
        0x2bt
        -0x1ct
    .end array-data

    nop

    :array_7
    .array-data 1
        0x59t
        -0x6ft
        0x38t
        0x7ct
        0x3bt
        0x40t
        0x54t
        -0x51t
    .end array-data

    :array_8
    .array-data 1
        -0x6at
        0x1dt
    .end array-data

    nop

    :array_9
    .array-data 1
        -0xdt
        0x73t
        -0x17t
        -0x52t
        -0x37t
        -0x39t
        -0x79t
        0x49t
    .end array-data

    :array_a
    .array-data 1
        0x68t
        -0x72t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x9t
        -0x4t
        -0x37t
        -0x70t
        -0x75t
        -0x3et
        0x73t
        0x20t
    .end array-data

    :array_c
    .array-data 1
        0x66t
        0x77t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x29t
        0x3ct
        0x73t
        -0x60t
        -0x1at
        -0x24t
        0x4at
        -0x43t
    .end array-data

    :array_e
    .array-data 1
        -0x55t
        -0xat
        0x8t
        -0x5et
        -0x61t
        -0x47t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x16t
        -0x66t
        0x64t
        -0x33t
        -0x18t
        -0x67t
        0x17t
        -0x28t
    .end array-data

    :array_10
    .array-data 1
        -0x29t
        0x30t
        -0x4t
        -0x48t
        -0x12t
        -0x22t
        -0x18t
        0x1bt
        -0x6bt
        0x25t
        -0x10t
        -0xdt
        -0x4t
        -0x21t
        -0x1et
        0x4et
        -0x67t
        0x20t
        -0x4dt
        -0x4t
        -0x6t
        -0x27t
        -0x14t
        0x1bt
        -0x6ft
        0x2bt
        -0x1ft
        -0x48t
        -0x12t
        -0x23t
        -0x17t
        0x5at
        -0x7dt
        0x21t
        -0x20t
        -0x4at
    .end array-data

    :array_11
    .array-data 1
        -0x9t
        0x44t
        -0x6dt
        -0x68t
        -0x65t
        -0x53t
        -0x73t
        0x3bt
    .end array-data

    :array_12
    .array-data 1
        0x52t
        -0x57t
        0x28t
        -0x38t
        -0x15t
        -0x1bt
        0x8t
        -0x58t
        0x53t
        -0x44t
        0x28t
        -0x36t
        -0x16t
        -0x24t
        0x8t
        -0x56t
    .end array-data

    :array_13
    .array-data 1
        -0x7et
        0x3bt
        -0x8t
        0x72t
        0x3bt
        0x5et
        -0x27t
        0x26t
    .end array-data

    :array_14
    .array-data 1
        -0x6ct
        0x45t
        0x38t
        0x16t
        -0x6ct
        0x34t
        -0x16t
        0x63t
        -0x6ct
        0x50t
        0x39t
        0x2et
        -0x6ct
        0x3bt
        -0x16t
        0x61t
        -0x6ct
        0x50t
        -0x38t
    .end array-data

    :array_15
    .array-data 1
        0x44t
        -0x1bt
        -0x18t
        -0x5at
        0x44t
        -0x7dt
        0x3bt
        -0x1dt
    .end array-data

    :array_16
    .array-data 1
        -0x12t
        0x16t
        0x13t
        0x7bt
        0x26t
        0x60t
        -0x40t
        -0x8t
        0x70t
        0x16t
        0x10t
        0x7bt
        0x2bt
        0x60t
        -0x38t
        -0x8t
        0x70t
        0x16t
        0x19t
        0x7at
        0x17t
        0x61t
        -0x3t
        -0x7t
        0x42t
        -0x1at
        0x7bt
        0x1et
        0x77t
        0x0t
        -0x51t
        -0x6bt
        0x1et
        0x7bt
        0x7at
        0x21t
        0x77t
        0x5t
        0x5ft
        -0x8t
        0x7ct
        -0x1at
        0x7at
        0x2et
        0x77t
        0xet
        -0x51t
        -0x6bt
        0x1et
        0x78t
        0x7bt
        0x18t
        0x77t
        0xet
        -0x51t
        -0x6ct
        -0x12t
        0x17t
        0x2bt
        0x7at
        0x12t
        0x60t
        -0x37t
        -0x8t
        0x76t
        0x16t
        0x17t
        0x7at
        0x12t
        -0x70t
        -0x51t
        -0x64t
        0x1et
        0x7dt
        0x7at
        0x25t
        -0x79t
        0x60t
        -0x3ft
        -0x8t
        0x7ft
        0x16t
        0x16t
        0x7at
        0x19t
        0x60t
        -0x33t
        -0x8t
        0x75t
        0x16t
        0x1et
        0x7at
        0x1at
        0x60t
        -0x39t
        -0x8t
        0x77t
        -0x18t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x32t
        -0x3at
        -0x55t
        -0x56t
        -0x59t
        -0x50t
        0x7ft
        0x28t
    .end array-data

    :array_18
    .array-data 1
        -0x6et
        0x29t
        0xdt
        0xdt
        -0x46t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x3at
        0x48t
        0x60t
        0x6ct
        -0x29t
        0x12t
        -0x12t
        -0x1at
    .end array-data

    :array_1a
    .array-data 1
        -0x5bt
        -0x33t
        0x74t
        -0x6at
        -0x13t
        -0xct
        -0x4dt
        -0x61t
        -0x1ct
        -0x35t
        -0x37t
        0x40t
        -0xat
        0x5ct
        0x63t
        -0x64t
        -0x5bt
        -0x21t
        -0x32t
        0x4dt
        -0xat
        -0x5t
        -0x49t
        -0x62t
        -0x17t
        -0x23t
        0x60t
        -0x6ct
        -0xct
        -0x3t
        -0x60t
        -0x2et
        -0x14t
        0x7bt
        -0x56t
        -0x68t
        -0xat
        -0x48t
        -0x4dt
        -0x80t
        -0x12t
        -0x27t
        0x2dt
        -0x7ft
        -0xct
        -0x7t
        -0x44t
        -0x6at
        -0x1ct
        -0x68t
        0x7bt
        -0x6ct
        -0x16t
        -0xft
        -0xet
        -0x67t
        -0x10t
        -0x2ct
        0x61t
        -0x70t
        -0xat
        -0xbt
        -0x4dt
        -0x7ft
        0x41t
        0x9t
        0x63t
        -0x70t
        -0x48t
        -0xft
        -0x58t
        -0x65t
        -0x15t
        -0x68t
        0x7bt
        -0x6ct
        -0x16t
        -0xft
        -0x44t
        -0x24t
    .end array-data

    :array_1b
    .array-data 1
        -0x7bt
        -0x48t
        0xdt
        -0xft
        -0x68t
        -0x68t
        -0x2et
        -0xet
    .end array-data

    :array_1c
    .array-data 1
        -0x4et
        -0x51t
        -0x5dt
        0x2bt
        -0x6bt
        -0x24t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x57t
        0x3ft
        0xct
        -0x34t
        0x1t
        0x74t
        0x4at
        -0x46t
    .end array-data

    :array_1e
    .array-data 1
        -0x15t
        -0x38t
        -0x1bt
        -0x47t
        -0x43t
        0x7t
        -0x68t
    .end array-data

    :array_1f
    .array-data 1
        0xet
        0x4dt
        0x64t
        0x51t
        0x13t
        -0x41t
        -0x48t
        0x49t
    .end array-data

    :array_20
    .array-data 1
        0x7at
        -0x3t
        0x12t
        0x49t
        0x48t
        0x72t
        0x79t
        -0x66t
        -0x2bt
        -0x58t
        0x6at
        0x5ct
        0x12t
        0x5t
        0x63t
        -0x29t
        -0x44t
        -0x73t
        0x3et
        0x7t
        0x20t
        0x4ct
        0x13t
        -0x3ct
        -0x1t
        -0x10t
        0x0t
        0x56t
        0x48t
        0x6dt
        0x61t
        -0x67t
        -0x3ft
        -0x54t
        0x68t
        0x77t
        0x1dt
        0x1t
        0x77t
        -0x3t
    .end array-data

    :array_21
    .array-data 1
        0x5at
        0x18t
        -0x72t
        -0x1ft
        -0x53t
        -0x1et
        -0x9t
        0x7ft
    .end array-data

    :array_22
    .array-data 1
        -0x7at
        -0x43t
        -0x6et
        -0x44t
        0x71t
        0x28t
        0x48t
        0x8t
        -0x79t
        -0x6dt
    .end array-data

    nop

    :array_23
    .array-data 1
        0x5et
        0x17t
        0x4bt
        0x3dt
        -0x57t
        -0x6ft
        -0x6ft
        -0x7et
    .end array-data

    :array_24
    .array-data 1
        -0x37t
        -0x64t
        -0x39t
        -0x52t
        0x0t
        0x18t
        -0x7at
        0x21t
        0x31t
        -0x1et
        -0x65t
        -0x3ct
        0x59t
        -0x43t
    .end array-data

    nop

    :array_25
    .array-data 1
        0x11t
        0x3bt
        0x1ft
        0x1dt
        -0x27t
        -0x63t
        0x5et
        -0x74t
    .end array-data

    :array_26
    .array-data 1
        -0x5ft
        0x65t
        -0x10t
        0x21t
        -0x40t
        -0x47t
        -0x27t
        0x29t
        0x2bt
        0x65t
        -0xat
        0x21t
        -0x38t
        -0x47t
        -0x33t
        0x28t
        0x4t
        -0x63t
        -0x80t
        0x5et
        -0x42t
        -0x1bt
        -0x4et
        0x59t
        0x58t
        0x37t
        -0x80t
        0x5et
        -0x42t
        -0x19t
        -0x4et
        0x56t
        0x59t
        0x17t
        0x78t
        0x20t
        -0x1at
        -0x48t
        -0x20t
        -0x2ft
        0x59t
        0x1at
        -0x7ft
        0x7dt
        -0x41t
        -0x31t
        -0x4dt
        0x75t
        0x58t
        0x3ct
        -0x7ft
        0x73t
        -0x41t
        -0x38t
        0x4at
        0x28t
        0x5t
        0x64t
        -0x24t
        0x21t
        -0x33t
        -0x47t
        -0x39t
        0x29t
        0x2et
        0x64t
        -0x2et
        0x21t
        -0x34t
        -0x47t
        -0x33t
        0x29t
        0x2bt
        -0x6dt
    .end array-data

    nop

    :array_27
    .array-data 1
        -0x7ft
        -0x43t
        0x58t
        -0x7t
        0x67t
        0x61t
        0x6at
        -0xft
    .end array-data

    :array_28
    .array-data 1
        0x70t
        0x14t
        -0x70t
        -0x56t
        -0xet
        -0x14t
    .end array-data

    nop

    :array_29
    .array-data 1
        0x35t
        0x7at
        -0xft
        -0x38t
        -0x62t
        -0x77t
        0x1ct
        -0x44t
    .end array-data

    :array_2a
    .array-data 1
        -0x1ft
        -0x6dt
        -0x34t
        0x76t
        0x69t
        0x75t
    .end array-data

    nop

    :array_2b
    .array-data 1
        -0x60t
        -0x1t
        -0x60t
        0x19t
        0x1et
        0x55t
        -0x75t
        -0x16t
    .end array-data

    :array_2c
    .array-data 1
        -0x57t
        -0x54t
        0xct
        0x7ft
        -0x74t
        0x3dt
        -0x18t
        -0x67t
        -0x15t
        -0x47t
        0x0t
        0x34t
        -0x62t
        0x3ct
        -0x1et
        -0x34t
        -0x19t
        -0x44t
        0x43t
        0x3bt
        -0x68t
        0x3at
        -0x14t
        -0x67t
        -0x11t
        -0x49t
        0x11t
        0x7ft
        -0x74t
        0x3et
        -0x17t
        -0x28t
        -0x3t
        -0x43t
        0x10t
        0x71t
    .end array-data

    :array_2d
    .array-data 1
        -0x77t
        -0x28t
        0x63t
        0x5ft
        -0x7t
        0x4et
        -0x73t
        -0x47t
    .end array-data

    :array_2e
    .array-data 1
        -0x79t
        0x71t
        -0x55t
        0x7dt
        0x27t
        0x15t
        -0x1ct
        -0x8t
        -0x75t
        0x77t
        -0x5et
        0x7dt
        0x30t
        0x1et
        -0x12t
        -0x12t
        -0x73t
        0x70t
        -0x5ft
    .end array-data

    :array_2f
    .array-data 1
        -0x1ct
        0x1et
        -0x3at
        0x53t
        0x46t
        0x7bt
        -0x80t
        -0x76t
    .end array-data

    :array_30
    .array-data 1
        -0x66t
        0x3ct
        0x16t
        0x9t
        -0x50t
        0x3bt
        0x61t
        -0x7ft
        -0x4ft
        0x32t
        0x0t
    .end array-data

    :array_31
    .array-data 1
        -0x23t
        0x53t
        0x79t
        0x6et
        -0x24t
        0x5et
        0x41t
        -0x2ft
    .end array-data

    :array_32
    .array-data 1
        0x50t
        -0xdt
        0x3dt
        0x14t
        0x65t
        -0x4ct
        0x2bt
        -0x5et
        0x5ct
        -0xbt
        0x34t
        0x14t
        0x77t
        -0x41t
        0x3bt
        -0x5ct
        0x5at
        -0xet
        0x37t
        0x49t
    .end array-data

    :array_33
    .array-data 1
        0x33t
        -0x64t
        0x50t
        0x3at
        0x4t
        -0x26t
        0x4ft
        -0x30t
    .end array-data

    :array_34
    .array-data 1
        0x8t
        -0x50t
        -0x9t
        -0x46t
        0xdt
        -0x72t
        -0x34t
        0x61t
    .end array-data

    :array_35
    .array-data 1
        0x5bt
        -0x2bt
        -0x7dt
        -0x32t
        0x64t
        -0x20t
        -0x55t
        0x12t
    .end array-data
.end method

.method public finish()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/16 p1, 0xc

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_1

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/net/ConnectivityManager;

    invoke-virtual {p1}, Landroid/net/ConnectivityManager;->isActiveNetworkMetered()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    invoke-virtual {p1}, Landroid/net/ConnectivityManager;->getRestrictBackgroundStatus()I

    move-result p1

    const/4 v1, 0x3

    if-eq p1, v1, :cond_0

    sput-boolean v2, Lcom/icontrol/protector/AccessServices;->u:Z

    invoke-virtual {p0}, Lcom/icontrol/protector/RequestDataUsage;->finish()V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lcom/icontrol/protector/RequestDataUsage;->a()V

    :goto_0
    iget-object p1, p0, Lcom/icontrol/protector/RequestDataUsage;->c:Lcom/icontrol/protector/RequestDataUsage$b;

    new-instance v1, Landroid/content/IntentFilter;

    const/16 v2, 0x2c

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 p1, 0x1

    iput-boolean p1, p0, Lcom/icontrol/protector/RequestDataUsage;->b:Z

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Lcom/icontrol/protector/RequestDataUsage;->finish()V

    sput-boolean v2, Lcom/icontrol/protector/AccessServices;->u:Z

    :goto_1
    return-void

    :array_0
    .array-data 1
        -0x72t
        -0x79t
        0x48t
        -0xbt
        -0x6et
        0x17t
        0x3ft
        -0x42t
        -0x65t
        -0x7ft
        0x52t
        -0x1et
    .end array-data

    :array_1
    .array-data 1
        -0x13t
        -0x18t
        0x26t
        -0x65t
        -0x9t
        0x74t
        0x4bt
        -0x29t
    .end array-data

    :array_2
    .array-data 1
        0x6et
        0x8t
        0x1at
        -0x3ft
        0x56t
        -0x2et
        0x26t
        0x7t
        0x61t
        0x3t
        0xat
        -0x63t
        0x5at
        -0x2ct
        0x2ct
        0x47t
        0x21t
        0x34t
        0x3bt
        -0x20t
        0x6dt
        -0x17t
        0xbt
        0x6at
        0x5bt
        0x39t
        0x3ct
        -0xet
        0x7at
        -0x10t
        0x5t
        0x7bt
        0x40t
        0x33t
        0x30t
        -0x9t
        0x66t
        -0x8t
        0xat
        0x68t
        0x41t
        0x21t
        0x3bt
        -0x9t
    .end array-data

    :array_3
    .array-data 1
        0xft
        0x66t
        0x7et
        -0x4dt
        0x39t
        -0x45t
        0x42t
        0x29t
    .end array-data
.end method

.method protected onDestroy()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    :try_start_0
    iget-boolean v0, p0, Lcom/icontrol/protector/RequestDataUsage;->b:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/icontrol/protector/RequestDataUsage;->c:Lcom/icontrol/protector/RequestDataUsage$b;

    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method
