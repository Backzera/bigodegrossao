.class public final enum Lcom/icontrol/protector/d$b;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation


# static fields
.field public static final enum f:Lcom/icontrol/protector/d$b;

.field public static final enum g:Lcom/icontrol/protector/d$b;

.field public static final enum h:Lcom/icontrol/protector/d$b;

.field public static final enum i:Lcom/icontrol/protector/d$b;

.field private static final synthetic j:[Lcom/icontrol/protector/d$b;


# instance fields
.field private e:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 15

    new-instance v0, Lcom/icontrol/protector/d$b;

    const/4 v1, 0x6

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    new-array v5, v4, [B

    fill-array-data v5, :array_2

    new-array v6, v3, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/4 v5, 0x4

    new-array v6, v5, [B

    fill-array-data v6, :array_4

    new-array v8, v3, [B

    fill-array-data v8, :array_5

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v6, v4, [B

    fill-array-data v6, :array_6

    new-array v9, v3, [B

    fill-array-data v9, :array_7

    invoke-static {v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-array v6, v4, [B

    fill-array-data v6, :array_8

    new-array v10, v3, [B

    fill-array-data v10, :array_9

    invoke-static {v6, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    new-array v6, v4, [B

    fill-array-data v6, :array_a

    new-array v11, v3, [B

    fill-array-data v11, :array_b

    invoke-static {v6, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v6, v5, [B

    fill-array-data v6, :array_c

    new-array v12, v3, [B

    fill-array-data v12, :array_d

    invoke-static {v6, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    new-array v6, v5, [B

    fill-array-data v6, :array_e

    new-array v13, v3, [B

    fill-array-data v13, :array_f

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    new-array v6, v5, [B

    fill-array-data v6, :array_10

    new-array v14, v3, [B

    fill-array-data v14, :array_11

    invoke-static {v6, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v14

    filled-new-array/range {v7 .. v14}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-direct {v0, v2, v7, v6}, Lcom/icontrol/protector/d$b;-><init>(Ljava/lang/String;I[Ljava/lang/String;)V

    sput-object v0, Lcom/icontrol/protector/d$b;->f:Lcom/icontrol/protector/d$b;

    new-instance v0, Lcom/icontrol/protector/d$b;

    new-array v2, v1, [B

    fill-array-data v2, :array_12

    new-array v6, v3, [B

    fill-array-data v6, :array_13

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v6, v4, [B

    fill-array-data v6, :array_14

    new-array v7, v3, [B

    fill-array-data v7, :array_15

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v6, v4, [B

    fill-array-data v6, :array_16

    new-array v7, v3, [B

    fill-array-data v7, :array_17

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-array v6, v4, [B

    fill-array-data v6, :array_18

    new-array v7, v3, [B

    fill-array-data v7, :array_19

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    new-array v6, v4, [B

    fill-array-data v6, :array_1a

    new-array v7, v3, [B

    fill-array-data v7, :array_1b

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v6, v4, [B

    fill-array-data v6, :array_1c

    new-array v7, v3, [B

    fill-array-data v7, :array_1d

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    new-array v6, v4, [B

    fill-array-data v6, :array_1e

    new-array v7, v3, [B

    fill-array-data v7, :array_1f

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    new-array v6, v4, [B

    fill-array-data v6, :array_20

    new-array v7, v3, [B

    fill-array-data v7, :array_21

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v14

    filled-new-array/range {v8 .. v14}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    invoke-direct {v0, v2, v7, v6}, Lcom/icontrol/protector/d$b;-><init>(Ljava/lang/String;I[Ljava/lang/String;)V

    sput-object v0, Lcom/icontrol/protector/d$b;->g:Lcom/icontrol/protector/d$b;

    new-instance v0, Lcom/icontrol/protector/d$b;

    new-array v1, v1, [B

    fill-array-data v1, :array_22

    new-array v2, v3, [B

    fill-array-data v2, :array_23

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v2, v4, [B

    fill-array-data v2, :array_24

    new-array v6, v3, [B

    fill-array-data v6, :array_25

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v2, v4, [B

    fill-array-data v2, :array_26

    new-array v6, v3, [B

    fill-array-data v6, :array_27

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v2, v5, [B

    fill-array-data v2, :array_28

    new-array v6, v3, [B

    fill-array-data v6, :array_29

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-array v2, v4, [B

    fill-array-data v2, :array_2a

    new-array v6, v3, [B

    fill-array-data v6, :array_2b

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    new-array v2, v4, [B

    fill-array-data v2, :array_2c

    new-array v6, v3, [B

    fill-array-data v6, :array_2d

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v2, v4, [B

    fill-array-data v2, :array_2e

    new-array v6, v3, [B

    fill-array-data v6, :array_2f

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    new-array v2, v4, [B

    fill-array-data v2, :array_30

    new-array v6, v3, [B

    fill-array-data v6, :array_31

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    filled-new-array/range {v7 .. v13}, [Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    invoke-direct {v0, v1, v6, v2}, Lcom/icontrol/protector/d$b;-><init>(Ljava/lang/String;I[Ljava/lang/String;)V

    sput-object v0, Lcom/icontrol/protector/d$b;->h:Lcom/icontrol/protector/d$b;

    new-instance v0, Lcom/icontrol/protector/d$b;

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_32

    new-array v2, v3, [B

    fill-array-data v2, :array_33

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v2, v4, [B

    fill-array-data v2, :array_34

    new-array v6, v3, [B

    fill-array-data v6, :array_35

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v2, v4, [B

    fill-array-data v2, :array_36

    new-array v6, v3, [B

    fill-array-data v6, :array_37

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v2, v5, [B

    fill-array-data v2, :array_38

    new-array v6, v3, [B

    fill-array-data v6, :array_39

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-array v2, v4, [B

    fill-array-data v2, :array_3a

    new-array v6, v3, [B

    fill-array-data v6, :array_3b

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    new-array v2, v5, [B

    fill-array-data v2, :array_3c

    new-array v6, v3, [B

    fill-array-data v6, :array_3d

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v2, v4, [B

    fill-array-data v2, :array_3e

    new-array v6, v3, [B

    fill-array-data v6, :array_3f

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    new-array v2, v5, [B

    fill-array-data v2, :array_40

    new-array v5, v3, [B

    fill-array-data v5, :array_41

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    new-array v2, v4, [B

    fill-array-data v2, :array_42

    new-array v3, v3, [B

    fill-array-data v3, :array_43

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v14

    filled-new-array/range {v7 .. v14}, [Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v4, v2}, Lcom/icontrol/protector/d$b;-><init>(Ljava/lang/String;I[Ljava/lang/String;)V

    sput-object v0, Lcom/icontrol/protector/d$b;->i:Lcom/icontrol/protector/d$b;

    invoke-static {}, Lcom/icontrol/protector/d$b;->a()[Lcom/icontrol/protector/d$b;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/d$b;->j:[Lcom/icontrol/protector/d$b;

    return-void

    nop

    :array_0
    .array-data 1
        0x43t
        -0xet
        -0x4dt
        -0x6ft
        0xbt
        -0x3et
    .end array-data

    nop

    :array_1
    .array-data 1
        0xat
        -0x41t
        -0xet
        -0x2at
        0x4et
        -0x6ft
        0x9t
        0x14t
    .end array-data

    :array_2
    .array-data 1
        -0xft
        0x40t
        -0x38t
    .end array-data

    :array_3
    .array-data 1
        -0x65t
        0x30t
        -0x51t
        -0x2bt
        0x6ct
        0x20t
        -0x4et
        0x79t
    .end array-data

    :array_4
    .array-data 1
        -0x2ft
        0x4ft
        0x3ct
        -0x27t
    .end array-data

    :array_5
    .array-data 1
        -0x45t
        0x3ft
        0x59t
        -0x42t
        0xat
        -0x2ct
        -0x56t
        -0x2dt
    .end array-data

    :array_6
    .array-data 1
        -0x33t
        -0x1bt
        -0x23t
    .end array-data

    :array_7
    .array-data 1
        -0x43t
        -0x75t
        -0x46t
        -0x77t
        -0x53t
        -0x7ct
        -0x41t
        0x3dt
    .end array-data

    :array_8
    .array-data 1
        0x7t
        -0x3ct
        0x43t
    .end array-data

    :array_9
    .array-data 1
        0x60t
        -0x53t
        0x25t
        0x50t
        -0x12t
        0x7et
        0x1at
        -0x59t
    .end array-data

    :array_a
    .array-data 1
        -0x2dt
        0x19t
        -0x60t
    .end array-data

    :array_b
    .array-data 1
        -0x4ft
        0x74t
        -0x30t
        -0x74t
        0x68t
        0xdt
        0x74t
        -0x64t
    .end array-data

    :array_c
    .array-data 1
        -0x72t
        -0x3dt
        0x77t
        0x11t
    .end array-data

    :array_d
    .array-data 1
        -0x7t
        -0x5at
        0x15t
        0x61t
        0x6et
        -0x2bt
        -0x5bt
        -0x3dt
    .end array-data

    :array_e
    .array-data 1
        0x5et
        -0x5ct
        -0x32t
        -0x51t
    .end array-data

    :array_f
    .array-data 1
        0x36t
        -0x3ft
        -0x59t
        -0x34t
        0x61t
        0x7dt
        0x76t
        0x51t
    .end array-data

    :array_10
    .array-data 1
        0x9t
        -0x4et
        -0x5ft
        -0x80t
    .end array-data

    :array_11
    .array-data 1
        0x61t
        -0x29t
        -0x38t
        -0x1at
        0x26t
        -0x1at
        0x70t
        -0xft
    .end array-data

    :array_12
    .array-data 1
        0x24t
        -0x2ft
        -0x35t
        -0x9t
        0x4at
        -0x80t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x72t
        -0x68t
        -0x71t
        -0x4et
        0x5t
        -0x2dt
        0x59t
        -0x7ft
    .end array-data

    :array_14
    .array-data 1
        -0x40t
        -0x24t
        0x2ft
    .end array-data

    :array_15
    .array-data 1
        -0x53t
        -0x54t
        0x1bt
        0x58t
        -0x3dt
        0x7bt
        0x23t
        -0x4bt
    .end array-data

    :array_16
    .array-data 1
        0x54t
        0x78t
        -0x3ft
    .end array-data

    :array_17
    .array-data 1
        0x39t
        0x13t
        -0x49t
        0x2et
        0x3et
        0x7ct
        -0x3et
        0x60t
    .end array-data

    :array_18
    .array-data 1
        -0x75t
        -0x3ft
        -0x67t
    .end array-data

    :array_19
    .array-data 1
        -0x48t
        -0x5at
        -0x17t
        0x14t
        -0x2ft
        -0x2at
        0x7ft
        0x15t
    .end array-data

    :array_1a
    .array-data 1
        0x7t
        -0x3bt
        0x1et
    .end array-data

    :array_1b
    .array-data 1
        0x66t
        -0x4dt
        0x77t
        0x6et
        0x65t
        -0x17t
        0x46t
        -0x9t
    .end array-data

    :array_1c
    .array-data 1
        0x29t
        0x30t
        0x62t
    .end array-data

    :array_1d
    .array-data 1
        0x44t
        0x5ft
        0x14t
        0x76t
        -0x22t
        0x14t
        0x16t
        -0x5bt
    .end array-data

    :array_1e
    .array-data 1
        0x13t
        -0xat
        -0x80t
    .end array-data

    :array_1f
    .array-data 1
        0x75t
        -0x66t
        -0xat
        0x5et
        -0x3at
        -0x20t
        0x14t
        -0x7et
    .end array-data

    :array_20
    .array-data 1
        -0x5et
        -0x16t
        -0x3dt
    .end array-data

    :array_21
    .array-data 1
        -0x2bt
        -0x79t
        -0x4bt
        0x1ct
        0x2at
        0x20t
        -0x21t
        -0x6et
    .end array-data

    :array_22
    .array-data 1
        -0x54t
        -0x4et
        0x55t
        0x3ct
        -0x69t
        0x1t
    .end array-data

    nop

    :array_23
    .array-data 1
        -0x13t
        -0x19t
        0x11t
        0x75t
        -0x28t
        0x52t
        -0x1et
        0x51t
    .end array-data

    :array_24
    .array-data 1
        -0x1et
        -0x63t
        -0x76t
    .end array-data

    :array_25
    .array-data 1
        -0x71t
        -0x13t
        -0x47t
        -0x49t
        0x11t
        0x50t
        -0x27t
        -0x7t
    .end array-data

    :array_26
    .array-data 1
        -0x58t
        0x7et
        -0x1dt
    .end array-data

    :array_27
    .array-data 1
        -0x37t
        0x1ft
        -0x80t
        0x3at
        -0x30t
        0x7at
        -0x9t
        0x5at
    .end array-data

    :array_28
    .array-data 1
        -0x49t
        0x24t
        -0x36t
        -0x19t
    .end array-data

    :array_29
    .array-data 1
        -0x2ft
        0x48t
        -0x55t
        -0x7ct
        0x3t
        -0x77t
        -0xft
        0x56t
    .end array-data

    :array_2a
    .array-data 1
        -0x12t
        -0x76t
        -0x19t
    .end array-data

    :array_2b
    .array-data 1
        -0x67t
        -0x15t
        -0x6ft
        -0x31t
        -0x18t
        -0x55t
        -0x4ft
        0x1at
    .end array-data

    :array_2c
    .array-data 1
        0x78t
        0x5dt
        0x7dt
    .end array-data

    :array_2d
    .array-data 1
        0x17t
        0x3at
        0x1at
        0x70t
        0x66t
        0x3at
        -0x77t
        0x54t
    .end array-data

    :array_2e
    .array-data 1
        -0x5dt
        -0x3bt
        0x6at
    .end array-data

    :array_2f
    .array-data 1
        -0x32t
        -0xft
        0xbt
        0x63t
        0x3at
        -0x4dt
        -0x6at
        0x26t
    .end array-data

    :array_30
    .array-data 1
        0x41t
        -0x2et
        -0x37t
    .end array-data

    :array_31
    .array-data 1
        0x36t
        -0x41t
        -0x58t
        0x73t
        0x18t
        -0x70t
        -0x10t
        -0x39t
    .end array-data

    :array_32
    .array-data 1
        0x36t
        -0x61t
        -0x3ft
        0x7t
        0x27t
        -0x19t
        0x55t
        0x6et
        0x21t
    .end array-data

    nop

    :array_33
    .array-data 1
        0x72t
        -0x30t
        -0x7et
        0x52t
        0x6at
        -0x5et
        0x1bt
        0x3at
    .end array-data

    :array_34
    .array-data 1
        -0x12t
        -0x27t
        -0x49t
    .end array-data

    :array_35
    .array-data 1
        -0x62t
        -0x43t
        -0x2ft
        -0x31t
        0x28t
        0x60t
        0x41t
        -0xbt
    .end array-data

    :array_36
    .array-data 1
        0x2t
        0x55t
        0x17t
    .end array-data

    :array_37
    .array-data 1
        0x66t
        0x3at
        0x74t
        0x36t
        0x79t
        -0x5t
        -0x54t
        -0x4ft
    .end array-data

    :array_38
    .array-data 1
        -0x7ft
        0x6t
        0x52t
        -0x50t
    .end array-data

    :array_39
    .array-data 1
        -0x1bt
        0x69t
        0x31t
        -0x38t
        -0x7dt
        -0x5t
        0x19t
        -0x8t
    .end array-data

    :array_3a
    .array-data 1
        -0x6ct
        0x19t
        0x2ct
    .end array-data

    :array_3b
    .array-data 1
        -0x14t
        0x75t
        0x5ft
        0x8t
        -0x29t
        0x5ct
        0x70t
        -0x53t
    .end array-data

    :array_3c
    .array-data 1
        -0x3bt
        0x7ft
        -0x2bt
        0x5et
    .end array-data

    :array_3d
    .array-data 1
        -0x43t
        0x13t
        -0x5at
        0x26t
        0xdt
        0x75t
        -0x41t
        0x4ft
    .end array-data

    :array_3e
    .array-data 1
        0x9t
        -0xdt
        -0x55t
    .end array-data

    :array_3f
    .array-data 1
        0x79t
        -0x7dt
        -0x21t
        -0x9t
        -0x36t
        0x30t
        -0x1dt
        0x6ft
    .end array-data

    :array_40
    .array-data 1
        0x78t
        0x1dt
        -0x31t
        -0x6ft
    .end array-data

    :array_41
    .array-data 1
        0x8t
        0x6dt
        -0x45t
        -0x17t
        -0x64t
        0x62t
        0x68t
        0x5bt
    .end array-data

    :array_42
    .array-data 1
        0x54t
        -0x72t
        -0x3dt
    .end array-data

    :array_43
    .array-data 1
        0x20t
        -0xat
        -0x49t
        0x58t
        -0x5bt
        0x7et
        0x33t
        -0x2dt
    .end array-data
.end method

.method private constructor <init>(Ljava/lang/String;I[Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lcom/icontrol/protector/d$b;->e:[Ljava/lang/String;

    return-void
.end method

.method private static synthetic a()[Lcom/icontrol/protector/d$b;
    .locals 4

    .line 1
    sget-object v0, Lcom/icontrol/protector/d$b;->f:Lcom/icontrol/protector/d$b;

    sget-object v1, Lcom/icontrol/protector/d$b;->g:Lcom/icontrol/protector/d$b;

    sget-object v2, Lcom/icontrol/protector/d$b;->h:Lcom/icontrol/protector/d$b;

    sget-object v3, Lcom/icontrol/protector/d$b;->i:Lcom/icontrol/protector/d$b;

    filled-new-array {v0, v1, v2, v3}, [Lcom/icontrol/protector/d$b;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/icontrol/protector/d$b;
    .locals 1

    const-class v0, Lcom/icontrol/protector/d$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/icontrol/protector/d$b;

    return-object p0
.end method

.method public static values()[Lcom/icontrol/protector/d$b;
    .locals 1

    sget-object v0, Lcom/icontrol/protector/d$b;->j:[Lcom/icontrol/protector/d$b;

    invoke-virtual {v0}, [Lcom/icontrol/protector/d$b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/icontrol/protector/d$b;

    return-object v0
.end method


# virtual methods
.method public b(Ljava/lang/String;)Lcom/icontrol/protector/d$c;
    .locals 5

    .line 1
    iget-object v0, p0, Lcom/icontrol/protector/d$b;->e:[Ljava/lang/String;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    aget-object v3, v0, v2

    invoke-virtual {v3, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_0

    new-instance p1, Lcom/icontrol/protector/d$c;

    invoke-direct {p1, v3}, Lcom/icontrol/protector/d$c;-><init>(Ljava/lang/String;)V

    return-object p1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method
