.class public abstract Lcom/icontrol/protector/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/a$e;
    }
.end annotation


# static fields
.field public static a:Ljava/util/ArrayList;

.field public static b:Ljava/util/ArrayList;

.field public static c:Ljava/util/ArrayList;

.field public static d:Ljava/util/ArrayList;

.field private static e:Landroid/os/PowerManager$WakeLock;

.field private static f:Z

.field public static g:Ljava/util/List;

.field public static h:Ljava/util/Map;

.field public static i:Ljava/util/Map;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/icontrol/protector/a;->a:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/icontrol/protector/a;->b:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/icontrol/protector/a;->c:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    const/4 v0, 0x0

    sput-object v0, Lcom/icontrol/protector/a;->e:Landroid/os/PowerManager$WakeLock;

    const/4 v0, 0x0

    sput-boolean v0, Lcom/icontrol/protector/a;->f:Z

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/icontrol/protector/a;->g:Ljava/util/List;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/icontrol/protector/a;->h:Ljava/util/Map;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/icontrol/protector/a;->i:Ljava/util/Map;

    return-void
.end method

.method public static A()[B
    .locals 8

    .line 1
    const/4 v0, 0x0

    :try_start_0
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v1

    if-nez v1, :cond_0

    return-object v0

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v2

    if-nez v2, :cond_1

    return-object v0

    :cond_1
    invoke-virtual {v1}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v1

    if-nez v1, :cond_2

    return-object v0

    :cond_2
    const/4 v3, 0x4

    new-array v4, v3, [B

    fill-array-data v4, :array_0

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_1

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x3

    new-array v6, v6, [B

    fill-array-data v6, :array_2

    new-array v7, v5, [B

    fill-array-data v7, :array_3

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    new-array v6, v3, [B

    fill-array-data v6, :array_4

    new-array v7, v5, [B

    fill-array-data v7, :array_5

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-array v3, v3, [B

    fill-array-data v3, :array_6

    new-array v5, v5, [B

    fill-array-data v5, :array_7

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v6, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    sget-object v5, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v4, v3, v5}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v3

    new-instance v4, Landroid/graphics/Canvas;

    invoke-direct {v4, v3}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    new-instance v5, Landroid/graphics/Paint;

    invoke-direct {v5}, Landroid/graphics/Paint;-><init>()V

    sget-object v6, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    const/4 v7, 0x0

    invoke-virtual {v4, v7, v6}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    invoke-static {v1, v4, v5, v2}, Lcom/icontrol/protector/a;->X(Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/content/Context;)V

    invoke-static {v3}, Lcom/icontrol/protector/a;->z(Landroid/graphics/Bitmap;)[B

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    return-object v0

    nop

    :array_0
    .array-data 1
        0x6t
        -0x18t
        -0x3bt
        0x6ft
    .end array-data

    :array_1
    .array-data 1
        0x51t
        -0x65t
        -0x5at
        0x1dt
        -0x78t
        -0x6et
        0x75t
        -0x67t
    .end array-data

    :array_2
    .array-data 1
        0x2ct
        -0x1at
        -0x68t
    .end array-data

    :array_3
    .array-data 1
        0x1bt
        -0x2ct
        -0x58t
        0x5t
        0x44t
        0x53t
        -0x37t
        0x21t
    .end array-data

    :array_4
    .array-data 1
        -0x4t
        -0x71t
        -0x5at
        0x45t
    .end array-data

    :array_5
    .array-data 1
        -0x4ct
        -0x4t
        -0x3bt
        0x37t
        0x5et
        -0x21t
        0x5et
        -0x4t
    .end array-data

    :array_6
    .array-data 1
        -0x34t
        0x4dt
        0x60t
        0x5et
    .end array-data

    :array_7
    .array-data 1
        -0x3t
        0x7ft
        0x58t
        0x6et
        -0x4ct
        -0xdt
        -0x66t
        -0x1et
    .end array-data
.end method

.method private static B(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/Rect;Ljava/lang/String;I)V
    .locals 3

    .line 1
    invoke-virtual {p1, p4}, Landroid/graphics/Paint;->setColor(I)V

    sget-object p4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, p4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 p4, 0x40000000    # 2.0f

    invoke-virtual {p1, p4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p0, p2, p1}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget v0, Lcom/icontrol/protector/AccessServices;->q:I

    int-to-float v0, v0

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    sget-object v0, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    sget-object v0, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    iget v0, p2, Landroid/graphics/Rect;->left:I

    invoke-virtual {p2}, Landroid/graphics/Rect;->centerY()I

    move-result p2

    invoke-virtual {p1}, Landroid/graphics/Paint;->descent()F

    move-result v1

    invoke-virtual {p1}, Landroid/graphics/Paint;->ascent()F

    move-result v2

    add-float/2addr v1, v2

    div-float/2addr v1, p4

    float-to-int p4, v1

    sub-int/2addr p2, p4

    int-to-float p4, v0

    int-to-float p2, p2

    invoke-virtual {p0, p3, p4, p2, p1}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method private static C(Landroid/graphics/Canvas;Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/graphics/Paint;I)V
    .locals 5

    .line 1
    if-eqz p1, :cond_4

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_4

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v2

    if-eqz v2, :cond_3

    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    invoke-static {v1}, Lcom/icontrol/protector/a;->D(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_2

    :cond_1
    const/4 v3, 0x3

    new-array v3, v3, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v4, v4, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    :cond_2
    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    sget v4, Lcom/icontrol/protector/AccessServices;->q:I

    int-to-float v4, v4

    invoke-virtual {p2, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-static {p0, p2, v2, v3, p3}, Lcom/icontrol/protector/a;->B(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/Rect;Ljava/lang/String;I)V

    invoke-static {p0, v1, p2, p3}, Lcom/icontrol/protector/a;->C(Landroid/graphics/Canvas;Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/graphics/Paint;I)V

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_4
    :goto_1
    return-void

    nop

    :array_0
    .array-data 1
        0x2et
        -0x12t
        0x37t
    .end array-data

    :array_1
    .array-data 1
        -0x34t
        0x6et
        -0x6bt
        0x5t
        -0x46t
        -0x4ct
        0x24t
        -0x22t
    .end array-data
.end method

.method private static D(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/String;
    .locals 5

    .line 1
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x1a

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    const/16 v2, 0x18

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v3, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    :cond_2
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object p0

    goto :goto_0

    :cond_3
    return-object v0

    nop

    :array_0
    .array-data 1
        -0x55t
        0x10t
        -0x3et
        0x6at
        -0x68t
        -0x2et
        0x3dt
        -0x3dt
        -0x43t
        0x17t
        -0x3et
        0x7ft
        -0x6et
        -0x31t
        0x77t
        -0x5ct
        -0x59t
        0x1ft
        -0x3ft
        0x7dt
        -0x4bt
        -0x32t
        0x2dt
        -0x67t
        -0x5bt
        0x10t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x36t
        0x7et
        -0x5at
        0x18t
        -0x9t
        -0x45t
        0x59t
        -0x13t
    .end array-data

    :array_2
    .array-data 1
        -0x76t
        -0x5at
        -0x26t
        0x4ft
        -0x3t
        -0x4et
        0x38t
        -0x1ft
        -0x64t
        -0x5ft
        -0x26t
        0x5at
        -0x9t
        -0x51t
        0x72t
        -0x7at
        -0x7at
        -0x57t
        -0x27t
        0x58t
        -0x3ct
        -0x4et
        0x39t
        -0x48t
    .end array-data

    :array_3
    .array-data 1
        -0x15t
        -0x38t
        -0x42t
        0x3dt
        -0x6et
        -0x25t
        0x5ct
        -0x31t
    .end array-data
.end method

.method public static E(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .locals 4

    .line 1
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v2

    if-ge v1, v2, :cond_3

    invoke-virtual {p0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v3

    if-eqz v3, :cond_2

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    return-object v2

    :cond_1
    invoke-static {v2, p1, p2}, Lcom/icontrol/protector/a;->E(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    if-eqz v2, :cond_2

    return-object v2

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    return-object v0
.end method

.method public static F(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .locals 2

    .line 1
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0, p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByViewId(Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    return-object p1

    :cond_2
    return-object v0
.end method

.method public static G(Ljava/lang/String;Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/util/List;
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    invoke-virtual {p1, p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByText(Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static H(I)Ljava/lang/String;
    .locals 4

    .line 1
    const/4 v0, 0x1

    const/4 v1, 0x7

    const/16 v2, 0x8

    if-eq p0, v0, :cond_a

    const/4 v0, 0x2

    const/16 v3, 0xc

    if-eq p0, v0, :cond_9

    const/4 v0, 0x4

    if-eq p0, v0, :cond_8

    if-eq p0, v2, :cond_7

    const/16 v0, 0x10

    if-eq p0, v0, :cond_6

    const/16 v0, 0x20

    if-eq p0, v0, :cond_5

    const/16 v0, 0x40

    if-eq p0, v0, :cond_4

    const/16 v0, 0x80

    if-eq p0, v0, :cond_3

    const/16 v0, 0x100

    if-eq p0, v0, :cond_2

    const/16 v0, 0x1000

    if-eq p0, v0, :cond_1

    const/16 v0, 0x2000

    if-eq p0, v0, :cond_0

    new-array p0, v1, [B

    fill-array-data p0, :array_0

    new-array v0, v2, [B

    fill-array-data v0, :array_1

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const/16 p0, 0x16

    new-array p0, p0, [B

    fill-array-data p0, :array_2

    new-array v0, v2, [B

    fill-array-data v0, :array_3

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    new-array p0, v2, [B

    fill-array-data p0, :array_4

    new-array v0, v2, [B

    fill-array-data v0, :array_5

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2
    const/16 p0, 0xa

    new-array p0, p0, [B

    fill-array-data p0, :array_6

    new-array v0, v2, [B

    fill-array-data v0, :array_7

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3
    const/16 p0, 0xb

    new-array p0, p0, [B

    fill-array-data p0, :array_8

    new-array v0, v2, [B

    fill-array-data v0, :array_9

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_4
    const/16 p0, 0x14

    new-array p0, p0, [B

    fill-array-data p0, :array_a

    new-array v0, v2, [B

    fill-array-data v0, :array_b

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_5
    const/16 p0, 0xe

    new-array p0, p0, [B

    fill-array-data p0, :array_c

    new-array v0, v2, [B

    fill-array-data v0, :array_d

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_6
    new-array p0, v3, [B

    fill-array-data p0, :array_e

    new-array v0, v2, [B

    fill-array-data v0, :array_f

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_7
    new-array p0, v1, [B

    fill-array-data p0, :array_10

    new-array v0, v2, [B

    fill-array-data v0, :array_11

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_8
    new-array p0, v2, [B

    fill-array-data p0, :array_12

    new-array v0, v2, [B

    fill-array-data v0, :array_13

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_9
    new-array p0, v3, [B

    fill-array-data p0, :array_14

    new-array v0, v2, [B

    fill-array-data v0, :array_15

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_a
    new-array p0, v1, [B

    fill-array-data p0, :array_16

    new-array v0, v2, [B

    fill-array-data v0, :array_17

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :array_0
    .array-data 1
        -0x36t
        0x5ft
        -0x4dt
        -0x25t
        -0x6ft
        -0x70t
        0x6dt
    .end array-data

    :array_1
    .array-data 1
        -0x61t
        0x31t
        -0x28t
        -0x4bt
        -0x2t
        -0x19t
        0x3t
        -0x74t
    .end array-data

    :array_2
    .array-data 1
        -0x4dt
        -0x72t
        -0x80t
        -0x4et
        -0x73t
        0x63t
        -0x77t
        -0x6bt
        -0x7et
        -0x78t
        -0x74t
        -0x51t
        -0x3et
        0x5et
        -0x34t
        -0x46t
        -0x71t
        -0x76t
        -0x6at
        -0x5ft
        -0x38t
        0x54t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x19t
        -0x15t
        -0x8t
        -0x3at
        -0x53t
        0x30t
        -0x14t
        -0x7t
    .end array-data

    :array_4
    .array-data 1
        0x51t
        0x3ft
        0x65t
        -0x33t
        -0x5t
        0x50t
        -0x6at
        -0x5et
    .end array-data

    :array_5
    .array-data 1
        0x2t
        0x5ct
        0x17t
        -0x5et
        -0x69t
        0x3ct
        -0xdt
        -0x3at
    .end array-data

    :array_6
    .array-data 1
        0x6dt
        0x44t
        0x52t
        0x48t
        0x5et
        0x47t
        -0x50t
        -0x3bt
        0x4ct
        0x5ft
    .end array-data

    nop

    :array_7
    .array-data 1
        0x25t
        0x2bt
        0x24t
        0x2dt
        0x2ct
        0x67t
        -0xbt
        -0x43t
    .end array-data

    :array_8
    .array-data 1
        -0x3ct
        -0x7t
        -0x11t
        0x1bt
        0x34t
        0x11t
        0x6t
        0x7ct
        -0x8t
        -0xdt
        -0x15t
    .end array-data

    :array_9
    .array-data 1
        -0x74t
        -0x6at
        -0x67t
        0x7et
        0x46t
        0x31t
        0x43t
        0x12t
    .end array-data

    :array_a
    .array-data 1
        0x57t
        -0x43t
        -0x21t
        -0x62t
        0x15t
        -0x4t
        0x17t
        0x65t
        0x6dt
        -0x45t
        -0x3ct
        -0x67t
        0x53t
        -0x2at
        0x1ct
        0x65t
        0x77t
        -0x4bt
        -0x32t
        -0x6dt
    .end array-data

    :array_b
    .array-data 1
        0x19t
        -0x2et
        -0x55t
        -0x9t
        0x73t
        -0x6bt
        0x74t
        0x4t
    .end array-data

    :array_c
    .array-data 1
        0x5t
        0x56t
        -0xet
        -0x65t
        0x7ct
        0x5ft
        0x2ct
        0x5et
        0x3at
        0x5et
        -0xet
        -0x68t
        0x76t
        0x4ct
    .end array-data

    nop

    :array_d
    .array-data 1
        0x52t
        0x3ft
        -0x64t
        -0x1t
        0x13t
        0x28t
        0xct
        0x1dt
    .end array-data

    :array_e
    .array-data 1
        0x23t
        -0x39t
        -0x7t
        0x79t
        0x16t
        0x2ft
        -0x9t
        0x5ft
        0x19t
        -0x3bt
        -0x1ct
        0x69t
    .end array-data

    :array_f
    .array-data 1
        0x77t
        -0x5et
        -0x7ft
        0xdt
        0x36t
        0x6ct
        -0x61t
        0x3et
    .end array-data

    :array_10
    .array-data 1
        0x40t
        -0x7ft
        0x12t
        -0x5t
        -0x62t
        -0x3at
        -0x58t
    .end array-data

    :array_11
    .array-data 1
        0x6t
        -0x12t
        0x71t
        -0x72t
        -0x13t
        -0x5dt
        -0x34t
        0x4bt
    .end array-data

    :array_12
    .array-data 1
        -0x56t
        -0x49t
        0x75t
        0x6et
        0x1t
        -0x55t
        0x2ct
        -0x7ct
    .end array-data

    :array_13
    .array-data 1
        -0x7t
        -0x2et
        0x19t
        0xbt
        0x62t
        -0x21t
        0x49t
        -0x20t
    .end array-data

    :array_14
    .array-data 1
        -0x10t
        -0x14t
        0x2bt
        0x36t
        -0x34t
        0x55t
        0x37t
        0x61t
        -0x21t
        -0x18t
        0x20t
        0x35t
    .end array-data

    :array_15
    .array-data 1
        -0x44t
        -0x7dt
        0x45t
        0x51t
        -0x14t
        0x16t
        0x5bt
        0x8t
    .end array-data

    :array_16
    .array-data 1
        -0x28t
        0x40t
        -0x6ct
        0x2ct
        0x5at
        0x1bt
        0x46t
    .end array-data

    :array_17
    .array-data 1
        -0x65t
        0x2ct
        -0x3t
        0x4ft
        0x31t
        0x7et
        0x22t
        0x7dt
    .end array-data
.end method

.method public static I(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 9

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    if-eqz p0, :cond_7

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v1

    const/16 v2, 0x8

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v1

    const/16 v3, 0x15

    new-array v3, v3, [B

    fill-array-data v3, :array_0

    new-array v4, v2, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    :cond_1
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x22

    if-lt v1, v3, :cond_6

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_6

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v1

    const/16 v3, 0x17

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    :cond_2
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_6

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x9

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v4, v2, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    const/4 v3, 0x5

    new-array v4, v3, [B

    fill-array-data v4, :array_6

    new-array v5, v2, [B

    fill-array-data v5, :array_7

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_5

    const/16 v4, 0xd

    new-array v5, v4, [B

    fill-array-data v5, :array_8

    new-array v6, v2, [B

    fill-array-data v6, :array_9

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    new-array v5, v4, [B

    fill-array-data v5, :array_a

    new-array v6, v2, [B

    fill-array-data v6, :array_b

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    new-array v5, v4, [B

    fill-array-data v5, :array_c

    new-array v6, v2, [B

    fill-array-data v6, :array_d

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    const/16 v5, 0xe

    new-array v6, v5, [B

    fill-array-data v6, :array_e

    new-array v7, v2, [B

    fill-array-data v7, :array_f

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    const/4 v6, 0x7

    new-array v7, v6, [B

    fill-array-data v7, :array_10

    new-array v8, v2, [B

    fill-array-data v8, :array_11

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_5

    new-array v6, v6, [B

    fill-array-data v6, :array_12

    new-array v7, v2, [B

    fill-array-data v7, :array_13

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    new-array v4, v4, [B

    fill-array-data v4, :array_14

    new-array v6, v2, [B

    fill-array-data v6, :array_15

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_5

    new-array v4, v5, [B

    fill-array-data v4, :array_16

    new-array v5, v2, [B

    fill-array-data v5, :array_17

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_5

    const/16 v4, 0xc

    new-array v4, v4, [B

    fill-array-data v4, :array_18

    new-array v5, v2, [B

    fill-array-data v5, :array_19

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    goto :goto_0

    :cond_3
    const/4 v4, 0x6

    new-array v5, v4, [B

    fill-array-data v5, :array_1a

    new-array v6, v2, [B

    fill-array-data v6, :array_1b

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_4

    new-array v5, v2, [B

    fill-array-data v5, :array_1c

    new-array v6, v2, [B

    fill-array-data v6, :array_1d

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_4

    new-array v3, v3, [B

    fill-array-data v3, :array_1e

    new-array v5, v2, [B

    fill-array-data v5, :array_1f

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    new-array v3, v4, [B

    fill-array-data v3, :array_20

    new-array v2, v2, [B

    fill-array-data v2, :array_21

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    :cond_4
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    iget v0, v0, Lcom/icontrol/protector/AccessServices;->g:I

    iget v2, v1, Landroid/graphics/Rect;->left:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0xa

    iget v1, v1, Landroid/graphics/Rect;->top:I

    add-int/lit8 v1, v1, 0xa

    invoke-static {v0, v1}, Lcom/icontrol/protector/a;->y(II)Z

    goto :goto_1

    :cond_5
    :goto_0
    const/16 v0, 0x10

    invoke-virtual {p0, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    :cond_6
    :goto_1
    const/4 v0, 0x0

    :goto_2
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_7

    invoke-virtual {p0, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v1

    invoke-static {v1}, Lcom/icontrol/protector/a;->I(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_7
    return-void

    nop

    :array_0
    .array-data 1
        -0x46t
        0x7dt
        0xat
        0x44t
        -0x6t
        -0x1dt
        0x58t
        0x49t
        -0x54t
        0x7at
        0xat
        0x51t
        -0x10t
        -0x2t
        0x12t
        0x25t
        -0x52t
        0x67t
        0x1at
        0x59t
        -0x5t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x25t
        0x13t
        0x6et
        0x36t
        -0x6bt
        -0x76t
        0x3ct
        0x67t
    .end array-data

    :array_2
    .array-data 1
        -0x39t
        0x6at
        0xct
        0x15t
        -0x2et
        0x59t
        -0x7at
        -0x3dt
        -0x2ft
        0x6dt
        0xct
        0x0t
        -0x28t
        0x44t
        -0x34t
        -0x47t
        -0x3dt
        0x7ct
        0x1ct
        0x31t
        -0x2ct
        0x55t
        -0x6bt
    .end array-data

    :array_3
    .array-data 1
        -0x5at
        0x4t
        0x68t
        0x67t
        -0x43t
        0x30t
        -0x1et
        -0x13t
    .end array-data

    :array_4
    .array-data 1
        -0x16t
        -0x8t
        -0x3bt
        -0x55t
        -0x5ct
        0x6ct
        0x0t
        -0x65t
        -0x12t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x67t
        -0x74t
        -0x5ct
        -0x27t
        -0x30t
        0x4ct
        0x6et
        -0xct
    .end array-data

    :array_6
    .array-data 1
        -0x50t
        -0x54t
        -0x7et
        0x6ct
        0x79t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x3dt
        -0x28t
        -0x1dt
        0x1et
        0xdt
        -0x22t
        -0x67t
        -0x7et
    .end array-data

    :array_8
    .array-data 1
        -0x2t
        0x3bt
        0x41t
        0x62t
        -0x4dt
        -0x4et
        0x4dt
        0x56t
        -0xat
        0x32t
        0x47t
        0x73t
        -0x45t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x69t
        0x55t
        0x28t
        0x1t
        -0x26t
        -0x2dt
        0x3ft
        0x76t
    .end array-data

    :array_a
    .array-data 1
        -0xft
        0x37t
        -0x28t
        -0x18t
        -0x6t
        -0x35t
        0x2bt
        0xat
        -0x7t
        0x31t
        -0x22t
        -0x7t
        -0xet
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x68t
        0x59t
        -0x4ft
        -0x75t
        -0x6dt
        -0x56t
        0x59t
        0x2at
    .end array-data

    :array_c
    .array-data 1
        0x43t
        0x78t
        -0x28t
        0x11t
        0x5bt
        -0x1bt
        -0x55t
        -0x19t
        0x47t
        0x7dt
        -0x39t
        0x6t
        0x40t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x26t
        0x15t
        -0x58t
        0x74t
        0x21t
        -0x7ct
        -0x27t
        -0x39t
    .end array-data

    :array_e
    .array-data 1
        0xct
        -0x35t
        0x13t
        0x10t
        0x13t
        -0x80t
        0x1dt
        -0x23t
        0x4ft
        -0x3bt
        0x19t
        0x1at
        -0x5et
        0x46t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x6ft
        -0x5ct
        0x7et
        0x75t
        -0x30t
        0x27t
        0x7ct
        -0x51t
    .end array-data

    :array_10
    .array-data 1
        -0x62t
        0x7et
        0x6bt
        -0x5ct
        -0x62t
        -0x61t
        -0x3ft
    .end array-data

    :array_11
    .array-data 1
        -0x9t
        0x10t
        -0x58t
        0x9t
        -0x3t
        -0xat
        -0x52t
        0x28t
    .end array-data

    :array_12
    .array-data 1
        -0x3dt
        -0x53t
        -0x2ft
        -0x7dt
        -0x1bt
        -0x36t
        -0x19t
    .end array-data

    :array_13
    .array-data 1
        -0x56t
        -0x3dt
        -0x48t
        -0x20t
        -0x74t
        -0x55t
        -0x6bt
        -0x68t
    .end array-data

    :array_14
    .array-data 1
        -0x4ft
        0x14t
        -0x62t
        0x3t
        -0x1bt
        -0x18t
        0x63t
        -0x67t
        0x15t
        0x4et
        0x68t
        0x2t
        -0x20t
    .end array-data

    nop

    :array_15
    .array-data 1
        0x74t
        -0x75t
        -0x9t
        0x6et
        -0x7ft
        -0x7ft
        0x43t
        -0x5t
    .end array-data

    :array_16
    .array-data 1
        0x6t
        0x4ft
        0x24t
        0x4t
        -0x6ft
        -0x11t
        -0x79t
        -0x63t
        -0x5et
        0x15t
        -0x2et
        0x5t
        -0x6ct
        -0xet
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x3dt
        -0x30t
        0x4dt
        0x69t
        -0xbt
        -0x7at
        -0x59t
        -0x1t
    .end array-data

    :array_18
    .array-data 1
        0x78t
        -0xct
        0x4at
        0x44t
        0x17t
        0x63t
        -0x5et
        0x70t
        0x1ft
        -0x46t
        0x66t
        0x2at
    .end array-data

    :array_19
    .array-data 1
        -0x61t
        0x5ft
        -0x3ft
        -0x5ft
        -0x66t
        -0x30t
        0x47t
        -0x34t
    .end array-data

    :array_1a
    .array-data 1
        -0x15t
        -0x17t
        -0x38t
        0x55t
        -0x64t
        0xct
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x78t
        -0x78t
        -0x5at
        0x36t
        -0x7t
        0x60t
        -0x77t
        -0x78t
    .end array-data

    :array_1c
    .array-data 1
        -0x4t
        -0x2dt
        -0x7dt
        0xbt
        -0x16t
        -0x2t
        -0x53t
        0x1et
    .end array-data

    :array_1d
    .array-data 1
        -0x61t
        -0x4et
        -0x13t
        0x68t
        -0x71t
        -0x6et
        -0x34t
        0x6ct
    .end array-data

    :array_1e
    .array-data 1
        0x9t
        0x7bt
        0xdt
        0x19t
        0x7ft
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x60t
        0xbt
        0x79t
        0x78t
        0x13t
        -0x62t
        -0x7dt
        0x6at
    .end array-data

    :array_20
    .array-data 1
        0x15t
        0x3ft
        0x6dt
        0xat
        -0x26t
        0x2dt
    .end array-data

    nop

    :array_21
    .array-data 1
        -0x10t
        -0x50t
        -0x5t
        -0x14t
        0x6ct
        -0x5bt
        -0x50t
        -0x7bt
    .end array-data
.end method

.method public static J(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .locals 1

    .line 1
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0, p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByViewId(Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    move-object v0, p0

    check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;

    :goto_0
    return-object v0
.end method

.method public static K(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/util/List;
    .locals 1

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-static {p0, p1, v0}, Lcom/icontrol/protector/a;->a0(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Ljava/util/List;)V

    return-object v0
.end method

.method public static L()Ljava/util/List;
    .locals 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->F0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->G0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->H0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->I0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->J0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->K0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->L0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->M0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->N0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->O0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->P0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->Q0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->R0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->S0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->T0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->U0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->V0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->W0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->X0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->Y0:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/icontrol/protector/a$e;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->Z0:Ljava/lang/String;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->a1:Ljava/lang/String;

    invoke-direct {v1, v2, v3}, Lcom/icontrol/protector/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method public static M(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2

    .line 1
    const/16 v0, 0x32

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0

    :array_0
    .array-data 1
        0x73t
        0x29t
        -0xbt
        0x56t
        0x51t
        0x4t
        0x6dt
        -0x2at
        0x5et
        0x3et
        -0x10t
        0x43t
        0x16t
        0x59t
        0x26t
        -0x72t
        0x12t
        0x3bt
        -0x6ft
        0x32t
        0x3t
        0x5ft
        0x45t
        -0x38t
        0x70t
        0x2at
        -0x6at
        0x42t
        0x10t
        0x4ft
        0x31t
        -0x3t
        0x73t
        0x3bt
        -0x1bt
        0x30t
        0x57t
        0x2dt
        0x32t
        -0x6t
        0x3t
        0x5at
        -0x6ct
        0x56t
        0x16t
        0x2ct
        0x77t
        -0x5t
        0x6t
        0x28t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x2dt
        0x1t
        -0x36t
        0x6ct
        0x39t
        0x70t
        0x19t
        -0x5at
    .end array-data
.end method

.method public static N(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->flags:I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    and-int/2addr p0, p1

    if-eqz p0, :cond_0

    move v0, p1

    :catch_0
    :cond_0
    return v0
.end method

.method private static synthetic O(Lcom/icontrol/protector/AccessServices;)V
    .locals 2

    .line 1
    sget-object p0, Lcom/icontrol/protector/AccessServices;->J:Landroid/widget/FrameLayout;

    invoke-virtual {p0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object p0

    if-nez p0, :cond_0

    :try_start_0
    sget-object p0, Lcom/icontrol/protector/AccessServices;->x:Landroid/view/WindowManager;

    sget-object v0, Lcom/icontrol/protector/AccessServices;->J:Landroid/widget/FrameLayout;

    sget-object v1, Lcom/icontrol/protector/AccessServices;->K:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {p0, v0, v1}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 p0, 0x1

    sput-boolean p0, Lcom/icontrol/protector/AccessServices;->z:Z

    return-void
.end method

.method private static synthetic P(Lcom/icontrol/protector/AccessServices;)V
    .locals 1

    .line 1
    sget-object p0, Lcom/icontrol/protector/AccessServices;->J:Landroid/widget/FrameLayout;

    invoke-virtual {p0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object p0

    if-eqz p0, :cond_0

    :try_start_0
    sget-object p0, Lcom/icontrol/protector/AccessServices;->x:Landroid/view/WindowManager;

    sget-object v0, Lcom/icontrol/protector/AccessServices;->J:Landroid/widget/FrameLayout;

    invoke-interface {p0, v0}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 p0, 0x0

    sput-boolean p0, Lcom/icontrol/protector/AccessServices;->z:Z

    return-void
.end method

.method private static synthetic Q(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 6

    .line 1
    const/16 v0, 0xd

    const/16 v1, 0x8

    :try_start_0
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1e

    if-lt v2, v3, :cond_6

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/e0;->a()Z

    move-result v3

    if-eqz v3, :cond_0

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object p0, Lcom/icontrol/protector/AccessServices;->F:Ljava/lang/Boolean;

    goto/16 :goto_3

    :catch_0
    move-exception p0

    goto/16 :goto_2

    :cond_0
    const/16 v3, 0x15

    new-array v3, v3, [B

    fill-array-data v3, :array_0

    new-array v4, v1, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x22

    if-lt v2, v4, :cond_1

    const/16 v2, 0x11

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    :cond_1
    invoke-static {p0, v3}, Lcom/icontrol/protector/a;->K(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_2
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isCheckable()Z

    move-result v3

    if-eqz v3, :cond_2

    new-array v3, v0, [B

    fill-array-data v3, :array_4

    new-array v4, v1, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x19

    new-array v4, v4, [B

    fill-array-data v4, :array_6

    new-array v5, v1, [B

    fill-array-data v5, :array_7

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isChecked()Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isClickable()Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/e0;->a()Z

    move-result v3

    if-eqz v3, :cond_3

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object p0, Lcom/icontrol/protector/AccessServices;->F:Ljava/lang/Boolean;

    return-void

    :cond_3
    const/16 v3, 0x10

    invoke-virtual {v2, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    :goto_1
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    goto :goto_0

    :cond_4
    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v2, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    invoke-virtual {v3}, Landroid/graphics/Rect;->exactCenterX()F

    move-result v2

    float-to-int v2, v2

    invoke-virtual {v3}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v3

    float-to-int v3, v3

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/e0;->a()Z

    move-result v4

    if-eqz v4, :cond_5

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object p0, Lcom/icontrol/protector/AccessServices;->F:Ljava/lang/Boolean;

    return-void

    :cond_5
    invoke-static {v2, v3}, Lcom/icontrol/protector/a;->y(II)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :goto_2
    new-array v0, v0, [B

    fill-array-data v0, :array_8

    new-array v1, v1, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_6
    :goto_3
    return-void

    nop

    :array_0
    .array-data 1
        0x7t
        0x15t
        -0x54t
        0x6ft
        0x52t
        -0x67t
        -0x6at
        0x3ct
        0x11t
        0x12t
        -0x54t
        0x7at
        0x58t
        -0x7ct
        -0x24t
        0x41t
        0x11t
        0x12t
        -0x44t
        0x7et
        0x55t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x66t
        0x7bt
        -0x38t
        0x1dt
        0x3dt
        -0x10t
        -0xet
        0x12t
    .end array-data

    :array_2
    .array-data 1
        0x1ft
        -0x16t
        0x58t
        0x4et
        0x6t
        -0x21t
        0x26t
        -0x29t
        0x8t
        -0x13t
        0x59t
        0x4bt
        0x47t
        -0x20t
        0x2bt
        -0x64t
        0x9t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x7et
        -0x7ct
        0x3ct
        0x3ct
        0x69t
        -0x4at
        0x42t
        -0x7t
    .end array-data

    :array_4
    .array-data 1
        -0x70t
        0x36t
        0x13t
        0x6ct
        -0x6dt
        -0x5ct
        -0x3dt
        -0x1et
        -0x48t
        0x39t
        0x19t
        0x7dt
        -0x67t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x2ft
        0x55t
        0x70t
        0x9t
        -0x20t
        -0x29t
        -0x56t
        -0x80t
    .end array-data

    :array_6
    .array-data 1
        0x4ct
        0x74t
        -0x80t
        0x64t
        0x33t
        -0x27t
        0x4et
        -0x4ft
        0x6ft
        0x78t
        -0x62t
        0x6bt
        0x35t
        -0x6bt
        0x48t
        -0x7t
        0x6ft
        0x77t
        -0x70t
        0x67t
        0x32t
        -0x69t
        0x59t
        -0x1dt
        0x2at
    .end array-data

    nop

    :array_7
    .array-data 1
        0xat
        0x1bt
        -0xbt
        0xat
        0x57t
        -0x7t
        0x2dt
        -0x27t
    .end array-data

    :array_8
    .array-data 1
        -0x68t
        0x4at
        0xet
        -0x38t
        -0x75t
        0x7et
        -0x18t
        -0x47t
        -0x7ft
        0x56t
        0x8t
        -0x3bt
        -0x77t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x22t
        0x5t
        0x5ct
        -0x69t
        -0x32t
        0x26t
        -0x44t
        -0x15t
    .end array-data
.end method

.method private static synthetic R(Landroid/content/Context;Lcom/icontrol/protector/AccessServices;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 5

    .line 1
    const/16 p1, 0xd

    const/16 v0, 0x8

    :try_start_0
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object p0, Lcom/icontrol/protector/AccessServices;->G:Ljava/lang/Boolean;

    goto/16 :goto_4

    :catch_0
    move-exception p0

    goto/16 :goto_3

    :cond_0
    invoke-static {p0}, Lcom/icontrol/protector/n;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x10

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    new-array v4, v0, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {p2, v3, v1}, Lcom/icontrol/protector/a;->F(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    if-nez v3, :cond_1

    const/16 v3, 0x17

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v4, v0, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {p2, v3, v1}, Lcom/icontrol/protector/a;->E(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    :cond_1
    if-eqz v3, :cond_4

    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v3, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    new-instance v4, Landroid/graphics/Rect;

    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p2, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    invoke-virtual {v4, v1}, Landroid/graphics/Rect;->contains(Landroid/graphics/Rect;)Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-virtual {v1}, Landroid/graphics/Rect;->exactCenterX()F

    move-result v3

    float-to-int v3, v3

    invoke-virtual {v1}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v1

    float-to-int v1, v1

    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result p0

    if-eqz p0, :cond_2

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object p0, Lcom/icontrol/protector/AccessServices;->G:Ljava/lang/Boolean;

    return-void

    :cond_2
    invoke-static {v3, v1}, Lcom/icontrol/protector/a;->y(II)Z

    goto :goto_0

    :cond_3
    invoke-static {p2}, Lcom/icontrol/protector/a;->Z(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz p0, :cond_5

    const-wide/16 v3, 0xfa

    :try_start_1
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :cond_4
    :try_start_2
    invoke-static {p2}, Lcom/icontrol/protector/a;->Z(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result p0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    if-eqz p0, :cond_5

    const-wide/16 v3, 0x64

    :try_start_3
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    :catch_1
    :cond_5
    :goto_0
    const/16 p0, 0x15

    :try_start_4
    new-array p0, p0, [B

    fill-array-data p0, :array_4

    new-array v1, v0, [B

    fill-array-data v1, :array_5

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x22

    if-lt v1, v3, :cond_6

    const/16 p0, 0x11

    new-array p0, p0, [B

    fill-array-data p0, :array_6

    new-array v1, v0, [B

    fill-array-data v1, :array_7

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    :cond_6
    invoke-static {p2, p0}, Lcom/icontrol/protector/a;->K(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_7
    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_9

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isCheckable()Z

    move-result v1

    if-eqz v1, :cond_7

    new-array v1, p1, [B

    fill-array-data v1, :array_8

    new-array v3, v0, [B

    fill-array-data v3, :array_9

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x19

    new-array v3, v3, [B

    fill-array-data v3, :array_a

    new-array v4, v0, [B

    fill-array-data v4, :array_b

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isChecked()Z

    move-result v1

    if-nez v1, :cond_7

    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isClickable()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-virtual {p2, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    :goto_2
    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    goto :goto_1

    :cond_8
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p2, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    invoke-virtual {v1}, Landroid/graphics/Rect;->exactCenterX()F

    move-result p2

    float-to-int p2, p2

    invoke-virtual {v1}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v1

    float-to-int v1, v1

    invoke-static {p2, v1}, Lcom/icontrol/protector/a;->y(II)Z
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_2

    :goto_3
    new-array p1, p1, [B

    fill-array-data p1, :array_c

    new-array p2, v0, [B

    fill-array-data p2, :array_d

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_9
    :goto_4
    return-void

    nop

    :array_0
    .array-data 1
        0x71t
        -0x4t
        0x65t
        -0x3dt
        -0x5t
        0x4ft
        0x7t
        -0x3ft
        0x79t
        -0xat
        0x2et
        -0x3bt
        -0x3t
        0x52t
        0xft
        -0x62t
    .end array-data

    :array_1
    .array-data 1
        0x10t
        -0x6et
        0x1t
        -0x4ft
        -0x6ct
        0x26t
        0x63t
        -0x5t
    .end array-data

    :array_2
    .array-data 1
        0x52t
        -0x2bt
        -0x3bt
        0x25t
        0x2t
        -0x50t
        0x4dt
        -0x60t
        0x44t
        -0x2et
        -0x3bt
        0x30t
        0x8t
        -0x53t
        0x7t
        -0x26t
        0x56t
        -0x3dt
        -0x2bt
        0x1t
        0x4t
        -0x44t
        0x5et
    .end array-data

    :array_3
    .array-data 1
        0x33t
        -0x45t
        -0x5ft
        0x57t
        0x6dt
        -0x27t
        0x29t
        -0x72t
    .end array-data

    :array_4
    .array-data 1
        -0x76t
        0x2et
        -0x6dt
        -0x5ct
        -0x15t
        -0x7bt
        0x58t
        -0x2ct
        -0x64t
        0x29t
        -0x6dt
        -0x4ft
        -0x1ft
        -0x68t
        0x12t
        -0x57t
        -0x64t
        0x29t
        -0x7dt
        -0x4bt
        -0x14t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x15t
        0x40t
        -0x9t
        -0x2at
        -0x7ct
        -0x14t
        0x3ct
        -0x6t
    .end array-data

    :array_6
    .array-data 1
        0xct
        -0x36t
        -0x80t
        -0x7at
        0x78t
        0x6t
        0xat
        -0x4bt
        0x1bt
        -0x33t
        -0x7ft
        -0x7dt
        0x39t
        0x39t
        0x7t
        -0x2t
        0x1at
    .end array-data

    nop

    :array_7
    .array-data 1
        0x6dt
        -0x5ct
        -0x1ct
        -0xct
        0x17t
        0x6ft
        0x6et
        -0x65t
    .end array-data

    :array_8
    .array-data 1
        0x11t
        -0x47t
        0x65t
        -0x63t
        0x20t
        0x59t
        -0x1dt
        0x62t
        0x39t
        -0x4at
        0x6ft
        -0x74t
        0x2at
    .end array-data

    nop

    :array_9
    .array-data 1
        0x50t
        -0x26t
        0x6t
        -0x8t
        0x53t
        0x2at
        -0x76t
        0x0t
    .end array-data

    :array_a
    .array-data 1
        0x31t
        -0x76t
        0x19t
        -0x64t
        0x2et
        0x3ft
        -0x16t
        -0x68t
        0x12t
        -0x7at
        0x7t
        -0x6dt
        0x28t
        0x73t
        -0x14t
        -0x30t
        0x12t
        -0x77t
        0x9t
        -0x61t
        0x2ft
        0x71t
        -0x3t
        -0x36t
        0x57t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x77t
        -0x1bt
        0x6ct
        -0xet
        0x4at
        0x1ft
        -0x77t
        -0x10t
    .end array-data

    :array_c
    .array-data 1
        0x0t
        0x2ct
        0x18t
        -0x33t
        0x15t
        0x4ct
        0x41t
        0x5dt
        0x19t
        0x2ct
        0x1ct
        -0x29t
        0x3t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x46t
        0x63t
        0x4at
        -0x6et
        0x51t
        0x1et
        0x0t
        0xat
    .end array-data
.end method

.method public static S([Landroid/graphics/Point;I)V
    .locals 7

    .line 1
    :try_start_0
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    const/4 v1, 0x0

    aget-object v1, p0, v1

    iget v3, v1, Landroid/graphics/Point;->x:I

    int-to-float v3, v3

    iget v1, v1, Landroid/graphics/Point;->y:I

    int-to-float v1, v1

    invoke-virtual {v2, v3, v1}, Landroid/graphics/Path;->moveTo(FF)V

    const/4 v1, 0x1

    :goto_0
    array-length v3, p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-ge v1, v3, :cond_1

    :try_start_1
    aget-object v3, p0, v1

    iget v4, v3, Landroid/graphics/Point;->x:I

    int-to-float v4, v4

    iget v3, v3, Landroid/graphics/Point;->y:I

    int-to-float v3, v3

    invoke-virtual {v2, v4, v3}, Landroid/graphics/Path;->lineTo(FF)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :try_start_2
    new-instance p0, Landroid/accessibilityservice/GestureDescription$StrokeDescription;

    const-wide/16 v3, 0x0

    int-to-long v5, p1

    move-object v1, p0

    invoke-direct/range {v1 .. v6}, Landroid/accessibilityservice/GestureDescription$StrokeDescription;-><init>(Landroid/graphics/Path;JJ)V

    new-instance p1, Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-direct {p1}, Landroid/accessibilityservice/GestureDescription$Builder;-><init>()V

    invoke-virtual {p1, p0}, Landroid/accessibilityservice/GestureDescription$Builder;->addStroke(Landroid/accessibilityservice/GestureDescription$StrokeDescription;)Landroid/accessibilityservice/GestureDescription$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/accessibilityservice/GestureDescription$Builder;->build()Landroid/accessibilityservice/GestureDescription;

    move-result-object p0

    new-instance p1, Lcom/icontrol/protector/a$b;

    invoke-direct {p1}, Lcom/icontrol/protector/a$b;-><init>()V

    const/4 v1, 0x0

    invoke-virtual {v0, p0, p1, v1}, Landroid/accessibilityservice/AccessibilityService;->dispatchGesture(Landroid/accessibilityservice/GestureDescription;Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;Landroid/os/Handler;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    return-void
.end method

.method public static T()Lcom/icontrol/protector/AccessServices;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method

.method private static U()Landroid/content/Context;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    return-object v0
.end method

.method public static V()V
    .locals 5

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1e

    const/16 v4, 0x8

    if-lt v2, v3, :cond_2

    const/4 v2, 0x4

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    new-array v3, v4, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x46

    invoke-virtual {v0, v1, v2, v3}, Lcom/icontrol/protector/AccessServices;->a(Landroid/content/Context;Ljava/lang/String;I)V

    goto :goto_0

    :cond_2
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v2, v4, [B

    fill-array-data v2, :array_3

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x2b

    new-array v2, v2, [B

    fill-array-data v2, :array_4

    new-array v3, v4, [B

    fill-array-data v3, :array_5

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v0, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    return-void

    nop

    :array_0
    .array-data 1
        -0x4ct
        0x11t
        -0x79t
        0x8t
    .end array-data

    :array_1
    .array-data 1
        -0x39t
        0x7ft
        -0x1at
        0x78t
        -0x36t
        0x5bt
        0x59t
        0x3et
    .end array-data

    :array_2
    .array-data 1
        0x76t
        -0x6ft
        0x2ct
        -0x4et
        0x8t
        -0x6t
        0x54t
        -0x1at
        0x57t
        -0x75t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x25t
        -0x1t
        0x4dt
        -0x3et
        0x28t
        -0x57t
        0x3ct
        -0x77t
    .end array-data

    :array_4
    .array-data 1
        0x2dt
        0x59t
        -0x38t
        -0x45t
        -0x31t
        -0x62t
        0x2ct
        0x19t
        0x2dt
        0x44t
        -0x2dt
        -0x53t
        -0x31t
        -0x76t
        0x2ct
        0x9t
        0x2ct
        0x58t
        -0x2dt
        -0x53t
        -0x64t
        -0x28t
        0x28t
        0x16t
        0x3dt
        0x43t
        -0x32t
        -0x5ft
        -0x75t
        -0x28t
        0x78t
        0x49t
        0x79t
        0x50t
        -0x31t
        -0x54t
        -0x31t
        -0x66t
        0x2ct
        0x1t
        0x36t
        0x5ft
        -0x3bt
    .end array-data

    :array_5
    .array-data 1
        0x59t
        0x31t
        -0x5ft
        -0x38t
        -0x11t
        -0x8t
        0x49t
        0x78t
    .end array-data
.end method

.method public static W(Ljava/lang/String;)V
    .locals 5

    .line 1
    :try_start_0
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    invoke-virtual {v0}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->findFocus(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const/16 v3, 0x25

    new-array v3, v3, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v4, v4, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/high16 p0, 0x200000

    if-eqz v1, :cond_2

    invoke-virtual {v1, p0, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(ILandroid/os/Bundle;)Z

    move-result v3

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    if-nez v3, :cond_4

    :cond_2
    sget-object v0, Lcom/icontrol/protector/AccessServices;->H:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-nez v0, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0, p0, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(ILandroid/os/Bundle;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_4
    return-void

    :array_0
    .array-data 1
        -0x75t
        0x33t
        -0x69t
        -0x40t
        0x2bt
        0x7t
        0x53t
        0x2at
        -0x68t
        0x37t
        -0x6at
        -0x3ct
        0x21t
        0x7t
        0x58t
        0x34t
        -0x67t
        0x35t
        -0x69t
        -0x2at
        0x30t
        0xct
        0x54t
        0x3ft
        -0x6bt
        0x33t
        -0x75t
        -0x38t
        0x36t
        0x1at
        0x49t
        0x3at
        -0x61t
        0x35t
        -0x73t
        -0x36t
        0x21t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x36t
        0x70t
        -0x3dt
        -0x77t
        0x64t
        0x49t
        0xct
        0x6bt
    .end array-data
.end method

.method private static X(Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/content/Context;)V
    .locals 4

    .line 1
    if-nez p0, :cond_0

    return-void

    :cond_0
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p0, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    invoke-static {p0}, Lcom/icontrol/protector/a;->D(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x8

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_2

    :cond_1
    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    :cond_2
    const/high16 v3, -0x10000

    invoke-static {p1, p2, v0, v1, v3}, Lcom/icontrol/protector/a;->B(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/Rect;Ljava/lang/String;I)V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->F:Ljava/lang/String;

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v2, v2, [B

    fill-array-data v2, :array_3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {p3, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-static {p3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p3

    invoke-static {p1, p0, p2, p3}, Lcom/icontrol/protector/a;->C(Landroid/graphics/Canvas;Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/graphics/Paint;I)V

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    return-void

    nop

    :array_0
    .array-data 1
        0x7ct
        -0x4t
        0x54t
    .end array-data

    :array_1
    .array-data 1
        -0x62t
        0x7ct
        -0xat
        -0x4ft
        0x71t
        0x33t
        -0x34t
        -0x57t
    .end array-data

    :array_2
    .array-data 1
        0x6at
        0x58t
        0x52t
        -0x22t
        0x4at
        0x43t
        -0x5bt
    .end array-data

    :array_3
    .array-data 1
        0x49t
        0x1et
        0x14t
        -0x68t
        0xct
        0x5t
        -0x1dt
        -0x6bt
    .end array-data
.end method

.method public static Y(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/String;
    .locals 5

    .line 1
    const-string v0, ""

    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v2, 0x0

    :goto_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v3

    if-ge v2, v3, :cond_3

    invoke-virtual {p0, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    invoke-static {v3}, Lcom/icontrol/protector/a;->Y(Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, " "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    return-object v0
.end method

.method public static Z(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .locals 3

    .line 1
    const/4 v0, 0x0

    if-nez p0, :cond_0

    return v0

    :cond_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->isScrollable()Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v0, 0x1000

    invoke-virtual {p0, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    move-result p0

    return p0

    :cond_1
    move v1, v0

    :goto_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v2

    if-ge v1, v2, :cond_3

    invoke-virtual {p0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    invoke-static {v2}, Lcom/icontrol/protector/a;->Z(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 p0, 0x1

    return p0

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    return v0
.end method

.method public static synthetic a(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 0

    .line 1
    invoke-static {p0}, Lcom/icontrol/protector/a;->Q(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    return-void
.end method

.method private static a0(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Ljava/util/List;)V
    .locals 2

    .line 1
    if-nez p0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getClassName()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p2, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_2

    invoke-virtual {p0, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v1

    invoke-static {v1, p1, p2}, Lcom/icontrol/protector/a;->a0(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Ljava/util/List;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public static synthetic b(Lcom/icontrol/protector/AccessServices;)V
    .locals 0

    .line 1
    invoke-static {p0}, Lcom/icontrol/protector/a;->P(Lcom/icontrol/protector/AccessServices;)V

    return-void
.end method

.method public static b0(Z)V
    .locals 4

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    const/16 v2, 0xc

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/inputmethod/InputMethodManager;

    const/4 v2, 0x0

    if-eqz p0, :cond_2

    invoke-virtual {v0}, Landroid/accessibilityservice/AccessibilityService;->getSoftKeyboardController()Landroid/accessibilityservice/AccessibilityService$SoftKeyboardController;

    move-result-object p0

    invoke-virtual {p0, v2}, Landroid/accessibilityservice/AccessibilityService$SoftKeyboardController;->setShowMode(I)Z

    const/4 p0, 0x2

    :try_start_0
    invoke-virtual {v1, p0, v2}, Landroid/view/inputmethod/InputMethodManager;->toggleSoftInput(II)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_0

    :cond_2
    invoke-virtual {v0}, Landroid/accessibilityservice/AccessibilityService;->getSoftKeyboardController()Landroid/accessibilityservice/AccessibilityService$SoftKeyboardController;

    move-result-object p0

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/accessibilityservice/AccessibilityService$SoftKeyboardController;->setShowMode(I)Z

    :try_start_1
    invoke-virtual {v1, v0, v2}, Landroid/view/inputmethod/InputMethodManager;->toggleSoftInput(II)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :goto_0
    return-void

    :array_0
    .array-data 1
        -0x62t
        0x19t
        -0x72t
        -0x37t
        -0x5bt
        -0x6et
        -0x4dt
        0x38t
        -0x7dt
        0x1ft
        -0x6ft
        -0x28t
    .end array-data

    :array_1
    .array-data 1
        -0x9t
        0x77t
        -0x2t
        -0x44t
        -0x2ft
        -0x33t
        -0x22t
        0x5dt
    .end array-data
.end method

.method public static synthetic c(Lcom/icontrol/protector/AccessServices;)V
    .locals 0

    .line 1
    invoke-static {p0}, Lcom/icontrol/protector/a;->O(Lcom/icontrol/protector/AccessServices;)V

    return-void
.end method

.method private static c0(II)V
    .locals 8

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    int-to-float p0, p0

    const/high16 v1, 0x3f000000    # 0.5f

    mul-float/2addr p0, v1

    int-to-float p1, p1

    const/high16 v1, 0x3f400000    # 0.75f

    mul-float/2addr v1, p1

    const v2, 0x3e4ccccd    # 0.2f

    mul-float/2addr p1, v2

    new-instance v3, Landroid/graphics/Path;

    invoke-direct {v3}, Landroid/graphics/Path;-><init>()V

    invoke-virtual {v3, p0, v1}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v3, p0, p1}, Landroid/graphics/Path;->lineTo(FF)V

    new-instance p0, Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-direct {p0}, Landroid/accessibilityservice/GestureDescription$Builder;-><init>()V

    new-instance p1, Landroid/accessibilityservice/GestureDescription$StrokeDescription;

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x1f4

    move-object v2, p1

    invoke-direct/range {v2 .. v7}, Landroid/accessibilityservice/GestureDescription$StrokeDescription;-><init>(Landroid/graphics/Path;JJ)V

    invoke-virtual {p0, p1}, Landroid/accessibilityservice/GestureDescription$Builder;->addStroke(Landroid/accessibilityservice/GestureDescription$StrokeDescription;)Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-virtual {p0}, Landroid/accessibilityservice/GestureDescription$Builder;->build()Landroid/accessibilityservice/GestureDescription;

    move-result-object p0

    new-instance p1, Lcom/icontrol/protector/a$c;

    invoke-direct {p1}, Lcom/icontrol/protector/a$c;-><init>()V

    const/4 v1, 0x0

    invoke-virtual {v0, p0, p1, v1}, Landroid/accessibilityservice/AccessibilityService;->dispatchGesture(Landroid/accessibilityservice/GestureDescription;Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;Landroid/os/Handler;)Z

    return-void
.end method

.method public static synthetic d(Landroid/content/Context;Lcom/icontrol/protector/AccessServices;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, Lcom/icontrol/protector/a;->R(Landroid/content/Context;Lcom/icontrol/protector/AccessServices;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    return-void
.end method

.method public static d0()V
    .locals 2

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget v1, v0, Lcom/icontrol/protector/AccessServices;->g:I

    iget v0, v0, Lcom/icontrol/protector/AccessServices;->h:I

    invoke-static {v1, v0}, Lcom/icontrol/protector/a;->c0(II)V

    return-void
.end method

.method public static e(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/a;->i:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/a;->i:Ljava/util/Map;

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method public static f(Ljava/lang/String;)V
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/a;->g:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/a;->g:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public static g(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/a;->h:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/a;->h:Ljava/util/Map;

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method public static h(II)V
    .locals 4

    .line 1
    div-int/lit8 p0, p0, 0x4

    int-to-double v0, p1

    const-wide/high16 v2, 0x3fd0000000000000L    # 0.25

    mul-double/2addr v0, v2

    double-to-int v0, v0

    add-int/lit16 v0, v0, 0x12c

    add-int/lit8 p1, p1, -0x64

    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v1

    invoke-static {}, Lcom/icontrol/protector/k;->a()[Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/icontrol/protector/k;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    const-wide/16 v1, 0x3e8

    :try_start_0
    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    if-ge v0, p1, :cond_2

    const-wide/16 v1, 0x28

    :try_start_1
    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v1

    invoke-static {}, Lcom/icontrol/protector/k;->a()[Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/icontrol/protector/k;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object p0

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/ab;->D:Ljava/lang/String;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p0, p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    goto :goto_1

    :cond_1
    :try_start_2
    invoke-static {p0, v0}, Lcom/icontrol/protector/a;->y(II)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    add-int/lit8 v0, v0, 0xf

    goto :goto_0

    :cond_2
    :goto_1
    return-void
.end method

.method public static i(Ljava/lang/Boolean;)V
    .locals 3

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    :try_start_0
    new-instance v1, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_2

    new-instance p0, Lntidisestablish/neumonoul/floccinaucinih/f0;

    invoke-direct {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/f0;-><init>(Lcom/icontrol/protector/AccessServices;)V

    :goto_0
    invoke-virtual {v1, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_2

    :catch_0
    move-exception p0

    goto :goto_1

    :cond_2
    new-instance p0, Lntidisestablish/neumonoul/floccinaucinih/g0;

    invoke-direct {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/g0;-><init>(Lcom/icontrol/protector/AccessServices;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :goto_1
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_2
    return-void
.end method

.method public static j(Landroid/content/Context;)V
    .locals 4

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 p0, 0x7

    new-array p0, p0, [B

    fill-array-data p0, :array_0

    const/16 v0, 0x8

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/icontrol/protector/a;->q(Ljava/lang/String;[Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/icontrol/protector/a$d;

    invoke-direct {v1, p0}, Lcom/icontrol/protector/a$d;-><init>(Landroid/content/Context;)V

    const-wide/16 v2, 0x1

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_0
    return-void

    :array_0
    .array-data 1
        -0x16t
        0x48t
        0x6bt
        -0x6dt
        -0x12t
        -0x69t
        -0x14t
    .end array-data

    :array_1
    .array-data 1
        -0x62t
        0x27t
        0xdt
        -0x1ft
        -0x7ft
        -0x7t
        -0x68t
        0x49t
    .end array-data
.end method

.method private static k(Ljava/lang/String;Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .locals 6

    .line 1
    const/4 v0, 0x0

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    move v1, v0

    :goto_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v2

    if-ge v1, v2, :cond_4

    invoke-virtual {p1, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    if-eqz v2, :cond_3

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v4, 0x1

    if-eqz v3, :cond_1

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    new-instance p0, Landroid/graphics/Rect;

    invoke-direct {p0}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v2, p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    iget p1, p0, Landroid/graphics/Rect;->left:I

    invoke-virtual {p0}, Landroid/graphics/Rect;->centerY()I

    move-result p0

    const-wide/16 v0, 0x1f4

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-static {p1, p0}, Lcom/icontrol/protector/a;->y(II)Z

    return v4

    :cond_1
    invoke-static {p0, v2}, Lcom/icontrol/protector/a;->k(Ljava/lang/String;Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v3

    if-eqz v3, :cond_2

    return v4

    :cond_2
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_4
    :goto_1
    return v0
.end method

.method public static l(Landroid/view/accessibility/AccessibilityNodeInfo;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 47

    .line 1
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v3

    if-nez v3, :cond_1

    return-void

    :cond_1
    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->G:Ljava/lang/String;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v3, v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_2

    const-wide/16 v2, 0x320

    :try_start_0
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-static/range {p0 .. p0}, Lcom/icontrol/protector/a;->I(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    return-void

    :cond_2
    sget-object v4, Lcom/icontrol/protector/AccessServices;->F:Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    const-wide/16 v5, 0x3e8

    if-eqz v4, :cond_3

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lntidisestablish/neumonoul/floccinaucinih/h0;

    invoke-direct {v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/h0;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    invoke-virtual {v0, v2, v5, v6}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_3
    sget-object v4, Lcom/icontrol/protector/AccessServices;->G:Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_4

    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v2, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v4, Lntidisestablish/neumonoul/floccinaucinih/i0;

    invoke-direct {v4, v3, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/i0;-><init>(Landroid/content/Context;Lcom/icontrol/protector/AccessServices;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    invoke-virtual {v2, v4, v5, v6}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_4
    const/16 v4, 0xd

    const/16 v5, 0x21

    const/16 v7, 0xf

    const/16 v9, 0x8

    if-eqz v1, :cond_6

    const/16 v0, 0x23

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v10, v9, [B

    fill-array-data v10, :array_1

    invoke-static {v0, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    const/16 v0, 0x12

    new-array v10, v0, [B

    fill-array-data v10, :array_2

    new-array v12, v9, [B

    fill-array-data v12, :array_3

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    const/16 v10, 0x4b

    new-array v13, v10, [B

    fill-array-data v13, :array_4

    new-array v14, v9, [B

    fill-array-data v14, :array_5

    invoke-static {v13, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    const/16 v14, 0x3b

    new-array v14, v14, [B

    fill-array-data v14, :array_6

    new-array v15, v9, [B

    fill-array-data v15, :array_7

    invoke-static {v14, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v14

    const/16 v15, 0x3e

    new-array v15, v15, [B

    fill-array-data v15, :array_8

    new-array v8, v9, [B

    fill-array-data v8, :array_9

    invoke-static {v15, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v15

    const/16 v8, 0x47

    new-array v8, v8, [B

    fill-array-data v8, :array_a

    new-array v6, v9, [B

    fill-array-data v6, :array_b

    invoke-static {v8, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v16

    new-array v6, v10, [B

    fill-array-data v6, :array_c

    new-array v8, v9, [B

    fill-array-data v8, :array_d

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v17

    new-array v6, v0, [B

    fill-array-data v6, :array_e

    new-array v8, v9, [B

    fill-array-data v8, :array_f

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v18

    const/16 v6, 0x3f

    new-array v6, v6, [B

    fill-array-data v6, :array_10

    new-array v8, v9, [B

    fill-array-data v8, :array_11

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v19

    const/16 v6, 0x43

    new-array v6, v6, [B

    fill-array-data v6, :array_12

    new-array v8, v9, [B

    fill-array-data v8, :array_13

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v20

    const/16 v6, 0x53

    new-array v6, v6, [B

    fill-array-data v6, :array_14

    new-array v8, v9, [B

    fill-array-data v8, :array_15

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v21

    const/16 v6, 0x25

    new-array v6, v6, [B

    fill-array-data v6, :array_16

    new-array v8, v9, [B

    fill-array-data v8, :array_17

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v22

    const/16 v6, 0x36

    new-array v6, v6, [B

    fill-array-data v6, :array_18

    new-array v8, v9, [B

    fill-array-data v8, :array_19

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v23

    const/16 v6, 0x40

    new-array v6, v6, [B

    fill-array-data v6, :array_1a

    new-array v8, v9, [B

    fill-array-data v8, :array_1b

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v24

    new-array v6, v5, [B

    fill-array-data v6, :array_1c

    new-array v8, v9, [B

    fill-array-data v8, :array_1d

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v25

    new-array v6, v4, [B

    fill-array-data v6, :array_1e

    new-array v8, v9, [B

    fill-array-data v8, :array_1f

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v26

    new-array v6, v7, [B

    fill-array-data v6, :array_20

    new-array v8, v9, [B

    fill-array-data v8, :array_21

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v27

    const/16 v6, 0x17

    new-array v6, v6, [B

    fill-array-data v6, :array_22

    new-array v8, v9, [B

    fill-array-data v8, :array_23

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v28

    filled-new-array/range {v11 .. v28}, [Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x0

    :goto_0
    if-ge v8, v0, :cond_6

    aget-object v10, v6, v8

    invoke-virtual {v1, v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByViewId(Ljava/lang/String;)Ljava/util/List;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :catch_1
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_5

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/view/accessibility/AccessibilityNodeInfo;

    const/16 v12, 0x10

    :try_start_1
    invoke-virtual {v11, v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    const/4 v12, 0x0

    sput-boolean v12, Lntidisestablish/neumonoul/floccinaucinih/ab;->i0:Z

    invoke-virtual {v11}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :cond_5
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_6
    const/4 v6, 0x7

    const/16 v8, 0xc

    const/4 v10, 0x3

    const/16 v11, 0x9

    const/4 v12, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x5

    const/4 v15, 0x6

    const/4 v7, 0x2

    :try_start_2
    new-array v0, v11, [Ljava/lang/String;

    new-array v4, v14, [B

    fill-array-data v4, :array_24

    new-array v5, v9, [B

    fill-array-data v5, :array_25

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    aput-object v4, v0, v5

    new-array v4, v11, [B

    fill-array-data v4, :array_26

    new-array v5, v9, [B

    fill-array-data v5, :array_27

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v12

    new-array v4, v9, [B

    fill-array-data v4, :array_28

    new-array v5, v9, [B

    fill-array-data v5, :array_29

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v7

    new-array v4, v9, [B

    fill-array-data v4, :array_2a

    new-array v5, v9, [B

    fill-array-data v5, :array_2b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v10

    new-array v4, v15, [B

    fill-array-data v4, :array_2c

    new-array v5, v9, [B

    fill-array-data v5, :array_2d

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v13

    new-array v4, v15, [B

    fill-array-data v4, :array_2e

    new-array v5, v9, [B

    fill-array-data v5, :array_2f

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v14

    new-array v4, v8, [B

    fill-array-data v4, :array_30

    new-array v5, v9, [B

    fill-array-data v5, :array_31

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v15

    new-array v4, v9, [B

    fill-array-data v4, :array_32

    new-array v5, v9, [B

    fill-array-data v5, :array_33

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v6

    new-array v4, v9, [B

    fill-array-data v4, :array_34

    new-array v5, v9, [B

    fill-array-data v5, :array_35

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v9

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v11, :cond_8

    aget-object v10, v0, v5
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3

    :try_start_3
    invoke-static {v10, v2}, Lcom/icontrol/protector/a;->G(Ljava/lang/String;Landroid/view/accessibility/AccessibilityNodeInfo;)Ljava/util/List;

    move-result-object v4
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    if-eqz v4, :cond_7

    :try_start_4
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_7

    const/4 v10, 0x0

    invoke-interface {v4, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;

    const/16 v4, 0x10

    invoke-virtual {v0, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    sput-boolean v10, Lntidisestablish/neumonoul/floccinaucinih/ab;->i0:Z

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    goto :goto_3

    :catch_3
    move-exception v0

    goto :goto_2

    :cond_7
    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x3

    goto :goto_1

    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_8
    :goto_3
    if-eqz v2, :cond_9

    const/16 v4, 0x21

    new-array v0, v4, [B

    fill-array-data v0, :array_36

    new-array v4, v9, [B

    fill-array-data v4, :array_37

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByViewId(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_9

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo;

    const/16 v4, 0x10

    invoke-virtual {v2, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    goto :goto_4

    :cond_9
    if-eqz v1, :cond_c

    new-array v0, v15, [B

    fill-array-data v0, :array_38

    new-array v2, v9, [B

    fill-array-data v2, :array_39

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v29

    new-array v0, v13, [B

    fill-array-data v0, :array_3a

    new-array v2, v9, [B

    fill-array-data v2, :array_3b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v30

    const/16 v0, 0x57

    new-array v0, v0, [B

    fill-array-data v0, :array_3c

    new-array v2, v9, [B

    fill-array-data v2, :array_3d

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v31

    new-array v0, v13, [B

    fill-array-data v0, :array_3e

    new-array v2, v9, [B

    fill-array-data v2, :array_3f

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v32

    new-array v0, v14, [B

    fill-array-data v0, :array_40

    new-array v2, v9, [B

    fill-array-data v2, :array_41

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v33

    const/16 v0, 0x18

    new-array v2, v0, [B

    fill-array-data v2, :array_42

    new-array v4, v9, [B

    fill-array-data v4, :array_43

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v34

    new-array v2, v15, [B

    fill-array-data v2, :array_44

    new-array v4, v9, [B

    fill-array-data v4, :array_45

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v35

    new-array v2, v14, [B

    fill-array-data v2, :array_46

    new-array v4, v9, [B

    fill-array-data v4, :array_47

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v36

    new-array v2, v13, [B

    fill-array-data v2, :array_48

    new-array v4, v9, [B

    fill-array-data v4, :array_49

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v37

    new-array v2, v8, [B

    fill-array-data v2, :array_4a

    new-array v4, v9, [B

    fill-array-data v4, :array_4b

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v38

    new-array v0, v0, [B

    fill-array-data v0, :array_4c

    new-array v2, v9, [B

    fill-array-data v2, :array_4d

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v39

    new-array v0, v6, [B

    fill-array-data v0, :array_4e

    new-array v2, v9, [B

    fill-array-data v2, :array_4f

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v40

    const/16 v2, 0xd

    new-array v0, v2, [B

    fill-array-data v0, :array_50

    new-array v2, v9, [B

    fill-array-data v2, :array_51

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v41

    const/16 v0, 0x1e

    new-array v0, v0, [B

    fill-array-data v0, :array_52

    new-array v2, v9, [B

    fill-array-data v2, :array_53

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v42

    new-array v0, v9, [B

    fill-array-data v0, :array_54

    new-array v2, v9, [B

    fill-array-data v2, :array_55

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v43

    const/16 v0, 0x2c

    new-array v0, v0, [B

    fill-array-data v0, :array_56

    new-array v2, v9, [B

    fill-array-data v2, :array_57

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v44

    new-array v0, v9, [B

    fill-array-data v0, :array_58

    new-array v2, v9, [B

    fill-array-data v2, :array_59

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v45

    const/16 v0, 0x34

    new-array v0, v0, [B

    fill-array-data v0, :array_5a

    new-array v2, v9, [B

    fill-array-data v2, :array_5b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v46

    filled-new-array/range {v29 .. v46}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByText(Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_b

    const/4 v4, 0x0

    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isClickable()Z

    move-result v5

    if-eqz v5, :cond_a

    const/16 v5, 0x10

    invoke-virtual {v2, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    sput-boolean v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->i0:Z

    goto :goto_6

    :cond_a
    const/16 v5, 0x10

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    goto :goto_5

    :cond_b
    const/16 v5, 0x10

    goto :goto_5

    :cond_c
    :goto_6
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->H:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v3, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_16

    invoke-static {v3}, Lcom/icontrol/protector/n;->h(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_d

    const/4 v4, 0x0

    sput-boolean v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->j0:Z

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->H:Ljava/lang/String;

    invoke-static {v3, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    return-void

    :cond_d
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    const/16 v4, 0xf

    new-array v5, v4, [B

    fill-array-data v5, :array_5c

    new-array v4, v9, [B

    fill-array-data v4, :array_5d

    invoke-static {v5, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/16 v6, 0xc31

    if-eq v5, v6, :cond_14

    const/16 v6, 0xca9

    if-eq v5, v6, :cond_13

    const/16 v6, 0xcae

    if-eq v5, v6, :cond_12

    const/16 v6, 0xe04

    if-eq v5, v6, :cond_11

    const/16 v6, 0xe43

    if-eq v5, v6, :cond_10

    const/16 v6, 0xe7e

    if-eq v5, v6, :cond_f

    const/16 v6, 0xf2e

    if-eq v5, v6, :cond_e

    goto/16 :goto_7

    :cond_e
    new-array v5, v7, [B

    fill-array-data v5, :array_5e

    new-array v6, v9, [B

    fill-array-data v6, :array_5f

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    move v14, v7

    goto/16 :goto_8

    :cond_f
    new-array v5, v7, [B

    fill-array-data v5, :array_60

    new-array v6, v9, [B

    fill-array-data v6, :array_61

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    const/4 v14, 0x3

    goto/16 :goto_8

    :cond_10
    new-array v5, v7, [B

    fill-array-data v5, :array_62

    new-array v6, v9, [B

    fill-array-data v6, :array_63

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    goto :goto_8

    :cond_11
    new-array v5, v7, [B

    fill-array-data v5, :array_64

    new-array v6, v9, [B

    fill-array-data v6, :array_65

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    move v14, v13

    goto :goto_8

    :cond_12
    new-array v5, v7, [B

    fill-array-data v5, :array_66

    new-array v6, v9, [B

    fill-array-data v6, :array_67

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    move v14, v15

    goto :goto_8

    :cond_13
    new-array v5, v7, [B

    fill-array-data v5, :array_68

    new-array v6, v9, [B

    fill-array-data v6, :array_69

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    const/4 v14, 0x0

    goto :goto_8

    :cond_14
    new-array v5, v7, [B

    fill-array-data v5, :array_6a

    new-array v6, v9, [B

    fill-array-data v6, :array_6b

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    move v14, v12

    goto :goto_8

    :cond_15
    :goto_7
    const/4 v0, -0x1

    move v14, v0

    :goto_8
    packed-switch v14, :pswitch_data_0

    const/4 v5, 0x0

    sput-boolean v5, Lntidisestablish/neumonoul/floccinaucinih/ab;->j0:Z

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->H:Ljava/lang/String;

    invoke-static {v3, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    goto/16 :goto_9

    :pswitch_0
    const/16 v0, 0x11

    new-array v0, v0, [B

    fill-array-data v0, :array_6c

    new-array v4, v9, [B

    fill-array-data v4, :array_6d

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_9

    :pswitch_1
    const/16 v0, 0x1d

    new-array v0, v0, [B

    fill-array-data v0, :array_6e

    new-array v4, v9, [B

    fill-array-data v4, :array_6f

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_9

    :pswitch_2
    const/16 v0, 0x13

    new-array v0, v0, [B

    fill-array-data v0, :array_70

    new-array v4, v9, [B

    fill-array-data v4, :array_71

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_9

    :pswitch_3
    const/16 v4, 0xf

    new-array v0, v4, [B

    fill-array-data v0, :array_72

    new-array v4, v9, [B

    fill-array-data v4, :array_73

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_9

    :pswitch_4
    new-array v0, v11, [B

    fill-array-data v0, :array_74

    new-array v4, v9, [B

    fill-array-data v4, :array_75

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_9

    :pswitch_5
    const/16 v0, 0x16

    new-array v0, v0, [B

    fill-array-data v0, :array_76

    new-array v4, v9, [B

    fill-array-data v4, :array_77

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_9

    :pswitch_6
    const/16 v4, 0xf

    new-array v0, v4, [B

    fill-array-data v0, :array_78

    new-array v4, v9, [B

    fill-array-data v4, :array_79

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    :goto_9
    invoke-static {v4, v1}, Lcom/icontrol/protector/a;->k(Ljava/lang/String;Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v0

    if-eqz v0, :cond_16

    const/4 v1, 0x0

    sput-boolean v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->j0:Z

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->H:Ljava/lang/String;

    invoke-static {v3, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-static {}, Lcom/icontrol/protector/a;->w()V

    :cond_16
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        -0x1t
        0x7et
        0x35t
        0x14t
        0x23t
        0x7et
        -0x78t
        0x54t
        -0xdt
        0x78t
        0x3ct
        0x14t
        0x31t
        0x75t
        -0x68t
        0x52t
        -0xbt
        0x7ft
        0x3ft
        0x49t
        0x78t
        0x79t
        -0x78t
        0x9t
        -0x10t
        0x74t
        0x3et
        0x4et
        0x1dt
        0x72t
        -0x67t
        0x52t
        -0x18t
        0x7et
        0x36t
    .end array-data

    :array_1
    .array-data 1
        -0x64t
        0x11t
        0x58t
        0x3at
        0x42t
        0x10t
        -0x14t
        0x26t
    .end array-data

    :array_2
    .array-data 1
        0x49t
        0x6t
        -0x62t
        -0x44t
        0x5at
        0xct
        -0x2ct
        0x58t
        0x41t
        0xct
        -0x2bt
        -0x54t
        0x40t
        0x11t
        -0x3ct
        0xdt
        0x46t
        0x59t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x28t
        0x68t
        -0x6t
        -0x32t
        0x35t
        0x65t
        -0x50t
        0x62t
    .end array-data

    :array_4
    .array-data 1
        -0x57t
        0x25t
        -0x33t
        0xet
        -0x4at
        0x28t
        0x43t
        0x78t
        -0x5bt
        0x23t
        -0x3ct
        0xet
        -0x59t
        0x23t
        0x55t
        0x67t
        -0x5dt
        0x39t
        -0x2dt
        0x49t
        -0x48t
        0x28t
        0x44t
        0x65t
        -0x5ct
        0x3et
        -0x2et
        0x4ft
        -0x45t
        0x2at
        0x42t
        0x78t
        -0x10t
        0x23t
        -0x3ct
        0xft
        -0x59t
        0x23t
        0x55t
        0x67t
        -0x5dt
        0x39t
        -0x2dt
        0x49t
        -0x48t
        0x28t
        0x78t
        0x6bt
        -0x5at
        0x26t
        -0x31t
        0x57t
        -0x78t
        0x20t
        0x48t
        0x78t
        -0x51t
        0x2dt
        -0x2et
        0x4ft
        -0x5et
        0x28t
        0x43t
        0x55t
        -0x5bt
        0x24t
        -0x34t
        0x59t
        -0x78t
        0x24t
        0x52t
        0x7et
        -0x42t
        0x25t
        -0x32t
    .end array-data

    :array_5
    .array-data 1
        -0x36t
        0x4at
        -0x60t
        0x20t
        -0x29t
        0x46t
        0x27t
        0xat
    .end array-data

    :array_6
    .array-data 1
        -0x63t
        0x55t
        -0x77t
        0x2at
        0x36t
        0x6et
        0x6dt
        -0x5dt
        -0x6ft
        0x53t
        -0x80t
        0x2at
        0x27t
        0x65t
        0x7bt
        -0x44t
        -0x69t
        0x49t
        -0x69t
        0x6dt
        0x38t
        0x6et
        0x6at
        -0x42t
        -0x70t
        0x4et
        -0x6at
        0x6bt
        0x3bt
        0x6ct
        0x6ct
        -0x5dt
        -0x3ct
        0x53t
        -0x80t
        0x2bt
        0x27t
        0x65t
        0x7bt
        -0x44t
        -0x69t
        0x49t
        -0x69t
        0x6dt
        0x38t
        0x6et
        0x56t
        -0x50t
        -0x6et
        0x56t
        -0x75t
        0x73t
        0x8t
        0x62t
        0x7ct
        -0x5bt
        -0x76t
        0x55t
        -0x76t
    .end array-data

    :array_7
    .array-data 1
        -0x2t
        0x3at
        -0x1ct
        0x4t
        0x57t
        0x0t
        0x9t
        -0x2ft
    .end array-data

    :array_8
    .array-data 1
        0x2t
        -0x20t
        -0x14t
        -0x24t
        0x16t
        -0x8t
        -0x7ft
        0x8t
        0xet
        -0x1at
        -0x1bt
        -0x24t
        0x7t
        -0x9t
        -0x7at
        0x11t
        0x0t
        -0x18t
        -0x1ct
        -0x65t
        0x19t
        -0x1bt
        -0x6ft
        0x1bt
        0xdt
        -0x1dt
        -0x1ct
        -0x80t
        0x4dt
        -0x1t
        -0x7ft
        0x55t
        0x11t
        -0x16t
        -0xdt
        -0x61t
        0x1et
        -0x1bt
        -0x6at
        0x13t
        0xet
        -0x1ft
        -0x22t
        -0x6dt
        0x1bt
        -0x6t
        -0x76t
        0xdt
        0x3et
        -0x12t
        -0x13t
        -0x7bt
        0x16t
        -0x11t
        -0x6at
        0x25t
        0x3t
        -0x6t
        -0xbt
        -0x7at
        0x18t
        -0x8t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x61t
        -0x71t
        -0x7ft
        -0xet
        0x77t
        -0x6at
        -0x1bt
        0x7at
    .end array-data

    :array_a
    .array-data 1
        -0x3et
        -0x44t
        -0x33t
        -0x30t
        0x61t
        -0x57t
        0x79t
        0xdt
        -0x32t
        -0x46t
        -0x3ct
        -0x30t
        0x70t
        -0x5at
        0x7et
        0x14t
        -0x40t
        -0x4ct
        -0x3bt
        -0x69t
        0x6et
        -0x4ct
        0x69t
        0x1et
        -0x33t
        -0x41t
        -0x3bt
        -0x74t
        0x3at
        -0x52t
        0x79t
        0x50t
        -0x2ft
        -0x4at
        -0x2et
        -0x6dt
        0x69t
        -0x4ct
        0x6et
        0x16t
        -0x32t
        -0x43t
        -0x1t
        -0x61t
        0x6ct
        -0x55t
        0x72t
        0x8t
        -0x2t
        -0x4bt
        -0x31t
        -0x74t
        0x65t
        -0x60t
        0x6ft
        0x10t
        -0x2ct
        -0x43t
        -0x3ct
        -0x5ft
        0x6ft
        -0x57t
        0x71t
        0x6t
        -0x2t
        -0x4ft
        -0x2bt
        -0x76t
        0x74t
        -0x58t
        0x73t
    .end array-data

    :array_b
    .array-data 1
        -0x5ft
        -0x2dt
        -0x60t
        -0x2t
        0x0t
        -0x39t
        0x1dt
        0x7ft
    .end array-data

    :array_c
    .array-data 1
        -0x52t
        0x14t
        0x33t
        -0x58t
        0x20t
        -0x1bt
        0x62t
        -0xat
        -0x5et
        0x12t
        0x3at
        -0x58t
        0x31t
        -0x12t
        0x74t
        -0x17t
        -0x5ct
        0x8t
        0x2dt
        -0x11t
        0x2et
        -0x1bt
        0x65t
        -0x15t
        -0x5dt
        0xft
        0x2ct
        -0x17t
        0x2dt
        -0x19t
        0x63t
        -0xat
        -0x9t
        0x12t
        0x3at
        -0x57t
        0x31t
        -0x12t
        0x74t
        -0x17t
        -0x5ct
        0x8t
        0x2dt
        -0x11t
        0x2et
        -0x1bt
        0x59t
        -0x1bt
        -0x5ft
        0x17t
        0x31t
        -0xft
        0x1et
        -0x13t
        0x69t
        -0xat
        -0x58t
        0x1ct
        0x2ct
        -0x17t
        0x34t
        -0x1bt
        0x62t
        -0x25t
        -0x5et
        0x15t
        0x32t
        -0x1t
        0x1et
        -0x17t
        0x73t
        -0x10t
        -0x47t
        0x14t
        0x30t
    .end array-data

    :array_d
    .array-data 1
        -0x33t
        0x7bt
        0x5et
        -0x7at
        0x41t
        -0x75t
        0x6t
        -0x7ct
    .end array-data

    :array_e
    .array-data 1
        0x4ct
        -0x67t
        0x77t
        0x3dt
        -0x53t
        0x5ft
        0x7bt
        0x67t
        0x44t
        -0x6dt
        0x3ct
        0x2dt
        -0x49t
        0x42t
        0x6bt
        0x32t
        0x43t
        -0x3at
    .end array-data

    nop

    :array_f
    .array-data 1
        0x2dt
        -0x9t
        0x13t
        0x4ft
        -0x3et
        0x36t
        0x1ft
        0x5dt
    .end array-data

    :array_10
    .array-data 1
        0x5et
        -0x20t
        0x67t
        -0x7bt
        0x5dt
        0x4dt
        0x54t
        0x3et
        0x48t
        -0x1ft
        0x6dt
        -0x7bt
        0x4ft
        0x42t
        0x5dt
        0x3ft
        0x52t
        -0x1at
        0x6et
        -0x7bt
        0x5et
        0x4dt
        0x5at
        0x26t
        0x5ct
        -0x18t
        0x6ft
        -0x3et
        0x40t
        0x5ft
        0x4dt
        0x2ct
        0x51t
        -0x1dt
        0x6ft
        -0x27t
        0x14t
        0x45t
        0x5dt
        0x62t
        0x4dt
        -0x16t
        0x78t
        -0x3at
        0x47t
        0x5ft
        0x4at
        0x24t
        0x52t
        -0x1ft
        0x55t
        -0x36t
        0x42t
        0x40t
        0x56t
        0x3at
        0x62t
        -0x13t
        0x7ft
        -0x21t
        0x5at
        0x43t
        0x57t
    .end array-data

    :array_11
    .array-data 1
        0x3dt
        -0x71t
        0xat
        -0x55t
        0x2et
        0x2ct
        0x39t
        0x4dt
    .end array-data

    :array_12
    .array-data 1
        0x36t
        -0x2t
        0x20t
        0x15t
        0x22t
        -0x4bt
        0x2dt
        0x55t
        0x20t
        -0x1t
        0x2at
        0x15t
        0x30t
        -0x46t
        0x24t
        0x54t
        0x3at
        -0x8t
        0x29t
        0x15t
        0x21t
        -0x4ft
        0x32t
        0x4bt
        0x3ct
        -0x1et
        0x3et
        0x52t
        0x3et
        -0x46t
        0x23t
        0x49t
        0x3bt
        -0x1bt
        0x3ft
        0x54t
        0x3dt
        -0x48t
        0x25t
        0x54t
        0x6ft
        -0x8t
        0x29t
        0x14t
        0x21t
        -0x4ft
        0x32t
        0x4bt
        0x3ct
        -0x1et
        0x3et
        0x52t
        0x3et
        -0x46t
        0x1ft
        0x47t
        0x39t
        -0x3t
        0x22t
        0x4ct
        0xet
        -0x4at
        0x35t
        0x52t
        0x21t
        -0x2t
        0x23t
    .end array-data

    :array_13
    .array-data 1
        0x55t
        -0x6ft
        0x4dt
        0x3bt
        0x51t
        -0x2ct
        0x40t
        0x26t
    .end array-data

    :array_14
    .array-data 1
        -0x42t
        0x29t
        0x48t
        0x34t
        0x23t
        -0x3at
        -0x6t
        -0x33t
        -0x58t
        0x28t
        0x42t
        0x34t
        0x31t
        -0x37t
        -0xdt
        -0x34t
        -0x4et
        0x2ft
        0x41t
        0x34t
        0x20t
        -0x3et
        -0x1bt
        -0x2dt
        -0x4ct
        0x35t
        0x56t
        0x73t
        0x3ft
        -0x37t
        -0xct
        -0x2ft
        -0x4dt
        0x32t
        0x57t
        0x75t
        0x3ct
        -0x35t
        -0xet
        -0x34t
        -0x19t
        0x2ft
        0x41t
        0x35t
        0x20t
        -0x3et
        -0x1bt
        -0x2dt
        -0x4ct
        0x35t
        0x56t
        0x73t
        0x3ft
        -0x37t
        -0x38t
        -0x21t
        -0x4ft
        0x2at
        0x4at
        0x6dt
        0xft
        -0x3ft
        -0x8t
        -0x34t
        -0x48t
        0x21t
        0x57t
        0x75t
        0x25t
        -0x37t
        -0xdt
        -0x1ft
        -0x4et
        0x28t
        0x49t
        0x63t
        0xft
        -0x3bt
        -0x1et
        -0x36t
        -0x57t
        0x29t
        0x4bt
    .end array-data

    :array_15
    .array-data 1
        -0x23t
        0x46t
        0x25t
        0x1at
        0x50t
        -0x59t
        -0x69t
        -0x42t
    .end array-data

    :array_16
    .array-data 1
        0x72t
        0x11t
        0xbt
        0x6dt
        -0x6at
        0x3at
        -0xat
        0x1t
        0x74t
        0x17t
        0x48t
        0x30t
        -0x79t
        0x3ct
        -0x1dt
        0x13t
        0x7ct
        0x13t
        0x7t
        0x2dt
        -0x61t
        0x28t
        -0xet
        0x4t
        0x2bt
        0x17t
        0x2t
        0x6ct
        -0x64t
        0x3bt
        -0x7t
        0x29t
        0x70t
        0x12t
        0xat
        0x2ct
        -0x77t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x11t
        0x7et
        0x66t
        0x43t
        -0x2t
        0x4ft
        -0x69t
        0x76t
    .end array-data

    :array_18
    .array-data 1
        -0x2at
        0x6t
        -0x28t
        -0x38t
        0x61t
        0x34t
        -0xbt
        -0x11t
        -0x30t
        0x0t
        -0x65t
        -0x6at
        0x68t
        0x22t
        -0x1t
        -0x7t
        -0x2et
        0xct
        -0x24t
        -0x78t
        0x7at
        0x35t
        -0xbt
        -0xct
        -0x27t
        0xct
        -0x39t
        -0x24t
        0x60t
        0x25t
        -0x45t
        -0x18t
        -0x30t
        0x1bt
        -0x28t
        -0x71t
        0x7at
        0x32t
        -0x3t
        -0x9t
        -0x25t
        0x36t
        -0x2ct
        -0x76t
        0x65t
        0x2et
        -0x1dt
        -0x39t
        -0x29t
        0x1ct
        -0x3ft
        -0x6et
        0x66t
        0x2ft
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x4bt
        0x69t
        -0x4bt
        -0x1at
        0x9t
        0x41t
        -0x6ct
        -0x68t
    .end array-data

    :array_1a
    .array-data 1
        0x1dt
        0x10t
        -0x7ft
        0x45t
        0x2bt
        -0x32t
        -0x16t
        -0x75t
        0xdt
        0x1at
        -0x71t
        0x1et
        0x35t
        -0x3bt
        -0x5t
        -0x24t
        0x50t
        0x12t
        -0x7bt
        0x1et
        0x2et
        -0x6at
        -0x1at
        -0x3ft
        0x51t
        0xft
        -0x77t
        0x19t
        0x2at
        -0x3bt
        -0x4t
        -0x2at
        0x17t
        0x10t
        -0x7et
        0x34t
        0x26t
        -0x40t
        -0x1dt
        -0x36t
        0x9t
        0x20t
        -0x76t
        0x4t
        0x35t
        -0x37t
        -0x18t
        -0x29t
        0x11t
        0xat
        -0x7et
        0xft
        0x18t
        -0x3dt
        -0x1ft
        -0x37t
        0x7t
        0x20t
        -0x72t
        0x1et
        0x33t
        -0x28t
        -0x20t
        -0x35t
    .end array-data

    :array_1b
    .array-data 1
        0x7et
        0x7ft
        -0x14t
        0x6bt
        0x47t
        -0x54t
        -0x71t
        -0x5bt
    .end array-data

    :array_1c
    .array-data 1
        0x2at
        0x14t
        -0x18t
        -0x7et
        -0x57t
        -0x63t
        -0x54t
        0x73t
        0x67t
        0x8t
        -0x20t
        -0x31t
        -0x4ft
        -0x7at
        -0x50t
        0x6et
        0x30t
        0x18t
        -0x20t
        -0x3et
        -0x50t
        -0x6ft
        -0x55t
        0x20t
        0x20t
        0x1ft
        -0x56t
        -0x33t
        -0x59t
        -0x69t
        -0x44t
        0x6at
        0x3dt
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x49t
        0x7bt
        -0x7bt
        -0x54t
        -0x3ct
        -0xct
        -0x27t
        0x1at
    .end array-data

    :array_1e
    .array-data 1
        -0xft
        0x20t
        -0x4bt
        0x2t
        -0x24t
        0x58t
        -0x7bt
        -0x55t
        -0x5t
        0x3bt
        -0x5ft
        0x5t
        -0x6et
    .end array-data

    nop

    :array_1f
    .array-data 1
        -0x64t
        0x49t
        -0x40t
        0x6bt
        -0x1at
        0x31t
        -0x1ft
        -0x7ct
    .end array-data

    :array_20
    .array-data 1
        0x20t
        -0x38t
        -0x16t
        0x22t
        -0x80t
        -0x67t
        0x8t
        -0x30t
        0x2ft
        -0x2ct
        -0x15t
        0x3ft
        -0x2bt
        -0x62t
        0x5et
    .end array-data

    :array_21
    .array-data 1
        0x4dt
        -0x5ft
        -0x61t
        0x4bt
        -0x46t
        -0x10t
        0x6ct
        -0x1t
    .end array-data

    :array_22
    .array-data 1
        -0x57t
        0x74t
        0x64t
        0x43t
        -0x78t
        -0x7ct
        -0x57t
        0x63t
        -0x5bt
        0x7et
        0x65t
        0x43t
        -0x23t
        -0x7dt
        -0x6et
        0x3ct
        -0x55t
        0x6et
        0x78t
        0x5et
        -0x25t
        -0x65t
        -0x58t
    .end array-data

    :array_23
    .array-data 1
        -0x3ct
        0x1dt
        0x11t
        0x2at
        -0x4et
        -0x13t
        -0x33t
        0x4ct
    .end array-data

    :array_24
    .array-data 1
        0x3ct
        0x14t
        0x49t
        -0x10t
        0x2et
    .end array-data

    nop

    :array_25
    .array-data 1
        0x7dt
        0x78t
        0x25t
        -0x61t
        0x59t
        0xft
        0xft
        -0x3t
    .end array-data

    :array_26
    .array-data 1
        0x21t
        -0x77t
        -0x62t
        -0x4dt
        0x2ct
        0x68t
        0x5ct
        -0xbt
        0x12t
    .end array-data

    nop

    :array_27
    .array-data 1
        0x60t
        -0x4t
        -0x16t
        -0x24t
        0x5et
        0x1t
        0x2ft
        -0x70t
    .end array-data

    :array_28
    .array-data 1
        -0x9t
        0x6t
        0x5ft
        0x64t
        0x65t
        -0x7ct
        0x21t
        -0x40t
    .end array-data

    :array_29
    .array-data 1
        -0x4et
        0x74t
        0x33t
        0x5t
        0x10t
        -0x1at
        0x44t
        -0x52t
    .end array-data

    :array_2a
    .array-data 1
        0x77t
        -0x50t
        0x5t
        0x5dt
        0x4ft
        0x6dt
        0x69t
        0x60t
    .end array-data

    :array_2b
    .array-data 1
        0x27t
        -0x2bt
        0x77t
        0x30t
        0x26t
        0x19t
        0x0t
        0x12t
    .end array-data

    :array_2c
    .array-data 1
        -0x13t
        0x3bt
        0x6bt
        -0x57t
        0x3at
        -0x19t
    .end array-data

    nop

    :array_2d
    .array-data 1
        0x8t
        -0x42t
        -0x16t
        0x41t
        -0x6ct
        0x5ft
        -0x36t
        0x75t
    .end array-data

    :array_2e
    .array-data 1
        -0x5at
        -0x5t
        0x3dt
        -0x3ft
        0x5ft
        -0x50t
    .end array-data

    nop

    :array_2f
    .array-data 1
        0x4bt
        0x6ct
        -0x4bt
        0x2dt
        -0x3bt
        0x19t
        -0x1at
        0x47t
    .end array-data

    :array_30
    .array-data 1
        -0x52t
        0x11t
        -0x68t
        -0x68t
        -0xbt
        -0x5ct
        0x5at
        0x12t
        -0x52t
        0x11t
        -0x67t
        -0x4ft
    .end array-data

    :array_31
    .array-data 1
        0x76t
        -0x4at
        0x41t
        0x1ct
        0x2dt
        0x17t
        -0x7dt
        -0x69t
    .end array-data

    :array_32
    .array-data 1
        0x59t
        -0x67t
        0x7et
        -0x68t
        -0x18t
        -0x7ct
        -0x77t
        0x43t
    .end array-data

    :array_33
    .array-data 1
        0x30t
        -0x1dt
        0x17t
        -0xat
        -0x38t
        -0xet
        -0x14t
        0x31t
    .end array-data

    :array_34
    .array-data 1
        0x53t
        0x2et
        0x58t
        0x67t
        0x1t
        0x71t
        -0x73t
        0x72t
    .end array-data

    :array_35
    .array-data 1
        0x3t
        0x4bt
        0x2at
        0xat
        0x68t
        0x5t
        -0x1ct
        0x0t
    .end array-data

    :array_36
    .array-data 1
        -0x40t
        -0x4ft
        -0x24t
        -0x1ct
        -0x1t
        0x3at
        0x5at
        -0x76t
        -0x73t
        -0x53t
        -0x2ct
        -0x57t
        -0x19t
        0x21t
        0x46t
        -0x69t
        -0x26t
        -0x43t
        -0x2ct
        -0x5ct
        -0x1at
        0x36t
        0x5dt
        -0x27t
        -0x36t
        -0x46t
        -0x62t
        -0x55t
        -0xft
        0x30t
        0x4at
        -0x6dt
        -0x29t
    .end array-data

    nop

    :array_37
    .array-data 1
        -0x5dt
        -0x22t
        -0x4ft
        -0x36t
        -0x6et
        0x53t
        0x2ft
        -0x1dt
    .end array-data

    :array_38
    .array-data 1
        -0x2dt
        -0x73t
        -0x52t
        0x5bt
        0x4at
        -0x58t
    .end array-data

    nop

    :array_39
    .array-data 1
        0x35t
        0x11t
        0x2t
        -0x43t
        -0x1at
        0x9t
        0x43t
        -0xdt
    .end array-data

    :array_3a
    .array-data 1
        0x56t
        -0x72t
        0x22t
        0x59t
    .end array-data

    :array_3b
    .array-data 1
        0x19t
        -0x20t
        0x41t
        0x3ct
        -0x14t
        -0x5bt
        -0x6ft
        -0x7ft
    .end array-data

    :array_3c
    .array-data 1
        0x5bt
        0x3bt
        0x6at
        0x9t
        -0x5bt
        0x31t
        0x29t
        -0x2at
        0x3ft
        0x66t
        0x47t
        0x4ft
        -0x8t
        0x37t
        0x42t
        -0x75t
        0x6t
        0x26t
        0x1at
        0x54t
        -0x77t
        0x6bt
        0x74t
        -0x27t
        0x5bt
        0x3bt
        0x58t
        0x9t
        -0x5ct
        0x0t
        0x29t
        -0x2at
        0x1bt
        0x66t
        0x47t
        0x68t
        -0x8t
        0x36t
        0x75t
        -0x75t
        0x6t
        0x24t
        0x1at
        0x55t
        -0x6dt
        0x6bt
        0x74t
        -0x33t
        0x5bt
        0x38t
        0x6at
        0x9t
        -0x5at
        0x3at
        0x29t
        -0x2at
        0x7t
        0x66t
        0x47t
        0x78t
        -0x8t
        0x37t
        0x42t
        -0x75t
        0x6t
        0x10t
        0x1at
        0x57t
        -0x57t
        0x6bt
        0x74t
        -0x2ft
        0x5bt
        0x3bt
        0x6bt
        0x9t
        -0x5ct
        0x0t
        0x29t
        -0x2at
        0x3dt
        0x66t
        0x47t
        0x55t
        -0x8t
        0x36t
        0x4bt
    .end array-data

    :array_3d
    .array-data 1
        -0x45t
        -0x7at
        -0x6t
        -0x17t
        0x18t
        -0x75t
        -0x37t
        0x6bt
    .end array-data

    :array_3e
    .array-data 1
        -0x30t
        -0x63t
        0x6bt
        -0x68t
    .end array-data

    :array_3f
    .array-data 1
        -0x45t
        -0x4t
        0x7t
        -0xft
        -0x18t
        0x25t
        -0x29t
        -0x20t
    .end array-data

    :array_40
    .array-data 1
        0x4ft
        -0x11t
        -0xbt
        0x42t
        0x7et
    .end array-data

    nop

    :array_41
    .array-data 1
        0x23t
        0xet
        0x4ft
        -0x1bt
        0x10t
        -0x38t
        -0x35t
        -0x7et
    .end array-data

    :array_42
    .array-data 1
        -0x40t
        -0x45t
        -0x1ft
        0x47t
        0x31t
        0x74t
        0xat
        -0xft
        -0x65t
        -0x26t
        -0xft
        0x26t
        0x50t
        0x71t
        0x57t
        -0x70t
        -0x5ft
        -0x6at
        -0x70t
        0x26t
        0x28t
        0x10t
        0x6bt
        -0x35t
    .end array-data

    :array_43
    .array-data 1
        0x21t
        0x3bt
        0x71t
        -0x5at
        -0x4ft
        -0xft
        -0x15t
        0x71t
    .end array-data

    :array_44
    .array-data 1
        -0x63t
        0x5bt
        0x37t
        0x7bt
        -0x4t
        0x10t
    .end array-data

    nop

    :array_45
    .array-data 1
        0x78t
        -0x4t
        -0x44t
        -0x64t
        0x47t
        -0x68t
        -0x2bt
        -0x3bt
    .end array-data

    :array_46
    .array-data 1
        0x9t
        -0x20t
        0x58t
        0x68t
        -0x6ct
    .end array-data

    nop

    :array_47
    .array-data 1
        0x48t
        -0x74t
        0x34t
        0x7t
        -0x1dt
        0x4ct
        -0x56t
        0x67t
    .end array-data

    :array_48
    .array-data 1
        0x2bt
        -0x16t
        -0x74t
        -0x58t
    .end array-data

    :array_49
    .array-data 1
        0x5ft
        -0x7dt
        -0x1ft
        -0x33t
        0x7ct
        0x60t
        0xbt
        0x4ct
    .end array-data

    :array_4a
    .array-data 1
        0x4dt
        0x27t
        0x78t
        0x2bt
        -0x65t
        0x6ft
        -0x8t
        -0x26t
        0x4dt
        0x27t
        0x79t
        0x2t
    .end array-data

    :array_4b
    .array-data 1
        -0x6bt
        -0x80t
        -0x5ft
        -0x51t
        0x43t
        -0x24t
        0x21t
        0x5ft
    .end array-data

    :array_4c
    .array-data 1
        0x35t
        -0x29t
        -0x51t
        0x1et
        0xdt
        0x69t
        -0x17t
        -0x4bt
        0x44t
        -0x76t
        -0x7dt
        0x44t
        0x51t
        0x5et
        -0x7et
        -0x18t
        0x68t
        -0x14t
        -0x22t
        0x43t
        0xdt
        0x2t
        -0x4ct
        -0x76t
    .end array-data

    :array_4d
    .array-data 1
        -0x2bt
        0x6at
        0x3et
        -0x2t
        -0x4ft
        -0x1et
        0x9t
        0x8t
    .end array-data

    :array_4e
    .array-data 1
        0x49t
        0x39t
        -0x3t
        0x10t
        0x79t
        -0x6ft
        -0x56t
    .end array-data

    :array_4f
    .array-data 1
        0x20t
        0x43t
        -0x6ct
        0x7et
        0x12t
        -0x10t
        -0x3ct
        -0x40t
    .end array-data

    :array_50
    .array-data 1
        0x3at
        -0x66t
        0x27t
        0x40t
        -0x7et
        -0x1dt
        -0x7ct
        0x7et
        0x11t
        0x13t
        0x7ct
        0x57t
        0x49t
    .end array-data

    nop

    :array_51
    .array-data 1
        0x79t
        -0xet
        -0x3at
        -0x6t
        0x27t
        -0x6dt
        -0x5ct
        0x10t
    .end array-data

    :array_52
    .array-data 1
        -0x5dt
        -0x5ct
        -0x37t
        -0x60t
        -0x47t
        -0x2at
        0x40t
        -0x4ft
        -0x3at
        -0x3bt
        -0x38t
        -0xat
        -0x28t
        -0x15t
        0x1bt
        -0x30t
        -0x3et
        -0x4ft
        -0x57t
        -0x3ft
        -0x7bt
        -0x76t
        0x21t
        -0x62t
        -0x5dt
        -0x5ct
        -0x23t
        -0x60t
        -0x47t
        -0x40t
    .end array-data

    nop

    :array_53
    .array-data 1
        0x42t
        0x24t
        0x48t
        0x41t
        0x39t
        0x6bt
        -0x5ft
        0x31t
    .end array-data

    :array_54
    .array-data 1
        -0x2dt
        0x15t
        0x3et
        0x3et
        0x4et
        -0x59t
        -0x28t
        -0x59t
    .end array-data

    :array_55
    .array-data 1
        -0x7dt
        0x70t
        0x4ct
        0x53t
        0x27t
        -0x2dt
        -0x4ft
        -0x2bt
    .end array-data

    :array_56
    .array-data 1
        0x2et
        0x3et
        0x59t
        -0x58t
        -0x61t
        0x3dt
        -0x13t
        0x4ft
        0x5et
        0x28t
        0x44t
        -0x57t
        -0x67t
        0x69t
        -0x17t
        0x54t
        0x1bt
        0x35t
        0x5ft
        -0x49t
        -0x69t
        0x3at
        -0x5ct
        0x4et
        0x1bt
        0x7bt
        0x5et
        -0x4at
        -0x69t
        0x69t
        -0x18t
        0x5ct
        0x5et
        0x3at
        0x5bt
        -0x57t
        -0x61t
        0x2at
        -0x1bt
        0x5et
        0x17t
        -0x68t
        -0x68t
        -0x55t
    .end array-data

    :array_57
    .array-data 1
        0x7et
        0x5bt
        0x2bt
        -0x3bt
        -0xat
        0x49t
        -0x7ct
        0x3dt
    .end array-data

    :array_58
    .array-data 1
        -0x38t
        0x3bt
        0x64t
        0x29t
        -0x69t
        0x76t
        0x71t
        -0x21t
    .end array-data

    :array_59
    .array-data 1
        -0x68t
        0x5et
        0x16t
        0x44t
        -0x2t
        0x2t
        0x18t
        -0x53t
    .end array-data

    :array_5a
    .array-data 1
        0x3ft
        -0x43t
        -0x8t
        0xft
        0x68t
        0x3t
        0x25t
        0x41t
        0x4ft
        -0x47t
        -0x6t
        0x7t
        0x6ft
        0x16t
        0x3ft
        0x13t
        0xat
        -0x4at
        -0x5t
        0x17t
        0x60t
        0x19t
        0x38t
        0x5ct
        0x4ft
        -0x43t
        -0x7t
        0x16t
        0x68t
        0x1t
        0x29t
        0x41t
        0x4ft
        -0x53t
        -0x7t
        0x3t
        0x6ft
        0x13t
        0x23t
        0x13t
        0x0t
        -0x8t
        -0x15t
        0x12t
        0x6dt
        0x1et
        0x2ft
        0x52t
        0x1bt
        -0x4ft
        -0x4t
        0xdt
    .end array-data

    :array_5b
    .array-data 1
        0x6ft
        -0x28t
        -0x76t
        0x62t
        0x1t
        0x77t
        0x4ct
        0x33t
    .end array-data

    :array_5c
    .array-data 1
        0x32t
        -0x19t
        -0x13t
        0x45t
        -0x73t
        0x20t
        -0x20t
        0x13t
        0x15t
        -0x15t
        -0x47t
        0x5et
        -0x79t
        0x3dt
        -0x19t
    .end array-data

    :array_5d
    .array-data 1
        0x7ct
        -0x78t
        -0x33t
        0x37t
        -0x18t
        0x53t
        -0x6ct
        0x61t
    .end array-data

    :array_5e
    .array-data 1
        -0x55t
        -0x6bt
    .end array-data

    nop

    :array_5f
    .array-data 1
        -0x2ft
        -0x3t
        0x5dt
        -0x1dt
        -0x10t
        0x27t
        -0x1ft
        0x73t
    .end array-data

    :array_60
    .array-data 1
        -0xet
        0x21t
    .end array-data

    nop

    :array_61
    .array-data 1
        -0x7at
        0x53t
        -0x45t
        -0x37t
        0x77t
        -0x1bt
        -0x5at
        -0x21t
    .end array-data

    :array_62
    .array-data 1
        0x21t
        0x6at
    .end array-data

    nop

    :array_63
    .array-data 1
        0x53t
        0x1ft
        -0x57t
        0x10t
        0x4ft
        -0x15t
        0x64t
        0x2t
    .end array-data

    :array_64
    .array-data 1
        0x4t
        0x66t
    .end array-data

    nop

    :array_65
    .array-data 1
        0x74t
        0x12t
        0x4bt
        -0x51t
        -0x16t
        -0x21t
        0x64t
        0x58t
    .end array-data

    :array_66
    .array-data 1
        -0x31t
        -0x3t
    .end array-data

    nop

    :array_67
    .array-data 1
        -0x56t
        -0x72t
        -0x11t
        0x53t
        -0x35t
        -0x5ct
        0x6ft
        0x21t
    .end array-data

    :array_68
    .array-data 1
        0x77t
        0x72t
    .end array-data

    nop

    :array_69
    .array-data 1
        0x12t
        0x1ct
        -0x2et
        0x71t
        0x42t
        -0x52t
        0x55t
        -0x27t
    .end array-data

    :array_6a
    .array-data 1
        0x36t
        0x58t
    .end array-data

    nop

    :array_6b
    .array-data 1
        0x57t
        0x2at
        -0x7ft
        -0x4dt
        0x14t
        -0x13t
        -0x18t
        -0x2ct
    .end array-data

    :array_6c
    .array-data 1
        -0x70t
        0x77t
        0x2ft
        -0x61t
        0x72t
        0x4ct
        0xbt
        0x22t
        -0x4ft
        0x77t
        0x22t
        -0x24t
        0x69t
        0x46t
        0x16t
        0x33t
        -0x50t
    .end array-data

    nop

    :array_6d
    .array-data 1
        -0x3dt
        0x1et
        0x41t
        -0x41t
        0x0t
        0x29t
        0x78t
        0x56t
    .end array-data

    :array_6e
    .array-data 1
        0x7ft
        0x14t
        -0x37t
        -0x29t
        0x59t
        -0x35t
        0x66t
        -0xft
        0x11t
        0x59t
        -0x56t
        -0x4dt
        0x8t
        -0x67t
        -0xat
        -0xft
        0x12t
        0x59t
        -0x5ft
        -0x4dt
        0xft
        -0x67t
        -0xdt
        -0xft
        0x12t
        0x59t
        -0x5ft
        -0x4et
        0x31t
    .end array-data

    nop

    :array_6f
    .array-data 1
        -0x51t
        -0x77t
        0x19t
        0x62t
        -0x78t
        0x49t
        0x46t
        0x21t
    .end array-data

    :array_70
    .array-data 1
        -0x77t
        -0x6bt
        0x25t
        -0x4ct
        -0x4at
        0x35t
        0x25t
        -0x57t
        -0x4bt
        -0x6bt
        0x38t
        -0x58t
        -0x4ft
        0x31t
        -0x79t
        0x2et
        0x4t
        0x53t
        0x24t
    .end array-data

    :array_71
    .array-data 1
        -0x39t
        -0x10t
        0x4bt
        -0x24t
        -0x3dt
        0x58t
        0x44t
        -0x77t
    .end array-data

    :array_72
    .array-data 1
        -0x71t
        -0x52t
        0x15t
        -0x1et
        -0x22t
        0x3dt
        0x20t
        -0x5ft
        -0x5bt
        0x7t
        -0x3bt
        -0x4ft
        0x63t
        -0x1dt
        0x3ft
    .end array-data

    :array_73
    .array-data 1
        -0x3ct
        0x6at
        -0x5ct
        -0x6ft
        0x1at
        -0x74t
        0x54t
        -0x33t
    .end array-data

    :array_74
    .array-data 1
        0x5ct
        -0x36t
        -0x3dt
        0x13t
        0x6t
        -0x26t
        0x5ft
        0x33t
        0xct
    .end array-data

    nop

    :array_75
    .array-data 1
        -0x46t
        0x5dt
        0x63t
        -0x6t
        -0x61t
        0x4at
        -0x46t
        -0x45t
    .end array-data

    :array_76
    .array-data 1
        0x14t
        0x2dt
        -0x8t
        0x1dt
        -0x1bt
        -0x60t
        0xct
        -0x38t
        0x45t
        0x71t
        -0x74t
        0x62t
        0x6at
        0x58t
        0x7ft
        -0x6dt
        0x14t
        0x23t
        -0x7t
        0x32t
        0x1dt
        -0x29t
    .end array-data

    nop

    :array_77
    .array-data 1
        -0x33t
        -0x57t
        0x20t
        -0x46t
        -0x3bt
        0x78t
        -0x5at
        0x11t
    .end array-data

    :array_78
    .array-data 1
        0x3at
        0x7dt
        -0x57t
        0x1dt
        -0x28t
        -0x3ft
        -0x74t
        -0x3ct
        0x1dt
        0x71t
        -0x3t
        0x6t
        -0x2et
        -0x24t
        -0x75t
    .end array-data

    :array_79
    .array-data 1
        0x74t
        0x12t
        -0x77t
        0x6ft
        -0x43t
        -0x4et
        -0x8t
        -0x4at
    .end array-data
.end method

.method public static m()V
    .locals 5

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    :try_start_0
    new-instance v1, Landroid/content/Intent;

    const/16 v2, 0x1a

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x1c

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v3, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v2, 0x10010000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void

    :array_0
    .array-data 1
        0x9t
        0x76t
        0x1ft
        -0x3ft
        0x29t
        0x37t
        -0x58t
        -0x38t
        0x1t
        0x76t
        0xft
        -0x2at
        0x28t
        0x2at
        -0x1et
        -0x79t
        0xbt
        0x6ct
        0x12t
        -0x24t
        0x28t
        0x70t
        -0x7ft
        -0x59t
        0x21t
        0x56t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x68t
        0x18t
        0x7bt
        -0x4dt
        0x46t
        0x5et
        -0x34t
        -0x1at
    .end array-data

    :array_2
    .array-data 1
        -0x16t
        0x2ft
        -0x1ct
        -0x5ct
        -0x21t
        -0x4dt
        0x63t
        0x1dt
        -0x1et
        0x2ft
        -0xct
        -0x4dt
        -0x22t
        -0x52t
        0x29t
        0x50t
        -0x16t
        0x35t
        -0x1bt
        -0x4ft
        -0x21t
        -0x58t
        0x7et
        0x1dt
        -0x3dt
        0xet
        -0x33t
        -0x6dt
    .end array-data

    :array_3
    .array-data 1
        -0x75t
        0x41t
        -0x80t
        -0x2at
        -0x50t
        -0x26t
        0x7t
        0x33t
    .end array-data
.end method

.method public static n()V
    .locals 4

    .line 1
    sget-object v0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    new-array v1, v1, [B

    const/4 v2, 0x0

    const/16 v3, 0x9

    aput-byte v3, v1, v2

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    :cond_0
    return-void

    nop

    :array_0
    .array-data 1
        0x31t
        0x17t
        -0x11t
        -0x71t
        -0x27t
        -0x65t
        -0x4at
        0xct
    .end array-data
.end method

.method public static o(Ljava/lang/String;)V
    .locals 7

    .line 1
    sget-object v0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xd07

    const/4 v3, 0x1

    const/16 v4, 0x8

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eq v1, v2, :cond_4

    const v2, 0x17c0c

    if-eq v1, v2, :cond_3

    const v2, 0x1b890

    if-eq v1, v2, :cond_2

    goto :goto_0

    :cond_2
    new-array v1, v5, [B

    fill-array-data v1, :array_0

    new-array v2, v4, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_5

    move p0, v3

    goto :goto_1

    :cond_3
    new-array v1, v5, [B

    fill-array-data v1, :array_2

    new-array v2, v4, [B

    fill-array-data v2, :array_3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_5

    move p0, v6

    goto :goto_1

    :cond_4
    new-array v1, v6, [B

    fill-array-data v1, :array_4

    new-array v2, v4, [B

    fill-array-data v2, :array_5

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_5

    const/4 p0, 0x0

    goto :goto_1

    :cond_5
    :goto_0
    const/4 p0, -0x1

    :goto_1
    if-eqz p0, :cond_8

    if-eq p0, v3, :cond_7

    if-eq p0, v6, :cond_6

    goto :goto_2

    :cond_6
    sget-object p0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    invoke-virtual {p0, v3}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    goto :goto_2

    :cond_7
    sget-object p0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    invoke-virtual {p0, v5}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    goto :goto_2

    :cond_8
    invoke-static {v0}, Lcom/icontrol/protector/n;->i(Landroid/content/Context;)Z

    move-result p0

    if-nez p0, :cond_9

    const/4 p0, 0x0

    invoke-static {p0}, Lcom/icontrol/protector/a;->t(Landroid/content/Context;)V

    :cond_9
    sget-object p0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    invoke-virtual {p0, v6}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    :goto_2
    return-void

    :array_0
    .array-data 1
        -0x59t
        0x16t
        -0x1t
    .end array-data

    :array_1
    .array-data 1
        -0x2bt
        0x73t
        -0x64t
        0x2et
        0x9t
        -0x39t
        0x47t
        -0x2bt
    .end array-data

    :array_2
    .array-data 1
        -0x4t
        0x35t
        -0x58t
    .end array-data

    :array_3
    .array-data 1
        -0x62t
        0x54t
        -0x3dt
        -0x4ct
        -0x79t
        -0x7et
        -0x42t
        0x5ft
    .end array-data

    :array_4
    .array-data 1
        -0x2bt
        0x37t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x43t
        0x58t
        -0x5ct
        0x69t
        -0x30t
        0x75t
        -0x77t
        0x50t
    .end array-data
.end method

.method public static p(Ljava/lang/String;)V
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/a;->h:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/a;->h:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    sget-object v0, Lcom/icontrol/protector/a;->i:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/icontrol/protector/a;->i:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    sget-object v0, Lcom/icontrol/protector/a;->g:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Lcom/icontrol/protector/a;->g:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    :cond_2
    return-void
.end method

.method public static q(Ljava/lang/String;[Ljava/lang/String;)V
    .locals 5

    .line 1
    const-string v0, ""

    :try_start_0
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v1

    if-nez v1, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v2

    if-nez v2, :cond_1

    return-void

    :cond_1
    if-eqz p1, :cond_3

    const/4 v3, 0x0

    aget-object v3, p1, v3

    const/4 v4, 0x1

    aget-object p1, p1, v4

    sget-object v4, Lcom/icontrol/protector/AccessServices;->M:Ljava/util/HashMap;

    invoke-virtual {v4, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    sget-object v4, Lcom/icontrol/protector/AccessServices;->M:Ljava/util/HashMap;

    invoke-virtual {v4, v0}, Ljava/util/HashMap;->containsValue(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    :catch_0
    move-exception p0

    goto :goto_1

    :cond_2
    :goto_0
    sget-object v0, Lcom/icontrol/protector/AccessServices;->M:Ljava/util/HashMap;

    invoke-virtual {v0, v3, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    const/16 p1, 0xd

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/accessibility/AccessibilityManager;

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {}, Landroid/view/accessibility/AccessibilityEvent;->obtain()Landroid/view/accessibility/AccessibilityEvent;

    move-result-object v0

    const/16 v3, 0x4000

    invoke-virtual {v0, v3}, Landroid/view/accessibility/AccessibilityEvent;->setEventType(I)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setClassName(Ljava/lang/CharSequence;)V

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityEvent;->setPackageName(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityRecord;->getText()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityManager;->sendAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_4
    :goto_2
    return-void

    :array_0
    .array-data 1
        0x6bt
        -0x58t
        -0x75t
        0x67t
        0x26t
        -0x6ct
        0x78t
        0x1at
        0x63t
        -0x59t
        -0x7ft
        0x76t
        0x2ct
    .end array-data

    nop

    :array_1
    .array-data 1
        0xat
        -0x35t
        -0x18t
        0x2t
        0x55t
        -0x19t
        0x11t
        0x78t
    .end array-data
.end method

.method public static r()V
    .locals 11

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    new-array v4, v2, [B

    fill-array-data v4, :array_1

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/KeyguardManager;

    invoke-virtual {v3}, Landroid/app/KeyguardManager;->isKeyguardLocked()Z

    move-result v3

    if-eqz v3, :cond_b

    const/4 v3, 0x1

    sput-boolean v3, Lcom/icontrol/protector/AccessServices;->A:Z

    const/4 v4, 0x0

    invoke-static {v4}, Lcom/icontrol/protector/a;->t(Landroid/content/Context;)V

    invoke-virtual {v1}, Lcom/icontrol/protector/AccessServices;->j()V

    const-wide/16 v4, 0x3e8

    :try_start_0
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-static {}, Lcom/icontrol/protector/a;->d0()V

    const-wide/16 v4, 0xdac

    :try_start_1
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object v4, Lcom/icontrol/protector/AccessServices;->C:Ljava/lang/Boolean;

    sget-object v5, Lntidisestablish/neumonoul/floccinaucinih/ab;->O:Ljava/lang/String;

    const-string v6, ""

    invoke-static {v1, v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    sget-object v6, Lcom/icontrol/protector/AccessServices;->S:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    move-result v7

    const/16 v8, 0xdf1

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eq v7, v8, :cond_4

    const/16 v8, 0xdf9

    if-eq v7, v8, :cond_3

    const/16 v8, 0xe04

    if-eq v7, v8, :cond_2

    goto :goto_0

    :cond_2
    new-array v7, v10, [B

    fill-array-data v7, :array_2

    new-array v8, v2, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5

    move v6, v3

    goto :goto_1

    :cond_3
    new-array v7, v10, [B

    fill-array-data v7, :array_4

    new-array v8, v2, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5

    move v6, v10

    goto :goto_1

    :cond_4
    new-array v7, v10, [B

    fill-array-data v7, :array_6

    new-array v8, v2, [B

    fill-array-data v8, :array_7

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5

    move v6, v9

    goto :goto_1

    :cond_5
    :goto_0
    const/4 v6, -0x1

    :goto_1
    if-eqz v6, :cond_9

    if-eq v6, v3, :cond_8

    if-eq v6, v10, :cond_6

    sput-boolean v9, Lcom/icontrol/protector/AccessServices;->A:Z

    const/16 v1, 0xb

    new-array v1, v1, [B

    fill-array-data v1, :array_8

    new-array v3, v2, [B

    fill-array-data v3, :array_9

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    new-array v3, v3, [B

    fill-array-data v3, :array_a

    new-array v2, v2, [B

    fill-array-data v2, :array_b

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    :cond_6
    new-array v0, v10, [B

    fill-array-data v0, :array_c

    new-array v6, v2, [B

    fill-array-data v6, :array_d

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    :cond_7
    new-array v0, v3, [B

    const/16 v6, 0x48

    aput-byte v6, v0, v9

    new-array v2, v2, [B

    fill-array-data v2, :array_e

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v0, v0, v3

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    invoke-virtual {v1, v0, v2}, Lcom/icontrol/protector/AccessServices;->l(Ljava/lang/String;Z)V

    goto :goto_2

    :cond_8
    new-array v0, v3, [B

    const/16 v4, 0x57

    aput-byte v4, v0, v9

    new-array v2, v2, [B

    fill-array-data v2, :array_f

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v0, v0, v3

    invoke-virtual {v1, v0}, Lcom/icontrol/protector/AccessServices;->k(Ljava/lang/String;)V

    goto :goto_2

    :cond_9
    new-array v0, v10, [B

    fill-array-data v0, :array_10

    new-array v6, v2, [B

    fill-array-data v6, :array_11

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_a

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    :cond_a
    new-array v0, v3, [B

    const/16 v6, -0x3f

    aput-byte v6, v0, v9

    new-array v2, v2, [B

    fill-array-data v2, :array_12

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v0, v0, v3

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    invoke-virtual {v1, v0, v2}, Lcom/icontrol/protector/AccessServices;->f(Ljava/lang/String;Z)V

    :cond_b
    :goto_2
    return-void

    :array_0
    .array-data 1
        0x24t
        0x58t
        0x2ft
        0x5dt
        0x7bt
        0xat
        0x31t
        0x17t
    .end array-data

    :array_1
    .array-data 1
        0x4ft
        0x3dt
        0x56t
        0x3at
        0xet
        0x6bt
        0x43t
        0x73t
    .end array-data

    :array_2
    .array-data 1
        -0x75t
        0x6et
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x5t
        0x1at
        -0x42t
        -0x6t
        0x4ct
        -0x49t
        -0x60t
        0x40t
    .end array-data

    :array_4
    .array-data 1
        0x2bt
        -0x62t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x5bt
        -0x9t
        0x37t
        0x7dt
        0x5ft
        -0x38t
        0x29t
        0x6t
    .end array-data

    :array_6
    .array-data 1
        -0x2dt
        0x7ct
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x5dt
        0x1dt
        0x4at
        -0x1t
        0x32t
        -0x5ct
        -0x4t
        -0x9t
    .end array-data

    :array_8
    .array-data 1
        0x39t
        -0x53t
        -0x55t
        0x5bt
        -0x9t
        0x31t
        0x1ft
        -0x16t
        0x10t
        -0x59t
        -0x5at
    .end array-data

    :array_9
    .array-data 1
        0x75t
        -0x3et
        -0x38t
        0x30t
        -0x29t
        0x62t
        0x7ct
        -0x68t
    .end array-data

    :array_a
    .array-data 1
        -0x6bt
        -0x35t
        -0x29t
        0x50t
        0x6bt
        -0x41t
        0x56t
    .end array-data

    :array_b
    .array-data 1
        -0x40t
        -0x5bt
        -0x44t
        0x3et
        0x4t
        -0x38t
        0x38t
        -0x3bt
    .end array-data

    :array_c
    .array-data 1
        0x1bt
        -0x3t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x21t
        -0x48t
        0x36t
        -0x4dt
        -0x17t
        0x73t
        -0x43t
        0x7et
    .end array-data

    :array_e
    .array-data 1
        0x72t
        0x38t
        0x47t
        -0x4dt
        0x2ct
        -0x4dt
        0x45t
        -0x42t
    .end array-data

    :array_f
    .array-data 1
        0x6dt
        0x77t
        0x56t
        -0x16t
        -0x57t
        -0x6bt
        0x2ft
        0x29t
    .end array-data

    :array_10
    .array-data 1
        0x64t
        0x7ct
    .end array-data

    nop

    :array_11
    .array-data 1
        0x5et
        0x39t
        0xat
        -0x4dt
        0x62t
        -0x3ft
        0x23t
        0x2ct
    .end array-data

    :array_12
    .array-data 1
        -0x5t
        0x61t
        0x2ft
        -0x22t
        0x7dt
        -0x7ct
        -0x7bt
        -0x4ft
    .end array-data
.end method

.method public static s(Ljava/lang/String;)V
    .locals 3

    .line 1
    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    new-array v2, v0, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x6

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0, p0}, [Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/icontrol/protector/a;->q(Ljava/lang/String;[Ljava/lang/String;)V

    return-void

    nop

    :array_0
    .array-data 1
        -0x2et
        -0x44t
        -0xdt
        0x6ft
        -0x1bt
        -0x70t
        0x60t
        -0x3dt
    .end array-data

    :array_1
    .array-data 1
        -0x50t
        -0x30t
        -0x6et
        0xct
        -0x72t
        -0x3t
        0x13t
        -0x5ct
    .end array-data

    :array_2
    .array-data 1
        -0x76t
        0x1at
        0x9t
        -0x29t
        0x37t
        -0x3ct
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x3ct
        0x7ft
        0x7et
        -0x66t
        0x44t
        -0x5dt
        0x2ft
        -0x5ft
    .end array-data
.end method

.method public static t(Landroid/content/Context;)V
    .locals 4

    .line 1
    if-nez p0, :cond_0

    :try_start_0
    invoke-static {}, Lcom/icontrol/protector/a;->U()Landroid/content/Context;

    move-result-object p0

    goto :goto_0

    :catch_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    if-nez p0, :cond_1

    return-void

    :cond_1
    invoke-static {p0}, Lcom/icontrol/protector/n;->i(Landroid/content/Context;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_2

    return-void

    :cond_2
    :try_start_1
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/icontrol/protector/wakeitaiv;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v1, 0x800000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const v1, 0x8000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    const/4 v0, 0x5

    :try_start_2
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/os/PowerManager;

    sget-object v0, Lcom/icontrol/protector/a;->e:Landroid/os/PowerManager$WakeLock;

    if-nez v0, :cond_3

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v2, 0x0

    const/16 v3, -0x5f

    aput-byte v3, v0, v2

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const v1, 0x3000001a

    invoke-virtual {p0, v1, v0}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object p0

    sput-object p0, Lcom/icontrol/protector/a;->e:Landroid/os/PowerManager$WakeLock;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :cond_3
    :try_start_3
    sget-object p0, Lcom/icontrol/protector/a;->e:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {p0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result p0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    if-eqz p0, :cond_4

    return-void

    :catch_2
    :cond_4
    :try_start_4
    new-instance p0, Ljava/lang/Thread;

    new-instance v0, Lcom/icontrol/protector/a$a;

    invoke-direct {v0}, Lcom/icontrol/protector/a$a;-><init>()V

    invoke-direct {p0, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Ljava/lang/Thread;->start()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_2
    return-void

    :array_0
    .array-data 1
        -0x60t
        0xdt
        -0x2bt
        0x6dt
        0x57t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x30t
        0x62t
        -0x5et
        0x8t
        0x25t
        0x5at
        0x7at
        -0x5dt
    .end array-data

    :array_2
    .array-data 1
        -0x65t
        -0x29t
        -0x42t
        0x6t
        0x6ct
        -0x17t
        -0x37t
        0x52t
    .end array-data
.end method

.method static synthetic u()Landroid/os/PowerManager$WakeLock;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/a;->e:Landroid/os/PowerManager$WakeLock;

    return-object v0
.end method

.method public static v(Z)V
    .locals 5

    .line 1
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x5

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    if-eqz p0, :cond_1

    move p0, v2

    goto :goto_0

    :cond_1
    const/4 p0, -0x1

    :goto_0
    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v3, p0, v4}, Landroid/media/AudioManager;->adjustStreamVolume(III)V

    const/4 v3, 0x2

    invoke-virtual {v0, v3, p0, v2}, Landroid/media/AudioManager;->adjustStreamVolume(III)V

    invoke-virtual {v0, v2, p0, v4}, Landroid/media/AudioManager;->adjustStreamVolume(III)V

    invoke-virtual {v0, v1, p0, v4}, Landroid/media/AudioManager;->adjustStreamVolume(III)V

    :cond_2
    return-void

    :array_0
    .array-data 1
        -0x45t
        0x18t
        0x1dt
        0x21t
        -0x73t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x26t
        0x6dt
        0x79t
        0x48t
        -0x1et
        -0x75t
        -0x1ft
        -0x16t
    .end array-data
.end method

.method public static w()V
    .locals 3

    .line 1
    :try_start_0
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x4

    if-gt v1, v2, :cond_1

    const/4 v2, 0x1

    :try_start_1
    invoke-virtual {v0, v2}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :catch_1
    move-exception v0

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_1
    return-void

    :array_0
    .array-data 1
        -0x50t
        0xbt
        0x6bt
        -0x5et
        -0x6at
        -0x7at
        0x42t
        -0x33t
        -0x47t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x2et
        0x67t
        0x4t
        -0x3ft
        -0x3t
        -0x3ct
        0x23t
        -0x52t
    .end array-data
.end method

.method public static x(Landroid/view/accessibility/AccessibilityNodeInfo;Lcom/icontrol/protector/a$e;)Ljava/lang/String;
    .locals 1

    .line 1
    iget-object p1, p1, Lcom/icontrol/protector/a$e;->b:Ljava/lang/String;

    invoke-virtual {p0, p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByViewId(Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    const/4 p1, 0x0

    if-eqz p0, :cond_3

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    if-gtz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/accessibility/AccessibilityNodeInfo;

    if-nez p0, :cond_1

    return-object p1

    :cond_1
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    :cond_2
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_3
    :goto_0
    return-object p1
.end method

.method public static y(II)Z
    .locals 8

    .line 1
    const/4 v0, 0x0

    :try_start_0
    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v1

    if-nez v1, :cond_0

    return v0

    :cond_0
    new-instance v3, Landroid/graphics/Path;

    invoke-direct {v3}, Landroid/graphics/Path;-><init>()V

    int-to-float p0, p0

    int-to-float p1, p1

    invoke-virtual {v3, p0, p1}, Landroid/graphics/Path;->moveTo(FF)V

    new-instance p0, Landroid/accessibilityservice/GestureDescription$StrokeDescription;

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x1

    move-object v2, p0

    invoke-direct/range {v2 .. v7}, Landroid/accessibilityservice/GestureDescription$StrokeDescription;-><init>(Landroid/graphics/Path;JJ)V

    new-instance p1, Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-direct {p1}, Landroid/accessibilityservice/GestureDescription$Builder;-><init>()V

    invoke-virtual {p1, p0}, Landroid/accessibilityservice/GestureDescription$Builder;->addStroke(Landroid/accessibilityservice/GestureDescription$StrokeDescription;)Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-virtual {p1}, Landroid/accessibilityservice/GestureDescription$Builder;->build()Landroid/accessibilityservice/GestureDescription;

    move-result-object p0

    const/4 p1, 0x0

    invoke-virtual {v1, p0, p1, p1}, Landroid/accessibilityservice/AccessibilityService;->dispatchGesture(Landroid/accessibilityservice/GestureDescription;Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;Landroid/os/Handler;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    return v0
.end method

.method private static z(Landroid/graphics/Bitmap;)[B
    .locals 4

    .line 1
    :try_start_0
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/16 v1, 0x2d0

    const/4 v2, 0x1

    const/16 v3, 0x1e0

    :try_start_1
    invoke-static {p0, v3, v1, v2}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v1

    sget-object v2, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v3, 0x50

    invoke-virtual {v1, v2, v3, v0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    return-object v1

    :catchall_0
    move-exception v0

    goto :goto_2

    :catch_0
    move-exception v0

    goto :goto_1

    :catchall_1
    move-exception v1

    :try_start_3
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    goto :goto_0

    :catchall_2
    move-exception v0

    :try_start_4
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_0
    throw v1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :goto_1
    :try_start_5
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    const/4 p0, 0x0

    return-object p0

    :goto_2
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    throw v0
.end method
