.class public Lcom/icontrol/protector/BootReceiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method public static synthetic a(Landroid/content/Intent;Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lcom/icontrol/protector/BootReceiver;->b(Landroid/content/Intent;Landroid/content/Context;)V

    return-void
.end method

.method private static synthetic b(Landroid/content/Intent;Landroid/content/Context;)V
    .locals 3

    .line 1
    const/16 v0, 0x24

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/hm;->a(Landroid/content/Context;)V

    const/16 p0, 0xc

    new-array p0, p0, [B

    fill-array-data p0, :array_2

    new-array v0, v1, [B

    fill-array-data v0, :array_3

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x12

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v1, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, p0, v0}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    sget-object p0, Lntidisestablish/neumonoul/floccinaucinih/ab;->P:Ljava/lang/String;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p1, p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    const-class p0, Lcom/icontrol/protector/WorkServices;

    invoke-static {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v0

    if-nez v0, :cond_2

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, p1, p0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt p0, v1, :cond_1

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/p1;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_1
    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_2
    :goto_0
    return-void

    :array_0
    .array-data 1
        -0x26t
        0x17t
        -0x26t
        -0x5dt
        -0x6t
        -0x33t
        0x60t
        -0x47t
        -0x2et
        0x17t
        -0x36t
        -0x4ct
        -0x5t
        -0x30t
        0x2at
        -0xat
        -0x28t
        0xdt
        -0x29t
        -0x42t
        -0x5t
        -0x76t
        0x46t
        -0x28t
        -0xct
        0x2dt
        -0x1ft
        -0x6et
        -0x26t
        -0x17t
        0x54t
        -0x25t
        -0x2t
        0x2dt
        -0x5t
        -0x6bt
    .end array-data

    :array_1
    .array-data 1
        -0x45t
        0x79t
        -0x42t
        -0x2ft
        -0x6bt
        -0x5ct
        0x4t
        -0x69t
    .end array-data

    :array_2
    .array-data 1
        0x7at
        -0x77t
        -0x44t
        0x21t
        -0x78t
        -0x18t
        -0x27t
        0xft
        0x43t
        -0x79t
        -0x56t
        0x2dt
    .end array-data

    :array_3
    .array-data 1
        0x37t
        -0x1at
        -0x22t
        0x48t
        -0x1ct
        -0x73t
        -0x7t
        0x5ct
    .end array-data

    :array_4
    .array-data 1
        -0x73t
        0x67t
        0x7ct
        0x4ft
        0x0t
        0x7ft
        -0x32t
        0x5ft
        -0x5bt
        0x7bt
        0x6at
        0x47t
        0x1et
        0x6et
        -0x32t
        0x63t
        -0x51t
        0x7ft
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x40t
        0x8t
        0x1et
        0x26t
        0x6ct
        0x1at
        -0x12t
        0xdt
    .end array-data
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/t5;

    invoke-direct {v1, p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/t5;-><init>(Landroid/content/Intent;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method
