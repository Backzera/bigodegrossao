.class public Lcom/icontrol/protector/StarterServices;
.super Landroid/app/Service;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 0

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    sget-object p1, Lcom/icontrol/protector/My_Configs;->Is_Store:Ljava/lang/String;

    const/4 p2, 0x1

    new-array p2, p2, [B

    const/4 p3, 0x0

    const/16 v0, 0x74

    aput-byte v0, p2, p3

    const/16 p3, 0x8

    new-array p3, p3, [B

    fill-array-data p3, :array_0

    invoke-static {p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p3

    invoke-direct {p2, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p3, Lcom/icontrol/protector/StarterServices$a;

    invoke-direct {p3, p0, p1}, Lcom/icontrol/protector/StarterServices$a;-><init>(Lcom/icontrol/protector/StarterServices;Landroid/content/Context;)V

    const-wide/16 v0, 0x3e8

    invoke-virtual {p2, p3, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    const/4 p1, 0x2

    return p1

    :array_0
    .array-data 1
        0x45t
        -0x19t
        0x5ct
        0x59t
        -0x6ct
        -0x43t
        -0x7ft
        -0x3et
    .end array-data
.end method
