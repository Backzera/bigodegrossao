.class Lcom/icontrol/protector/EngineWorker$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/EngineWorker;->onHandleIntent(Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Landroid/content/Intent;

.field final synthetic g:Lcom/icontrol/protector/EngineWorker;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/EngineWorker;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/EngineWorker$b;->g:Lcom/icontrol/protector/EngineWorker;

    iput-object p2, p0, Lcom/icontrol/protector/EngineWorker$b;->e:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/EngineWorker$b;->f:Landroid/content/Intent;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lcom/icontrol/protector/EngineWorker$b;->e:Landroid/content/Context;

    iget-object v1, p0, Lcom/icontrol/protector/EngineWorker$b;->f:Landroid/content/Intent;

    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
