.class public Lcom/icontrol/protector/WebBrowser;
.super Landroid/app/Activity;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/WebBrowser$d;,
        Lcom/icontrol/protector/WebBrowser$e;
    }
.end annotation


# static fields
.field static h:Ljava/util/ArrayList;


# instance fields
.field b:Landroid/webkit/WebView;

.field c:Ljava/lang/String;

.field d:Landroid/content/Context;

.field private e:Lntidisestablish/neumonoul/floccinaucinih/m70;

.field private f:Lntidisestablish/neumonoul/floccinaucinih/ks;

.field private g:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/icontrol/protector/WebBrowser;->h:Ljava/util/ArrayList;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/WebBrowser;->g:Z

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/webkit/WebView;)V
    .locals 2

    .line 1
    if-nez p1, :cond_0

    return-void

    :cond_0
    const/16 v0, 0x305

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lcom/icontrol/protector/WebBrowser$b;

    invoke-direct {v1, p0}, Lcom/icontrol/protector/WebBrowser$b;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, v0, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    return-void

    :array_0
    .array-data 1
        -0x16t
        0x1ct
        0x22t
        -0x32t
        -0x69t
        0x5ct
        -0x42t
        -0x62t
        -0x7t
        0x5dt
        0x6dt
        -0x32t
        -0x61t
        0x5bt
        -0x4dt
        -0x61t
        -0x59t
        0x77t
        0x5at
        -0x78t
        -0x7ct
        0x40t
        -0x44t
        -0x79t
        -0xbt
        0x12t
        0x3et
        -0x32t
        -0x6at
        0x4at
        -0x14t
        -0x40t
        -0x52t
        0x55t
        0x79t
        -0x32t
        -0x76t
        0x24t
        -0x1t
        -0x2dt
        -0xbt
        0x1bt
        0x70t
        -0x3at
        -0x30t
        0x48t
        -0x53t
        -0x6et
        -0xft
        0x18t
        0x79t
        -0x32t
        -0x76t
        0x24t
        -0x1t
        -0x2dt
        -0x44t
        0x5dt
        0x36t
        -0x64t
        -0x70t
        0x43t
        -0x46t
        -0x2dt
        -0x5ft
        0x5dt
        0x34t
        -0x7ft
        -0x6et
        0x5bt
        -0x4et
        -0x6at
        -0xet
        0x9t
        0x7et
        -0x73t
        -0x7dt
        0x4bt
        -0x42t
        -0x79t
        -0x7t
        0x38t
        0x3ct
        -0x75t
        -0x64t
        0x4bt
        -0x4ft
        -0x79t
        -0x4ct
        0x5at
        0x39t
        -0x78t
        -0x7dt
        0x4ft
        -0x4et
        -0x6at
        -0x45t
        0x54t
        0x6bt
        -0x1ct
        -0x2ft
        0xet
        -0x1t
        -0x2dt
        -0x6t
        0xft
        0x31t
        -0x7dt
        -0x6ct
        0x0t
        -0x54t
        -0x79t
        -0x1bt
        0x11t
        0x35t
        -0x40t
        -0x6bt
        0x47t
        -0x54t
        -0x7dt
        -0x10t
        0x1ct
        0x29t
        -0x32t
        -0x34t
        0xet
        -0x8t
        -0x63t
        -0xdt
        0x13t
        0x35t
        -0x37t
        -0x36t
        0x24t
        -0x1t
        -0x2dt
        -0x44t
        0x5dt
        0x34t
        -0x7ft
        -0x6et
        0x5bt
        -0x4et
        -0x6at
        -0xet
        0x9t
        0x7et
        -0x74t
        -0x62t
        0x4at
        -0x5at
        -0x23t
        -0x3t
        0xdt
        0x20t
        -0x75t
        -0x61t
        0x4at
        -0x64t
        -0x65t
        -0xbt
        0x11t
        0x34t
        -0x3at
        -0x69t
        0x5ct
        -0x42t
        -0x62t
        -0x7t
        0x54t
        0x6bt
        -0x1ct
        -0x2ft
        0xet
        -0x5et
        -0x7t
        -0x44t
        0x5dt
        0x33t
        -0x7ft
        -0x61t
        0x5dt
        -0x50t
        -0x61t
        -0x7t
        0x5dt
        0x6dt
        -0x32t
        -0x69t
        0x5ct
        -0x42t
        -0x62t
        -0x7t
        0x53t
        0x33t
        -0x7ft
        -0x61t
        0x5at
        -0x46t
        -0x63t
        -0x18t
        0x2at
        0x39t
        -0x80t
        -0x6bt
        0x41t
        -0x58t
        -0x23t
        -0x1t
        0x12t
        0x3et
        -0x63t
        -0x62t
        0x42t
        -0x46t
        -0x38t
        -0x6at
        0x5dt
        0x70t
        -0x68t
        -0x70t
        0x5ct
        -0x1t
        -0x66t
        -0xet
        0xdt
        0x25t
        -0x66t
        -0x7et
        0xet
        -0x1et
        -0x2dt
        -0x8t
        0x12t
        0x33t
        -0x65t
        -0x64t
        0x4bt
        -0x4ft
        -0x79t
        -0x4et
        0xct
        0x25t
        -0x75t
        -0x7dt
        0x57t
        -0x74t
        -0x6at
        -0x10t
        0x18t
        0x33t
        -0x66t
        -0x62t
        0x5ct
        -0x62t
        -0x61t
        -0x10t
        0x55t
        0x77t
        -0x79t
        -0x61t
        0x5et
        -0x56t
        -0x79t
        -0x45t
        0x54t
        0x6bt
        -0x1ct
        -0x2ft
        0xet
        -0x57t
        -0x6et
        -0x12t
        0x5dt
        0x27t
        -0x75t
        -0x6dt
        0x5dt
        -0x4at
        -0x79t
        -0x7t
        0x31t
        0x39t
        -0x80t
        -0x66t
        0xet
        -0x1et
        -0x2dt
        -0x15t
        0x14t
        0x3et
        -0x76t
        -0x62t
        0x59t
        -0xft
        -0x61t
        -0xdt
        0x1et
        0x31t
        -0x66t
        -0x68t
        0x41t
        -0x4ft
        -0x23t
        -0xct
        0x12t
        0x23t
        -0x66t
        -0x61t
        0x4ft
        -0x4et
        -0x6at
        -0x59t
        0x77t
        0x70t
        -0x32t
        -0x79t
        0x4ft
        -0x53t
        -0x2dt
        -0x12t
        0x18t
        0x23t
        -0x65t
        -0x63t
        0x5at
        -0x1t
        -0x32t
        -0x44t
        0x26t
        0xdt
        -0x2bt
        -0x5t
        0x24t
        -0x1t
        -0x2dt
        -0xbt
        0x13t
        0x20t
        -0x65t
        -0x7bt
        0x5dt
        -0xft
        -0x6bt
        -0xdt
        0xft
        0x15t
        -0x71t
        -0x6et
        0x46t
        -0x9t
        -0x6bt
        -0x17t
        0x13t
        0x33t
        -0x66t
        -0x68t
        0x41t
        -0x4ft
        -0x25t
        -0xbt
        0x13t
        0x20t
        -0x65t
        -0x7bt
        0x7t
        -0x1t
        -0x78t
        -0x6at
        0x5dt
        0x70t
        -0x32t
        -0x2ft
        0x58t
        -0x42t
        -0x7ft
        -0x44t
        0x9t
        0x29t
        -0x62t
        -0x6ct
        0xet
        -0x1et
        -0x2dt
        -0xbt
        0x13t
        0x20t
        -0x65t
        -0x7bt
        0x0t
        -0x48t
        -0x6at
        -0x18t
        0x3ct
        0x24t
        -0x66t
        -0x7dt
        0x47t
        -0x43t
        -0x7at
        -0x18t
        0x18t
        0x78t
        -0x37t
        -0x7bt
        0x57t
        -0x51t
        -0x6at
        -0x45t
        0x54t
        0x6bt
        -0x1ct
        -0x2ft
        0xet
        -0x1t
        -0x2dt
        -0x16t
        0x1ct
        0x22t
        -0x32t
        -0x79t
        0x4ft
        -0x4dt
        -0x7at
        -0x7t
        0x5dt
        0x6dt
        -0x32t
        -0x68t
        0x40t
        -0x51t
        -0x7at
        -0x18t
        0x53t
        0x26t
        -0x71t
        -0x63t
        0x5bt
        -0x46t
        -0x38t
        -0x6at
        0x77t
        0x70t
        -0x32t
        -0x2ft
        0xet
        -0x4at
        -0x6bt
        -0x44t
        0x55t
        0x26t
        -0x71t
        -0x63t
        0x5bt
        -0x46t
        -0x2dt
        -0x43t
        0x40t
        0x6dt
        -0x32t
        -0x2dt
        0xct
        -0x1t
        -0x2bt
        -0x46t
        0x5dt
        0x26t
        -0x71t
        -0x63t
        0x5bt
        -0x46t
        -0x2dt
        -0x43t
        0x40t
        0x6dt
        -0x32t
        -0x61t
        0x5bt
        -0x4dt
        -0x61t
        -0x44t
        0x5bt
        0x76t
        -0x32t
        -0x7bt
        0x57t
        -0x51t
        -0x6at
        -0x44t
        0x5ct
        0x6dt
        -0x2dt
        -0x2ft
        0xct
        -0x49t
        -0x66t
        -0x8t
        0x19t
        0x35t
        -0x80t
        -0x2dt
        0xet
        -0x7t
        -0x2bt
        -0x44t
        0x9t
        0x29t
        -0x62t
        -0x6ct
        0xet
        -0x2t
        -0x32t
        -0x5ft
        0x5dt
        0x72t
        -0x73t
        -0x67t
        0x4bt
        -0x44t
        -0x68t
        -0x2t
        0x12t
        0x28t
        -0x34t
        -0x28t
        0xet
        -0x5ct
        -0x7t
        -0x44t
        0x5dt
        0x70t
        -0x32t
        -0x2ft
        0xet
        -0x57t
        -0x6et
        -0x12t
        0x5dt
        0x34t
        -0x71t
        -0x7bt
        0x4ft
        -0x1t
        -0x32t
        -0x44t
        0x6t
        0x5at
        -0x32t
        -0x2ft
        0xet
        -0x1t
        -0x2dt
        -0x44t
        0x5dt
        0x70t
        -0x37t
        -0x7bt
        0x57t
        -0x51t
        -0x6at
        -0x45t
        0x47t
        0x70t
        -0x66t
        -0x78t
        0x5et
        -0x46t
        -0x21t
        -0x6at
        0x5dt
        0x70t
        -0x32t
        -0x2ft
        0xet
        -0x1t
        -0x2dt
        -0x44t
        0x5at
        0x26t
        -0x71t
        -0x63t
        0x5bt
        -0x46t
        -0x2ct
        -0x5at
        0x5dt
        0x26t
        -0x71t
        -0x63t
        0x5bt
        -0x46t
        -0x21t
        -0x6at
        0x5dt
        0x70t
        -0x32t
        -0x2ft
        0xet
        -0x1t
        -0x2dt
        -0x44t
        0x5at
        0x34t
        -0x71t
        -0x7bt
        0x4bt
        -0x8t
        -0x37t
        -0x44t
        0x13t
        0x35t
        -0x67t
        -0x2ft
        0x6at
        -0x42t
        -0x79t
        -0x7t
        0x55t
        0x79t
        -0x40t
        -0x7bt
        0x41t
        -0x6dt
        -0x64t
        -0x1t
        0x1ct
        0x3ct
        -0x75t
        -0x5et
        0x5at
        -0x53t
        -0x66t
        -0xet
        0x1at
        0x78t
        -0x39t
        -0x5t
        0xet
        -0x1t
        -0x2dt
        -0x44t
        0x5dt
        0x70t
        -0x6dt
        -0x36t
        0x24t
        -0x1t
        -0x2dt
        -0x44t
        0x5dt
        0x70t
        -0x32t
        -0x7dt
        0x4bt
        -0x54t
        -0x7at
        -0x10t
        0x9t
        0x7et
        -0x62t
        -0x7ct
        0x5dt
        -0x49t
        -0x25t
        -0x8t
        0x1ct
        0x24t
        -0x71t
        -0x28t
        0x15t
        -0x2bt
        -0x2dt
        -0x44t
        0x5dt
        0x70t
        -0x6dt
        -0x5t
        0xet
        -0x1t
        -0x72t
        -0x4bt
        0x46t
        0x5at
        -0x1ct
        -0x2ft
        0xet
        -0x53t
        -0x6at
        -0x18t
        0x8t
        0x22t
        -0x80t
        -0x2ft
        0x64t
        -0x74t
        -0x44t
        -0x2et
        0x53t
        0x23t
        -0x66t
        -0x7dt
        0x47t
        -0x4ft
        -0x6ct
        -0xbt
        0x1bt
        0x29t
        -0x3at
        -0x76t
        0x24t
        -0x1t
        -0x2dt
        -0x44t
        0x5dt
        0x27t
        -0x75t
        -0x6dt
        0x5dt
        -0x4at
        -0x79t
        -0x7t
        0x47t
        0x70t
        -0x67t
        -0x6ct
        0x4ct
        -0x54t
        -0x66t
        -0x18t
        0x18t
        0x1ct
        -0x79t
        -0x61t
        0x45t
        -0xdt
        -0x7t
        -0x44t
        0x5dt
        0x70t
        -0x32t
        -0x68t
        0x40t
        -0x51t
        -0x7at
        -0x18t
        0xet
        0x6at
        -0x32t
        -0x7dt
        0x4bt
        -0x54t
        -0x7at
        -0x10t
        0x9t
        0x5at
        -0x32t
        -0x2ft
        0x53t
        -0xat
        -0x38t
        -0x6at
        0x0t
        0x5at
        -0x1ct
        -0x6at
        0x4at
        -0x14t
        -0x40t
        -0x52t
        0x55t
        0x79t
        -0x2bt
        -0x5t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x64t
        0x7dt
        0x50t
        -0x12t
        -0xft
        0x2et
        -0x21t
        -0xdt
    .end array-data
.end method

.method private b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-nez v0, :cond_0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/WebBrowser;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    new-instance v2, Lcom/icontrol/protector/WebBrowser$c;

    invoke-direct {v2, p0, p1, p2}, Lcom/icontrol/protector/WebBrowser$c;-><init>(Lcom/icontrol/protector/WebBrowser;Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v1, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    move-result-object p1

    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    goto :goto_0

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/WebBrowser;->h(Landroid/content/Context;Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method static synthetic c(Lcom/icontrol/protector/WebBrowser;Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/WebBrowser;->b(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic d(Lcom/icontrol/protector/WebBrowser;Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/WebBrowser;->h(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic e(Lcom/icontrol/protector/WebBrowser;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-object p1
.end method

.method static synthetic f(Lcom/icontrol/protector/WebBrowser;)Lntidisestablish/neumonoul/floccinaucinih/ks;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/WebBrowser;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    return-object p0
.end method

.method private h(Landroid/content/Context;Ljava/lang/String;)V
    .locals 10

    .line 1
    const/4 v0, 0x2

    const/16 v1, 0x3e8

    const/16 v2, 0x8

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v3, v2, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {p1, v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v4, 0x0

    invoke-static {p1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0xa

    if-eqz v0, :cond_1

    if-nez v3, :cond_0

    goto/16 :goto_0

    :cond_0
    sget-object v5, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    const/4 v6, 0x4

    new-array v7, v6, [B

    fill-array-data v7, :array_4

    new-array v8, v2, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {p1, v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x3

    new-array v8, v7, [B

    fill-array-data v8, :array_6

    new-array v9, v2, [B

    fill-array-data v9, :array_7

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v7, [B

    fill-array-data v3, :array_8

    new-array v8, v2, [B

    fill-array-data v8, :array_9

    invoke-static {v3, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v2, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v3, v4, [B

    fill-array-data v3, :array_c

    new-array v4, v2, [B

    fill-array-data v4, :array_d

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v6, [B

    fill-array-data v0, :array_e

    new-array v3, v2, [B

    fill-array-data v3, :array_f

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v3, v7, [B

    fill-array-data v3, :array_10

    new-array v4, v2, [B

    fill-array-data v4, :array_11

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v7, [B

    fill-array-data v0, :array_12

    new-array v3, v2, [B

    fill-array-data v3, :array_13

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v7, [B

    fill-array-data p2, :array_14

    new-array v0, v2, [B

    fill-array-data v0, :array_15

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v5, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z

    goto :goto_2

    :catch_0
    move-exception p1

    goto :goto_1

    :cond_1
    :goto_0
    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    new-array p2, v4, [B

    fill-array-data p2, :array_16

    new-array v0, v2, [B

    fill-array-data v0, :array_17

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, v1, p2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :goto_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz p1, :cond_2

    const/16 p2, 0x1c

    new-array p2, p2, [B

    fill-array-data p2, :array_18

    new-array v0, v2, [B

    fill-array-data v0, :array_19

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, v1, p2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    :cond_2
    :goto_2
    return-void

    nop

    :array_0
    .array-data 1
        -0xbt
        0x68t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x44t
        0x2ct
        -0x40t
        -0x57t
        0x7at
        0x41t
        -0x4dt
        -0x2ft
    .end array-data

    :array_2
    .array-data 1
        -0x6dt
        -0x2t
        0x43t
        -0x8t
        -0x9t
        -0x43t
        0x31t
        0x7t
    .end array-data

    :array_3
    .array-data 1
        -0x29t
        -0x65t
        0x35t
        -0x6ft
        -0x6ct
        -0x28t
        0x58t
        0x63t
    .end array-data

    :array_4
    .array-data 1
        0x2dt
        0x52t
        -0x5ct
        0x19t
    .end array-data

    :array_5
    .array-data 1
        0x43t
        0x27t
        -0x38t
        0x75t
        0x35t
        0x3ct
        -0x60t
        0xat
    .end array-data

    :array_6
    .array-data 1
        0x69t
        0x63t
        0x44t
    .end array-data

    :array_7
    .array-data 1
        0x0t
        0x7t
        0x22t
        -0x4dt
        0x11t
        0x4dt
        -0x35t
        -0x7t
    .end array-data

    :array_8
    .array-data 1
        -0x3t
        -0x1ct
        -0x8t
    .end array-data

    :array_9
    .array-data 1
        -0x73t
        -0x73t
        -0x64t
        -0x35t
        -0x6bt
        0x10t
        0x1ct
        0x1ct
    .end array-data

    :array_a
    .array-data 1
        -0x1ct
        -0x45t
        0x75t
        0x3bt
        -0x2at
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x73t
        -0x31t
        0xct
        0x4bt
        -0x4dt
        0xft
        -0x27t
        -0x13t
    .end array-data

    :array_c
    .array-data 1
        0x2ct
        0x44t
        -0x43t
        0x44t
        0x43t
        0x1at
        0x6bt
        -0x77t
        0x11t
        0x5ct
    .end array-data

    nop

    :array_d
    .array-data 1
        0x7ft
        0x28t
        -0x31t
        0x1bt
        0x20t
        0x76t
        0x2t
        -0x14t
    .end array-data

    :array_e
    .array-data 1
        -0x66t
        0x76t
        -0x3ct
        0x73t
    .end array-data

    :array_f
    .array-data 1
        -0x17t
        0x3t
        -0x5at
        0x10t
        0x19t
        -0x62t
        0x75t
        0x15t
    .end array-data

    :array_10
    .array-data 1
        -0x4ct
        0x7t
        -0x7bt
    .end array-data

    :array_11
    .array-data 1
        -0x27t
        0x74t
        -0x1et
        0x1ct
        -0x61t
        -0x71t
        -0x2t
        0x25t
    .end array-data

    :array_12
    .array-data 1
        0x65t
        0x7dt
        -0x57t
    .end array-data

    :array_13
    .array-data 1
        0x8t
        0xet
        -0x32t
        -0x1ft
        0x1dt
        -0x3bt
        -0x7at
        -0x15t
    .end array-data

    :array_14
    .array-data 1
        -0x80t
        0x6dt
        -0x3t
    .end array-data

    :array_15
    .array-data 1
        -0x1dt
        0x4t
        -0x73t
        -0x38t
        0x2bt
        -0x2et
        0x69t
        0x71t
    .end array-data

    :array_16
    .array-data 1
        -0x43t
        -0x58t
        -0x8t
        0x17t
        0x3et
        0x71t
        0x2at
        -0x4ct
        -0x47t
        -0x7bt
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x10t
        -0x3ft
        -0x75t
        0x64t
        0x57t
        0x1ft
        0x4dt
        -0x6ct
    .end array-data

    :array_18
    .array-data 1
        0x55t
        0x1ft
        0x3t
        0x5ct
        -0x3dt
        0x4t
        0x51t
        0x2et
        0x62t
        0x4t
        0x1ft
        0x54t
        -0x6ft
        0x49t
        0x50t
        0x28t
        0x63t
        0xct
        0x16t
        0x56t
        -0x6ft
        0x57t
        0x50t
        0x35t
        0x74t
        0x4t
        0x1ft
        0x54t
    .end array-data

    :array_19
    .array-data 1
        0x10t
        0x6dt
        0x71t
        0x33t
        -0x4ft
        0x24t
        0x35t
        0x5bt
    .end array-data
.end method

.method private i(Landroid/content/Context;Landroid/webkit/WebView;)V
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->V:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    new-instance v0, Lcom/icontrol/protector/WebBrowser$a;

    invoke-direct {v0, p0, p1, p2}, Lcom/icontrol/protector/WebBrowser$a;-><init>(Lcom/icontrol/protector/WebBrowser;Landroid/content/Context;Landroid/webkit/WebView;)V

    new-instance p1, Ljava/lang/Thread;

    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return-void
.end method


# virtual methods
.method public g()V
    .locals 5

    .line 1
    const/16 v0, 0x8

    :try_start_0
    iget-boolean v1, p0, Lcom/icontrol/protector/WebBrowser;->g:Z

    if-nez v1, :cond_0

    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/icontrol/protector/WebBrowser;->g:Z

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v2, 0x7

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    new-array v3, v0, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0xc

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v4, v0, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v2, v3}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    iget-object v1, p0, Lcom/icontrol/protector/WebBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    const/16 v3, 0x11

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v0, v0, [B

    fill-array-data v0, :array_5

    invoke-static {v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v3, 0x3e8

    invoke-interface {v1, v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    iput-object v2, p0, Lcom/icontrol/protector/WebBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    :cond_1
    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->a()V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->l()Lntidisestablish/neumonoul/floccinaucinih/da;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/da;->a()V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    iput-object v2, p0, Lcom/icontrol/protector/WebBrowser;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    :cond_2
    return-void

    :array_0
    .array-data 1
        -0x6ft
        -0x23t
        -0x9t
        -0x7dt
        -0x4ft
        0x3et
        -0x22t
    .end array-data

    :array_1
    .array-data 1
        -0x2dt
        -0x51t
        -0x68t
        -0xct
        -0x3et
        0x5bt
        -0x54t
        -0x1ft
    .end array-data

    :array_2
    .array-data 1
        0x51t
        -0x15t
        -0x50t
        0x7ct
        0x55t
        0x79t
        -0x72t
        0x4dt
        0x6at
        -0x12t
        -0x53t
        0x37t
    .end array-data

    :array_3
    .array-data 1
        0x12t
        -0x79t
        -0x27t
        0x19t
        0x3bt
        0xdt
        -0x52t
        0x8t
    .end array-data

    :array_4
    .array-data 1
        0x2at
        0x4t
        0x74t
        -0x12t
        0x6et
        0x16t
        -0x7t
        0x45t
        0x3et
        0xdt
        0x79t
        -0x32t
        0x68t
        0x1bt
        -0xbt
        0x0t
        0x1dt
    .end array-data

    nop

    :array_5
    .array-data 1
        0x69t
        0x68t
        0x1bt
        -0x63t
        0x7t
        0x78t
        -0x62t
        0x65t
    .end array-data
.end method

.method public onBackPressed()V
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V

    goto :goto_0

    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    :goto_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 13

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser;->d:Landroid/content/Context;

    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/icontrol/protector/WebBrowser;->g:Z

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v1, 0x3

    :try_start_0
    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    new-array v4, v3, [B

    fill-array-data v4, :array_2

    new-array v5, v2, [B

    fill-array-data v5, :array_3

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    const/4 v5, 0x0

    const/4 v6, 0x5

    :try_start_1
    new-array v7, v3, [B

    fill-array-data v7, :array_4

    new-array v8, v2, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v7
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const-string v8, " "

    if-eqz v7, :cond_0

    :try_start_2
    new-array v3, v3, [B

    fill-array-data v3, :array_6

    new-array v7, v2, [B

    fill-array-data v7, :array_7

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getByteArrayExtra(Ljava/lang/String;)[B

    move-result-object v3

    array-length v7, v3

    invoke-static {v3, p1, v7}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v3

    new-instance v7, Landroid/app/ActivityManager$TaskDescription;

    invoke-direct {v7, v8, v3}, Landroid/app/ActivityManager$TaskDescription;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;)V

    invoke-virtual {p0, v7}, Landroid/app/Activity;->setTaskDescription(Landroid/app/ActivityManager$TaskDescription;)V

    new-array v3, v6, [B

    fill-array-data v3, :array_8

    new-array v7, v2, [B

    fill-array-data v7, :array_9

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setTitle(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_0
    const/16 v0, 0x12

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v2, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/icontrol/protector/n;->P(Ljava/lang/String;Landroid/content/pm/PackageManager;)Z

    move-result v3

    if-nez v3, :cond_1

    const/16 v0, 0x13

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v3, v2, [B

    fill-array-data v3, :array_d

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/icontrol/protector/n;->P(Ljava/lang/String;Landroid/content/pm/PackageManager;)Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/n;->H(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/icontrol/protector/n;->P(Ljava/lang/String;Landroid/content/pm/PackageManager;)Z

    move-result v3

    if-nez v3, :cond_1

    move-object v0, v5

    :cond_1
    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-virtual {v3, v0, p1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/content/pm/PackageManager;->getApplicationIcon(Landroid/content/pm/ApplicationInfo;)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    invoke-virtual {v3, v0}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setTitle(Ljava/lang/CharSequence;)V

    invoke-static {v7}, Lcom/icontrol/protector/n;->v(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;

    move-result-object v0

    new-instance v3, Landroid/app/ActivityManager$TaskDescription;

    invoke-direct {v3, v8, v0}, Landroid/app/ActivityManager$TaskDescription;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;)V

    invoke-virtual {p0, v3}, Landroid/app/Activity;->setTaskDescription(Landroid/app/ActivityManager$TaskDescription;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    :cond_2
    :goto_0
    :try_start_3
    new-instance v0, Landroid/webkit/WebView;

    invoke-direct {v0, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setLoadsImagesAutomatically(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    :try_start_4
    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/CookieManager;->setAcceptCookie(Z)V

    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v0

    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0, v7, v3}, Landroid/webkit/CookieManager;->setAcceptThirdPartyCookies(Landroid/webkit/WebView;Z)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    :catch_1
    :try_start_5
    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0, p1}, Landroid/webkit/WebView;->setScrollBarStyle(I)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setCacheMode(I)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    const/4 v0, -0x1

    :try_start_6
    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    const/4 v8, 0x2

    invoke-virtual {v7, v8, v5}, Landroid/webkit/WebView;->setLayerType(ILandroid/graphics/Paint;)V

    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v7}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v7

    sget-object v8, Landroid/webkit/WebSettings$PluginState;->ON:Landroid/webkit/WebSettings$PluginState;

    invoke-virtual {v7, v8}, Landroid/webkit/WebSettings;->setPluginState(Landroid/webkit/WebSettings$PluginState;)V

    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v7}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v7

    sget-object v8, Landroid/webkit/WebSettings$RenderPriority;->HIGH:Landroid/webkit/WebSettings$RenderPriority;

    invoke-virtual {v7, v8}, Landroid/webkit/WebSettings;->setRenderPriority(Landroid/webkit/WebSettings$RenderPriority;)V

    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v7, v0}, Landroid/webkit/WebView;->setBackgroundColor(I)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    :catch_2
    :try_start_7
    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v7}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v7

    invoke-virtual {v7, p1}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v7}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v7

    invoke-virtual {v7}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    move-result-object v7

    iget-object v8, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v8}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v8

    invoke-virtual {v8, v7}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    new-instance v8, Lcom/icontrol/protector/WebBrowser$d;

    invoke-direct {v8, p0}, Lcom/icontrol/protector/WebBrowser$d;-><init>(Lcom/icontrol/protector/WebBrowser;)V

    invoke-virtual {v7, v8}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    new-instance v8, Lcom/icontrol/protector/WebBrowser$e;

    invoke-direct {v8, p0, v5}, Lcom/icontrol/protector/WebBrowser$e;-><init>(Lcom/icontrol/protector/WebBrowser;Lcom/icontrol/protector/WebBrowser$a;)V

    invoke-virtual {v7, v8}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/16 v7, 0x66

    if-eq v5, v7, :cond_4

    const/16 v7, 0x75

    if-eq v5, v7, :cond_3

    goto :goto_1

    :cond_3
    new-array v5, v3, [B

    const/16 v7, -0x39

    aput-byte v7, v5, p1

    new-array v7, v2, [B

    fill-array-data v7, :array_e

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    move v0, p1

    goto :goto_1

    :cond_4
    new-array v5, v3, [B

    const/16 v7, 0x3f

    aput-byte v7, v5, p1

    new-array v7, v2, [B

    fill-array-data v7, :array_f

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    move v0, v3

    :cond_5
    :goto_1
    if-eqz v0, :cond_7

    if-eq v0, v3, :cond_6

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_6
    new-instance v9, Ljava/lang/String;

    invoke-static {v1, p1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    new-array v0, v6, [B

    fill-array-data v0, :array_10

    new-array v1, v2, [B

    fill-array-data v1, :array_11

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v9, p1, v0}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    iget-object v7, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    const/4 v8, 0x0

    const/16 p1, 0x9

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v2, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    new-array p1, v6, [B

    fill-array-data p1, :array_14

    new-array v0, v2, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    const/4 v12, 0x0

    invoke-virtual/range {v7 .. v12}, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    goto :goto_3

    :cond_7
    iput-object v1, p0, Lcom/icontrol/protector/WebBrowser;->c:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    new-array v0, v2, [B

    fill-array-data v0, :array_16

    new-array v3, v2, [B

    fill-array-data v3, :array_17

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_8

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x7

    new-array v3, v0, [B

    fill-array-data v3, :array_18

    new-array v4, v2, [B

    fill-array-data v4, :array_19

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_8

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    new-array v0, v0, [B

    fill-array-data v0, :array_1a

    new-array v2, v2, [B

    fill-array-data v2, :array_1b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_8
    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    goto :goto_2

    :goto_3
    new-instance p1, Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;-><init>()V

    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser;->b:Landroid/webkit/WebView;

    invoke-direct {p0, p1, v0}, Lcom/icontrol/protector/WebBrowser;->i(Landroid/content/Context;Landroid/webkit/WebView;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    :catch_3
    return-void

    :catch_4
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    nop

    :array_0
    .array-data 1
        0x5at
        -0x53t
        0x34t
    .end array-data

    :array_1
    .array-data 1
        0x31t
        -0x38t
        0x4dt
        0x25t
        -0x17t
        0x29t
        -0x5dt
        -0x50t
    .end array-data

    :array_2
    .array-data 1
        -0x19t
        -0x9t
        0xdt
        -0x7ft
    .end array-data

    :array_3
    .array-data 1
        -0x6dt
        -0x72t
        0x7dt
        -0x1ct
        -0x4t
        -0x4at
        0x6ft
        0x63t
    .end array-data

    :array_4
    .array-data 1
        0x6ct
        0x15t
        0xet
        -0x80t
    .end array-data

    :array_5
    .array-data 1
        0x5t
        0x76t
        0x61t
        -0x12t
        0x3at
        -0x24t
        -0x19t
        0x12t
    .end array-data

    :array_6
    .array-data 1
        -0x75t
        -0x2et
        0x37t
        -0x4dt
    .end array-data

    :array_7
    .array-data 1
        -0x1et
        -0x4ft
        0x58t
        -0x23t
        -0x6dt
        -0x36t
        -0x5ct
        0x50t
    .end array-data

    :array_8
    .array-data 1
        0x5bt
        -0x12t
        -0x1bt
        0x3et
        -0x76t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x37t
        -0x71t
        -0x79t
        0x5bt
        -0x1at
        -0x3ft
        0xat
        -0x4bt
    .end array-data

    :array_a
    .array-data 1
        -0x7t
        0x33t
        -0x66t
        -0x39t
        0x33t
        0x45t
        -0x61t
        0x45t
        -0xbt
        0x35t
        -0x6dt
        -0x39t
        0x31t
        0x43t
        -0x77t
        0x58t
        -0x9t
        0x39t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x66t
        0x5ct
        -0x9t
        -0x17t
        0x52t
        0x2bt
        -0x5t
        0x37t
    .end array-data

    :array_c
    .array-data 1
        -0x43t
        -0x5ct
        -0x5bt
        0x6t
        0x3t
        0x77t
        -0x17t
        0x10t
        -0x4ft
        -0x5et
        -0x54t
        0x6t
        0x14t
        0x7ct
        -0x1dt
        0x6t
        -0x49t
        -0x5bt
        -0x51t
    .end array-data

    :array_d
    .array-data 1
        -0x22t
        -0x35t
        -0x38t
        0x28t
        0x62t
        0x19t
        -0x73t
        0x62t
    .end array-data

    :array_e
    .array-data 1
        -0x4et
        0x1bt
        -0x26t
        -0x61t
        0x4at
        0x6ct
        -0x3ct
        0x75t
    .end array-data

    :array_f
    .array-data 1
        0x59t
        -0x73t
        -0x1ct
        -0x50t
        0x79t
        -0xft
        0x5t
        0x2at
    .end array-data

    :array_10
    .array-data 1
        0x5bt
        -0x59t
        -0xat
        -0x25t
        -0x7ft
    .end array-data

    nop

    :array_11
    .array-data 1
        0xet
        -0xdt
        -0x50t
        -0xat
        -0x47t
        -0x65t
        0x10t
        -0x7t
    .end array-data

    :array_12
    .array-data 1
        0x77t
        0x55t
        0x71t
        -0x3et
        0x39t
        0xbt
        -0x42t
        -0x63t
        0x6ft
    .end array-data

    nop

    :array_13
    .array-data 1
        0x3t
        0x30t
        0x9t
        -0x4at
        0x16t
        0x63t
        -0x36t
        -0x10t
    .end array-data

    :array_14
    .array-data 1
        0x12t
        -0x5dt
        0x54t
        0x7at
        -0x6bt
    .end array-data

    nop

    :array_15
    .array-data 1
        0x47t
        -0x9t
        0x12t
        0x57t
        -0x53t
        -0x15t
        -0xct
        0x34t
    .end array-data

    :array_16
    .array-data 1
        0x70t
        -0x56t
        -0x62t
        0x68t
        -0x4bt
        0x77t
        0x78t
        -0x65t
    .end array-data

    :array_17
    .array-data 1
        0x18t
        -0x22t
        -0x16t
        0x18t
        -0x3at
        0x4dt
        0x57t
        -0x4ct
    .end array-data

    :array_18
    .array-data 1
        0x6bt
        0x49t
        -0x1t
        0x1at
        -0x28t
        0x2t
        -0x3at
    .end array-data

    :array_19
    .array-data 1
        0x3t
        0x3dt
        -0x75t
        0x6at
        -0x1et
        0x2dt
        -0x17t
        -0x23t
    .end array-data

    :array_1a
    .array-data 1
        -0xbt
        -0x7bt
        -0x7t
        -0x35t
        0x42t
        -0x1ft
        -0x50t
    .end array-data

    :array_1b
    .array-data 1
        -0x63t
        -0xft
        -0x73t
        -0x45t
        0x78t
        -0x32t
        -0x61t
        -0x71t
    .end array-data
.end method

.method public onDestroy()V
    .locals 3

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->V:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-virtual {p0}, Lcom/icontrol/protector/WebBrowser;->g()V

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 0

    const/4 p2, 0x3

    if-eq p1, p2, :cond_1

    const/4 p2, 0x4

    if-eq p1, p2, :cond_1

    const/16 p2, 0x52

    if-ne p1, p2, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method

.method protected onStop()V
    .locals 3

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->V:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-virtual {p0}, Lcom/icontrol/protector/WebBrowser;->g()V

    return-void
.end method
