.class public abstract Lcom/icontrol/protector/e;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method private static a(Ljava/io/File;Ljava/util/HashSet;Lcom/icontrol/protector/d$b;)V
    .locals 4

    .line 1
    new-instance v0, Lcom/icontrol/protector/d;

    const/4 v1, 0x1

    invoke-direct {v0, p2, v1}, Lcom/icontrol/protector/d;-><init>(Lcom/icontrol/protector/d$b;Z)V

    invoke-virtual {p0, v0}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object p0

    if-eqz p0, :cond_2

    array-length v0, p0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_2

    aget-object v2, p0, v1

    invoke-virtual {v2}, Ljava/io/File;->isFile()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    invoke-virtual {v2}, Ljava/io/File;->isDirectory()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-static {v2, p1, p2}, Lcom/icontrol/protector/e;->a(Ljava/io/File;Ljava/util/HashSet;Lcom/icontrol/protector/d$b;)V

    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public static b(Landroid/content/Context;Lcom/icontrol/protector/d$b;Ljava/io/File;)[Ljava/lang/String;
    .locals 7

    .line 1
    const/4 p0, 0x7

    const/4 v0, 0x2

    const/16 v1, 0x8

    :try_start_0
    invoke-virtual {p2}, Ljava/io/File;->exists()Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_3

    invoke-virtual {p2}, Ljava/io/File;->isDirectory()Z

    move-result v2

    if-eqz v2, :cond_3

    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    invoke-static {p2, v2, p1}, Lcom/icontrol/protector/e;->a(Ljava/io/File;Ljava/util/HashSet;Lcom/icontrol/protector/d$b;)V

    invoke-virtual {v2}, Ljava/util/HashSet;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_2

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->length()I

    move-result v5

    if-lez v5, :cond_0

    const/4 v5, 0x5

    new-array v5, v5, [B

    fill-array-data v5, :array_0

    new-array v6, v1, [B

    fill-array-data v6, :array_1

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :catch_0
    move-exception p1

    goto/16 :goto_2

    :cond_0
    :goto_1
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_1
    new-array p2, v0, [Ljava/lang/String;

    new-array v2, v3, [B

    const/16 v5, -0x51

    aput-byte v5, v2, v4

    new-array v5, v1, [B

    fill-array-data v5, :array_2

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, p2, v4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    aput-object p1, p2, v3

    return-object p2

    :cond_2
    new-array p2, v0, [Ljava/lang/String;

    new-array v2, v0, [B

    fill-array-data v2, :array_3

    new-array v5, v1, [B

    fill-array-data v5, :array_4

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, p2, v4

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    new-array v4, v4, [B

    fill-array-data v4, :array_5

    new-array v5, v1, [B

    fill-array-data v5, :array_6

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p1, p0, [B

    fill-array-data p1, :array_7

    new-array v4, v1, [B

    fill-array-data v4, :array_8

    invoke-static {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    aput-object p1, p2, v3

    return-object p2

    :cond_3
    new-array p1, v0, [Ljava/lang/String;

    new-array p2, v0, [B

    fill-array-data p2, :array_9

    new-array v2, v1, [B

    fill-array-data v2, :array_a

    invoke-static {p2, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    aput-object p2, p1, v4

    const/16 p2, 0x2f

    new-array p2, p2, [B

    fill-array-data p2, :array_b

    new-array v2, v1, [B

    fill-array-data v2, :array_c

    invoke-static {p2, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    aput-object p2, p1, v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :goto_2
    new-array p2, v0, [B

    fill-array-data p2, :array_d

    new-array v0, v1, [B

    fill-array-data v0, :array_e

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    new-array p0, p0, [B

    fill-array-data p0, :array_f

    new-array v1, v1, [B

    fill-array-data v1, :array_10

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    filled-new-array {p2, p0}, [Ljava/lang/String;

    move-result-object p0

    return-object p0

    :array_0
    .array-data 1
        -0x28t
        0x5ft
        0x32t
        0x3ft
        -0xdt
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x1ct
        0x75t
        0x62t
        0x15t
        -0x33t
        0x2t
        -0x49t
        -0x2et
    .end array-data

    :array_2
    .array-data 1
        -0x62t
        -0x19t
        0x3ft
        0x64t
        -0x1et
        0x1t
        -0x74t
        -0x2et
    .end array-data

    :array_3
    .array-data 1
        -0x53t
        -0x26t
    .end array-data

    nop

    :array_4
    .array-data 1
        -0x80t
        -0x15t
        0x67t
        0x25t
        0x8t
        -0x7ft
        -0x13t
        0xbt
    .end array-data

    :array_5
    .array-data 1
        -0x3et
        0x1t
        -0x5t
    .end array-data

    :array_6
    .array-data 1
        -0x74t
        0x6et
        -0x25t
        0x63t
        -0x68t
        -0x1ft
        -0x10t
        -0x1et
    .end array-data

    :array_7
    .array-data 1
        0x63t
        0x3bt
        -0x59t
        0x46t
        -0xdt
        0x72t
        -0x23t
    .end array-data

    :array_8
    .array-data 1
        0x43t
        0x5dt
        -0x38t
        0x33t
        -0x63t
        0x16t
        -0xdt
        -0x60t
    .end array-data

    :array_9
    .array-data 1
        -0xft
        -0x4ft
    .end array-data

    nop

    :array_a
    .array-data 1
        -0x24t
        -0x80t
        0x6t
        0x1bt
        -0x63t
        -0x7bt
        0x78t
        -0x5et
    .end array-data

    :array_b
    .array-data 1
        0x5bt
        0x21t
        0x6et
        0x19t
        0x3bt
        0x71t
        0xat
        0x45t
        0x46t
        0x68t
        0x78t
        0x13t
        0x3dt
        0x76t
        0x45t
        0x59t
        0x50t
        0x3ct
        0x3ct
        0x19t
        0x20t
        0x6ct
        0x16t
        0x43t
        0x1ft
        0x27t
        0x6et
        0x5ct
        0x31t
        0x76t
        0x45t
        0x59t
        0x50t
        0x3ct
        0x3ct
        0x1dt
        0x78t
        0x61t
        0xct
        0x45t
        0x5at
        0x2bt
        0x68t
        0x13t
        0x2at
        0x7ct
        0x4bt
    .end array-data

    :array_c
    .array-data 1
        0x3ft
        0x48t
        0x1ct
        0x7ct
        0x58t
        0x5t
        0x65t
        0x37t
    .end array-data

    :array_d
    .array-data 1
        -0x35t
        -0x45t
    .end array-data

    nop

    :array_e
    .array-data 1
        -0x1at
        -0x76t
        0x2bt
        -0x72t
        -0x42t
        -0x56t
        0x59t
        -0x3et
    .end array-data

    :array_f
    .array-data 1
        -0xdt
        -0xat
        -0x37t
        -0x25t
        -0x7dt
        -0x62t
        0x35t
    .end array-data

    :array_10
    .array-data 1
        -0x4at
        -0x7ct
        -0x45t
        -0x4ct
        -0xft
        -0x5ct
        0x15t
        -0x30t
    .end array-data
.end method
