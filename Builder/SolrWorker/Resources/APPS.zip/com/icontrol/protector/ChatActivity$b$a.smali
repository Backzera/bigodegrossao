.class Lcom/icontrol/protector/ChatActivity$b$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/ChatActivity$b;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lcom/icontrol/protector/ChatActivity$b;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/ChatActivity$b;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/ChatActivity$b$a;->e:Lcom/icontrol/protector/ChatActivity$b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lcom/icontrol/protector/ChatActivity$b$a;->e:Lcom/icontrol/protector/ChatActivity$b;

    iget-object v0, v0, Lcom/icontrol/protector/ChatActivity$b;->g:Lcom/icontrol/protector/ChatActivity;

    invoke-static {v0}, Lcom/icontrol/protector/ChatActivity;->b(Lcom/icontrol/protector/ChatActivity;)Landroid/widget/ScrollView;

    move-result-object v0

    const/16 v1, 0x82

    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->fullScroll(I)Z

    return-void
.end method
