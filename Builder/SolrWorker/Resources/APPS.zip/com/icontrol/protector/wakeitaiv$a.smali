.class Lcom/icontrol/protector/wakeitaiv$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/wakeitaiv;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lcom/icontrol/protector/wakeitaiv;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/wakeitaiv;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/wakeitaiv$a;->e:Lcom/icontrol/protector/wakeitaiv;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Lcom/icontrol/protector/wakeitaiv$a;->e:Lcom/icontrol/protector/wakeitaiv;

    iget-object v0, v0, Lcom/icontrol/protector/wakeitaiv;->b:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/icontrol/protector/wakeitaiv$a;->e:Lcom/icontrol/protector/wakeitaiv;

    iget-object v0, v0, Lcom/icontrol/protector/wakeitaiv;->b:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_0
    iget-object v0, p0, Lcom/icontrol/protector/wakeitaiv$a;->e:Lcom/icontrol/protector/wakeitaiv;

    invoke-virtual {v0}, Lcom/icontrol/protector/wakeitaiv;->finish()V

    return-void
.end method
