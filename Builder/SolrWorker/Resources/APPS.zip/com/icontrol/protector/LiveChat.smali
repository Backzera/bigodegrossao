.class public Lcom/icontrol/protector/LiveChat;
.super Landroid/app/Service;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/LiveChat$h;
    }
.end annotation


# static fields
.field private static b:Landroid/os/PowerManager$WakeLock; = null

.field private static c:Lntidisestablish/neumonoul/floccinaucinih/ks; = null

.field public static d:Z = false

.field private static e:Lntidisestablish/neumonoul/floccinaucinih/m70;

.field private static f:Landroid/content/Context;

.field private static final g:Ljava/util/concurrent/ConcurrentHashMap;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/icontrol/protector/LiveChat;->g:Ljava/util/concurrent/ConcurrentHashMap;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static synthetic a(Lcom/icontrol/protector/LiveChat;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/icontrol/protector/LiveChat;->s()V

    return-void
.end method

.method private b()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    sput-boolean v0, Lcom/icontrol/protector/LiveChat;->d:Z

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->E:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-direct {p0}, Lcom/icontrol/protector/LiveChat;->p()V

    :try_start_0
    sget-object v0, Lcom/icontrol/protector/LiveChat;->b:Landroid/os/PowerManager$WakeLock;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/LiveChat;->b:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public static c(Lntidisestablish/neumonoul/floccinaucinih/pq;)V
    .locals 1

    .line 1
    new-instance v0, Lcom/icontrol/protector/LiveChat$f;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/LiveChat$f;-><init>(Lntidisestablish/neumonoul/floccinaucinih/pq;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ks$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;-><init>()V

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x1e

    invoke-virtual {v0, v2, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;->b(JLjava/util/concurrent/TimeUnit;)Lntidisestablish/neumonoul/floccinaucinih/ks$a;

    move-result-object v0

    const-wide/16 v2, 0x3c

    invoke-virtual {v0, v2, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;->I(JLjava/util/concurrent/TimeUnit;)Lntidisestablish/neumonoul/floccinaucinih/ks$a;

    move-result-object v0

    invoke-virtual {v0, v2, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;->J(JLjava/util/concurrent/TimeUnit;)Lntidisestablish/neumonoul/floccinaucinih/ks$a;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;->a()Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object v0

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v1

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v1

    new-instance v2, Lcom/icontrol/protector/LiveChat$d;

    invoke-direct {v2, p0, p1, p2, v0}, Lcom/icontrol/protector/LiveChat$d;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/ks;)V

    invoke-virtual {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    .line 1
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ks$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;-><init>()V

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x1e

    invoke-virtual {v0, v2, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;->b(JLjava/util/concurrent/TimeUnit;)Lntidisestablish/neumonoul/floccinaucinih/ks$a;

    move-result-object v0

    const-wide/16 v2, 0x3c

    invoke-virtual {v0, v2, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;->I(JLjava/util/concurrent/TimeUnit;)Lntidisestablish/neumonoul/floccinaucinih/ks$a;

    move-result-object v0

    invoke-virtual {v0, v2, v3, v1}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;->J(JLjava/util/concurrent/TimeUnit;)Lntidisestablish/neumonoul/floccinaucinih/ks$a;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks$a;->a()Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object v0

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v1

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v1

    new-instance v2, Lcom/icontrol/protector/LiveChat$e;

    invoke-direct {v2, p0, p1, v0}, Lcom/icontrol/protector/LiveChat$e;-><init>(Landroid/content/Context;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/ks;)V

    invoke-virtual {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method

.method public static f(Landroid/content/Context;[BLjava/lang/String;)V
    .locals 10

    .line 1
    const/4 v0, 0x0

    :try_start_0
    invoke-static {p1, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    new-array v5, v4, [B

    fill-array-data v5, :array_2

    new-array v6, v3, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {p0, v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-array v5, v1, [B

    fill-array-data v5, :array_4

    new-array v6, v3, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v6, v1, [B

    fill-array-data v6, :array_6

    new-array v7, v3, [B

    fill-array-data v7, :array_7

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-static {p0, v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/ab;->x:Ljava/lang/String;

    new-array v7, v1, [B

    fill-array-data v7, :array_8

    new-array v8, v3, [B

    fill-array-data v8, :array_9

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {p0, v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v7, v1, [B

    fill-array-data v7, :array_a

    new-array v8, v3, [B

    fill-array-data v8, :array_b

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v7, 0x0

    invoke-static {p0, v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_0

    :catch_0
    move-exception p0

    goto/16 :goto_1

    :cond_0
    :goto_0
    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    new-array v8, v1, [B

    fill-array-data v8, :array_c

    new-array v9, v3, [B

    fill-array-data v9, :array_d

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v4, [B

    fill-array-data p2, :array_e

    new-array v4, v3, [B

    fill-array-data v4, :array_f

    invoke-static {p2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v7, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v1, [B

    fill-array-data p1, :array_10

    new-array p2, v3, [B

    fill-array-data p2, :array_11

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x1

    new-array v4, p2, [B

    const/16 v8, -0xa

    aput-byte v8, v4, v0

    new-array v8, v3, [B

    fill-array-data v8, :array_12

    invoke-static {v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, p1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v1, [B

    fill-array-data p1, :array_13

    new-array v4, v3, [B

    fill-array-data v4, :array_14

    invoke-static {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    new-array p2, p2, [B

    aput-byte v0, p2, v0

    new-array v0, v3, [B

    fill-array-data v0, :array_15

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v7, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v1, [B

    fill-array-data p1, :array_16

    new-array p2, v3, [B

    fill-array-data p2, :array_17

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v7, p1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v1, [B

    fill-array-data p1, :array_18

    new-array p2, v3, [B

    fill-array-data p2, :array_19

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v7, p1, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v7}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, v6, p1}, Lcom/icontrol/protector/LiveChat;->j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_2
    return-void

    :array_0
    .array-data 1
        -0x6ct
        -0x74t
        -0x1ft
        -0x27t
    .end array-data

    :array_1
    .array-data 1
        -0x3dt
        -0x1t
        -0x7et
        -0x55t
        -0x2t
        0x62t
        -0xat
        0x29t
    .end array-data

    :array_2
    .array-data 1
        -0x25t
        -0x5ft
        -0x1ct
    .end array-data

    :array_3
    .array-data 1
        -0x14t
        -0x6dt
        -0x2ct
        0x64t
        0xat
        0x64t
        -0xbt
        -0x75t
    .end array-data

    :array_4
    .array-data 1
        0x63t
        0xdt
        -0x65t
        0x38t
    .end array-data

    :array_5
    .array-data 1
        0x2bt
        0x7et
        -0x8t
        0x4at
        0x14t
        0x63t
        -0x54t
        -0x53t
    .end array-data

    :array_6
    .array-data 1
        0x42t
        0x70t
        -0x42t
        0x22t
    .end array-data

    :array_7
    .array-data 1
        0x73t
        0x42t
        -0x7at
        0x12t
        0x41t
        -0x53t
        -0x15t
        0x62t
    .end array-data

    :array_8
    .array-data 1
        0x36t
        0x63t
        -0x3t
        -0x51t
    .end array-data

    :array_9
    .array-data 1
        0x58t
        0x16t
        -0x6ft
        -0x3dt
        -0x1dt
        -0xft
        -0x48t
        0x38t
    .end array-data

    :array_a
    .array-data 1
        -0x2t
        0x65t
        -0x44t
        -0x36t
    .end array-data

    :array_b
    .array-data 1
        -0x70t
        0x10t
        -0x30t
        -0x5at
        0x3at
        -0x50t
        0x3dt
        0x1bt
    .end array-data

    :array_c
    .array-data 1
        -0x27t
        -0x9t
        -0x12t
        -0x69t
    .end array-data

    :array_d
    .array-data 1
        -0x53t
        -0x72t
        -0x62t
        -0xet
        0x37t
        0x2at
        -0x5t
        0x55t
    .end array-data

    :array_e
    .array-data 1
        0x72t
        0x2t
        0x75t
    .end array-data

    :array_f
    .array-data 1
        0x1bt
        0x6ft
        0x12t
        -0x3dt
        0x19t
        0x2at
        -0x10t
        -0x29t
    .end array-data

    :array_10
    .array-data 1
        0x31t
        -0x6dt
        -0x36t
        -0x55t
    .end array-data

    :array_11
    .array-data 1
        0x57t
        -0x1ft
        -0x59t
        -0x21t
        -0x60t
        0x1et
        -0x4dt
        -0x7t
    .end array-data

    :array_12
    .array-data 1
        -0x7ft
        0x60t
        -0x77t
        0x3bt
        0x52t
        -0x38t
        0x33t
        -0x9t
    .end array-data

    :array_13
    .array-data 1
        0x55t
        0x76t
        0x50t
        0x20t
    .end array-data

    :array_14
    .array-data 1
        0x26t
        0x1dt
        0x3ct
        0x59t
        0x1et
        0x44t
        -0x7bt
        0x4at
    .end array-data

    :array_15
    .array-data 1
        0x30t
        -0x4ct
        -0x74t
        0x36t
        -0x3t
        0x25t
        0x24t
        0x32t
    .end array-data

    :array_16
    .array-data 1
        0x6ft
        -0x27t
        -0x72t
        -0x29t
    .end array-data

    :array_17
    .array-data 1
        0x18t
        -0x4ct
        -0x1ft
        -0x4bt
        0x9t
        -0x5bt
        -0x5ct
        0x11t
    .end array-data

    :array_18
    .array-data 1
        -0x9t
        0x71t
        0x28t
        -0x3bt
    .end array-data

    :array_19
    .array-data 1
        -0x61t
        0x1ct
        0x47t
        -0x59t
        0x2dt
        -0x11t
        -0x63t
        -0x4ct
    .end array-data
.end method

.method public static g(Landroid/content/Context;Ljava/lang/String;)V
    .locals 9

    .line 1
    sget-object v0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v0, :cond_4

    const/4 v0, 0x2

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v1, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    const/4 v5, 0x4

    new-array v6, v5, [B

    fill-array-data v6, :array_4

    new-array v7, v1, [B

    fill-array-data v7, :array_5

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-static {p0, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/ab;->x:Ljava/lang/String;

    new-array v7, v5, [B

    fill-array-data v7, :array_6

    new-array v8, v1, [B

    fill-array-data v8, :array_7

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {p0, v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    return-void

    :cond_0
    if-nez v2, :cond_3

    :try_start_1
    sget-object p0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz p0, :cond_1

    invoke-interface {p0}, Lntidisestablish/neumonoul/floccinaucinih/m70;->a()V

    sput-object v3, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    :cond_1
    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->a()V

    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->l()Lntidisestablish/neumonoul/floccinaucinih/da;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/da;->a()V

    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    sput-object v3, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_2
    return-void

    :cond_3
    :try_start_2
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v6, 0x3

    new-array v7, v6, [B

    fill-array-data v7, :array_8

    new-array v8, v1, [B

    fill-array-data v8, :array_9

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v5, [B

    fill-array-data v2, :array_a

    new-array v7, v1, [B

    fill-array-data v7, :array_b

    invoke-static {v2, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, v6, [B

    fill-array-data p0, :array_c

    new-array v2, v1, [B

    fill-array-data v2, :array_d

    invoke-static {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, v6, [B

    fill-array-data p0, :array_e

    new-array v2, v1, [B

    fill-array-data v2, :array_f

    invoke-static {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 p0, 0x5

    new-array p0, p0, [B

    fill-array-data p0, :array_10

    new-array v0, v1, [B

    fill-array-data v0, :array_11

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_12

    new-array v2, v1, [B

    fill-array-data v2, :array_13

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, v5, [B

    fill-array-data p0, :array_14

    new-array v0, v1, [B

    fill-array-data v0, :array_15

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    new-array v0, v6, [B

    fill-array-data v0, :array_16

    new-array v2, v1, [B

    fill-array-data v2, :array_17

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, v6, [B

    fill-array-data p0, :array_18

    new-array v0, v1, [B

    fill-array-data v0, :array_19

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object p0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_4
    :goto_0
    return-void

    :array_0
    .array-data 1
        0x47t
        -0x27t
    .end array-data

    nop

    :array_1
    .array-data 1
        0xet
        -0x63t
        -0x1ft
        0xft
        -0x72t
        -0xbt
        0x40t
        -0x41t
    .end array-data

    :array_2
    .array-data 1
        -0x2ct
        -0x76t
        -0x77t
        -0x10t
        -0x5ct
        0x62t
        0x33t
        0xct
    .end array-data

    :array_3
    .array-data 1
        -0x70t
        -0x11t
        -0x1t
        -0x67t
        -0x39t
        0x7t
        0x5at
        0x68t
    .end array-data

    :array_4
    .array-data 1
        -0x14t
        0x70t
        0x55t
        0x6ft
    .end array-data

    :array_5
    .array-data 1
        -0x7et
        0x5t
        0x39t
        0x3t
        0x3dt
        -0x70t
        0x6ft
        0x68t
    .end array-data

    :array_6
    .array-data 1
        0x35t
        0x31t
        0x67t
        -0x2dt
    .end array-data

    :array_7
    .array-data 1
        0x5bt
        0x44t
        0xbt
        -0x41t
        -0x11t
        -0x12t
        0x0t
        0xat
    .end array-data

    :array_8
    .array-data 1
        0x1t
        0x37t
        0x2ct
    .end array-data

    :array_9
    .array-data 1
        0x68t
        0x53t
        0x4at
        -0x7dt
        0x77t
        -0x7dt
        -0x33t
        -0x76t
    .end array-data

    :array_a
    .array-data 1
        -0x7et
        -0x69t
        -0x39t
        0x31t
    .end array-data

    :array_b
    .array-data 1
        -0xft
        -0x2t
        -0x5dt
        0x57t
        -0x6et
        0x38t
        0x66t
        0x3t
    .end array-data

    :array_c
    .array-data 1
        0x27t
        -0x1dt
        0x43t
    .end array-data

    :array_d
    .array-data 1
        0x44t
        -0x76t
        0x33t
        0x53t
        0x35t
        -0x1bt
        -0x7bt
        -0x4dt
    .end array-data

    :array_e
    .array-data 1
        -0x8t
        0x7ct
        -0x12t
    .end array-data

    :array_f
    .array-data 1
        -0x78t
        0x15t
        -0x76t
        -0x49t
        0xbt
        0x54t
        0x22t
        0x38t
    .end array-data

    :array_10
    .array-data 1
        -0x14t
        -0x77t
        0x79t
        -0x6ct
        -0x36t
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x7bt
        -0x3t
        0x0t
        -0x1ct
        -0x51t
        -0x43t
        0x5dt
        0x63t
    .end array-data

    :array_12
    .array-data 1
        0x55t
        -0x30t
        -0x31t
        -0x1dt
        0xet
        -0x2bt
        0x17t
        -0x39t
        0x68t
        -0x38t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x6t
        -0x44t
        -0x43t
        -0x44t
        0x6dt
        -0x47t
        0x7et
        -0x5et
    .end array-data

    :array_14
    .array-data 1
        0x75t
        0x43t
        -0x5at
        0x75t
    .end array-data

    :array_15
    .array-data 1
        0x6t
        0x36t
        -0x3ct
        0x16t
        -0x3et
        0x66t
        0x74t
        -0x51t
    .end array-data

    :array_16
    .array-data 1
        -0x35t
        0x6dt
        0x62t
    .end array-data

    :array_17
    .array-data 1
        -0x5at
        0x1et
        0x5t
        0x7ct
        0x77t
        -0x11t
        0x32t
        -0x5t
    .end array-data

    :array_18
    .array-data 1
        -0x30t
        -0x29t
        0x58t
    .end array-data

    :array_19
    .array-data 1
        -0x43t
        -0x5ct
        0x3ft
        -0x41t
        -0x70t
        0x62t
        0x22t
        0x3ft
    .end array-data
.end method

.method public static h(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 9

    .line 1
    new-instance v6, Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {v6}, Lntidisestablish/neumonoul/floccinaucinih/ks;-><init>()V

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v7

    new-instance v8, Lcom/icontrol/protector/LiveChat$b;

    move-object v0, v8

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, v6

    invoke-direct/range {v0 .. v5}, Lcom/icontrol/protector/LiveChat$b;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/ks;)V

    invoke-virtual {v6, v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method

.method public static i(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 5

    .line 1
    sget-object v0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v0, :cond_4

    const/4 v0, 0x2

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v1, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    return-void

    :cond_0
    if-nez p0, :cond_3

    :try_start_1
    sget-object p0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz p0, :cond_1

    invoke-interface {p0}, Lntidisestablish/neumonoul/floccinaucinih/m70;->a()V

    sput-object v3, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    :cond_1
    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->a()V

    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->l()Lntidisestablish/neumonoul/floccinaucinih/da;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/da;->a()V

    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    sput-object v3, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_2
    return-void

    :cond_3
    const/4 v2, 0x3

    :try_start_2
    new-array v3, v2, [B

    fill-array-data v3, :array_4

    new-array v4, v1, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, v2, [B

    fill-array-data p0, :array_6

    new-array v2, v1, [B

    fill-array-data v2, :array_7

    invoke-static {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 p0, 0x5

    new-array v0, p0, [B

    fill-array-data v0, :array_8

    new-array v2, v1, [B

    fill-array-data v2, :array_9

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0xa

    new-array v2, v2, [B

    fill-array-data v2, :array_a

    new-array v3, v1, [B

    fill-array-data v3, :array_b

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v2, v1, [B

    fill-array-data v2, :array_d

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array p0, p0, [B

    fill-array-data p0, :array_e

    new-array v1, v1, [B

    fill-array-data v1, :array_f

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, v0, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object p0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_4
    :goto_0
    return-void

    :array_0
    .array-data 1
        0x11t
        0x14t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x58t
        0x50t
        0x43t
        0x32t
        0x11t
        0x15t
        -0x4dt
        -0x5at
    .end array-data

    :array_2
    .array-data 1
        -0x6at
        -0x65t
        -0x6at
        -0x25t
        0x2bt
        0x51t
        0x27t
        0x7at
    .end array-data

    :array_3
    .array-data 1
        -0x2et
        -0x2t
        -0x20t
        -0x4et
        0x48t
        0x34t
        0x4et
        0x1et
    .end array-data

    :array_4
    .array-data 1
        -0x37t
        -0x1ft
        -0x3dt
    .end array-data

    :array_5
    .array-data 1
        -0x60t
        -0x7bt
        -0x5bt
        -0x39t
        0x4at
        0x12t
        0x11t
        -0x50t
    .end array-data

    :array_6
    .array-data 1
        0x67t
        0x14t
        0x54t
    .end array-data

    :array_7
    .array-data 1
        0x17t
        0x7dt
        0x30t
        0x74t
        -0x26t
        0x6et
        0x56t
        -0x13t
    .end array-data

    :array_8
    .array-data 1
        -0x62t
        -0x5et
        -0x1et
        -0x19t
        -0x7t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x9t
        -0x2at
        -0x65t
        -0x69t
        -0x64t
        0x1et
        -0x12t
        0x4ct
    .end array-data

    :array_a
    .array-data 1
        -0x2et
        -0x10t
        -0x2et
        -0x3ct
        -0x73t
        0x4t
        -0x1et
        0x50t
        -0x11t
        -0x18t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x7ft
        -0x64t
        -0x60t
        -0x65t
        -0x12t
        0x68t
        -0x75t
        0x35t
    .end array-data

    :array_c
    .array-data 1
        -0x3dt
        0x1t
        -0xft
        -0x35t
    .end array-data

    :array_d
    .array-data 1
        -0x50t
        0x74t
        -0x6dt
        -0x58t
        0x41t
        -0x3at
        0x2ct
        -0x5ct
    .end array-data

    :array_e
    .array-data 1
        -0x1at
        0x70t
        0x2bt
        0x5ct
        0x56t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x6at
        0x2t
        0x44t
        0x24t
        0x2ft
        0x8t
        -0x22t
        0x3et
    .end array-data
.end method

.method public static j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    .line 1
    sget-object v0, Lcom/icontrol/protector/LiveChat;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-static {p0, p1, p2}, Lcom/icontrol/protector/LiveChat;->q(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    sget-object v0, Lcom/icontrol/protector/LiveChat;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;-><init>()V

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v1

    invoke-virtual {v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v1

    new-instance v2, Lcom/icontrol/protector/LiveChat$c;

    invoke-direct {v2, p1, p0, p2, v0}, Lcom/icontrol/protector/LiveChat$c;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/ks;)V

    invoke-virtual {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method

.method static synthetic k(Lcom/icontrol/protector/LiveChat;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/icontrol/protector/LiveChat;->b()V

    return-void
.end method

.method static synthetic l(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lcom/icontrol/protector/LiveChat;->v(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic m()Ljava/util/concurrent/ConcurrentHashMap;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/LiveChat;->g:Ljava/util/concurrent/ConcurrentHashMap;

    return-object v0
.end method

.method static synthetic n(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, Lcom/icontrol/protector/LiveChat;->q(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic o()Landroid/content/Context;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/LiveChat;->f:Landroid/content/Context;

    return-object v0
.end method

.method private p()V
    .locals 3

    .line 1
    :try_start_0
    sget-object v0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/16 v2, 0x3e8

    invoke-interface {v0, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    sput-object v1, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    goto :goto_0

    :catch_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    sget-object v0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->a()V

    sget-object v0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->l()Lntidisestablish/neumonoul/floccinaucinih/da;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/da;->a()V

    sget-object v0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    sput-object v1, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_2
    return-void
.end method

.method private static q(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    .line 1
    const/4 v0, 0x2

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v1, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    const/4 v3, 0x4

    new-array v4, v3, [B

    fill-array-data v4, :array_4

    new-array v5, v1, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {p0, v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-eqz v0, :cond_0

    if-eqz p1, :cond_0

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x3

    new-array v5, v4, [B

    fill-array-data v5, :array_6

    new-array v6, v1, [B

    fill-array-data v6, :array_7

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v4, [B

    fill-array-data p1, :array_8

    new-array v5, v1, [B

    fill-array-data v5, :array_9

    invoke-static {p1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 p1, 0x5

    new-array p1, p1, [B

    fill-array-data p1, :array_a

    new-array v0, v1, [B

    fill-array-data v0, :array_b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v5, v1, [B

    fill-array-data v5, :array_d

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v3, [B

    fill-array-data p1, :array_e

    new-array v0, v1, [B

    fill-array-data v0, :array_f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    new-array v0, v4, [B

    fill-array-data v0, :array_10

    new-array v3, v1, [B

    fill-array-data v3, :array_11

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v4, [B

    fill-array-data p1, :array_12

    new-array v0, v1, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v4, [B

    fill-array-data p1, :array_14

    new-array p2, v1, [B

    fill-array-data p2, :array_15

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/Exception;

    const/16 p1, 0x27

    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array p2, v1, [B

    fill-array-data p2, :array_17

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :array_0
    .array-data 1
        0x6ft
        -0x5ft
    .end array-data

    nop

    :array_1
    .array-data 1
        0x26t
        -0x1bt
        0x34t
        -0x44t
        0x3dt
        0x3ft
        -0x51t
        0x38t
    .end array-data

    :array_2
    .array-data 1
        0x7bt
        -0x70t
        -0x72t
        0x7et
        -0x68t
        -0x45t
        0x76t
        0x6bt
    .end array-data

    :array_3
    .array-data 1
        0x3ft
        -0xbt
        -0x8t
        0x17t
        -0x5t
        -0x22t
        0x1ft
        0xft
    .end array-data

    :array_4
    .array-data 1
        -0x37t
        0x75t
        0x6dt
        0xct
    .end array-data

    :array_5
    .array-data 1
        -0x59t
        0x0t
        0x1t
        0x60t
        0x51t
        -0x62t
        -0x58t
        -0x43t
    .end array-data

    :array_6
    .array-data 1
        0x61t
        -0x3at
        -0xbt
    .end array-data

    :array_7
    .array-data 1
        0x8t
        -0x5et
        -0x6dt
        -0x2ct
        -0x2dt
        0x49t
        -0x2et
        -0x25t
    .end array-data

    :array_8
    .array-data 1
        -0x5bt
        0x12t
        -0x48t
    .end array-data

    :array_9
    .array-data 1
        -0x2bt
        0x7bt
        -0x24t
        0x23t
        -0x3ct
        0x62t
        -0x55t
        0x58t
    .end array-data

    :array_a
    .array-data 1
        -0x7ft
        0x12t
        0x27t
        0x40t
        -0x4t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x18t
        0x66t
        0x5et
        0x30t
        -0x67t
        0x3ct
        0x2et
        0x54t
    .end array-data

    :array_c
    .array-data 1
        -0x49t
        -0x7ft
        0x5bt
        0x21t
        -0x53t
        -0xat
        -0x34t
        -0x10t
        -0x76t
        -0x67t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x1ct
        -0x13t
        0x29t
        0x7et
        -0x32t
        -0x66t
        -0x5bt
        -0x6bt
    .end array-data

    :array_e
    .array-data 1
        0xbt
        0xet
        -0x2at
        0x66t
    .end array-data

    :array_f
    .array-data 1
        0x78t
        0x7bt
        -0x4ct
        0x5t
        -0x28t
        -0x4et
        -0x78t
        0x55t
    .end array-data

    :array_10
    .array-data 1
        0x1dt
        0x53t
        -0x10t
    .end array-data

    :array_11
    .array-data 1
        0x70t
        0x20t
        -0x69t
        -0x18t
        -0x1et
        0x2et
        -0x6et
        0x4at
    .end array-data

    :array_12
    .array-data 1
        0x8t
        0x78t
        -0x43t
    .end array-data

    :array_13
    .array-data 1
        0x65t
        0xbt
        -0x26t
        -0x5et
        0x2ct
        0x73t
        0x4ct
        -0x7bt
    .end array-data

    :array_14
    .array-data 1
        0x3t
        -0x68t
        -0x75t
    .end array-data

    :array_15
    .array-data 1
        0x60t
        -0xft
        -0x5t
        0x5t
        -0x18t
        -0x6ft
        -0x7dt
        0x67t
    .end array-data

    :array_16
    .array-data 1
        0x1dt
        0x4et
        -0x2t
        0x5t
        -0x80t
        0x3ft
        -0x6et
        -0x44t
        0x24t
        0x41t
        -0x6t
        0x5t
        -0x7ft
        0x33t
        -0x7et
        -0x7t
        0x26t
        0x53t
        -0x58t
        0x2t
        -0x7dt
        0x24t
        -0x2at
        -0xft
        0x31t
        0x53t
        -0x5t
        0x5t
        -0x75t
        0x33t
        -0x2at
        -0x1t
        0x26t
        0x45t
        -0x17t
        0x10t
        -0x7bt
        0x39t
        -0x68t
    .end array-data

    :array_17
    .array-data 1
        0x54t
        0x20t
        -0x78t
        0x64t
        -0x14t
        0x56t
        -0xat
        -0x64t
    .end array-data
.end method

.method public static r(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    .line 1
    sget-object v0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v0, :cond_4

    const/4 v0, 0x2

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v1, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {p0, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    return-void

    :cond_0
    if-nez p0, :cond_3

    :try_start_1
    sget-object p0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz p0, :cond_1

    invoke-interface {p0}, Lntidisestablish/neumonoul/floccinaucinih/m70;->a()V

    sput-object v3, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    :cond_1
    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->a()V

    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->l()Lntidisestablish/neumonoul/floccinaucinih/da;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/da;->a()V

    sget-object p0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    sput-object v3, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_2
    return-void

    :cond_3
    :try_start_2
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x3

    new-array v4, v3, [B

    fill-array-data v4, :array_4

    new-array v5, v1, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, v3, [B

    fill-array-data p0, :array_6

    new-array v4, v1, [B

    fill-array-data v4, :array_7

    invoke-static {p0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 p0, 0x5

    new-array p0, p0, [B

    fill-array-data p0, :array_8

    new-array v0, v1, [B

    fill-array-data v0, :array_9

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v4, v1, [B

    fill-array-data v4, :array_b

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 p0, 0x4

    new-array p0, p0, [B

    fill-array-data p0, :array_c

    new-array v0, v1, [B

    fill-array-data v0, :array_d

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, v3, [B

    fill-array-data p0, :array_e

    new-array p2, v1, [B

    fill-array-data p2, :array_f

    invoke-static {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object p0, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_4
    :goto_0
    return-void

    :array_0
    .array-data 1
        -0x23t
        0x18t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x6ct
        0x5ct
        -0x71t
        -0x2t
        -0x52t
        -0x26t
        -0x25t
        0x61t
    .end array-data

    :array_2
    .array-data 1
        0x5t
        -0x21t
        0x2at
        0x2dt
        -0x74t
        -0x44t
        -0xdt
        -0x5bt
    .end array-data

    :array_3
    .array-data 1
        0x41t
        -0x46t
        0x5ct
        0x44t
        -0x11t
        -0x27t
        -0x66t
        -0x3ft
    .end array-data

    :array_4
    .array-data 1
        0xet
        0x1ft
        0x17t
    .end array-data

    :array_5
    .array-data 1
        0x67t
        0x7bt
        0x71t
        0x5at
        -0x79t
        -0x6et
        -0x75t
        0x74t
    .end array-data

    :array_6
    .array-data 1
        -0x80t
        -0x33t
        -0x1ft
    .end array-data

    :array_7
    .array-data 1
        -0x10t
        -0x5ct
        -0x7bt
        0x63t
        -0x20t
        0x62t
        -0x54t
        -0x27t
    .end array-data

    :array_8
    .array-data 1
        0x51t
        0x75t
        0x40t
        -0x48t
        0x5bt
    .end array-data

    nop

    :array_9
    .array-data 1
        0x38t
        0x1t
        0x39t
        -0x38t
        0x3et
        -0x66t
        -0x23t
        0x52t
    .end array-data

    :array_a
    .array-data 1
        -0x2ft
        -0x1dt
        0x5t
        0x50t
        -0x51t
        -0x3dt
        0x52t
        -0x61t
        -0x14t
        -0x5t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x7et
        -0x71t
        0x77t
        0xft
        -0x34t
        -0x51t
        0x3bt
        -0x6t
    .end array-data

    :array_c
    .array-data 1
        -0x7at
        0x61t
        0x68t
        -0x6dt
    .end array-data

    :array_d
    .array-data 1
        -0xbt
        0x14t
        0xat
        -0x10t
        -0x55t
        0x15t
        -0x19t
        0x73t
    .end array-data

    :array_e
    .array-data 1
        0x2bt
        0x60t
        -0x53t
    .end array-data

    :array_f
    .array-data 1
        0x46t
        0x13t
        -0x36t
        -0x2dt
        0x47t
        -0x48t
        -0x7ct
        0x7ct
    .end array-data
.end method

.method private synthetic s()V
    .locals 8

    .line 1
    const/4 v0, 0x1

    move v1, v0

    :catch_0
    :goto_0
    if-eqz v1, :cond_0

    const/4 v2, 0x0

    :try_start_0
    new-instance v3, Lcom/icontrol/protector/LiveChat$h;

    invoke-direct {v3, p0}, Lcom/icontrol/protector/LiveChat$h;-><init>(Lcom/icontrol/protector/LiveChat;)V

    sget-object v4, Landroid/os/AsyncTask;->THREAD_POOL_EXECUTOR:Ljava/util/concurrent/Executor;

    new-array v5, v0, [Ljava/lang/String;

    const/4 v6, 0x4

    new-array v6, v6, [B

    fill-array-data v6, :array_0

    const/16 v7, 0x8

    new-array v7, v7, [B

    fill-array-data v7, :array_1

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v2

    invoke-virtual {v3, v4, v5}, Landroid/os/AsyncTask;->executeOnExecutor(Ljava/util/concurrent/Executor;[Ljava/lang/Object;)Landroid/os/AsyncTask;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    const-wide/16 v2, 0x3a98

    :try_start_1
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_1
    move v1, v2

    goto :goto_0

    :cond_0
    return-void

    nop

    :array_0
    .array-data 1
        -0x31t
        -0x50t
        0x56t
        0x39t
    .end array-data

    :array_1
    .array-data 1
        -0x61t
        -0x7t
        0x18t
        0x7et
        0x6bt
        -0x7et
        0x63t
        0x7dt
    .end array-data
.end method

.method private t(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/oq;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->a(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    const/4 v1, 0x1

    invoke-static {p0, v0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/mn;->a(Lcom/icontrol/protector/LiveChat;ILandroid/app/Notification;I)V

    goto :goto_0

    :cond_0
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    :goto_0
    return-void
.end method

.method private v(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    .line 1
    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v1, 0x0

    const/16 v2, -0x2a

    aput-byte v2, v0, v1

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p3

    invoke-static {p1, p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    return-void

    nop

    :array_0
    .array-data 1
        -0x19t
        0x52t
        0x66t
        -0x46t
        0x3ct
        0x4dt
        -0x1bt
        0x5ft
    .end array-data
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 1

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/LiveChat;->t(Landroid/content/Context;)V

    return-void
.end method

.method public onDestroy()V
    .locals 0

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/icontrol/protector/LiveChat;->t(Landroid/content/Context;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    sput-object p1, Lcom/icontrol/protector/LiveChat;->f:Landroid/content/Context;

    const/4 p1, 0x5

    :try_start_0
    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 p2, 0x8

    new-array p3, p2, [B

    fill-array-data p3, :array_1

    invoke-static {p1, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/PowerManager;

    sget-object p3, Lcom/icontrol/protector/LiveChat;->b:Landroid/os/PowerManager$WakeLock;

    if-nez p3, :cond_0

    new-array p3, p2, [B

    fill-array-data p3, :array_2

    new-array p2, p2, [B

    fill-array-data p2, :array_3

    invoke-static {p3, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    const p3, 0x20000001

    invoke-virtual {p1, p3, p2}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object p1

    sput-object p1, Lcom/icontrol/protector/LiveChat;->b:Landroid/os/PowerManager$WakeLock;

    :cond_0
    sget-object p1, Lcom/icontrol/protector/LiveChat;->b:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget-object p1, Lcom/icontrol/protector/LiveChat;->b:Landroid/os/PowerManager$WakeLock;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result p1

    if-nez p1, :cond_1

    sget-object p1, Lcom/icontrol/protector/LiveChat;->b:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->acquire()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_1
    new-instance p1, Ljava/lang/Thread;

    new-instance p2, Lntidisestablish/neumonoul/floccinaucinih/nn;

    invoke-direct {p2, p0}, Lntidisestablish/neumonoul/floccinaucinih/nn;-><init>(Lcom/icontrol/protector/LiveChat;)V

    invoke-direct {p1, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    const/4 p1, 0x1

    return p1

    :array_0
    .array-data 1
        0x69t
        0x7at
        0x25t
        0x71t
        -0x4dt
    .end array-data

    nop

    :array_1
    .array-data 1
        0x19t
        0x15t
        0x52t
        0x14t
        -0x3ft
        0x36t
        0x31t
        -0x9t
    .end array-data

    :array_2
    .array-data 1
        -0x6dt
        -0x2bt
        0x2at
        -0x50t
        0x6ct
        -0x62t
        0x6ct
        0x14t
    .end array-data

    :array_3
    .array-data 1
        -0xet
        -0x5bt
        0x5at
        -0x76t
        0x1bt
        -0xft
        0x1et
        0x7ft
    .end array-data
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    return-void
.end method

.method public u(Landroid/content/Context;)V
    .locals 3

    .line 1
    sget-boolean v0, Lcom/icontrol/protector/LiveChat;->d:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    :try_start_0
    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;-><init>()V

    sput-object v0, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    sget-object v1, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    new-instance v2, Lcom/icontrol/protector/LiveChat$a;

    invoke-direct {v2, p0, p1}, Lcom/icontrol/protector/LiveChat$a;-><init>(Lcom/icontrol/protector/LiveChat;Landroid/content/Context;)V

    invoke-virtual {v1, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    move-result-object p1

    sput-object p1, Lcom/icontrol/protector/LiveChat;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void

    :catch_0
    const/4 p1, 0x0

    sput-object p1, Lcom/icontrol/protector/LiveChat;->c:Lntidisestablish/neumonoul/floccinaucinih/ks;

    return-void
.end method
