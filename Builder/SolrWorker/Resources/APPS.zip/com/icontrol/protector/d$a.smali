.class Lcom/icontrol/protector/d$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/FileFilter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/d;->b(Ljava/io/File;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/ArrayList;

.field final synthetic b:Lcom/icontrol/protector/d;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/d;Ljava/util/ArrayList;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/d$a;->b:Lcom/icontrol/protector/d;

    iput-object p2, p0, Lcom/icontrol/protector/d$a;->a:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public accept(Ljava/io/File;)Z
    .locals 4

    invoke-virtual {p1}, Ljava/io/File;->isFile()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Lcom/icontrol/protector/d$a;->b:Lcom/icontrol/protector/d;

    invoke-static {v0, p1}, Lcom/icontrol/protector/d;->a(Lcom/icontrol/protector/d;Ljava/io/File;)Z

    move-result p1

    return p1

    :cond_1
    invoke-virtual {p1}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/icontrol/protector/d$a;->a:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    return v1

    nop

    :array_0
    .array-data 1
        0xdt
        -0x6dt
        -0xet
        0x10t
        0x4at
        -0x80t
        0x5at
        -0x5ft
    .end array-data

    :array_1
    .array-data 1
        0x23t
        -0x3t
        -0x63t
        0x7dt
        0x2ft
        -0x1ct
        0x33t
        -0x40t
    .end array-data
.end method
