.class Lcom/icontrol/protector/RequestDataUsage$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/RequestDataUsage;->a()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/RequestDataUsage;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/RequestDataUsage;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/RequestDataUsage$a;->a:Lcom/icontrol/protector/RequestDataUsage;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    const/4 p1, 0x1

    sput-boolean p1, Lcom/icontrol/protector/AccessServices;->u:Z

    :try_start_0
    new-instance p1, Landroid/content/Intent;

    const/16 p2, 0x3d

    new-array p2, p2, [B

    fill-array-data p2, :array_0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_1

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x7

    new-array p2, p2, [B

    fill-array-data p2, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lcom/icontrol/protector/RequestDataUsage$a;->a:Lcom/icontrol/protector/RequestDataUsage;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p2, v0, v1}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/high16 p2, 0x10000000

    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    iget-object p2, p0, Lcom/icontrol/protector/RequestDataUsage$a;->a:Lcom/icontrol/protector/RequestDataUsage;

    invoke-virtual {p2, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iget-object p1, p0, Lcom/icontrol/protector/RequestDataUsage$a;->a:Lcom/icontrol/protector/RequestDataUsage;

    invoke-virtual {p1}, Lcom/icontrol/protector/RequestDataUsage;->finish()V

    return-void

    nop

    :array_0
    .array-data 1
        0x2dt
        -0x5t
        -0x14t
        -0x7at
        0x10t
        0x6t
        0x67t
        0x4at
        0x3ft
        -0x10t
        -0x4t
        -0x80t
        0x16t
        0x1t
        0x64t
        0x17t
        0x62t
        -0x24t
        -0x31t
        -0x46t
        0x30t
        0x3dt
        0x46t
        0x3bt
        0xet
        -0x2ct
        -0x35t
        -0x41t
        0x38t
        0x3dt
        0x4ct
        0x31t
        0x2t
        -0x2ft
        -0x29t
        -0x50t
        0x3et
        0x3bt
        0x42t
        0x3bt
        0x1et
        -0x30t
        -0x25t
        -0x60t
        0x2dt
        0x26t
        0x40t
        0x30t
        0x5t
        -0x26t
        -0x3at
        -0x59t
        0x20t
        0x3ct
        0x46t
        0x30t
        0x18t
        -0x24t
        -0x3at
        -0x4dt
        0x2ct
    .end array-data

    nop

    :array_1
    .array-data 1
        0x4ct
        -0x6bt
        -0x78t
        -0xct
        0x7ft
        0x6ft
        0x3t
        0x64t
    .end array-data

    :array_2
    .array-data 1
        -0x34t
        0x4ct
        -0x24t
        0x4at
        0xdt
        0x1t
        -0x19t
    .end array-data

    :array_3
    .array-data 1
        -0x44t
        0x2dt
        -0x41t
        0x21t
        0x6ct
        0x66t
        -0x7et
        -0x30t
    .end array-data
.end method
