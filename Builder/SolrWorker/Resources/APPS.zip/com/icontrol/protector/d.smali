.class public Lcom/icontrol/protector/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/FileFilter;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/d$b;,
        Lcom/icontrol/protector/d$c;
    }
.end annotation


# static fields
.field protected static final c:Ljava/lang/String;


# instance fields
.field private final a:Z

.field private final b:Lcom/icontrol/protector/d$b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/16 v0, 0x11

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/d;->c:Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        0x39t
        -0x2ft
        0x60t
        -0x18t
        0x3ct
        -0x73t
        0x41t
        0x72t
        0x16t
        -0x3ft
        0x60t
        -0x26t
        0x3at
        -0x74t
        0x73t
        0x7et
        0x8t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x7at
        -0x5ct
        0x13t
        -0x64t
        0x53t
        -0x20t
        0x7t
        0x1bt
    .end array-data
.end method

.method public constructor <init>(Lcom/icontrol/protector/d$b;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/icontrol/protector/d;->b:Lcom/icontrol/protector/d$b;

    iput-boolean p2, p0, Lcom/icontrol/protector/d;->a:Z

    return-void
.end method

.method static synthetic a(Lcom/icontrol/protector/d;Ljava/io/File;)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/d;->c(Ljava/io/File;)Z

    move-result p0

    return p0
.end method

.method private b(Ljava/io/File;)Z
    .locals 3

    .line 1
    iget-boolean v0, p0, Lcom/icontrol/protector/d;->a:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Lcom/icontrol/protector/d$a;

    invoke-direct {v2, p0, v0}, Lcom/icontrol/protector/d$a;-><init>(Lcom/icontrol/protector/d;Ljava/util/ArrayList;)V

    invoke-virtual {p1, v2}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object p1

    if-nez p1, :cond_1

    return v1

    :cond_1
    array-length p1, p1

    const/4 v2, 0x1

    if-lez p1, :cond_2

    return v2

    :cond_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/io/File;

    invoke-direct {p0, v0}, Lcom/icontrol/protector/d;->b(Ljava/io/File;)Z

    move-result v0

    if-eqz v0, :cond_3

    return v2

    :cond_4
    return v1
.end method

.method private c(Ljava/io/File;)Z
    .locals 2

    .line 1
    invoke-virtual {p0, p1}, Lcom/icontrol/protector/d;->d(Ljava/io/File;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    :try_start_0
    iget-object v1, p0, Lcom/icontrol/protector/d;->b:Lcom/icontrol/protector/d$b;

    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lcom/icontrol/protector/d$b;->b(Ljava/lang/String;)Lcom/icontrol/protector/d$c;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    return p1

    :catch_0
    :cond_1
    return v0
.end method


# virtual methods
.method public accept(Ljava/io/File;)Z
    .locals 1

    invoke-virtual {p1}, Ljava/io/File;->canRead()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p1}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-direct {p0, p1}, Lcom/icontrol/protector/d;->b(Ljava/io/File;)Z

    move-result p1

    return p1

    :cond_1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/d;->c(Ljava/io/File;)Z

    move-result p1

    return p1
.end method

.method public d(Ljava/io/File;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/icontrol/protector/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public e(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 1
    const/16 v0, 0x2e

    invoke-virtual {p1, v0}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v0

    if-lez v0, :cond_0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    const/4 p1, 0x0

    return-object p1
.end method
