.class Lcom/icontrol/protector/LiveChat$c;
.super Lntidisestablish/neumonoul/floccinaucinih/o70;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/LiveChat;->j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Lntidisestablish/neumonoul/floccinaucinih/ks;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/ks;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$c;->a:Ljava/lang/String;

    iput-object p2, p0, Lcom/icontrol/protector/LiveChat$c;->b:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/LiveChat$c;->c:Ljava/lang/String;

    iput-object p4, p0, Lcom/icontrol/protector/LiveChat$c;->d:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/o70;-><init>()V

    return-void
.end method

.method public static synthetic g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/m70;)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2, p3}, Lcom/icontrol/protector/LiveChat$c;->h(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/m70;)V

    return-void
.end method

.method private static synthetic h(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/m70;)V
    .locals 0

    .line 1
    :try_start_0
    invoke-static {p0, p1, p2}, Lcom/icontrol/protector/LiveChat;->n(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-interface {p3, p0}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-static {}, Lcom/icontrol/protector/LiveChat;->m()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p1

    iget-object p2, p0, Lcom/icontrol/protector/LiveChat$c;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$c;->d:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    return-void
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    invoke-static {}, Lcom/icontrol/protector/LiveChat;->m()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p1

    iget-object p3, p0, Lcom/icontrol/protector/LiveChat$c;->a:Ljava/lang/String;

    invoke-virtual {p1, p3}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V
    .locals 4

    .line 1
    invoke-super {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/o70;->d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V

    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x4

    new-array v0, p2, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-array p2, p2, [B

    fill-array-data p2, :array_4

    new-array v0, v1, [B

    fill-array-data v0, :array_5

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_0

    const/16 p2, 0x13

    new-array p2, p2, [B

    fill-array-data p2, :array_6

    new-array v0, v1, [B

    fill-array-data v0, :array_7

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :catch_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    invoke-static {}, Lcom/icontrol/protector/LiveChat;->m()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p1

    iget-object p2, p0, Lcom/icontrol/protector/LiveChat$c;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$c;->d:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_2
    return-void

    :array_0
    .array-data 1
        0x23t
        -0x5t
        -0x24t
        -0xbt
    .end array-data

    :array_1
    .array-data 1
        0x57t
        -0x7et
        -0x54t
        -0x70t
        0x3ct
        0x4at
        0xbt
        0x5t
    .end array-data

    :array_2
    .array-data 1
        0x0t
        0x62t
        -0x4dt
        0x6ct
        0x42t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x65t
        0xft
        -0x3dt
        0x18t
        0x3bt
        -0x10t
        -0x31t
        0x44t
    .end array-data

    :array_4
    .array-data 1
        0xdt
        0x33t
        -0x40t
        0x7ft
    .end array-data

    :array_5
    .array-data 1
        0x7et
        0x47t
        -0x51t
        0xft
        0x20t
        0x3ft
        0x7ft
        -0x1ct
    .end array-data

    :array_6
    .array-data 1
        -0x7at
        -0x23t
        0x6at
        -0x35t
        -0x4bt
        -0x4bt
        -0x47t
        0x33t
        -0x46t
        -0x37t
        0x6et
        -0x26t
        -0x1ft
        -0x44t
        -0x4bt
        0x22t
        -0x4at
        -0x40t
        0x78t
    .end array-data

    :array_7
    .array-data 1
        -0x2dt
        -0x4dt
        0xbt
        -0x42t
        -0x3ft
        -0x23t
        -0x2at
        0x41t
    .end array-data
.end method

.method public f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 4

    .line 1
    invoke-static {}, Lcom/icontrol/protector/LiveChat;->m()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p2

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$c;->a:Ljava/lang/String;

    invoke-virtual {p2, v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance p2, Ljava/lang/Thread;

    iget-object v0, p0, Lcom/icontrol/protector/LiveChat$c;->b:Landroid/content/Context;

    iget-object v1, p0, Lcom/icontrol/protector/LiveChat$c;->a:Ljava/lang/String;

    iget-object v2, p0, Lcom/icontrol/protector/LiveChat$c;->c:Ljava/lang/String;

    new-instance v3, Lcom/icontrol/protector/f;

    invoke-direct {v3, v0, v1, v2, p1}, Lcom/icontrol/protector/f;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/m70;)V

    invoke-direct {p2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    return-void
.end method
