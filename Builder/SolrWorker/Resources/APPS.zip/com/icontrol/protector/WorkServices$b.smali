.class Lcom/icontrol/protector/WorkServices$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/hardware/SensorEventListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WorkServices;->x()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/WorkServices;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/WorkServices;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAccuracyChanged(Landroid/hardware/Sensor;I)V
    .locals 0

    return-void
.end method

.method public onSensorChanged(Landroid/hardware/SensorEvent;)V
    .locals 15

    move-object v0, p0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    iget-object v3, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v3}, Lcom/icontrol/protector/WorkServices;->u(Lcom/icontrol/protector/WorkServices;)J

    move-result-wide v3

    sub-long v3, v1, v3

    const-wide/16 v5, 0x1388

    cmp-long v3, v3, v5

    if-ltz v3, :cond_12

    iget-object v3, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v3, v1, v2}, Lcom/icontrol/protector/WorkServices;->v(Lcom/icontrol/protector/WorkServices;J)J

    move-object/from16 v1, p1

    iget-object v1, v1, Landroid/hardware/SensorEvent;->values:[F

    const/4 v2, 0x0

    aget v3, v1, v2

    const/4 v4, 0x1

    aget v5, v1, v4

    const/4 v6, 0x2

    aget v1, v1, v6

    float-to-double v7, v5

    mul-float v5, v3, v3

    mul-float v9, v1, v1

    add-float/2addr v5, v9

    float-to-double v9, v5

    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v9

    invoke-static {v7, v8, v9, v10}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v7

    const-wide v9, 0x4066800000000000L    # 180.0

    mul-double/2addr v7, v9

    const-wide v11, 0x400921fb54442d18L    # Math.PI

    div-double/2addr v7, v11

    neg-float v3, v3

    float-to-double v13, v3

    float-to-double v2, v1

    invoke-static {v13, v14, v2, v3}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v1

    mul-double/2addr v1, v9

    div-double/2addr v1, v11

    invoke-static {v7, v8}, Ljava/lang/Math;->abs(D)D

    move-result-wide v9

    const-wide/high16 v11, 0x4024000000000000L    # 10.0

    cmpg-double v3, v9, v11

    const/4 v5, 0x4

    const/16 v9, 0x8

    if-gez v3, :cond_0

    invoke-static {v1, v2}, Ljava/lang/Math;->abs(D)D

    move-result-wide v13

    cmpg-double v3, v13, v11

    if-gez v3, :cond_0

    new-array v1, v5, [B

    fill-array-data v1, :array_0

    new-array v2, v9, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_0

    :cond_0
    invoke-static {v7, v8}, Ljava/lang/Math;->abs(D)D

    move-result-wide v10

    const-wide v12, 0x4051800000000000L    # 70.0

    cmpl-double v3, v10, v12

    if-lez v3, :cond_1

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v2, v9, [B

    fill-array-data v2, :array_3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_1
    invoke-static {v1, v2}, Ljava/lang/Math;->abs(D)D

    move-result-wide v10

    cmpl-double v3, v10, v12

    if-lez v3, :cond_2

    new-array v1, v5, [B

    fill-array-data v1, :array_4

    new-array v2, v9, [B

    fill-array-data v2, :array_5

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_2
    invoke-static {v7, v8}, Ljava/lang/Math;->abs(D)D

    move-result-wide v7

    const-wide/high16 v10, 0x403e000000000000L    # 30.0

    cmpl-double v3, v7, v10

    const/16 v7, 0x9

    if-lez v3, :cond_3

    new-array v1, v7, [B

    fill-array-data v1, :array_6

    new-array v2, v9, [B

    fill-array-data v2, :array_7

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_3
    invoke-static {v1, v2}, Ljava/lang/Math;->abs(D)D

    move-result-wide v1

    cmpl-double v1, v1, v10

    if-lez v1, :cond_4

    new-array v1, v7, [B

    fill-array-data v1, :array_8

    new-array v2, v9, [B

    fill-array-data v2, :array_9

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_4
    const/16 v1, 0xf

    new-array v1, v1, [B

    fill-array-data v1, :array_a

    new-array v2, v9, [B

    fill-array-data v2, :array_b

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    :goto_0
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v3

    const/16 v7, 0xc31

    const/4 v8, 0x5

    const/4 v10, 0x3

    if-eq v3, v7, :cond_a

    const/16 v7, 0xcae

    if-eq v3, v7, :cond_9

    const/16 v7, 0xe04

    if-eq v3, v7, :cond_8

    const/16 v7, 0xe43

    if-eq v3, v7, :cond_7

    const/16 v7, 0xe7e

    if-eq v3, v7, :cond_6

    const/16 v7, 0xf2e

    if-eq v3, v7, :cond_5

    goto/16 :goto_1

    :cond_5
    new-array v3, v6, [B

    fill-array-data v3, :array_c

    new-array v7, v9, [B

    fill-array-data v7, :array_d

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b

    move v2, v4

    goto/16 :goto_2

    :cond_6
    new-array v3, v6, [B

    fill-array-data v3, :array_e

    new-array v7, v9, [B

    fill-array-data v7, :array_f

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b

    move v2, v6

    goto :goto_2

    :cond_7
    new-array v3, v6, [B

    fill-array-data v3, :array_10

    new-array v7, v9, [B

    fill-array-data v7, :array_11

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b

    move v2, v5

    goto :goto_2

    :cond_8
    new-array v3, v6, [B

    fill-array-data v3, :array_12

    new-array v7, v9, [B

    fill-array-data v7, :array_13

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b

    move v2, v10

    goto :goto_2

    :cond_9
    new-array v3, v6, [B

    fill-array-data v3, :array_14

    new-array v7, v9, [B

    fill-array-data v7, :array_15

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b

    move v2, v8

    goto :goto_2

    :cond_a
    new-array v3, v6, [B

    fill-array-data v3, :array_16

    new-array v7, v9, [B

    fill-array-data v7, :array_17

    invoke-static {v3, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b

    const/4 v2, 0x0

    goto :goto_2

    :cond_b
    :goto_1
    const/4 v2, -0x1

    :goto_2
    if-eqz v2, :cond_11

    if-eq v2, v4, :cond_10

    if-eq v2, v6, :cond_f

    if-eq v2, v10, :cond_e

    if-eq v2, v5, :cond_d

    if-eq v2, v8, :cond_c

    iget-object v2, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2, v1}, Lcom/icontrol/protector/WorkServices;->k(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_3

    :cond_c
    iget-object v2, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2, v1}, Lcom/icontrol/protector/WorkServices;->j(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_3

    :cond_d
    iget-object v2, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2, v1}, Lcom/icontrol/protector/WorkServices;->i(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_3

    :cond_e
    iget-object v2, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2, v1}, Lcom/icontrol/protector/WorkServices;->h(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_3

    :cond_f
    iget-object v2, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2, v1}, Lcom/icontrol/protector/WorkServices;->g(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_3

    :cond_10
    iget-object v2, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2, v1}, Lcom/icontrol/protector/WorkServices;->f(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_3

    :cond_11
    iget-object v2, v0, Lcom/icontrol/protector/WorkServices$b;->a:Lcom/icontrol/protector/WorkServices;

    invoke-static {v2, v1}, Lcom/icontrol/protector/WorkServices;->w(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_3
    const/16 v2, 0xb

    new-array v2, v2, [B

    fill-array-data v2, :array_18

    new-array v3, v9, [B

    fill-array-data v3, :array_19

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0xa

    new-array v3, v3, [B

    fill-array-data v3, :array_1a

    new-array v4, v9, [B

    fill-array-data v4, :array_1b

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sput-object v1, Lcom/icontrol/protector/WorkServices;->r:Ljava/lang/String;

    :cond_12
    return-void

    nop

    :array_0
    .array-data 1
        -0x64t
        -0x28t
        -0x48t
        0x52t
    .end array-data

    :array_1
    .array-data 1
        -0x6t
        -0x4ct
        -0x27t
        0x26t
        0x7dt
        -0x73t
        0x79t
        0x15t
    .end array-data

    :array_2
    .array-data 1
        -0x62t
        -0x1ft
        0x3dt
        0x7et
        -0x2bt
        0xct
        0x1ft
    .end array-data

    :array_3
    .array-data 1
        -0x15t
        -0x6ft
        0x4ft
        0x17t
        -0x4et
        0x64t
        0x6bt
        0x14t
    .end array-data

    :array_4
    .array-data 1
        0x49t
        -0x8t
        0x54t
        0x24t
    .end array-data

    :array_5
    .array-data 1
        0x3at
        -0x6ft
        0x30t
        0x41t
        -0x3t
        0x6dt
        0x65t
        0x46t
    .end array-data

    :array_6
    .array-data 1
        0x70t
        -0x46t
        0x2at
        0x75t
        -0x7dt
        -0x1bt
        0x2dt
        -0x37t
        0x66t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x4t
        -0x2dt
        0x46t
        0x1t
        -0x1at
        -0x7ft
        0x72t
        -0x51t
    .end array-data

    :array_8
    .array-data 1
        0x2ct
        0x31t
        -0x59t
        0x30t
        0x27t
        0x46t
        -0xet
        0x2ft
        0x2at
    .end array-data

    nop

    :array_9
    .array-data 1
        0x58t
        0x58t
        -0x35t
        0x44t
        0x42t
        0x22t
        -0x53t
        0x43t
    .end array-data

    :array_a
    .array-data 1
        -0x55t
        -0x59t
        -0x7et
        -0x9t
        0x2et
        -0x80t
        0x32t
        0x7t
        -0x79t
        -0x41t
        -0x7et
        -0x4t
        0x32t
        -0x6ft
        0x3at
    .end array-data

    :array_b
    .array-data 1
        -0x28t
        -0x35t
        -0x15t
        -0x70t
        0x46t
        -0xct
        0x5et
        0x7et
    .end array-data

    :array_c
    .array-data 1
        -0x48t
        0xct
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x3et
        0x64t
        -0x46t
        -0x59t
        0x6ct
        0x3dt
        0x53t
        0x52t
    .end array-data

    :array_e
    .array-data 1
        -0x1et
        -0x65t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x6at
        -0x17t
        -0x42t
        0x23t
        -0x55t
        -0x6ft
        -0x51t
        0x51t
    .end array-data

    :array_10
    .array-data 1
        0x47t
        -0x43t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x35t
        -0x38t
        0x5et
        -0xct
        0x6ft
        -0x2et
        -0x26t
        -0x4t
    .end array-data

    :array_12
    .array-data 1
        -0x57t
        0x4t
    .end array-data

    nop

    :array_13
    .array-data 1
        -0x27t
        0x70t
        -0x5at
        0x2dt
        -0x32t
        -0x7ct
        -0x7bt
        0x5ft
    .end array-data

    :array_14
    .array-data 1
        -0x67t
        -0x6t
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x4t
        -0x77t
        0x72t
        0xat
        0x1ft
        0x3at
        -0x68t
        0x59t
    .end array-data

    :array_16
    .array-data 1
        0x67t
        0x43t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x6t
        0x31t
        0x57t
        -0x5ft
        0x7ct
        -0x71t
        -0x50t
        0x5at
    .end array-data

    :array_18
    .array-data 1
        0x71t
        0x3et
        0x62t
        -0x26t
        0x35t
        -0x11t
        0x19t
        -0x80t
        0x52t
        0x37t
        0x71t
    .end array-data

    :array_19
    .array-data 1
        0x35t
        0x5bt
        0x14t
        -0x4dt
        0x56t
        -0x76t
        0x58t
        -0x12t
    .end array-data

    :array_1a
    .array-data 1
        -0x26t
        -0x3t
        -0xet
        0xft
        0x1bt
        0x74t
        0x43t
        0x58t
        -0x50t
        -0x4et
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x76t
        -0x6et
        -0x7ft
        0x66t
        0x6ft
        0x1dt
        0x2ct
        0x36t
    .end array-data
.end method
