.class Lcom/icontrol/protector/Requestinstall$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/Requestinstall;->a()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/Requestinstall;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/Requestinstall;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/Requestinstall$a;->a:Lcom/icontrol/protector/Requestinstall;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    new-instance p1, Landroid/content/Intent;

    const/16 p2, 0x2b

    new-array p2, p2, [B

    fill-array-data p2, :array_0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_1

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    new-array v2, v0, [B

    fill-array-data v2, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/icontrol/protector/Requestinstall$a;->a:Lcom/icontrol/protector/Requestinstall;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-direct {p1, p2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 p2, 0x10000000

    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    iget-object p2, p0, Lcom/icontrol/protector/Requestinstall$a;->a:Lcom/icontrol/protector/Requestinstall;

    const/16 v0, 0x3e9

    invoke-virtual {p2, p1, v0}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void

    nop

    :array_0
    .array-data 1
        0x6ft
        -0x5at
        -0x5ct
        0x1ct
        0x7at
        -0x1et
        -0x11t
        -0x7et
        0x7dt
        -0x53t
        -0x4ct
        0x1at
        0x7ct
        -0x1bt
        -0x14t
        -0x21t
        0x20t
        -0x7bt
        -0x7ft
        0x20t
        0x54t
        -0x34t
        -0x32t
        -0xdt
        0x5bt
        -0x7at
        -0x75t
        0x20t
        0x5at
        -0x24t
        -0x3bt
        -0xdt
        0x4ft
        -0x68t
        -0x70t
        0x31t
        0x46t
        -0x3ct
        -0x22t
        -0x2t
        0x4dt
        -0x73t
        -0x6dt
    .end array-data

    :array_1
    .array-data 1
        0xet
        -0x38t
        -0x40t
        0x6et
        0x15t
        -0x75t
        -0x75t
        -0x54t
    .end array-data

    :array_2
    .array-data 1
        -0x50t
        -0x3dt
        0x4t
        -0x1dt
        -0x4t
        0x74t
        0x1bt
        -0x64t
    .end array-data

    :array_3
    .array-data 1
        -0x40t
        -0x5et
        0x67t
        -0x78t
        -0x63t
        0x13t
        0x7et
        -0x5at
    .end array-data
.end method
