.class Lcom/icontrol/protector/CameraCap$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/CameraCap;->a(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Lcom/icontrol/protector/CameraCap;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/CameraCap;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    iput-object p2, p0, Lcom/icontrol/protector/CameraCap$a;->e:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {v1}, Lntidisestablish/neumonoul/floccinaucinih/ks;-><init>()V

    invoke-static {v0, v1}, Lcom/icontrol/protector/CameraCap;->e(Lcom/icontrol/protector/CameraCap;Lntidisestablish/neumonoul/floccinaucinih/ks;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/CameraCap$a;->f:Lcom/icontrol/protector/CameraCap;

    invoke-static {v1}, Lcom/icontrol/protector/CameraCap;->d(Lcom/icontrol/protector/CameraCap;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object v1

    new-instance v2, Lcom/icontrol/protector/CameraCap$a$a;

    invoke-direct {v2, p0}, Lcom/icontrol/protector/CameraCap$a$a;-><init>(Lcom/icontrol/protector/CameraCap$a;)V

    invoke-virtual {v1, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/CameraCap;->p:Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method
