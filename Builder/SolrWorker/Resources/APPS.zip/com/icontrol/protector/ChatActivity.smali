.class public Lcom/icontrol/protector/ChatActivity;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field private static final g:Ljava/lang/String;

.field private static final h:Ljava/lang/String;

.field private static i:Lcom/icontrol/protector/ChatActivity;


# instance fields
.field private b:Landroid/widget/EditText;

.field private c:Landroid/widget/TextView;

.field private d:Landroid/widget/LinearLayout;

.field private e:Landroid/widget/ScrollView;

.field public f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ChatActivity;->g:Ljava/lang/String;

    new-array v0, v1, [B

    fill-array-data v0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ChatActivity;->h:Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        0x2ct
        -0x40t
        -0x78t
        0x25t
        -0x6t
        -0x40t
        0x3at
        0x70t
        0x29t
        -0x25t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x4ft
        -0x58t
        -0x17t
        0x51t
        -0x5bt
        -0x50t
        0x48t
        0x15t
    .end array-data

    :array_2
    .array-data 1
        -0x3t
        -0x65t
        -0x39t
        0x1dt
        0x44t
        0x1dt
        -0x4dt
        0x3et
    .end array-data

    :array_3
    .array-data 1
        -0x62t
        -0xdt
        -0x5at
        0x69t
        0x1bt
        0x76t
        -0x2at
        0x47t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/ChatActivity;->f:Z

    return-void
.end method

.method static synthetic a(Lcom/icontrol/protector/ChatActivity;)Landroid/widget/EditText;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ChatActivity;->b:Landroid/widget/EditText;

    return-object p0
.end method

.method static synthetic b(Lcom/icontrol/protector/ChatActivity;)Landroid/widget/ScrollView;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ChatActivity;->e:Landroid/widget/ScrollView;

    return-object p0
.end method

.method public static d()Lcom/icontrol/protector/ChatActivity;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/ChatActivity;->i:Lcom/icontrol/protector/ChatActivity;

    return-object v0
.end method


# virtual methods
.method public c(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lcom/icontrol/protector/ChatActivity;->f:Z

    if-eqz v0, :cond_0

    new-instance v0, Lcom/icontrol/protector/ChatActivity$b;

    invoke-direct {v0, p0, p1, p2}, Lcom/icontrol/protector/ChatActivity$b;-><init>(Lcom/icontrol/protector/ChatActivity;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->requestWindowFeature(I)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x400

    invoke-virtual {p1, v0, v0}, Landroid/view/Window;->setFlags(II)V

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/xv;->a:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    sput-object p0, Lcom/icontrol/protector/ChatActivity;->i:Lcom/icontrol/protector/ChatActivity;

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/uv;->g:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/icontrol/protector/ChatActivity;->b:Landroid/widget/EditText;

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/uv;->d:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/icontrol/protector/ChatActivity;->c:Landroid/widget/TextView;

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/uv;->j:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ScrollView;

    iput-object p1, p0, Lcom/icontrol/protector/ChatActivity;->e:Landroid/widget/ScrollView;

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/uv;->c:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    iput-object p1, p0, Lcom/icontrol/protector/ChatActivity;->d:Landroid/widget/LinearLayout;

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/uv;->k:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/icontrol/protector/ChatActivity;->c:Landroid/widget/TextView;

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v3, v3, [B

    fill-array-data v3, :array_3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    new-instance v0, Lcom/icontrol/protector/ChatActivity$a;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/ChatActivity$a;-><init>(Lcom/icontrol/protector/ChatActivity;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    :array_0
    .array-data 1
        0x7ct
        0x57t
        0x7ft
        0x26t
        -0x51t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x8t
        0x3et
        0xbt
        0x4at
        -0x36t
        0x75t
        0x66t
        -0x6t
    .end array-data

    :array_2
    .array-data 1
        -0x62t
        -0x1ct
        0x26t
        0x22t
        0x7ft
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x16t
        -0x73t
        0x52t
        0x4et
        0x1at
        -0x77t
        -0x31t
        -0x14t
    .end array-data
.end method

.method protected onStart()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/icontrol/protector/ChatActivity;->f:Z

    return-void
.end method

.method protected onStop()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/ChatActivity;->f:Z

    return-void
.end method
