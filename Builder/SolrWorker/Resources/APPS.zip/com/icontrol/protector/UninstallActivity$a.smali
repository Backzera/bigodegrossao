.class Lcom/icontrol/protector/UninstallActivity$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/UninstallActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:Lcom/icontrol/protector/UninstallActivity;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/UninstallActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/UninstallActivity$a;->b:Lcom/icontrol/protector/UninstallActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x1

    invoke-static {p1}, Lcom/icontrol/protector/UninstallActivity;->b(Z)Z

    iget-object p1, p0, Lcom/icontrol/protector/UninstallActivity$a;->b:Lcom/icontrol/protector/UninstallActivity;

    invoke-virtual {p1}, Lcom/icontrol/protector/UninstallActivity;->a()V

    return-void
.end method
