.class Lcom/icontrol/protector/WebBrowser$a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WebBrowser$a;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lcom/icontrol/protector/WebBrowser$a;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/WebBrowser$a;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser$a$a;->e:Lcom/icontrol/protector/WebBrowser$a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser$a$a;->e:Lcom/icontrol/protector/WebBrowser$a;

    iget-object v1, v0, Lcom/icontrol/protector/WebBrowser$a;->e:Landroid/content/Context;

    iget-object v0, v0, Lcom/icontrol/protector/WebBrowser$a;->f:Landroid/webkit/WebView;

    invoke-static {v1, v0}, Lcom/icontrol/protector/WebBrowser;->a(Landroid/content/Context;Landroid/webkit/WebView;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method
