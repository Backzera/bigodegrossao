.class public Lcom/icontrol/protector/wakeitaiv;
.super Landroid/app/Activity;
.source "SourceFile"


# instance fields
.field b:Landroid/os/PowerManager$WakeLock;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/icontrol/protector/wakeitaiv;->b:Landroid/os/PowerManager$WakeLock;

    return-void
.end method


# virtual methods
.method public finish()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const v0, 0x280001

    const/high16 v1, 0x280000

    invoke-virtual {p1, v0, v1}, Landroid/view/Window;->setFlags(II)V

    new-instance p1, Landroid/view/View;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    const p1, 0x1020002

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setKeepScreenOn(Z)V

    const/4 p1, 0x5

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/PowerManager;

    iget-object v2, p0, Lcom/icontrol/protector/wakeitaiv;->b:Landroid/os/PowerManager$WakeLock;

    if-nez v2, :cond_0

    new-array v0, v0, [B

    const/4 v2, 0x0

    const/16 v3, -0x36

    aput-byte v3, v0, v2

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const v1, 0x3000001a

    invoke-virtual {p1, v1, v0}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object p1

    iput-object p1, p0, Lcom/icontrol/protector/wakeitaiv;->b:Landroid/os/PowerManager$WakeLock;

    :cond_0
    iget-object p1, p0, Lcom/icontrol/protector/wakeitaiv;->b:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result p1

    if-nez p1, :cond_1

    iget-object p1, p0, Lcom/icontrol/protector/wakeitaiv;->b:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->acquire()V

    :cond_1
    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    new-instance v0, Lcom/icontrol/protector/wakeitaiv$a;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/wakeitaiv$a;-><init>(Lcom/icontrol/protector/wakeitaiv;)V

    const-wide/16 v1, 0x64

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    nop

    :array_0
    .array-data 1
        0x16t
        -0x2bt
        0x1at
        0x28t
        -0x3dt
    .end array-data

    nop

    :array_1
    .array-data 1
        0x66t
        -0x46t
        0x6dt
        0x4dt
        -0x4ft
        -0x7dt
        0x1bt
        -0x4at
    .end array-data

    :array_2
    .array-data 1
        -0x10t
        -0x2ct
        -0x77t
        0x68t
        0x53t
        -0x6dt
        -0x2ft
        -0x3ct
    .end array-data
.end method
