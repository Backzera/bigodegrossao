.class public abstract Lcom/icontrol/protector/l;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/l;->a:Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        0x26t
        -0x73t
        0x27t
        0x50t
        0x14t
        -0x3at
        -0x38t
        -0x45t
        0x2ct
        -0x66t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x62t
        -0x21t
        0x62t
        0x17t
        0x4bt
        -0x6at
        -0x80t
        -0xct
    .end array-data
.end method

.method public static a(Landroid/content/Context;)Ljava/util/ArrayList;
    .locals 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/16 v1, 0x17

    invoke-static {v1}, Lcom/icontrol/protector/l;->b(I)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0x1e

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/SubscriptionManager;

    if-eqz v1, :cond_3

    const/16 v3, 0x23

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v2, v2, [B

    fill-array-data v2, :array_3

    invoke-static {v3, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v2}, Lntidisestablish/neumonoul/floccinaucinih/db;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-virtual {v1}, Landroid/telephony/SubscriptionManager;->getActiveSubscriptionInfoList()Ljava/util/List;

    move-result-object p0

    if-eqz p0, :cond_3

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/telephony/SubscriptionInfo;

    const/16 v3, 0x21

    invoke-static {v3}, Lcom/icontrol/protector/l;->b(I)Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-virtual {v2}, Landroid/telephony/SubscriptionInfo;->getSubscriptionId()I

    move-result v2

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/gt;->a(Landroid/telephony/SubscriptionManager;I)Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    :cond_2
    invoke-virtual {v2}, Landroid/telephony/SubscriptionInfo;->getNumber()Ljava/lang/String;

    move-result-object v2

    :goto_1
    if-eqz v2, :cond_1

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    return-object v0

    nop

    :array_0
    .array-data 1
        -0x42t
        -0x73t
        -0x2ct
        -0x50t
        -0x41t
        0x5ft
        0x43t
        -0x5t
        -0x4dt
        -0x49t
        -0x35t
        -0x60t
        -0x53t
        0x44t
        0x4ft
        -0x19t
        -0x5dt
        -0x68t
        -0x34t
        -0x44t
        -0x60t
        0x59t
        0x73t
        -0x1at
        -0x51t
        -0x66t
        -0x32t
        -0x44t
        -0x54t
        0x52t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x36t
        -0x18t
        -0x48t
        -0x2bt
        -0x31t
        0x37t
        0x2ct
        -0x6bt
    .end array-data

    :array_2
    .array-data 1
        -0x6ft
        -0x4ct
        -0x3et
        -0x7ft
        0x40t
        -0x12t
        0x4at
        -0x37t
        -0x80t
        -0x41t
        -0x2ct
        -0x62t
        0x46t
        -0xct
        0x5dt
        -0x72t
        -0x61t
        -0x4ct
        -0x78t
        -0x5ft
        0x6at
        -0x3at
        0x6at
        -0x48t
        -0x60t
        -0x6et
        -0x17t
        -0x43t
        0x6at
        -0x28t
        0x7dt
        -0x4dt
        -0x4ft
        -0x72t
        -0x1dt
    .end array-data

    :array_3
    .array-data 1
        -0x10t
        -0x26t
        -0x5at
        -0xdt
        0x2ft
        -0x79t
        0x2et
        -0x19t
    .end array-data
.end method

.method private static b(I)Z
    .locals 1

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static c(Landroid/content/Context;)V
    .locals 1

    .line 1
    new-instance v0, Lcom/icontrol/protector/l$a;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/l$a;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method
