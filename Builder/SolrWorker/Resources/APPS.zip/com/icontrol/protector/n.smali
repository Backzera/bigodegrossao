.class public abstract Lcom/icontrol/protector/n;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static a:I = 0x19f

.field private static b:Ljava/util/Random; = null

.field static c:Ljava/util/Random; = null

.field private static d:Ljava/lang/String; = ""


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public static A(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Landroid/content/IntentFilter;

    const/16 v1, 0x25

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0

    const/4 v0, 0x5

    new-array v1, v0, [B

    fill-array-data v1, :array_2

    new-array v3, v2, [B

    fill-array-data v3, :array_3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    invoke-virtual {p0, v1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v2, v2, [B

    fill-array-data v2, :array_5

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x64

    invoke-virtual {p0, v0, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    mul-int/2addr v1, v2

    div-int/2addr v1, p0

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :array_0
    .array-data 1
        0x5dt
        0x76t
        -0x39t
        0x7bt
        0x32t
        -0x45t
        0x68t
        -0x53t
        0x55t
        0x76t
        -0x29t
        0x6ct
        0x33t
        -0x5at
        0x22t
        -0x1et
        0x5ft
        0x6ct
        -0x36t
        0x66t
        0x33t
        -0x4t
        0x4et
        -0x3et
        0x68t
        0x4ct
        -0x1at
        0x5bt
        0x4t
        -0x73t
        0x4ft
        -0x35t
        0x7dt
        0x56t
        -0x1ct
        0x4ct
        0x19t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x3ct
        0x18t
        -0x5dt
        0x9t
        0x5dt
        -0x2et
        0xct
        -0x7dt
    .end array-data

    :array_2
    .array-data 1
        0x7et
        -0x71t
        -0x59t
        -0x46t
        0x43t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x12t
        -0x16t
        -0x2ft
        -0x21t
        0x2ft
        0x1ft
        -0x9t
        -0x77t
    .end array-data

    :array_4
    .array-data 1
        0x14t
        0x27t
        0x75t
        0x72t
        -0x39t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x67t
        0x44t
        0x14t
        0x1et
        -0x5et
        -0x56t
        0x6dt
        -0x1et
    .end array-data
.end method

.method public static B()Landroid/app/Activity;
    .locals 8

    .line 1
    const/16 v0, 0x1a

    const/4 v1, 0x0

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/16 v3, 0x15

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    new-array v5, v4, [Ljava/lang/Class;

    invoke-virtual {v0, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    new-array v4, v4, [Ljava/lang/Object;

    invoke-virtual {v3, v1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/16 v4, 0xb

    new-array v4, v4, [B

    fill-array-data v4, :array_4

    new-array v5, v2, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v4, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v0, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    const/4 v6, 0x6

    new-array v6, v6, [B

    fill-array-data v6, :array_6

    new-array v7, v2, [B

    fill-array-data v7, :array_7

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v6, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-nez v6, :cond_0

    new-array v0, v2, [B

    fill-array-data v0, :array_8

    new-array v2, v2, [B

    fill-array-data v2, :array_9

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v0, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Activity;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    return-object v1

    nop

    :array_0
    .array-data 1
        0x26t
        0x5dt
        0x66t
        -0x7dt
        -0x36t
        -0x6dt
        0x7et
        0x14t
        0x26t
        0x43t
        0x72t
        -0x21t
        -0x1ct
        -0x67t
        0x6et
        0x53t
        0x31t
        0x5at
        0x76t
        -0x78t
        -0xft
        -0x6et
        0x68t
        0x5ft
        0x26t
        0x57t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x47t
        0x33t
        0x2t
        -0xft
        -0x5bt
        -0x6t
        0x1at
        0x3at
    .end array-data

    :array_2
    .array-data 1
        0x5et
        0x20t
        -0x5t
        -0x2ct
        0x6dt
        0x10t
        -0x42t
        -0x67t
        0x5et
        0x21t
        -0x20t
        -0x30t
        0x61t
        0xat
        -0x4dt
        -0x74t
        0x55t
        0x27t
        -0x14t
        -0x39t
        0x6ct
    .end array-data

    nop

    :array_3
    .array-data 1
        0x3dt
        0x55t
        -0x77t
        -0x5at
        0x8t
        0x7et
        -0x36t
        -0x28t
    .end array-data

    :array_4
    .array-data 1
        -0x37t
        0x56t
        -0x1ft
        0x48t
        -0x1bt
        -0x6ct
        0x60t
        -0x1et
        -0x33t
        0x72t
        -0xft
    .end array-data

    :array_5
    .array-data 1
        -0x5ct
        0x17t
        -0x7et
        0x3ct
        -0x74t
        -0x1et
        0x9t
        -0x6at
    .end array-data

    :array_6
    .array-data 1
        0x5bt
        0x62t
        -0x36t
        0x10t
        -0x67t
        -0x79t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x2bt
        0x3t
        -0x41t
        0x63t
        -0x4t
        -0x1dt
        -0x7et
        0x77t
    .end array-data

    :array_8
    .array-data 1
        0x3ft
        0x72t
        0x5bt
        -0x27t
        0x76t
        -0x24t
        0x5at
        -0x7bt
    .end array-data

    :array_9
    .array-data 1
        0x5et
        0x11t
        0x2ft
        -0x50t
        0x0t
        -0x4bt
        0x2et
        -0x4t
    .end array-data
.end method

.method public static C(Ljava/lang/String;Landroid/content/Context;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    const/4 v0, 0x0

    invoke-static {p0, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    array-length v1, p0

    invoke-static {p0, v0, v1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object p0

    new-instance v0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-direct {v0, p1, p0}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    return-object v0
.end method

.method public static D()Ljava/lang/String;
    .locals 5

    .line 1
    const/16 v0, 0x8

    :try_start_0
    new-instance v1, Ljava/net/URL;

    const/16 v2, 0x1c

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    new-array v3, v0, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    const/4 v2, 0x0

    :try_start_1
    new-instance v3, Ljava/io/BufferedReader;

    new-instance v4, Ljava/io/InputStreamReader;

    invoke-virtual {v1}, Ljava/net/URL;->openStream()Ljava/io/InputStream;

    move-result-object v1

    invoke-direct {v4, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v3, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_0

    :catch_0
    move-exception v2

    :try_start_4
    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    :goto_0
    return-object v1

    :catchall_0
    move-exception v1

    move-object v2, v3

    goto :goto_1

    :catchall_1
    move-exception v1

    :goto_1
    if-eqz v2, :cond_0

    :try_start_5
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_1
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    goto :goto_2

    :catch_1
    move-exception v2

    :try_start_6
    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_2
    throw v1
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    :catch_2
    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_0
    .array-data 1
        0x41t
        0x31t
        -0x6bt
        -0x11t
        0x69t
        -0x72t
        -0x54t
        -0x7dt
        0x41t
        0x20t
        -0x7et
        -0xct
        0x3at
        -0x2ft
        -0x53t
        -0x7ft
        0x44t
        0x24t
        -0x65t
        -0x10t
        0x3dt
        -0x40t
        -0xct
        -0x6dt
        0x7t
        0x26t
        -0x72t
        -0xet
    .end array-data

    :array_1
    .array-data 1
        0x29t
        0x45t
        -0x1ft
        -0x61t
        0x53t
        -0x5ft
        -0x7dt
        -0x20t
    .end array-data

    :array_2
    .array-data 1
        0x1at
        0x2t
        0x70t
        0x2at
    .end array-data

    :array_3
    .array-data 1
        0x74t
        0x77t
        0x1ct
        0x46t
        -0x3ct
        0x4t
        0x28t
        0x4at
    .end array-data
.end method

.method public static E(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    .line 1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v2, 0x80

    invoke-virtual {v1, p0, v2}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object p0

    check-cast p0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    const-string p0, ""

    return-object p0
.end method

.method public static F(Landroid/content/Context;)Ljava/util/List;
    .locals 5

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Landroid/content/Intent;

    const/16 v2, 0x1a

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x20

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v3, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/pm/ResolveInfo;

    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v1, v1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-object v0

    nop

    :array_0
    .array-data 1
        0x22t
        -0x51t
        0x22t
        0x7ct
        -0x9t
        0x5ft
        -0x73t
        -0x1ft
        0x2at
        -0x51t
        0x32t
        0x6bt
        -0xat
        0x42t
        -0x39t
        -0x52t
        0x20t
        -0x4bt
        0x2ft
        0x61t
        -0xat
        0x18t
        -0x5ct
        -0x72t
        0xat
        -0x71t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x43t
        -0x3ft
        0x46t
        0xet
        -0x68t
        0x36t
        -0x17t
        -0x31t
    .end array-data

    :array_2
    .array-data 1
        -0x7ft
        0x76t
        -0x71t
        0x69t
        0x47t
        -0x7t
        -0x60t
        -0x71t
        -0x77t
        0x76t
        -0x61t
        0x7et
        0x46t
        -0x1ct
        -0x16t
        -0x3et
        -0x7ft
        0x6ct
        -0x72t
        0x7ct
        0x47t
        -0x1et
        -0x43t
        -0x71t
        -0x54t
        0x59t
        -0x42t
        0x55t
        0x6bt
        -0x28t
        -0x7ft
        -0xdt
    .end array-data

    :array_3
    .array-data 1
        -0x20t
        0x18t
        -0x15t
        0x1bt
        0x28t
        -0x70t
        -0x3ct
        -0x5ft
    .end array-data
.end method

.method public static G(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v1, 0x10

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x2

    new-array v1, v0, [B

    fill-array-data v1, :array_2

    new-array v3, v2, [B

    fill-array-data v3, :array_3

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v3

    invoke-virtual {v3, p0}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object p0

    new-instance v3, Ljava/io/BufferedReader;

    new-instance v4, Ljava/io/InputStreamReader;

    invoke-virtual {p0}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v3, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    :try_start_1
    invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_1

    const/4 v5, 0x5

    new-array v6, v5, [B

    fill-array-data v6, :array_4

    new-array v7, v2, [B

    fill-array-data v7, :array_5

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_0

    new-array v5, v5, [B

    fill-array-data v5, :array_6

    new-array v6, v2, [B

    fill-array-data v6, :array_7

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    aget-object v4, v4, v5

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    aget-object v4, v4, v5

    new-array v0, v0, [B

    fill-array-data v0, :array_8

    new-array v2, v2, [B

    fill-array-data v2, :array_9

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const-string v2, ""

    invoke-virtual {v4, v0, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    :goto_0
    invoke-virtual {p0}, Ljava/lang/Process;->destroy()V

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-lez p0, :cond_2

    :try_start_2
    invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V

    return-object v1

    :catch_0
    move-exception p0

    goto :goto_3

    :cond_2
    invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    return-object v1

    :goto_1
    :try_start_3
    invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v0

    :try_start_4
    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw p0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    :goto_3
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    return-object v1

    :array_0
    .array-data 1
        0x1bt
        0x51t
        0x69t
        0x62t
        0x4bt
        0x6at
        -0x66t
        -0x74t
        0x5at
        0x18t
        0x2at
        0x72t
        0x4bt
        0x76t
        -0x34t
        -0x74t
    .end array-data

    :array_1
    .array-data 1
        0x6bt
        0x38t
        0x7t
        0x5t
        0x6bt
        0x47t
        -0x7t
        -0x54t
    .end array-data

    :array_2
    .array-data 1
        -0x7bt
        -0x68t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x58t
        -0x57t
        0x30t
        0x70t
        0x6ct
        0x3bt
        0x3dt
        -0x42t
    .end array-data

    :array_4
    .array-data 1
        0x3ft
        -0x7at
        0x1bt
        -0x55t
        -0x51t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x4bt
        -0x11t
        0x76t
        -0x32t
        -0x71t
        -0x27t
        -0x7ft
        -0x75t
    .end array-data

    :array_6
    .array-data 1
        -0x3ct
        -0x5et
        0xet
        0x10t
        0x75t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x50t
        -0x35t
        0x63t
        0x75t
        0x55t
        0x62t
        0x18t
        -0x76t
    .end array-data

    :array_8
    .array-data 1
        0x53t
        0xat
    .end array-data

    nop

    :array_9
    .array-data 1
        0x3et
        0x79t
        0x34t
        0x5ct
        -0x69t
        -0x1at
        -0x63t
        -0x57t
    .end array-data
.end method

.method public static H(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Landroid/content/Intent;

    const/16 v3, 0x1a

    new-array v3, v3, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    invoke-direct {v2, v3, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/16 v3, 0x20

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v4, v4, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ResolveInfo;

    iget-object v3, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    if-eqz v3, :cond_0

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    if-eqz v3, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v4, v4, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_0

    :cond_1
    iget-object v2, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v2, v2, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_4

    sget-object p0, Lcom/icontrol/protector/n;->b:Ljava/util/Random;

    if-nez p0, :cond_3

    new-instance p0, Ljava/util/Random;

    invoke-direct {p0}, Ljava/util/Random;-><init>()V

    sput-object p0, Lcom/icontrol/protector/n;->b:Ljava/util/Random;

    :cond_3
    sget-object p0, Lcom/icontrol/protector/n;->b:Ljava/util/Random;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v0

    invoke-virtual {p0, v0}, Ljava/util/Random;->nextInt(I)I

    move-result p0

    invoke-interface {v1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_4
    return-object v5

    nop

    :array_0
    .array-data 1
        -0x7bt
        0x50t
        -0xat
        -0x54t
        -0x77t
        -0x17t
        -0x37t
        0x67t
        -0x73t
        0x50t
        -0x1at
        -0x45t
        -0x78t
        -0xct
        -0x7dt
        0x28t
        -0x79t
        0x4at
        -0x5t
        -0x4ft
        -0x78t
        -0x52t
        -0x20t
        0x8t
        -0x53t
        0x70t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x1ct
        0x3et
        -0x6et
        -0x22t
        -0x1at
        -0x80t
        -0x53t
        0x49t
    .end array-data

    :array_2
    .array-data 1
        0x24t
        0x77t
        -0x53t
        0x76t
        0x78t
        0x5bt
        -0x7bt
        -0x13t
        0x2ct
        0x77t
        -0x43t
        0x61t
        0x79t
        0x46t
        -0x31t
        -0x60t
        0x24t
        0x6dt
        -0x54t
        0x63t
        0x78t
        0x40t
        -0x68t
        -0x13t
        0x9t
        0x58t
        -0x64t
        0x4at
        0x54t
        0x7at
        -0x5ct
        -0x6ft
    .end array-data

    :array_3
    .array-data 1
        0x45t
        0x19t
        -0x37t
        0x4t
        0x17t
        0x32t
        -0x1ft
        -0x3dt
    .end array-data
.end method

.method public static I()Ljava/lang/String;
    .locals 4

    .line 1
    :try_start_0
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/net/NetworkInterface;

    invoke-virtual {v1}, Ljava/net/NetworkInterface;->getInetAddresses()Ljava/util/Enumeration;

    move-result-object v1

    :cond_1
    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/net/InetAddress;

    invoke-virtual {v2}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    move-result v3

    if-nez v3, :cond_1

    instance-of v3, v2, Ljava/net/Inet4Address;

    if-eqz v3, :cond_1

    invoke-virtual {v2}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/net/SocketException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    const/4 v0, 0x0

    return-object v0
.end method

.method public static J(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    .line 1
    invoke-static {p0}, Landroid/telephony/SubscriptionManager;->from(Landroid/content/Context;)Landroid/telephony/SubscriptionManager;

    move-result-object v0

    const/16 v1, 0x23

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/db;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    new-array p0, v3, [B

    fill-array-data p0, :array_2

    new-array v0, v2, [B

    fill-array-data v0, :array_3

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-virtual {v0}, Landroid/telephony/SubscriptionManager;->getActiveSubscriptionInfoCount()I

    move-result v1

    const/4 v4, 0x1

    if-le v1, v4, :cond_1

    invoke-virtual {v0}, Landroid/telephony/SubscriptionManager;->getActiveSubscriptionInfoList()Ljava/util/List;

    move-result-object p0

    const/4 v0, 0x0

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/SubscriptionInfo;

    invoke-interface {p0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/telephony/SubscriptionInfo;

    invoke-virtual {v1}, Landroid/telephony/SubscriptionInfo;->getDisplayName()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Landroid/telephony/SubscriptionInfo;->getDisplayName()Ljava/lang/CharSequence;

    move-result-object p0

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v1, v4, [B

    const/16 v4, -0x79

    aput-byte v4, v1, v0

    new-array v0, v2, [B

    fill-array-data v0, :array_4

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    new-array v0, v3, [B

    fill-array-data v0, :array_5

    new-array v1, v2, [B

    fill-array-data v1, :array_6

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/telephony/TelephonyManager;

    invoke-virtual {p0}, Landroid/telephony/TelephonyManager;->getNetworkOperatorName()Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :array_0
    .array-data 1
        -0x5ct
        -0x79t
        0x7t
        -0x15t
        0x6dt
        0x34t
        0x26t
        -0x36t
        -0x4bt
        -0x74t
        0x11t
        -0xct
        0x6bt
        0x2et
        0x31t
        -0x73t
        -0x56t
        -0x79t
        0x4dt
        -0x35t
        0x47t
        0x1ct
        0x6t
        -0x45t
        -0x6bt
        -0x5ft
        0x2ct
        -0x29t
        0x47t
        0x2t
        0x11t
        -0x50t
        -0x7ct
        -0x43t
        0x26t
    .end array-data

    :array_1
    .array-data 1
        -0x3bt
        -0x17t
        0x63t
        -0x67t
        0x2t
        0x5dt
        0x42t
        -0x1ct
    .end array-data

    :array_2
    .array-data 1
        -0xct
        0x5ct
        0x30t
        0x6at
        -0x33t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x41t
        0x32t
        0x5ft
        0x1dt
        -0x5dt
        0x5ct
        -0x1at
        -0x30t
    .end array-data

    :array_4
    .array-data 1
        -0x58t
        0x5t
        -0x7dt
        0xet
        -0x33t
        0x40t
        -0x27t
        0x34t
    .end array-data

    :array_5
    .array-data 1
        0x2dt
        0x1at
        0x2dt
        0x1bt
        -0x42t
    .end array-data

    nop

    :array_6
    .array-data 1
        0x5dt
        0x72t
        0x42t
        0x75t
        -0x25t
        -0x15t
        0x4ct
        -0x7dt
    .end array-data
.end method

.method public static K(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    .line 1
    const/16 v0, 0x8

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v2, 0x1000

    invoke-virtual {v1, p0, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    iget-wide v1, p0, Landroid/content/pm/PackageInfo;->firstInstallTime:J

    new-instance p0, Ljava/util/Date;

    invoke-direct {p0, v1, v2}, Ljava/util/Date;-><init>(J)V

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/16 v2, 0xa

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    new-array v3, v0, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    invoke-virtual {v1, p0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    const/16 p0, 0x9

    new-array p0, p0, [B

    fill-array-data p0, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :array_0
    .array-data 1
        -0x3t
        -0x6t
        -0x80t
        0x6ft
        0x0t
        0x4t
        -0x60t
        -0x30t
        -0x20t
        -0x19t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x7ct
        -0x7dt
        -0x7t
        0x16t
        0x2dt
        0x49t
        -0x13t
        -0x3t
    .end array-data

    :array_2
    .array-data 1
        -0x5et
        -0x1et
        0x6at
        0x6t
        0x27t
        0x21t
        -0x3ct
        0x2t
        -0x78t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x14t
        -0x73t
        0x1et
        0x26t
        0x61t
        0x4et
        -0x4ft
        0x6ct
    .end array-data
.end method

.method public static L(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Landroid/content/IntentFilter;

    const/16 v1, 0x25

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0

    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v1, v2, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v1, -0x1

    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eq p0, v1, :cond_1

    const/4 v3, 0x2

    if-ne p0, v3, :cond_0

    goto :goto_0

    :cond_0
    new-array p0, v1, [B

    const/16 v1, -0x70

    aput-byte v1, p0, v0

    new-array v0, v2, [B

    fill-array-data v0, :array_4

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_1
    :goto_0
    new-array p0, v1, [B

    const/4 v1, -0x6

    aput-byte v1, p0, v0

    new-array v0, v2, [B

    fill-array-data v0, :array_5

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    :goto_1
    return-object p0

    nop

    :array_0
    .array-data 1
        -0x7ft
        -0x75t
        -0x1et
        0x5ct
        0x6at
        0x29t
        0x1bt
        -0x9t
        -0x77t
        -0x75t
        -0xet
        0x4bt
        0x6bt
        0x34t
        0x51t
        -0x48t
        -0x7dt
        -0x6ft
        -0x11t
        0x41t
        0x6bt
        0x6et
        0x3dt
        -0x68t
        -0x4ct
        -0x4ft
        -0x3dt
        0x7ct
        0x5ct
        0x1ft
        0x3ct
        -0x6ft
        -0x5ft
        -0x55t
        -0x3ft
        0x6bt
        0x41t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x20t
        -0x1bt
        -0x7at
        0x2et
        0x5t
        0x40t
        0x7ft
        -0x27t
    .end array-data

    :array_2
    .array-data 1
        -0x60t
        -0x4ft
        -0x39t
        -0x3ct
        0x14t
        0x10t
        0x2t
    .end array-data

    :array_3
    .array-data 1
        -0x30t
        -0x23t
        -0x4et
        -0x5dt
        0x73t
        0x75t
        0x66t
        0x1bt
    .end array-data

    :array_4
    .array-data 1
        -0xat
        -0x62t
        -0x76t
        -0x59t
        0x71t
        0x79t
        -0x19t
        0xbt
    .end array-data

    :array_5
    .array-data 1
        -0x72t
        0x3et
        0x45t
        0x7dt
        0x20t
        0x4at
        -0x78t
        -0x6t
    .end array-data
.end method

.method public static M()Z
    .locals 3

    .line 1
    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0

    :array_0
    .array-data 1
        0x3bt
        0x1at
        -0x64t
        0xet
        -0x13t
        -0x11t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x5ct
        0x75t
        -0xdt
        0x69t
        -0x7ft
        -0x76t
        0x5at
        -0x28t
    .end array-data
.end method

.method private static N(Landroid/content/Context;Landroid/content/Intent;)Z
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/high16 v0, 0x10000

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static O(Landroid/content/Context;)Z
    .locals 8

    .line 1
    new-instance v0, Landroid/content/Intent;

    const/16 v1, 0x20

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v1, 0x1f

    new-array v3, v1, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/icontrol/protector/n;->N(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v0

    if-nez v0, :cond_1

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    new-instance v3, Landroid/content/ComponentName;

    const/16 v4, 0x17

    new-array v5, v4, [B

    fill-array-data v5, :array_4

    new-array v6, v2, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x39

    new-array v6, v6, [B

    fill-array-data v6, :array_6

    new-array v7, v2, [B

    fill-array-data v7, :array_7

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v3, v5, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/icontrol/protector/n;->N(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v0

    if-nez v0, :cond_1

    new-instance v0, Landroid/content/Intent;

    const/16 v3, 0x2b

    new-array v3, v3, [B

    fill-array-data v3, :array_8

    new-array v5, v2, [B

    fill-array-data v5, :array_9

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-array v1, v1, [B

    fill-array-data v1, :array_a

    new-array v3, v2, [B

    fill-array-data v3, :array_b

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/icontrol/protector/n;->N(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v0

    if-nez v0, :cond_1

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    new-instance v1, Landroid/content/ComponentName;

    new-array v3, v4, [B

    fill-array-data v3, :array_c

    new-array v4, v2, [B

    fill-array-data v4, :array_d

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x22

    new-array v4, v4, [B

    fill-array-data v4, :array_e

    new-array v2, v2, [B

    fill-array-data v2, :array_f

    invoke-static {v4, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v3, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/icontrol/protector/n;->N(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0

    nop

    :array_0
    .array-data 1
        -0x17t
        -0x4dt
        -0x7bt
        -0x51t
        0x1ct
        0x54t
        0x5dt
        0x16t
        -0x1ft
        -0x4ct
        -0x7ct
        -0x18t
        0x53t
        0x5et
        0x47t
        0xbt
        -0x15t
        -0x4ct
        -0x22t
        -0x77t
        0x62t
        0x62t
        0x72t
        0x37t
        -0x30t
        -0x6bt
        -0x51t
        -0x6bt
        0x66t
        0x7ct
        0x61t
        0x36t
    .end array-data

    :array_1
    .array-data 1
        -0x7ct
        -0x26t
        -0x10t
        -0x3at
        0x32t
        0x3dt
        0x33t
        0x62t
    .end array-data

    :array_2
    .array-data 1
        0x49t
        0x35t
        -0x4dt
        -0x60t
        0x4ft
        0x35t
        -0x68t
        0x53t
        0x41t
        0x35t
        -0x5dt
        -0x49t
        0x4et
        0x28t
        -0x2et
        0x1et
        0x49t
        0x2ft
        -0x4et
        -0x4bt
        0x4ft
        0x2et
        -0x7bt
        0x53t
        0x6ct
        0x1et
        -0x6ft
        -0x6dt
        0x75t
        0x10t
        -0x58t
    .end array-data

    :array_3
    .array-data 1
        0x28t
        0x5bt
        -0x29t
        -0x2et
        0x20t
        0x5ct
        -0x4t
        0x7dt
    .end array-data

    :array_4
    .array-data 1
        0x47t
        -0x31t
        -0x59t
        -0x61t
        0xft
        0x25t
        0xft
        -0x13t
        0xat
        -0x2dt
        -0x51t
        -0x2et
        0x17t
        0x3et
        0x13t
        -0x10t
        0x5dt
        -0x3dt
        -0x51t
        -0x21t
        0x16t
        0x29t
        0x8t
    .end array-data

    :array_5
    .array-data 1
        0x24t
        -0x60t
        -0x36t
        -0x4ft
        0x62t
        0x4ct
        0x7at
        -0x7ct
    .end array-data

    :array_6
    .array-data 1
        -0x36t
        -0x34t
        -0x29t
        -0x1ct
        -0x2dt
        -0x3ft
        0x3at
        -0x9t
        -0x79t
        -0x2dt
        -0x21t
        -0x48t
        -0x2dt
        -0x35t
        0x2at
        -0x10t
        -0x23t
        -0x3at
        -0x38t
        -0x1ct
        -0x21t
        -0x23t
        0x3bt
        -0xft
        -0x26t
        -0x29t
        -0x25t
        -0x48t
        -0x36t
        -0x7at
        0xet
        -0x15t
        -0x23t
        -0x34t
        -0x17t
        -0x42t
        -0x21t
        -0x26t
        0x3bt
        -0x2dt
        -0x38t
        -0x33t
        -0x25t
        -0x53t
        -0x25t
        -0x3bt
        0x2at
        -0x10t
        -0x23t
        -0x1et
        -0x27t
        -0x42t
        -0x29t
        -0x22t
        0x26t
        -0x16t
        -0x30t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x57t
        -0x5dt
        -0x46t
        -0x36t
        -0x42t
        -0x58t
        0x4ft
        -0x62t
    .end array-data

    :array_8
    .array-data 1
        0x1ct
        0x79t
        0x17t
        0x69t
        -0x3et
        0x1ct
        -0x7ct
        -0x2t
        0x14t
        0x7et
        0x16t
        0x2et
        -0x73t
        0x16t
        -0x62t
        -0x1dt
        0x1et
        0x7et
        0x4ct
        0x50t
        -0x5dt
        0x22t
        -0x51t
        -0x28t
        0x2et
        0x58t
        0x2bt
        0x44t
        -0x57t
        0x2at
        -0x59t
        -0x3bt
        0x35t
        0x55t
        0x3dt
        0x41t
        -0x44t
        0x25t
        -0x4bt
        -0x3at
        0x38t
        0x43t
        0x36t
    .end array-data

    :array_9
    .array-data 1
        0x71t
        0x10t
        0x62t
        0x0t
        -0x14t
        0x75t
        -0x16t
        -0x76t
    .end array-data

    :array_a
    .array-data 1
        -0x25t
        -0x40t
        0x59t
        0x47t
        -0x7ft
        -0x5dt
        -0x7ct
        -0x59t
        -0x2dt
        -0x40t
        0x49t
        0x50t
        -0x80t
        -0x42t
        -0x32t
        -0x16t
        -0x25t
        -0x26t
        0x58t
        0x52t
        -0x7ft
        -0x48t
        -0x67t
        -0x59t
        -0x2t
        -0x15t
        0x7bt
        0x74t
        -0x45t
        -0x7at
        -0x4ct
    .end array-data

    :array_b
    .array-data 1
        -0x46t
        -0x52t
        0x3dt
        0x35t
        -0x12t
        -0x36t
        -0x20t
        -0x77t
    .end array-data

    :array_c
    .array-data 1
        -0x55t
        -0x2et
        -0x51t
        0xft
        -0x37t
        -0x2bt
        -0x7dt
        -0x13t
        -0x1at
        -0x32t
        -0x59t
        0x42t
        -0x2ft
        -0x32t
        -0x61t
        -0x10t
        -0x4ft
        -0x22t
        -0x59t
        0x4ft
        -0x30t
        -0x27t
        -0x7ct
    .end array-data

    :array_d
    .array-data 1
        -0x38t
        -0x43t
        -0x3et
        0x21t
        -0x5ct
        -0x44t
        -0xat
        -0x7ct
    .end array-data

    :array_e
    .array-data 1
        -0x5dt
        -0x13t
        0xat
        0x1t
        -0x36t
        0x14t
        0x11t
        0x7dt
        -0x12t
        -0xet
        0x8t
        0x58t
        -0x3et
        0xft
        0x7t
        0x71t
        -0x52t
        -0xat
        0x2t
        0x5dt
        -0x77t
        0x2dt
        0xbt
        0x63t
        -0x5bt
        -0x10t
        0x34t
        0x4at
        -0x2dt
        0x9t
        0xdt
        0x7at
        -0x59t
        -0xft
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x40t
        -0x7et
        0x67t
        0x2ft
        -0x59t
        0x7dt
        0x64t
        0x14t
    .end array-data
.end method

.method public static P(Ljava/lang/String;Landroid/content/pm/PackageManager;)Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p1, p0, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p0, 0x1

    return p0

    :catch_0
    return v0
.end method

.method public static Q(I)Z
    .locals 4

    .line 1
    new-instance v0, Ljava/net/Socket;

    invoke-direct {v0}, Ljava/net/Socket;-><init>()V

    new-instance v1, Ljava/net/InetSocketAddress;

    const/16 v2, 0x9

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, p0}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    const/16 p0, 0x7d0

    :try_start_0
    invoke-virtual {v0, v1, p0}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 p0, 0x1

    return p0

    :catchall_0
    move-exception p0

    :try_start_2
    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    throw p0

    :catch_2
    :try_start_3
    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_2

    :catch_3
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_2
    const/4 p0, 0x0

    return p0

    nop

    :array_0
    .array-data 1
        -0x6et
        0x3at
        -0x13t
        -0x17t
        -0x44t
        -0x40t
        -0x3bt
        0x2ct
        -0x76t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x2t
        0x55t
        -0x72t
        -0x78t
        -0x30t
        -0x58t
        -0x56t
        0x5ft
    .end array-data
.end method

.method public static R()Z
    .locals 3

    .line 1
    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0

    :array_0
    .array-data 1
        0x39t
        0x0t
        0x8t
        -0x6ct
        -0x4bt
        0x7t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x4bt
        0x65t
        0x69t
        -0x8t
        -0x28t
        0x62t
        -0x15t
        -0x1t
    .end array-data
.end method

.method public static S()Z
    .locals 3

    .line 1
    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0

    :array_0
    .array-data 1
        -0x16t
        -0x73t
        0x3dt
        -0x3ft
        0x62t
        0x65t
        -0x61t
    .end array-data

    :array_1
    .array-data 1
        -0x67t
        -0x14t
        0x50t
        -0x4et
        0x17t
        0xbt
        -0x8t
        -0x12t
    .end array-data
.end method

.method public static T(Ljava/lang/String;)Z
    .locals 3

    .line 1
    const/4 v0, 0x0

    :try_start_0
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p0

    check-cast p0, Ljava/net/HttpURLConnection;

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/16 v1, 0x1388

    invoke-virtual {p0, v1}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    invoke-virtual {p0, v1}, Ljava/net/URLConnection;->setReadTimeout(I)V

    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/16 v1, 0xc8

    if-gt v1, p0, :cond_0

    const/16 v1, 0x12c

    if-ge p0, v1, :cond_0

    const/4 v0, 0x1

    :catch_0
    :cond_0
    return v0

    :array_0
    .array-data 1
        0x71t
        0x5t
        -0x44t
        -0x47t
    .end array-data

    :array_1
    .array-data 1
        0x39t
        0x40t
        -0x3t
        -0x3t
        0x5ft
        -0x32t
        0x66t
        0x49t
    .end array-data
.end method

.method public static U(Landroid/content/Context;)Z
    .locals 3

    .line 1
    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AppOpsManager;

    const/16 v2, 0x17

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v1, v2, p0}, Landroid/app/AppOpsManager;->checkOpNoThrow(Ljava/lang/String;ILjava/lang/String;)I

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0

    nop

    :array_0
    .array-data 1
        -0x5t
        -0x57t
        -0x59t
        -0x56t
        -0x5at
        -0x25t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x66t
        -0x27t
        -0x29t
        -0x3bt
        -0x2at
        -0x58t
        -0x5at
        -0x6at
    .end array-data

    :array_2
    .array-data 1
        -0x44t
        0x9t
        -0xat
        -0x50t
        0x4bt
        -0x31t
        -0x74t
        0x53t
        -0x46t
        0x2t
        -0x1at
        -0x63t
        0x51t
        -0x2bt
        -0x77t
        0xet
        -0x48t
        0x38t
        -0x1ft
        -0x4at
        0x45t
        -0x2et
        -0x65t
    .end array-data

    :array_3
    .array-data 1
        -0x23t
        0x67t
        -0x6et
        -0x3et
        0x24t
        -0x5at
        -0x18t
        0x69t
    .end array-data
.end method

.method public static V(Ljava/lang/String;)Z
    .locals 6

    .line 1
    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    new-instance v2, Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;-><init>()V

    new-array v1, v1, [Z

    const/4 v3, 0x0

    aput-boolean v3, v1, v3

    new-instance v4, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v4}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-virtual {v4, p0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object p0

    new-instance v4, Lcom/icontrol/protector/n$a;

    invoke-direct {v4, v1, v0}, Lcom/icontrol/protector/n$a;-><init>([ZLjava/util/concurrent/CountDownLatch;)V

    invoke-virtual {v2, p0, v4}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    :try_start_0
    sget-object p0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v4, 0x5

    invoke-virtual {v0, v4, v5, p0}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    invoke-virtual {v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p0

    invoke-virtual {p0}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    aget-boolean p0, v1, v3

    return p0
.end method

.method public static W(II)I
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/n;->c:Ljava/util/Random;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    sput-object v0, Lcom/icontrol/protector/n;->c:Ljava/util/Random;

    :cond_0
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    sub-int/2addr p1, p0

    add-int/lit8 p1, p1, 0x1

    invoke-virtual {v0, p1}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    add-int/2addr p1, p0

    return p1
.end method

.method public static X(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/icontrol/protector/n$c;

    invoke-direct {v2, p0, v0}, Lcom/icontrol/protector/n$c;-><init>(Landroid/content/Context;Ljava/util/concurrent/CountDownLatch;)V

    const-wide/16 v3, 0x3e8

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :try_start_0
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->await()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    sget-object p0, Lcom/icontrol/protector/n;->d:Ljava/lang/String;

    return-object p0
.end method

.method public static Y(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    .line 1
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/icontrol/protector/n$b;

    invoke-direct {v1, p0, p1}, Lcom/icontrol/protector/n$b;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const-wide/16 p0, 0x3e8

    invoke-virtual {v0, v1, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 4

    .line 1
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/icontrol/protector/AlertActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 p1, 0x3

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v1, v2, [B

    fill-array-data v1, :array_3

    invoke-static {p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 p1, 0x9

    new-array p1, p1, [B

    fill-array-data p1, :array_4

    new-array p2, v2, [B

    fill-array-data p2, :array_5

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1, p5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x4

    new-array p1, p1, [B

    fill-array-data p1, :array_6

    new-array p2, v2, [B

    fill-array-data p2, :array_7

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 p1, 0x6

    new-array p1, p1, [B

    fill-array-data p1, :array_8

    new-array p2, v2, [B

    fill-array-data p2, :array_9

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 p1, 0x10000000

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void

    :array_0
    .array-data 1
        0x6at
        0x63t
        -0x41t
        0x71t
        -0x63t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x3et
        0xat
        -0x35t
        0x1dt
        -0x8t
        -0x65t
        -0x72t
        -0x7dt
    .end array-data

    :array_2
    .array-data 1
        0x1ct
        -0x6at
        0xft
    .end array-data

    :array_3
    .array-data 1
        0x51t
        -0x1bt
        0x68t
        0x62t
        0x0t
        0x4t
        -0x2t
        0x5ct
    .end array-data

    :array_4
    .array-data 1
        -0x3at
        -0x9t
        0xat
        -0x46t
        -0x2et
        0x4bt
        0x2et
        0x69t
        -0x38t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x59t
        -0x65t
        0x6ft
        -0x38t
        -0x5at
        0x14t
        0x47t
        0xat
    .end array-data

    :array_6
    .array-data 1
        0x1bt
        0x16t
        0x6ft
        0x2ct
    .end array-data

    :array_7
    .array-data 1
        0x4ft
        0x6ft
        0x1ft
        0x49t
        0x11t
        -0x1ft
        -0x10t
        0xft
    .end array-data

    :array_8
    .array-data 1
        -0x7t
        0x2dt
        0x13t
        -0x67t
        0x6ft
        0x17t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x73t
        0x42t
        0x7ct
        -0x17t
        0xat
        0x79t
        -0x24t
        0x7ft
    .end array-data
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 11

    .line 1
    const/4 v0, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/16 v3, 0x8

    const/4 v4, 0x0

    if-eqz p3, :cond_3

    const/4 v5, 0x0

    const/high16 v6, 0xc000000

    const/high16 v7, 0x50800000

    const-class v8, Lcom/icontrol/protector/BrodcastActivity;

    const/4 v9, 0x7

    if-eq p3, v2, :cond_2

    if-eq p3, v0, :cond_0

    goto/16 :goto_2

    :cond_0
    :try_start_0
    new-array p3, v9, [B

    fill-array-data p3, :array_0

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {p3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p4, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    if-nez p3, :cond_1

    new-array p3, v3, [B

    fill-array-data p3, :array_2

    new-array v4, v3, [B

    fill-array-data v4, :array_3

    invoke-static {p3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p4, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    if-nez p3, :cond_1

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    new-array v4, v9, [B

    fill-array-data v4, :array_4

    new-array v10, v3, [B

    fill-array-data v10, :array_5

    invoke-static {v4, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p4

    goto :goto_0

    :catch_0
    move-exception p0

    goto/16 :goto_5

    :cond_1
    :goto_0
    new-instance p3, Landroid/content/Intent;

    invoke-direct {p3, p0, v8}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-array v4, v1, [B

    fill-array-data v4, :array_6

    new-array v8, v3, [B

    fill-array-data v8, :array_7

    invoke-static {v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v1, [B

    fill-array-data v8, :array_8

    new-array v10, v3, [B

    fill-array-data v10, :array_9

    invoke-static {v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p3, v4, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    new-array v4, v9, [B

    fill-array-data v4, :array_a

    new-array v8, v3, [B

    fill-array-data v8, :array_b

    invoke-static {v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p3, v4, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p3, v7}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    :goto_1
    invoke-static {p0, v5, p3, v6}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v4

    goto :goto_2

    :cond_2
    new-instance p3, Landroid/content/Intent;

    invoke-direct {p3, p0, v8}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-array v4, v1, [B

    fill-array-data v4, :array_c

    new-array v8, v3, [B

    fill-array-data v8, :array_d

    invoke-static {v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x3

    new-array v8, v8, [B

    fill-array-data v8, :array_e

    new-array v10, v3, [B

    fill-array-data v10, :array_f

    invoke-static {v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p3, v4, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    new-array v4, v9, [B

    fill-array-data v4, :array_10

    new-array v8, v3, [B

    fill-array-data v8, :array_11

    invoke-static {v4, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p3, v4, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p3, v7}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    goto :goto_1

    :cond_3
    :goto_2
    new-array p3, v1, [B

    fill-array-data p3, :array_12

    new-array p4, v3, [B

    fill-array-data p4, :array_13

    invoke-static {p3, p4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string p4, ""

    if-eqz p3, :cond_4

    move-object p1, p4

    :cond_4
    :try_start_1
    new-array p3, v1, [B

    fill-array-data p3, :array_14

    new-array v5, v3, [B

    fill-array-data v5, :array_15

    invoke-static {p3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_5

    move-object p2, p4

    :cond_5
    const/16 p3, 0x11

    if-eqz v4, :cond_6

    new-instance p4, Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    new-array v5, p3, [B

    fill-array-data v5, :array_16

    new-array v6, v3, [B

    fill-array-data v6, :array_17

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p4, p0, v5}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {p4, p1}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->h(Ljava/lang/CharSequence;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->g(Ljava/lang/CharSequence;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    sget p2, Lntidisestablish/neumonoul/floccinaucinih/pv;->a:I

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->q(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->t(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->n(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->f(Landroid/app/PendingIntent;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, v4, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->j(Landroid/app/PendingIntent;Z)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    :goto_3
    invoke-virtual {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->d(Z)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    goto :goto_4

    :cond_6
    new-instance p4, Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    new-array v4, p3, [B

    fill-array-data v4, :array_18

    new-array v5, v3, [B

    fill-array-data v5, :array_19

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-direct {p4, p0, v4}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {p4, p1}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->h(Ljava/lang/CharSequence;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->g(Ljava/lang/CharSequence;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->t(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    invoke-virtual {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->n(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    sget p2, Lntidisestablish/neumonoul/floccinaucinih/pv;->a:I

    invoke-virtual {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->q(I)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    move-result-object p1

    goto :goto_3

    :goto_4
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p4, 0x1a

    if-lt p2, p4, :cond_7

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/z;->a()V

    new-array p4, p3, [B

    fill-array-data p4, :array_1a

    new-array v4, v3, [B

    fill-array-data v4, :array_1b

    invoke-static {p4, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p4

    new-array v4, p3, [B

    fill-array-data v4, :array_1c

    new-array v5, v3, [B

    fill-array-data v5, :array_1d

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {p4, v4, v1}, Lntidisestablish/neumonoul/floccinaucinih/y;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object p4

    const-class v1, Landroid/app/NotificationManager;

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/NotificationManager;

    invoke-static {v1, p4}, Lntidisestablish/neumonoul/floccinaucinih/x;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    new-array p4, p3, [B

    fill-array-data p4, :array_1e

    new-array v1, v3, [B

    fill-array-data v1, :array_1f

    invoke-static {p4, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p1, p4}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->e(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    :cond_7
    const/4 p4, 0x5

    new-array p4, p4, [J

    fill-array-data p4, :array_20

    invoke-virtual {p1, p4}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->s([J)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    const/high16 p4, -0x10000

    const/16 v1, 0xbb8

    invoke-virtual {p1, p4, v1, v1}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->k(III)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    invoke-static {v0}, Landroid/media/RingtoneManager;->getDefaultUri(I)Landroid/net/Uri;

    move-result-object p4

    invoke-virtual {p1, p4}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->r(Landroid/net/Uri;)Lntidisestablish/neumonoul/floccinaucinih/rr$c;

    invoke-static {p0}, Lntidisestablish/neumonoul/floccinaucinih/fs;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/fs;

    move-result-object p4

    sget v0, Lcom/icontrol/protector/n;->a:I

    add-int/2addr v0, v2

    sput v0, Lcom/icontrol/protector/n;->a:I

    const/16 v1, 0x21

    if-lt p2, v1, :cond_9

    const/16 p2, 0x25

    new-array p2, p2, [B

    fill-array-data p2, :array_21

    new-array v0, v3, [B

    fill-array-data v0, :array_22

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p2}, Lntidisestablish/neumonoul/floccinaucinih/db;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result p2

    if-nez p2, :cond_8

    sget p0, Lcom/icontrol/protector/n;->a:I

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->a()Landroid/app/Notification;

    move-result-object p1

    invoke-virtual {p4, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/fs;->d(ILandroid/app/Notification;)V

    goto :goto_6

    :cond_8
    new-array p1, p3, [B

    fill-array-data p1, :array_23

    new-array p2, v3, [B

    fill-array-data p2, :array_24

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    const/16 p2, 0x26

    new-array p2, p2, [B

    fill-array-data p2, :array_25

    new-array p3, v3, [B

    fill-array-data p3, :array_26

    invoke-static {p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p1, p2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_6

    :cond_9
    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/rr$c;->a()Landroid/app/Notification;

    move-result-object p0

    invoke-virtual {p4, v0, p0}, Lntidisestablish/neumonoul/floccinaucinih/fs;->d(ILandroid/app/Notification;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_6

    :goto_5
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_6
    return-void

    nop

    :array_0
    .array-data 1
        -0x3ft
        -0x4ft
        0x39t
        0x3ct
        0x6et
        -0x3bt
        0x17t
    .end array-data

    :array_1
    .array-data 1
        -0x57t
        -0x3bt
        0x4dt
        0x4ct
        0x54t
        -0x16t
        0x38t
        -0x25t
    .end array-data

    :array_2
    .array-data 1
        -0x5ct
        -0x39t
        -0x6at
        0x5ct
        0x24t
        0x32t
        0x18t
        0x43t
    .end array-data

    :array_3
    .array-data 1
        -0x34t
        -0x4dt
        -0x1et
        0x2ct
        0x57t
        0x8t
        0x37t
        0x6ct
    .end array-data

    :array_4
    .array-data 1
        0x14t
        0x26t
        -0x43t
        0x6t
        0x56t
        0x62t
        -0x48t
    .end array-data

    :array_5
    .array-data 1
        0x7ct
        0x52t
        -0x37t
        0x76t
        0x6ct
        0x4dt
        -0x69t
        0x25t
    .end array-data

    :array_6
    .array-data 1
        0x6ct
        -0x6at
        -0x4ct
        0x30t
    .end array-data

    :array_7
    .array-data 1
        0x18t
        -0x11t
        -0x3ct
        0x55t
        -0x5ct
        -0x66t
        0x74t
        0x2dt
    .end array-data

    :array_8
    .array-data 1
        0x3et
        -0x15t
        -0x16t
        -0x2et
    .end array-data

    :array_9
    .array-data 1
        0x52t
        -0x7et
        -0x7ct
        -0x47t
        0x2et
        0x8t
        -0x2dt
        0x2et
    .end array-data

    :array_a
    .array-data 1
        0x8t
        -0x53t
        -0x61t
        -0x22t
        -0x6dt
        0x2at
        -0x7at
    .end array-data

    :array_b
    .array-data 1
        0x7ct
        -0x3et
        -0xdt
        -0x55t
        -0x3t
        0x49t
        -0x12t
        0x0t
    .end array-data

    :array_c
    .array-data 1
        -0x1at
        -0x68t
        0x77t
        -0x4ct
    .end array-data

    :array_d
    .array-data 1
        -0x6et
        -0x1ft
        0x7t
        -0x2ft
        -0x1et
        -0xdt
        -0x69t
        -0x5ft
    .end array-data

    :array_e
    .array-data 1
        0x68t
        -0x6ct
        0x3ct
    .end array-data

    :array_f
    .array-data 1
        0x9t
        -0x1ct
        0x4ct
        -0x65t
        -0x3bt
        0x4ft
        -0x7at
        -0x59t
    .end array-data

    :array_10
    .array-data 1
        0x3et
        -0x42t
        -0x3ct
        0x6ct
        0x22t
        0x54t
        -0x7et
    .end array-data

    :array_11
    .array-data 1
        0x4at
        -0x2ft
        -0x58t
        0x19t
        0x4ct
        0x37t
        -0x16t
        -0x43t
    .end array-data

    :array_12
    .array-data 1
        -0x2ft
        0x7ft
        -0x1t
        0x2at
    .end array-data

    :array_13
    .array-data 1
        -0x41t
        0xat
        -0x6dt
        0x46t
        -0x22t
        -0xdt
        -0x5t
        0x23t
    .end array-data

    :array_14
    .array-data 1
        0x13t
        -0x43t
        -0x3et
        0xat
    .end array-data

    :array_15
    .array-data 1
        0x7dt
        -0x38t
        -0x52t
        0x66t
        -0x30t
        -0x15t
        -0x5t
        -0x2ft
    .end array-data

    :array_16
    .array-data 1
        0x17t
        -0x45t
        -0x6bt
        0x4dt
        0x32t
        0x3et
        -0x80t
        -0x61t
        0x3ft
        -0x49t
        -0x7ft
        0xct
        0x8t
        0x38t
        -0x65t
        -0x68t
        0x2at
    .end array-data

    nop

    :array_17
    .array-data 1
        0x59t
        -0x22t
        -0x1et
        0x6dt
        0x7ct
        0x51t
        -0xct
        -0xat
    .end array-data

    :array_18
    .array-data 1
        -0x4dt
        0x70t
        -0x38t
        0x74t
        -0x4t
        -0x64t
        -0x48t
        -0x55t
        -0x65t
        0x7ct
        -0x24t
        0x35t
        -0x3at
        -0x66t
        -0x5dt
        -0x54t
        -0x72t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x3t
        0x15t
        -0x41t
        0x54t
        -0x4et
        -0xdt
        -0x34t
        -0x3et
    .end array-data

    :array_1a
    .array-data 1
        -0x75t
        0x70t
        0x68t
        0x26t
        0x4bt
        0x7bt
        -0x6et
        -0x77t
        -0x5dt
        0x7ct
        0x7ct
        0x67t
        0x71t
        0x7dt
        -0x77t
        -0x72t
        -0x4at
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x3bt
        0x15t
        0x1ft
        0x6t
        0x5t
        0x14t
        -0x1at
        -0x20t
    .end array-data

    :array_1c
    .array-data 1
        -0x4ft
        -0x31t
        0x67t
        0x17t
        -0x50t
        -0x6ft
        0x24t
        0x26t
        -0x67t
        -0x3dt
        0x73t
        0x56t
        -0x76t
        -0x69t
        0x3ft
        0x21t
        -0x74t
    .end array-data

    nop

    :array_1d
    .array-data 1
        -0x1t
        -0x56t
        0x10t
        0x37t
        -0x2t
        -0x2t
        0x50t
        0x4ft
    .end array-data

    :array_1e
    .array-data 1
        -0x80t
        -0x6dt
        0x7at
        -0x54t
        0x18t
        0x77t
        0x6bt
        -0x24t
        -0x58t
        -0x61t
        0x6et
        -0x13t
        0x22t
        0x71t
        0x70t
        -0x25t
        -0x43t
    .end array-data

    nop

    :array_1f
    .array-data 1
        -0x32t
        -0xat
        0xdt
        -0x74t
        0x56t
        0x18t
        0x1ft
        -0x4bt
    .end array-data

    :array_20
    .array-data 8
        0x3e8
        0x3e8
        0x3e8
        0x3e8
        0x3e8
    .end array-data

    :array_21
    .array-data 1
        0xct
        0x79t
        -0x35t
        0x23t
        0x4et
        -0x7et
        0x41t
        0x12t
        0x1dt
        0x72t
        -0x23t
        0x3ct
        0x48t
        -0x68t
        0x56t
        0x55t
        0x2t
        0x79t
        -0x7ft
        0x1t
        0x6et
        -0x48t
        0x71t
        0x63t
        0x23t
        0x58t
        -0x5t
        0x18t
        0x67t
        -0x5et
        0x66t
        0x7dt
        0x39t
        0x5et
        -0x20t
        0x1ft
        0x72t
    .end array-data

    nop

    :array_22
    .array-data 1
        0x6dt
        0x17t
        -0x51t
        0x51t
        0x21t
        -0x15t
        0x25t
        0x3ct
    .end array-data

    :array_23
    .array-data 1
        -0x20t
        0x1ct
        0x50t
        -0x71t
        -0x34t
        0x3dt
        -0x38t
        -0x7bt
        -0x27t
        0x15t
        0x4at
        -0x68t
        -0x73t
        0x7t
        -0x32t
        -0x62t
        -0x22t
    .end array-data

    nop

    :array_24
    .array-data 1
        -0x50t
        0x73t
        0x23t
        -0x5t
        -0x14t
        0x73t
        -0x59t
        -0xft
    .end array-data

    :array_25
    .array-data 1
        0x30t
        0x2et
        -0x80t
        -0x4dt
        -0x1t
        -0x1at
        0x5ct
        0x17t
        0x2at
        0x28t
        -0x65t
        -0x4ct
        -0x47t
        -0x1t
        0x5at
        0x4t
        0x33t
        0x28t
        -0x79t
        -0x57t
        -0x10t
        -0x20t
        0x51t
        0x56t
        0x37t
        0x32t
        -0x2ct
        -0x4ct
        -0xat
        -0x5t
        0x1ft
        0x11t
        0x2ct
        0x20t
        -0x66t
        -0x52t
        -0x4t
        -0x15t
    .end array-data

    nop

    :array_26
    .array-data 1
        0x5et
        0x41t
        -0xct
        -0x26t
        -0x67t
        -0x71t
        0x3ft
        0x76t
    .end array-data
.end method

.method public static c(Landroid/content/Context;)V
    .locals 2

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->N:Ljava/lang/String;

    const-string v1, ""

    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static d(Landroid/content/Context;)Ljava/lang/String;
    .locals 10

    .line 1
    const-string v0, ""

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/16 v1, 0xa

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v2}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_0

    const/16 v2, 0x10

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v4, v3, [B

    fill-array-data v4, :array_3

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v4, 0x5

    if-le v2, v4, :cond_0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x2

    new-array v2, v2, [B

    fill-array-data v2, :array_4

    new-array v4, v3, [B

    fill-array-data v4, :array_5

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->BOARD:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->BRAND:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->HOST:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->ID:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->TAGS:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->TYPE:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->USER:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v2, 0x6

    :try_start_0
    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v4, v3, [B

    fill-array-data v4, :array_7

    invoke-static {v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/security/MessageDigest;->update([B)V

    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    array-length v4, p0

    const/4 v5, 0x0

    move v6, v5

    :goto_0
    if-ge v6, v4, :cond_1

    aget-byte v7, p0, v6

    const/4 v8, 0x4

    new-array v8, v8, [B

    fill-array-data v8, :array_8

    new-array v9, v3, [B

    fill-array-data v9, :array_9

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x1

    new-array v9, v9, [Ljava/lang/Object;

    invoke-static {v7}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v7

    aput-object v7, v9, v5

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-array v1, v2, [B

    fill-array-data v1, :array_a

    new-array v4, v3, [B

    fill-array-data v4, :array_b

    invoke-static {v1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p0

    new-array v1, v2, [B

    fill-array-data v1, :array_c

    new-array v2, v3, [B

    fill-array-data v2, :array_d

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :array_0
    .array-data 1
        -0x2dt
        0x4dt
        -0x18t
        0x24t
        0x1ct
        0x4t
        -0x50t
        -0x39t
        -0x25t
        0x47t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x4et
        0x23t
        -0x74t
        0x56t
        0x73t
        0x6dt
        -0x2ct
        -0x68t
    .end array-data

    :array_2
    .array-data 1
        0x56t
        0xft
        -0x66t
        -0x45t
        -0x31t
        0x66t
        -0x5t
        0x52t
        0x59t
        0x0t
        -0x61t
        -0x16t
        -0x62t
        0x67t
        -0xct
        0x55t
    .end array-data

    :array_3
    .array-data 1
        0x6ft
        0x38t
        -0x53t
        -0x71t
        -0x55t
        0x53t
        -0x33t
        0x36t
    .end array-data

    :array_4
    .array-data 1
        0x73t
        -0x11t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x40t
        -0x26t
        0x62t
        -0x7bt
        0x48t
        0x5ct
        -0x42t
        -0x4et
    .end array-data

    :array_6
    .array-data 1
        -0x1et
        0x52t
        -0x1at
    .end array-data

    :array_7
    .array-data 1
        -0x51t
        0x16t
        -0x2dt
        -0x57t
        0x7bt
        0x77t
        -0x77t
        0x20t
    .end array-data

    :array_8
    .array-data 1
        0x5bt
        -0x6at
        -0x30t
        -0x2ft
    .end array-data

    :array_9
    .array-data 1
        0x7et
        -0x5at
        -0x1et
        -0x77t
        -0x7t
        0x72t
        -0x4ct
        -0x19t
    .end array-data

    :array_a
    .array-data 1
        0x45t
        -0x15t
        -0x5at
        0x3dt
        0x58t
        -0x6dt
    .end array-data

    nop

    :array_b
    .array-data 1
        0x1et
        -0x4bt
        -0x6at
        0x10t
        0x61t
        -0x32t
        -0x73t
        0x2t
    .end array-data

    :array_c
    .array-data 1
        -0x7bt
        0x6bt
        0x66t
        0x57t
        0x46t
        -0x25t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x22t
        0x35t
        0x56t
        0x7at
        0x7ft
        -0x7at
        -0x19t
        0x4at
    .end array-data
.end method

.method public static e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_0

    invoke-virtual {p0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, ""

    invoke-virtual {p0, p1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    :cond_0
    return-object p0
.end method

.method public static f()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/text/SimpleDateFormat;

    const/16 v1, 0x13

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_0
    .array-data 1
        0x39t
        -0x7ct
        0x2bt
        0x63t
        0x32t
        -0x7bt
        0x5ft
        0x71t
        0x24t
        -0x67t
        0x72t
        0x72t
        0x75t
        -0xet
        0x7ft
        0x33t
        0x7at
        -0x72t
        0x21t
    .end array-data

    :array_1
    .array-data 1
        0x40t
        -0x3t
        0x52t
        0x1at
        0x1dt
        -0x38t
        0x12t
        0x5et
    .end array-data
.end method

.method public static g(Landroid/content/Context;)Ljava/lang/String;
    .locals 10

    .line 1
    const/4 v0, 0x7

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xc

    new-array v4, v3, [B

    fill-array-data v4, :array_2

    new-array v5, v2, [B

    fill-array-data v5, :array_3

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/net/ConnectivityManager;

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    if-eqz p0, :cond_8

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v4

    if-eqz v4, :cond_8

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getType()I

    move-result v4

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-ne v4, v6, :cond_0

    new-array p0, v5, [B

    fill-array-data p0, :array_4

    new-array v0, v2, [B

    fill-array-data v0, :array_5

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getType()I

    move-result v4

    const/4 v7, 0x3

    const/16 v8, 0x11

    if-ne v4, v8, :cond_1

    new-array p0, v7, [B

    fill-array-data p0, :array_6

    new-array v0, v2, [B

    fill-array-data v0, :array_7

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getType()I

    move-result v4

    if-nez v4, :cond_8

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v4

    const/4 v9, 0x2

    if-eq v4, v6, :cond_7

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v4

    if-eq v4, v9, :cond_7

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v4

    if-eq v4, v0, :cond_7

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v4, 0xb

    if-eq v0, v4, :cond_7

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v4, 0x10

    if-eq v0, v4, :cond_7

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    if-ne v0, v5, :cond_2

    goto/16 :goto_2

    :cond_2
    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    if-eq v0, v7, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/4 v4, 0x5

    if-eq v0, v4, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/4 v4, 0x6

    if-eq v0, v4, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    if-eq v0, v2, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v4, 0x9

    if-eq v0, v4, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v4, 0xa

    if-eq v0, v4, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v4, 0xe

    if-eq v0, v4, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v4, 0xf

    if-eq v0, v4, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    if-eq v0, v3, :cond_6

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    if-ne v0, v8, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v3, 0xd

    if-eq v0, v3, :cond_5

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v3, 0x13

    if-eq v0, v3, :cond_5

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v0

    const/16 v3, 0x12

    if-ne v0, v3, :cond_4

    goto :goto_0

    :cond_4
    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result p0

    const/16 v0, 0x14

    if-ne p0, v0, :cond_8

    new-array p0, v9, [B

    fill-array-data p0, :array_8

    new-array v0, v2, [B

    fill-array-data v0, :array_9

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_5
    :goto_0
    new-array p0, v9, [B

    fill-array-data p0, :array_a

    new-array v0, v2, [B

    fill-array-data v0, :array_b

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_6
    :goto_1
    new-array p0, v9, [B

    fill-array-data p0, :array_c

    new-array v0, v2, [B

    fill-array-data v0, :array_d

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_7
    :goto_2
    new-array p0, v9, [B

    fill-array-data p0, :array_e

    new-array v0, v2, [B

    fill-array-data v0, :array_f

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_8
    return-object v1

    :array_0
    .array-data 1
        0xct
        -0xct
        -0x76t
        -0x9t
        -0x5et
        -0x31t
        -0x7dt
    .end array-data

    :array_1
    .array-data 1
        0x59t
        -0x66t
        -0x1ft
        -0x67t
        -0x33t
        -0x48t
        -0x13t
        0x79t
    .end array-data

    :array_2
    .array-data 1
        -0x48t
        -0x2at
        -0xbt
        0x4et
        0xet
        0x2ft
        -0x30t
        -0x2dt
        -0x53t
        -0x30t
        -0x11t
        0x59t
    .end array-data

    :array_3
    .array-data 1
        -0x25t
        -0x47t
        -0x65t
        0x20t
        0x6bt
        0x4ct
        -0x5ct
        -0x46t
    .end array-data

    :array_4
    .array-data 1
        0x2t
        0x30t
        -0xet
        -0x31t
    .end array-data

    :array_5
    .array-data 1
        0x55t
        0x79t
        -0x4ct
        -0x7at
        0x4bt
        -0x38t
        0x42t
        0x6at
    .end array-data

    :array_6
    .array-data 1
        0x8t
        0x5dt
        0x35t
    .end array-data

    :array_7
    .array-data 1
        0x5et
        0xdt
        0x7bt
        -0x1at
        -0x23t
        -0x1at
        0x2dt
        -0x58t
    .end array-data

    :array_8
    .array-data 1
        0x58t
        -0x58t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x6dt
        -0x11t
        -0x63t
        -0x36t
        -0x3ct
        -0x50t
        -0x39t
        -0x52t
    .end array-data

    :array_a
    .array-data 1
        0x33t
        0x16t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x7t
        0x51t
        0x35t
        -0x6et
        -0x56t
        -0x7at
        0x5t
        0x14t
    .end array-data

    :array_c
    .array-data 1
        0x28t
        0x5et
    .end array-data

    nop

    :array_d
    .array-data 1
        0x1bt
        0x19t
        -0x13t
        0x5at
        -0x41t
        0x49t
        -0xbt
        0x6et
    .end array-data

    :array_e
    .array-data 1
        -0x63t
        -0x6dt
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x51t
        -0x2ct
        -0x51t
        -0x9t
        -0x2dt
        0x71t
        -0x38t
        0xft
    .end array-data
.end method

.method public static h(Landroid/content/Context;)Z
    .locals 2

    .line 1
    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/os/PowerManager;->isIgnoringBatteryOptimizations(Ljava/lang/String;)Z

    move-result p0

    return p0

    :array_0
    .array-data 1
        -0x31t
        0x39t
        -0x25t
        -0x10t
        0x7t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x41t
        0x56t
        -0x54t
        -0x6bt
        0x75t
        0x1at
        -0x7et
        0x8t
    .end array-data
.end method

.method public static i(Landroid/content/Context;)Z
    .locals 2

    .line 1
    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/os/PowerManager;

    invoke-virtual {p0}, Landroid/os/PowerManager;->isInteractive()Z

    move-result p0

    return p0

    :array_0
    .array-data 1
        0x38t
        -0x41t
        -0x1bt
        -0x35t
        -0x62t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x48t
        -0x30t
        -0x6et
        -0x52t
        -0x14t
        0x5ct
        0x3ft
        0x3et
    .end array-data
.end method

.method public static j(Landroid/content/Context;)V
    .locals 12

    .line 1
    const/high16 v0, 0x800000

    const/high16 v1, 0x40000000    # 2.0f

    const/high16 v2, 0x10000000

    const/16 v3, 0x1f

    const/4 v4, 0x7

    const/16 v5, 0x2d

    const/16 v6, 0x8

    :try_start_0
    invoke-static {}, Lcom/icontrol/protector/n;->S()Z

    move-result v7

    if-nez v7, :cond_0

    invoke-static {}, Lcom/icontrol/protector/n;->M()Z

    move-result v7

    if-nez v7, :cond_0

    invoke-static {}, Lcom/icontrol/protector/n;->R()Z

    move-result v7

    if-nez v7, :cond_0

    new-instance v7, Landroid/content/Intent;

    new-array v8, v5, [B

    fill-array-data v8, :array_0

    new-array v9, v6, [B

    fill-array-data v9, :array_1

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-array v8, v4, [B

    fill-array-data v8, :array_2

    new-array v9, v6, [B

    fill-array-data v9, :array_3

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    const/16 v10, 0xd

    new-array v10, v10, [B

    fill-array-data v10, :array_4

    new-array v11, v6, [B

    fill-array-data v11, :array_5

    invoke-static {v10, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-static {v8, v9, v10}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    goto :goto_0

    :catch_0
    move-exception v7

    goto :goto_1

    :cond_0
    new-instance v7, Landroid/content/Intent;

    const/16 v8, 0x31

    new-array v8, v8, [B

    fill-array-data v8, :array_6

    new-array v9, v6, [B

    fill-array-data v9, :array_7

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    :goto_0
    new-array v8, v3, [B

    fill-array-data v8, :array_8

    new-array v9, v6, [B

    fill-array-data v9, :array_9

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v7, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v7, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v7, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v8, 0x0

    const/high16 v9, 0xc000000

    invoke-static {p0, v8, v7, v9}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v7

    invoke-virtual {v7}, Landroid/app/PendingIntent;->send()V

    invoke-virtual {v7}, Landroid/app/PendingIntent;->cancel()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {v7}, Ljava/lang/Throwable;->printStackTrace()V

    :try_start_1
    new-instance v7, Landroid/content/Intent;

    new-array v5, v5, [B

    fill-array-data v5, :array_a

    new-array v8, v6, [B

    fill-array-data v8, :array_b

    invoke-static {v5, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v7, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-array v3, v3, [B

    fill-array-data v3, :array_c

    new-array v5, v6, [B

    fill-array-data v5, :array_d

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    new-array v3, v4, [B

    fill-array-data v3, :array_e

    new-array v4, v6, [B

    fill-array-data v4, :array_f

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v7, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v7, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v7, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v7, v3}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    invoke-virtual {p0, v7}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :goto_2
    return-void

    nop

    :array_0
    .array-data 1
        0x7ft
        -0xdt
        -0x43t
        -0x10t
        -0x15t
        -0x58t
        0x6ft
        -0x59t
        0x6dt
        -0x8t
        -0x53t
        -0xat
        -0x13t
        -0x51t
        0x6ct
        -0x6t
        0x30t
        -0x24t
        -0x77t
        -0x2et
        -0x38t
        -0x78t
        0x48t
        -0x38t
        0x4at
        -0x2ct
        -0x6at
        -0x34t
        -0x25t
        -0x7bt
        0x4et
        -0x23t
        0x5ft
        -0x2ct
        -0x6bt
        -0x2ft
        -0x25t
        -0x6et
        0x4et
        -0x23t
        0x4at
        -0x2ct
        -0x69t
        -0x3bt
        -0x29t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x1et
        -0x63t
        -0x27t
        -0x7et
        -0x7ct
        -0x3ft
        0xbt
        -0x77t
    .end array-data

    :array_2
    .array-data 1
        0x9t
        -0x71t
        0x7at
        0xct
        0xft
        -0x26t
        -0x6at
    .end array-data

    :array_3
    .array-data 1
        0x79t
        -0x12t
        0x19t
        0x67t
        0x6et
        -0x43t
        -0xdt
        0x1dt
    .end array-data

    :array_4
    .array-data 1
        0x26t
        -0x5ft
        0x2et
        0x71t
        -0x46t
        0x79t
        -0x71t
        -0x60t
        0x72t
        -0x58t
        0x47t
        0xdt
        -0x4bt
    .end array-data

    nop

    :array_5
    .array-data 1
        0x58t
        -0x80t
        0x6et
        0x52t
        -0x62t
        0x5ct
        -0x2ft
        -0x7at
    .end array-data

    :array_6
    .array-data 1
        0x26t
        0x14t
        -0x69t
        0x5bt
        -0x2et
        -0x6dt
        0x3ft
        -0x38t
        0x34t
        0x1ft
        -0x79t
        0x5dt
        -0x2ct
        -0x6ct
        0x3ct
        -0x6bt
        0x69t
        0x37t
        -0x4et
        0x67t
        -0x4t
        -0x43t
        0x1et
        -0x47t
        0x6t
        0x36t
        -0x41t
        0x76t
        -0x4t
        -0x56t
        0xbt
        -0x56t
        0xet
        0x39t
        -0x4et
        0x7dt
        -0xct
        -0x4bt
        0x15t
        -0x4bt
        0x18t
        0x29t
        -0x4at
        0x7dt
        -0x17t
        -0x4dt
        0x15t
        -0x5ft
        0x14t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x47t
        0x7at
        -0xdt
        0x29t
        -0x43t
        -0x6t
        0x5bt
        -0x1at
    .end array-data

    :array_8
    .array-data 1
        0x74t
        0x1bt
        -0x68t
        0x31t
        -0x6dt
        0x0t
        0x3t
        0x55t
        0x7ct
        0x1bt
        -0x78t
        0x26t
        -0x6et
        0x1dt
        0x49t
        0x18t
        0x74t
        0x1t
        -0x67t
        0x24t
        -0x6dt
        0x1bt
        0x1et
        0x55t
        0x51t
        0x30t
        -0x46t
        0x2t
        -0x57t
        0x25t
        0x33t
    .end array-data

    :array_9
    .array-data 1
        0x15t
        0x75t
        -0x4t
        0x43t
        -0x4t
        0x69t
        0x67t
        0x7bt
    .end array-data

    :array_a
    .array-data 1
        0x2ft
        0x4at
        -0xbt
        0x56t
        0x34t
        0x4et
        -0x3at
        -0x4ft
        0x3dt
        0x41t
        -0x1bt
        0x50t
        0x32t
        0x49t
        -0x3bt
        -0x14t
        0x60t
        0x65t
        -0x3ft
        0x74t
        0x17t
        0x6et
        -0x1ft
        -0x22t
        0x1at
        0x6dt
        -0x22t
        0x6at
        0x4t
        0x63t
        -0x19t
        -0x35t
        0xft
        0x6dt
        -0x23t
        0x77t
        0x4t
        0x74t
        -0x19t
        -0x35t
        0x1at
        0x6dt
        -0x21t
        0x63t
        0x8t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x4et
        0x24t
        -0x6ft
        0x24t
        0x5bt
        0x27t
        -0x5et
        -0x61t
    .end array-data

    :array_c
    .array-data 1
        0x63t
        -0x11t
        0xet
        0x2et
        0x4at
        0x12t
        -0x28t
        0x4ct
        0x6bt
        -0x11t
        0x1et
        0x39t
        0x4bt
        0xft
        -0x6et
        0x1t
        0x63t
        -0xbt
        0xft
        0x3bt
        0x4at
        0x9t
        -0x3bt
        0x4ct
        0x46t
        -0x3ct
        0x2ct
        0x1dt
        0x70t
        0x37t
        -0x18t
    .end array-data

    :array_d
    .array-data 1
        0x2t
        -0x7ft
        0x6at
        0x5ct
        0x25t
        0x7bt
        -0x44t
        0x62t
    .end array-data

    :array_e
    .array-data 1
        0x66t
        -0x2at
        -0x37t
        -0x3at
        -0x4bt
        0x7et
        -0x29t
    .end array-data

    :array_f
    .array-data 1
        0x16t
        -0x49t
        -0x56t
        -0x53t
        -0x2ct
        0x19t
        -0x4et
        0x49t
    .end array-data
.end method

.method public static k(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    .line 1
    const/16 v0, 0x8

    :try_start_0
    new-array v1, v0, [B

    fill-array-data v1, :array_0

    new-array v2, v0, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/KeyguardManager;

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v0, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/os/PowerManager;

    invoke-virtual {p0}, Landroid/os/PowerManager;->isScreenOn()Z

    move-result p0

    invoke-virtual {v1}, Landroid/app/KeyguardManager;->isDeviceLocked()Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    if-ne p0, v3, :cond_0

    new-array p0, v3, [B

    const/16 v1, 0x70

    aput-byte v1, p0, v2

    new-array v1, v0, [B

    fill-array-data v1, :array_4

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    new-array p0, v3, [B

    const/16 v1, -0x3b

    aput-byte v1, p0, v2

    new-array v1, v0, [B

    fill-array-data v1, :array_5

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_1
    if-ne p0, v3, :cond_2

    new-array p0, v3, [B

    const/16 v1, 0x17

    aput-byte v1, p0, v2

    new-array v1, v0, [B

    fill-array-data v1, :array_6

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_2
    new-array p0, v3, [B

    const/16 v1, 0x38

    aput-byte v1, p0, v2

    new-array v1, v0, [B

    fill-array-data v1, :array_7

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-object p0

    :catch_0
    const/4 p0, 0x2

    new-array p0, p0, [B

    fill-array-data p0, :array_8

    new-array v0, v0, [B

    fill-array-data v0, :array_9

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :array_0
    .array-data 1
        0x55t
        -0x62t
        0x37t
        0x12t
        0x19t
        -0x45t
        0x5ct
        -0x74t
    .end array-data

    :array_1
    .array-data 1
        0x3et
        -0x5t
        0x4et
        0x75t
        0x6ct
        -0x26t
        0x2et
        -0x18t
    .end array-data

    :array_2
    .array-data 1
        -0x39t
        0x63t
        -0x1ft
        0x8t
        -0x1et
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x49t
        0xct
        -0x6at
        0x6dt
        -0x70t
        0x54t
        -0x4at
        -0x36t
    .end array-data

    :array_4
    .array-data 1
        0x40t
        0x42t
        -0x1t
        0x2et
        0x3at
        0x65t
        -0x39t
        0x5bt
    .end array-data

    :array_5
    .array-data 1
        -0xct
        -0x6dt
        -0x3et
        -0x70t
        -0x17t
        0x10t
        0x37t
        0x33t
    .end array-data

    :array_6
    .array-data 1
        0x25t
        -0x7bt
        0x30t
        -0x67t
        0x4at
        0x4ft
        -0x42t
        0xat
    .end array-data

    :array_7
    .array-data 1
        0xbt
        -0x30t
        -0x3dt
        -0x55t
        0x36t
        0x6et
        0x7et
        -0x16t
    .end array-data

    :array_8
    .array-data 1
        -0x50t
        -0xdt
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x63t
        -0x3et
        -0x6et
        -0x35t
        -0x2bt
        0x42t
        -0x2at
        -0x52t
    .end array-data
.end method

.method public static l(Landroid/content/Context;Ljava/lang/Class;)V
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, p0, p1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result p1

    if-nez p1, :cond_1

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt p1, v1, :cond_0

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/p1;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_1
    :goto_0
    return-void
.end method

.method public static m(Landroid/content/Context;Ljava/lang/String;)V
    .locals 7

    .line 1
    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->N:Ljava/lang/String;

    const-string v1, ""

    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->M:Ljava/lang/String;

    const/4 v2, 0x1

    new-array v3, v2, [B

    const/16 v4, -0x40

    const/4 v5, 0x0

    aput-byte v4, v3, v5

    const/16 v4, 0x8

    new-array v6, v4, [B

    fill-array-data v6, :array_0

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {p0, v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p1, v2, [B

    const/16 v0, 0x19

    aput-byte v0, p1, v5

    new-array v0, v4, [B

    fill-array-data v0, :array_1

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p1, v2, [B

    const/4 v0, -0x7

    aput-byte v0, p1, v5

    new-array v0, v4, [B

    fill-array-data v0, :array_2

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->N:Ljava/lang/String;

    invoke-static {p0, v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :array_0
    .array-data 1
        -0xft
        0x45t
        -0x32t
        0x79t
        0x49t
        0x48t
        0x40t
        0x52t
    .end array-data

    :array_1
    .array-data 1
        0x65t
        -0x48t
        -0x78t
        -0x21t
        -0x61t
        -0x70t
        0x6at
        -0xet
    .end array-data

    :array_2
    .array-data 1
        -0x2dt
        -0x11t
        -0x58t
        0x25t
        -0x50t
        -0x4dt
        0x34t
        -0x15t
    .end array-data
.end method

.method public static n()Ljava/lang/String;
    .locals 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    const/4 v2, 0x6

    const/16 v3, 0x8

    const-string v4, ""

    if-ne v0, v1, :cond_0

    new-array v0, v2, [B

    fill-array-data v0, :array_0

    new-array v1, v3, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1

    :cond_0
    const/16 v1, 0x19

    if-ne v0, v1, :cond_1

    new-array v0, v3, [B

    fill-array-data v0, :array_2

    new-array v1, v3, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1

    :cond_1
    const/16 v1, 0x1a

    if-ne v0, v1, :cond_2

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v3, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1

    :cond_2
    const/16 v1, 0x1b

    if-ne v0, v1, :cond_3

    new-array v0, v2, [B

    fill-array-data v0, :array_6

    new-array v1, v3, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1

    :cond_3
    const/16 v1, 0x1c

    if-ne v0, v1, :cond_4

    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_8

    new-array v1, v3, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_4
    const/16 v1, 0x1d

    const/16 v2, 0xa

    if-ne v0, v1, :cond_5

    new-array v0, v2, [B

    fill-array-data v0, :array_a

    new-array v1, v3, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_5
    const/16 v1, 0x1e

    if-ne v0, v1, :cond_6

    new-array v0, v2, [B

    fill-array-data v0, :array_c

    new-array v1, v3, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_6
    const/16 v1, 0x1f

    if-eq v0, v1, :cond_a

    const/16 v1, 0x20

    if-ne v0, v1, :cond_7

    goto :goto_0

    :cond_7
    const/16 v1, 0x21

    if-ne v0, v1, :cond_8

    new-array v0, v2, [B

    fill-array-data v0, :array_e

    new-array v1, v3, [B

    fill-array-data v1, :array_f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_8
    const/16 v1, 0x22

    if-ne v0, v1, :cond_9

    new-array v0, v2, [B

    fill-array-data v0, :array_10

    new-array v1, v3, [B

    fill-array-data v1, :array_11

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_9
    move-object v0, v4

    goto :goto_1

    :cond_a
    :goto_0
    new-array v0, v2, [B

    fill-array-data v0, :array_12

    new-array v1, v3, [B

    fill-array-data v1, :array_13

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    :goto_1
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-eqz v1, :cond_b

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_b
    return-object v4

    :array_0
    .array-data 1
        -0x6et
        -0x13t
        0x5at
        -0x33t
        -0x6bt
        0x0t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x24t
        -0x7et
        0x2ft
        -0x56t
        -0xct
        0x74t
        -0x21t
        -0x40t
    .end array-data

    :array_2
    .array-data 1
        0x63t
        0x3bt
        0x16t
        -0x12t
        -0x28t
        -0x2et
        0x6at
        0x1ct
    .end array-data

    :array_3
    .array-data 1
        0x2dt
        0x54t
        0x63t
        -0x77t
        -0x47t
        -0x5at
        0x41t
        0x37t
    .end array-data

    :array_4
    .array-data 1
        -0x4t
        -0x32t
        -0x11t
        -0x2ct
    .end array-data

    :array_5
    .array-data 1
        -0x4dt
        -0x44t
        -0x76t
        -0x45t
        -0x57t
        0x48t
        -0x57t
        0x44t
    .end array-data

    :array_6
    .array-data 1
        0x4at
        0x0t
        -0x3dt
        0x67t
        -0x6bt
        0x1ct
    .end array-data

    nop

    :array_7
    .array-data 1
        0x5t
        0x72t
        -0x5at
        0x8t
        -0x42t
        0x37t
        0x16t
        -0x2t
    .end array-data

    :array_8
    .array-data 1
        0x3bt
        0x3t
        0x56t
    .end array-data

    :array_9
    .array-data 1
        0x6bt
        0x6at
        0x33t
        0x7bt
        0x70t
        0x57t
        0x56t
        0x2bt
    .end array-data

    :array_a
    .array-data 1
        -0x7et
        -0x3dt
        -0x2et
        0x20t
        0x6et
        -0x48t
        0x27t
        0x21t
        -0xet
        -0x63t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x3dt
        -0x53t
        -0x4at
        0x52t
        0x1t
        -0x2ft
        0x43t
        0x1t
    .end array-data

    :array_c
    .array-data 1
        -0x2bt
        -0x73t
        0x42t
        0x7dt
        -0x41t
        0x7ft
        0x34t
        0x40t
        -0x5bt
        -0x2et
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x6ct
        -0x1dt
        0x26t
        0xft
        -0x30t
        0x16t
        0x50t
        0x60t
    .end array-data

    :array_e
    .array-data 1
        0x4at
        0x3ft
        -0x48t
        0x65t
        -0x3et
        -0x33t
        -0x51t
        -0x25t
        0x3at
        0x62t
    .end array-data

    nop

    :array_f
    .array-data 1
        0xbt
        0x51t
        -0x24t
        0x17t
        -0x53t
        -0x5ct
        -0x35t
        -0x5t
    .end array-data

    :array_10
    .array-data 1
        -0x7ct
        -0x44t
        -0x2dt
        -0x33t
        0x4ct
        -0x52t
        -0x18t
        -0x75t
        -0xct
        -0x1at
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x3bt
        -0x2et
        -0x49t
        -0x41t
        0x23t
        -0x39t
        -0x74t
        -0x55t
    .end array-data

    :array_12
    .array-data 1
        -0x3dt
        -0x2bt
        0x57t
        -0x50t
        -0x4at
        0x5ft
        0x24t
        -0x37t
        -0x4dt
        -0x77t
    .end array-data

    nop

    :array_13
    .array-data 1
        -0x7et
        -0x45t
        0x33t
        -0x3et
        -0x27t
        0x36t
        0x40t
        -0x17t
    .end array-data
.end method

.method public static o(Landroid/content/Context;IIZ)Ljava/lang/String;
    .locals 3

    .line 1
    const/16 v0, 0x8

    const/4 v1, 0x2

    :try_start_0
    invoke-static {p0}, Landroid/app/WallpaperManager;->getInstance(Landroid/content/Context;)Landroid/app/WallpaperManager;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    :try_start_1
    invoke-virtual {p0}, Landroid/app/WallpaperManager;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_3

    goto :goto_0

    :catch_0
    const/4 v2, 0x0

    :goto_0
    if-nez v2, :cond_0

    :try_start_2
    invoke-virtual {p0}, Landroid/app/WallpaperManager;->getBuiltInDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v2
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_2 .. :try_end_2} :catch_3

    goto :goto_1

    :catch_1
    :try_start_3
    new-array p0, v1, [B

    fill-array-data p0, :array_0

    new-array p1, v0, [B

    fill-array-data p1, :array_1

    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    :goto_1
    if-eqz v2, :cond_2

    instance-of p0, v2, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz p0, :cond_2

    check-cast v2, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz p3, :cond_1

    invoke-virtual {v2}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p0

    invoke-static {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/q8;->c(Landroid/graphics/Bitmap;II)Landroid/graphics/Bitmap;

    move-result-object p0

    goto :goto_2

    :cond_1
    invoke-virtual {v2}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p0

    const/16 p1, 0x2ee

    const/4 p2, 0x1

    const/16 p3, 0x1c2

    invoke-static {p0, p3, p1, p2}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object p0

    :goto_2
    new-instance p1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object p2, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 p3, 0x64

    invoke-virtual {p0, p2, p3, p1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {p1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    invoke-static {p0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p0

    goto :goto_3

    :cond_2
    new-array p0, v1, [B

    fill-array-data p0, :array_2

    new-array p1, v0, [B

    fill-array-data p1, :array_3

    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0
    :try_end_3
    .catch Ljava/lang/OutOfMemoryError; {:try_start_3 .. :try_end_3} :catch_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_3

    :catch_2
    new-array p0, v1, [B

    fill-array-data p0, :array_4

    new-array p1, v0, [B

    fill-array-data p1, :array_5

    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    goto :goto_3

    :catch_3
    new-array p0, v1, [B

    fill-array-data p0, :array_6

    new-array p1, v0, [B

    fill-array-data p1, :array_7

    invoke-static {p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p0

    :goto_3
    return-object p0

    nop

    :array_0
    .array-data 1
        -0x80t
        0x79t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x53t
        0x48t
        -0x59t
        0x1t
        0x7at
        0x4t
        0x30t
        0x2bt
    .end array-data

    :array_2
    .array-data 1
        -0x4ct
        -0x75t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x67t
        -0x46t
        0x5et
        0x4t
        -0x28t
        -0x2ct
        -0xat
        -0x9t
    .end array-data

    :array_4
    .array-data 1
        0x3ct
        -0x1dt
    .end array-data

    nop

    :array_5
    .array-data 1
        0x11t
        -0x2et
        0x39t
        0x6dt
        -0x5ct
        0x5bt
        0x7bt
        -0x2t
    .end array-data

    :array_6
    .array-data 1
        -0x3ct
        -0x2ct
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x17t
        -0x1bt
        0x28t
        -0x22t
        -0x2at
        -0x52t
        0x56t
        0xet
    .end array-data
.end method

.method static synthetic p(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    sput-object p0, Lcom/icontrol/protector/n;->d:Ljava/lang/String;

    return-object p0
.end method

.method private static q(Landroid/graphics/Bitmap;)Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v2, 0x64

    invoke-virtual {p0, v1, v2, v0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v0, 0x0

    invoke-static {p0, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static r(Ljava/io/File;)Ljava/lang/String;
    .locals 7

    .line 1
    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const/16 p0, 0x400

    :try_start_0
    new-array p0, p0, [B

    :goto_0
    invoke-virtual {v2, p0}, Ljava/io/InputStream;->read([B)I

    move-result v3

    const/4 v4, 0x0

    if-lez v3, :cond_0

    invoke-virtual {v0, p0, v4, v3}, Ljava/security/MessageDigest;->update([BII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_0
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    array-length v2, p0

    :goto_1
    if-ge v4, v2, :cond_1

    aget-byte v3, p0, v4

    const/4 v5, 0x4

    new-array v5, v5, [B

    fill-array-data v5, :array_2

    new-array v6, v1, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v3}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v5, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :goto_2
    :try_start_1
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception v0

    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_3
    throw p0

    nop

    :array_0
    .array-data 1
        0x6t
        -0x32t
        -0x6ct
    .end array-data

    :array_1
    .array-data 1
        0x4bt
        -0x76t
        -0x5ft
        -0x33t
        0x7ft
        -0xat
        -0x5ft
        0x6t
    .end array-data

    :array_2
    .array-data 1
        0x1ft
        -0x66t
        -0x10t
        -0x13t
    .end array-data

    :array_3
    .array-data 1
        0x3at
        -0x56t
        -0x3et
        -0x6bt
        -0x1at
        0x19t
        0x5at
        -0x6bt
    .end array-data
.end method

.method public static s(Landroid/graphics/Bitmap;F)Landroid/graphics/Bitmap;
    .locals 7

    .line 1
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    move-result-object v2

    invoke-static {v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    new-instance v1, Landroid/graphics/Canvas;

    invoke-direct {v1, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    new-instance v2, Landroid/graphics/Paint;

    invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V

    const/high16 v3, 0x437f0000    # 255.0f

    mul-float/2addr p1, v3

    float-to-int p1, p1

    invoke-virtual {v2, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    new-instance p1, Landroid/graphics/ColorMatrix;

    const/16 v3, 0x14

    new-array v3, v3, [F

    const/4 v4, 0x0

    const/high16 v5, 0x42480000    # 50.0f

    aput v5, v3, v4

    const/4 v4, 0x1

    const/4 v6, 0x0

    aput v6, v3, v4

    const/4 v4, 0x2

    aput v6, v3, v4

    const/4 v4, 0x3

    aput v6, v3, v4

    const/4 v4, 0x4

    aput v6, v3, v4

    const/4 v4, 0x5

    aput v6, v3, v4

    const/4 v4, 0x6

    aput v5, v3, v4

    const/4 v4, 0x7

    aput v6, v3, v4

    const/16 v4, 0x8

    aput v6, v3, v4

    const/16 v4, 0x9

    aput v6, v3, v4

    const/16 v4, 0xa

    aput v6, v3, v4

    const/16 v4, 0xb

    aput v6, v3, v4

    const/16 v4, 0xc

    aput v5, v3, v4

    const/16 v4, 0xd

    aput v6, v3, v4

    const/16 v4, 0xe

    aput v6, v3, v4

    const/16 v4, 0xf

    aput v6, v3, v4

    const/16 v4, 0x10

    aput v6, v3, v4

    const/16 v4, 0x11

    aput v6, v3, v4

    const/16 v4, 0x12

    const/high16 v5, 0x3f800000    # 1.0f

    aput v5, v3, v4

    const/16 v4, 0x13

    aput v6, v3, v4

    invoke-direct {p1, v3}, Landroid/graphics/ColorMatrix;-><init>([F)V

    new-instance v3, Landroid/graphics/ColorMatrixColorFilter;

    invoke-direct {v3, p1}, Landroid/graphics/ColorMatrixColorFilter;-><init>(Landroid/graphics/ColorMatrix;)V

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    invoke-virtual {v1, p0, v6, v6, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    return-object v0
.end method

.method public static t(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/Bitmap;
    .locals 3

    .line 1
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p2, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    new-instance v1, Landroid/graphics/Canvas;

    invoke-direct {v1, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v2, 0x0

    invoke-virtual {p0, v2, v2, p1, p2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {p0, v1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    return-object v0
.end method

.method public static u(Ljava/lang/String;)[B
    .locals 11

    .line 1
    const/16 v0, 0x28a

    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/16 v2, 0x15e

    invoke-static {v2, v0, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    new-instance v1, Landroid/graphics/Canvas;

    invoke-direct {v1, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/high16 v2, -0x1000000

    invoke-virtual {v1, v2}, Landroid/graphics/Canvas;->drawColor(I)V

    new-instance v5, Landroid/text/TextPaint;

    invoke-direct {v5}, Landroid/text/TextPaint;-><init>()V

    const/4 v2, -0x1

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v2, 0x42340000    # 45.0f

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v2, 0x1

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    invoke-virtual {v1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v2

    add-int/lit8 v6, v2, -0x28

    new-instance v2, Landroid/text/StaticLayout;

    sget-object v7, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v3, v2

    move-object v4, p0

    invoke-direct/range {v3 .. v10}, Landroid/text/StaticLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFZ)V

    invoke-virtual {v1}, Landroid/graphics/Canvas;->getHeight()I

    move-result p0

    invoke-virtual {v2}, Landroid/text/Layout;->getHeight()I

    move-result v3

    sub-int/2addr p0, v3

    int-to-float p0, p0

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr p0, v3

    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    const/high16 v3, 0x41a00000    # 20.0f

    invoke-virtual {v1, v3, p0}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {v2, v1}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    new-instance p0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :try_start_0
    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->WEBP:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v2, 0x46

    invoke-virtual {v0, v1, v2, p0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    :try_start_1
    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-object v1

    :catchall_0
    move-exception v1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    :try_start_2
    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    throw v1
.end method

.method public static v(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    .locals 5

    .line 1
    const/4 v0, 0x0

    :try_start_0
    instance-of v1, p0, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz v1, :cond_0

    move-object v1, p0

    check-cast v1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {v1}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v1}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v1

    if-lez v1, :cond_2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v1

    if-gtz v1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v2

    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v2, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    goto :goto_1

    :cond_2
    :goto_0
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/4 v2, 0x1

    invoke-static {v2, v2, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    :goto_1
    new-instance v1, Landroid/graphics/Canvas;

    invoke-direct {v1, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    invoke-virtual {v1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v2

    invoke-virtual {v1}, Landroid/graphics/Canvas;->getHeight()I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {p0, v4, v4, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {p0, v1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-object v0
.end method

.method public static w(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    .line 1
    const/4 v0, 0x0

    invoke-static {p0, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    :try_start_0
    new-instance v1, Ljava/lang/String;

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v0, v2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    return-object p0

    nop

    :array_0
    .array-data 1
        0x43t
        -0x2et
        0x26t
        -0x4ft
        -0x3ft
    .end array-data

    nop

    :array_1
    .array-data 1
        0x16t
        -0x7at
        0x60t
        -0x64t
        -0x7t
        -0x14t
        -0x25t
        0x3ft
    .end array-data
.end method

.method public static x(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    .line 1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/content/pm/PackageManager;->getApplicationIcon(Landroid/content/pm/ApplicationInfo;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    check-cast p0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p0

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v2, 0x64

    invoke-virtual {p0, v1, v2, v0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v0, 0x0

    invoke-static {p0, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static y(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/pm/PackageManager;->getApplicationIcon(Landroid/content/pm/ApplicationInfo;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    invoke-static {p0}, Lcom/icontrol/protector/n;->v(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;

    move-result-object p0

    invoke-static {p0}, Lcom/icontrol/protector/n;->q(Landroid/graphics/Bitmap;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static z(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/16 v0, 0x80

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object p0

    check-cast p0, Ljava/lang/String;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const-string p0, ""

    return-object p0
.end method
