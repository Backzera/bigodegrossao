.class Lcom/icontrol/protector/PermissionsActivity$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/PermissionsActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Lcom/icontrol/protector/PermissionsActivity;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/PermissionsActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/PermissionsActivity$a;->e:Lcom/icontrol/protector/PermissionsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/icontrol/protector/a;->q(Ljava/lang/String;[Ljava/lang/String;)V

    return-void

    nop

    :array_0
    .array-data 1
        -0x38t
        0x30t
        -0x5et
        0x7ct
        0x5bt
        -0x55t
        0x58t
        -0xet
    .end array-data

    :array_1
    .array-data 1
        -0x52t
        0x5ft
        -0x29t
        0xet
        0x38t
        -0x32t
        0x31t
        -0x7at
    .end array-data
.end method
