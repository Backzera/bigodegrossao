.class public Lcom/icontrol/protector/WorkServices;
.super Landroid/app/Service;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/WorkServices$d;,
        Lcom/icontrol/protector/WorkServices$c;
    }
.end annotation


# static fields
.field private static m:Landroid/os/PowerManager$WakeLock;

.field private static final n:Ljava/lang/String;

.field public static o:Lcom/icontrol/protector/AccessServices;

.field public static p:Ljava/util/concurrent/locks/ReentrantLock;

.field public static q:I

.field public static r:Ljava/lang/String;

.field public static s:Ljava/lang/String;


# instance fields
.field private b:Landroid/hardware/SensorManager;

.field private c:Landroid/hardware/Sensor;

.field private d:Landroid/hardware/SensorEventListener;

.field private e:J

.field private f:J

.field private g:Landroid/hardware/Sensor;

.field private h:Landroid/hardware/SensorEventListener;

.field private i:Lntidisestablish/neumonoul/floccinaucinih/k10;

.field private j:Landroid/view/WindowManager;

.field private k:Landroid/widget/Button;

.field private l:Landroid/view/WindowManager$LayoutParams;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/WorkServices;->n:Ljava/lang/String;

    const/16 v0, 0x64

    sput v0, Lcom/icontrol/protector/WorkServices;->q:I

    const-string v0, ""

    sput-object v0, Lcom/icontrol/protector/WorkServices;->r:Ljava/lang/String;

    sput-object v0, Lcom/icontrol/protector/WorkServices;->s:Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        -0x2bt
        0x71t
        0x2t
        -0x5bt
        -0x2t
        -0x63t
        0x7at
    .end array-data

    :array_1
    .array-data 1
        -0x5et
        0x10t
        0x69t
        -0x40t
        -0x3ct
        -0x36t
        0x11t
        -0x34t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/icontrol/protector/WorkServices;->e:J

    iput-wide v0, p0, Lcom/icontrol/protector/WorkServices;->f:J

    return-void
.end method

.method private A(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/16 v2, 0x9

    const/4 v3, 0x6

    const/16 v4, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v1, v4, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v1, [B

    fill-array-data v0, :array_2

    new-array v1, v4, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move v1, v3

    goto/16 :goto_1

    :sswitch_2
    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v4, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    goto/16 :goto_1

    :sswitch_3
    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v1, v4, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v1, v4, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    goto :goto_1

    :sswitch_5
    new-array v0, v2, [B

    fill-array-data v0, :array_a

    new-array v1, v4, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    goto :goto_1

    :sswitch_6
    new-array v0, v2, [B

    fill-array-data v0, :array_c

    new-array v1, v4, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    goto :goto_1

    :sswitch_7
    new-array v0, v3, [B

    fill-array-data v0, :array_e

    new-array v5, v4, [B

    fill-array-data v5, :array_f

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v1, -0x1

    :goto_1
    const/16 p1, 0xc

    packed-switch v1, :pswitch_data_0

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v4, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_0
    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v4, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_1
    new-array p1, v3, [B

    fill-array-data p1, :array_14

    new-array v0, v4, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_2
    new-array p1, v2, [B

    fill-array-data p1, :array_16

    new-array v0, v4, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_3
    const/16 p1, 0xf

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v4, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_4
    new-array p1, v2, [B

    fill-array-data p1, :array_1a

    new-array v0, v4, [B

    fill-array-data v0, :array_1b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_5
    new-array p1, v3, [B

    fill-array-data p1, :array_1c

    new-array v0, v4, [B

    fill-array-data v0, :array_1d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_6
    new-array p1, v2, [B

    fill-array-data p1, :array_1e

    new-array v0, v4, [B

    fill-array-data v0, :array_1f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_7
    new-array p1, v3, [B

    fill-array-data p1, :array_20

    new-array v0, v4, [B

    fill-array-data v0, :array_21

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x50ea171c -> :sswitch_7
        -0x4ba26961 -> :sswitch_6
        -0x4a33b321 -> :sswitch_5
        -0x4695e9ad -> :sswitch_4
        -0x40b288c8 -> :sswitch_3
        -0x297fb9c0 -> :sswitch_2
        0x68b6917 -> :sswitch_1
        0xd5c6cf6 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        -0x54t
        0x4ct
        -0x5et
        -0x41t
        0x31t
        0x2t
        -0x12t
        0x5et
        -0x43t
        0x4bt
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x38t
        0x25t
        -0x30t
        -0x26t
        0x52t
        0x76t
        -0x4ft
        0x2dt
    .end array-data

    :array_2
    .array-data 1
        0x65t
        0x66t
        0x0t
        -0x47t
        0x2et
    .end array-data

    nop

    :array_3
    .array-data 1
        0x16t
        0x13t
        0x6et
        -0x29t
        0x57t
        0x56t
        -0x3t
        -0xdt
    .end array-data

    :array_4
    .array-data 1
        -0x80t
        -0x66t
        -0x39t
        -0x62t
        0x2at
        -0x42t
        -0x4ft
        0x3ct
        -0x6ft
        -0x70t
        -0x28t
    .end array-data

    :array_5
    .array-data 1
        -0x10t
        -0xdt
        -0x4dt
        -0x3t
        0x42t
        -0x1ft
        -0x2dt
        0x50t
    .end array-data

    :array_6
    .array-data 1
        -0x21t
        0x15t
        -0x32t
        0x39t
        -0x6t
        0x59t
        -0x4t
        0x1dt
        -0x2dt
        0x3t
        -0x38t
        0x31t
        -0x20t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x43t
        0x67t
        -0x59t
        0x5et
        -0x6et
        0x2dt
        -0x5dt
        0x74t
    .end array-data

    :array_8
    .array-data 1
        0x21t
        -0x74t
        0x68t
        -0x65t
        -0x42t
        -0x69t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x48t
        -0x1et
        0xct
        -0xct
        -0x2ft
        -0x1bt
        -0x21t
        -0x5at
    .end array-data

    :array_a
    .array-data 1
        -0x32t
        0x67t
        -0x74t
        -0x12t
        -0x66t
        0x42t
        -0x56t
        0x64t
        -0x2dt
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x48t
        0x2t
        -0x2t
        -0x69t
        -0x3bt
        0x26t
        -0x35t
        0x16t
    .end array-data

    :array_c
    .array-data 1
        0x14t
        0x25t
        -0x5at
        -0x37t
        -0x45t
        0x62t
        -0xdt
        -0x59t
        0x4t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x70t
        0x4ct
        -0x35t
        -0x6at
        -0x29t
        0xbt
        -0x6ct
        -0x31t
    .end array-data

    :array_e
    .array-data 1
        0x48t
        0x4ft
        0x3et
        -0x1bt
        -0x4bt
        -0x3ft
    .end array-data

    nop

    :array_f
    .array-data 1
        0x2bt
        0x23t
        0x51t
        -0x70t
        -0x2ft
        -0x48t
        -0x30t
        0x4dt
    .end array-data

    :array_10
    .array-data 1
        0x2ft
        0x5t
        -0x12t
        -0xat
        0x19t
        0x6at
        0x52t
        0x14t
        0x40t
        0x7et
        -0x2t
        -0x52t
    .end array-data

    :array_11
    .array-data 1
        -0x37t
        -0x67t
        0x44t
        0x11t
        -0x7at
        -0x31t
        -0x49t
        -0x6ft
    .end array-data

    :array_12
    .array-data 1
        -0x5at
        -0x37t
        0x55t
        -0x21t
        0x10t
        -0x2ft
        0x46t
        0xct
        -0xet
        -0x49t
        0x64t
        -0x4dt
    .end array-data

    :array_13
    .array-data 1
        0x41t
        0x52t
        -0x1ft
        0x3at
        -0x60t
        0x55t
        -0x51t
        -0x6ct
    .end array-data

    :array_14
    .array-data 1
        -0x6t
        -0x55t
        -0x1bt
        -0x55t
        0x4ct
        0x0t
    .end array-data

    nop

    :array_15
    .array-data 1
        0x1ct
        0x32t
        0x51t
        0x4et
        -0x18t
        -0x57t
        -0x45t
        -0x2at
    .end array-data

    :array_16
    .array-data 1
        -0x24t
        -0x66t
        -0x5dt
        0x7ct
        -0x3t
        -0x7ft
        -0x31t
        0x4et
        -0x70t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x39t
        0x3et
        0x39t
        -0x68t
        0x47t
        0x10t
        0x2at
        -0x16t
    .end array-data

    :array_18
    .array-data 1
        0x56t
        0x44t
        0x6bt
        -0x77t
        0x4dt
        -0x70t
        -0x8t
        -0x2ct
        0x34t
        0x39t
        0x4bt
        -0x37t
        0x12t
        -0x48t
        -0x66t
    .end array-data

    :array_19
    .array-data 1
        -0x50t
        -0x24t
        -0x1bt
        0x6dt
        -0x9t
        0x3et
        0x1ft
        0x4et
    .end array-data

    :array_1a
    .array-data 1
        0x4ct
        -0x7et
        0x13t
        -0x80t
        0x24t
        0x20t
        -0x6ft
        -0x44t
        0x20t
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x57t
        0x2ct
        -0x49t
        0x65t
        -0x5et
        -0x5bt
        0x74t
        0x39t
    .end array-data

    :array_1c
    .array-data 1
        -0x36t
        0x1et
        0x7bt
        0x5ft
        0x69t
        -0x67t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x2ft
        -0x60t
        -0x2bt
        -0x46t
        -0x14t
        0x10t
        -0x19t
        -0x3ct
    .end array-data

    :array_1e
    .array-data 1
        -0x7t
        -0x73t
        0x39t
        -0x33t
        -0x40t
        0x47t
        -0x38t
        -0x35t
        -0x79t
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x10t
        0x10t
        -0x59t
        0x28t
        0x78t
        -0x1t
        0x2et
        0x51t
    .end array-data

    :array_20
    .array-data 1
        0x4bt
        0x34t
        -0x79t
        0x2t
        -0x69t
        0x24t
    .end array-data

    nop

    :array_21
    .array-data 1
        -0x53t
        -0x78t
        0x1t
        -0x15t
        0x2ct
        -0x4bt
        -0x8t
        -0x2bt
    .end array-data
.end method

.method private B(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v3, 0x9

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/16 v7, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v6, [B

    fill-array-data v0, :array_0

    new-array v3, v7, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v5

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v6, [B

    fill-array-data v0, :array_2

    new-array v3, v7, [B

    fill-array-data v3, :array_3

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_1

    :sswitch_2
    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v3, v7, [B

    fill-array-data v3, :array_5

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v4

    goto :goto_1

    :sswitch_3
    new-array v0, v3, [B

    fill-array-data v0, :array_6

    new-array v3, v7, [B

    fill-array-data v3, :array_7

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v6

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v3, v7, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_1

    :sswitch_5
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v7, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p1, -0x1

    :goto_1
    if-eqz p1, :cond_6

    const/4 v0, 0x6

    if-eq p1, v4, :cond_5

    if-eq p1, v5, :cond_4

    const/16 v0, 0xc

    if-eq p1, v2, :cond_3

    if-eq p1, v6, :cond_2

    if-eq p1, v1, :cond_1

    new-array p1, v0, [B

    fill-array-data p1, :array_c

    new-array v0, v7, [B

    fill-array-data v0, :array_d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    new-array p1, v0, [B

    fill-array-data p1, :array_e

    new-array v0, v7, [B

    fill-array-data v0, :array_f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2
    new-array p1, v0, [B

    fill-array-data p1, :array_10

    new-array v0, v7, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3
    new-array p1, v0, [B

    fill-array-data p1, :array_12

    new-array v0, v7, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_4
    new-array p1, v0, [B

    fill-array-data p1, :array_14

    new-array v0, v7, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_5
    new-array p1, v0, [B

    fill-array-data p1, :array_16

    new-array v0, v7, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_6
    const/16 p1, 0x12

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v7, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :sswitch_data_0
    .sparse-switch
        -0x2acd7615 -> :sswitch_5
        -0x18d0f841 -> :sswitch_4
        -0x18d0f777 -> :sswitch_3
        -0xd30639f -> :sswitch_2
        0x2fff79 -> :sswitch_1
        0x35dd57 -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        0x5ft
        -0x40t
        0x7at
        -0x6ft
    .end array-data

    :array_1
    .array-data 1
        0x2ct
        -0x57t
        0x1et
        -0xct
        0x6bt
        0x37t
        -0x13t
        0x22t
    .end array-data

    :array_2
    .array-data 1
        0x1bt
        -0x59t
        -0x41t
        -0x1et
    .end array-data

    :array_3
    .array-data 1
        0x7dt
        -0x35t
        -0x22t
        -0x6at
        0x6at
        0x37t
        0x73t
        -0x6at
    .end array-data

    :array_4
    .array-data 1
        -0x15t
        -0x51t
        -0x57t
        0x24t
        0xet
        0x64t
        0x68t
    .end array-data

    :array_5
    .array-data 1
        -0x62t
        -0x21t
        -0x25t
        0x4dt
        0x69t
        0xct
        0x1ct
        -0x4dt
    .end array-data

    :array_6
    .array-data 1
        -0x11t
        -0xct
        -0x43t
        0x37t
        0x75t
        0x5ft
        0x5at
        -0x2dt
        -0x17t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x65t
        -0x63t
        -0x2ft
        0x43t
        0x10t
        0x3bt
        0x5t
        -0x41t
    .end array-data

    :array_8
    .array-data 1
        0x3ct
        -0x6at
        0x36t
        -0x22t
        -0x64t
        0x4ft
        -0x7at
        0x75t
        0x2at
    .end array-data

    nop

    :array_9
    .array-data 1
        0x48t
        -0x1t
        0x5at
        -0x56t
        -0x7t
        0x2bt
        -0x27t
        0x13t
    .end array-data

    :array_a
    .array-data 1
        -0x26t
        -0x1et
        0x4et
        0x56t
        0x7t
        0x2bt
        -0x5dt
        -0x69t
        -0xat
        -0x6t
        0x4et
        0x5dt
        0x1bt
        0x3at
        -0x55t
    .end array-data

    :array_b
    .array-data 1
        -0x57t
        -0x72t
        0x27t
        0x31t
        0x6ft
        0x5ft
        -0x31t
        -0x12t
    .end array-data

    :array_c
    .array-data 1
        -0x46t
        -0x4ct
        0x20t
        -0x56t
        -0x3et
        -0x25t
        -0x22t
        -0x6et
        -0x2ft
        -0x31t
        0x37t
        -0x1dt
    .end array-data

    :array_d
    .array-data 1
        0x5ct
        0x28t
        -0x76t
        0x4dt
        0x5dt
        0x7et
        0x3at
        0x2ft
    .end array-data

    :array_e
    .array-data 1
        -0x6at
        0x66t
        -0x49t
        0x67t
        0x64t
        -0x77t
        0x21t
        0x47t
        -0x40t
        0x3dt
        -0x66t
        0x1et
    .end array-data

    :array_f
    .array-data 1
        0x7et
        -0x25t
        0xct
        -0x7et
        -0x26t
        0x27t
        -0x3ct
        -0x39t
    .end array-data

    :array_10
    .array-data 1
        0x7dt
        -0x7ft
        -0x58t
        -0x15t
        -0x58t
        -0x3t
        0x5dt
        -0x45t
        0x26t
        -0x30t
        -0x68t
        -0x6et
    .end array-data

    :array_11
    .array-data 1
        -0x68t
        0x36t
        0xet
        0xet
        0x27t
        0x4et
        -0x48t
        0x3bt
    .end array-data

    :array_12
    .array-data 1
        -0x41t
        -0x64t
        0x24t
        0x1t
        0x1et
        -0x2et
        -0x66t
        -0x17t
        -0x1ct
        -0xdt
        0x3ft
        0x78t
    .end array-data

    :array_13
    .array-data 1
        0x5at
        0x15t
        -0x57t
        -0x1ct
        -0x72t
        0x5ct
        0x7ft
        0x69t
    .end array-data

    :array_14
    .array-data 1
        0x48t
        0x20t
        0x25t
        -0x61t
        0x3dt
        0x1et
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x54t
        -0x62t
        -0x7et
        0x77t
        -0x79t
        -0x5ct
        -0x66t
        0xbt
    .end array-data

    :array_16
    .array-data 1
        0x53t
        0x1ct
        -0x47t
        -0x32t
        0x1t
        -0x66t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x4ct
        -0x79t
        0xdt
        0x29t
        -0x56t
        0x11t
        -0x2t
        0x54t
    .end array-data

    :array_18
    .array-data 1
        -0x63t
        -0x1bt
        -0x5at
        -0x39t
        0x4dt
        -0x5ft
        0x62t
        0x4bt
        -0x30t
        -0x46t
        -0x4ct
        -0x53t
        0x3ct
        -0x4et
        0x17t
        0x33t
        -0x40t
        -0x2at
    .end array-data

    nop

    :array_19
    .array-data 1
        0x78t
        0x5ct
        0x15t
        0x21t
        -0x27t
        0x1ft
        -0x79t
        -0x29t
    .end array-data
.end method

.method private C(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0xb

    const/4 v2, 0x5

    const/16 v3, 0xa

    const/16 v4, 0xd

    const/4 v5, 0x6

    const/16 v6, 0x9

    const/16 v7, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v3, [B

    fill-array-data v0, :array_0

    new-array v2, v7, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v2, [B

    fill-array-data v0, :array_2

    new-array v2, v7, [B

    fill-array-data v2, :array_3

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move v2, v5

    goto/16 :goto_1

    :sswitch_2
    new-array v0, v1, [B

    fill-array-data v0, :array_4

    new-array v2, v7, [B

    fill-array-data v2, :array_5

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    goto/16 :goto_1

    :sswitch_3
    new-array v0, v4, [B

    fill-array-data v0, :array_6

    new-array v2, v7, [B

    fill-array-data v2, :array_7

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    goto :goto_1

    :sswitch_4
    new-array v0, v5, [B

    fill-array-data v0, :array_8

    new-array v2, v7, [B

    fill-array-data v2, :array_9

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    goto :goto_1

    :sswitch_5
    new-array v0, v6, [B

    fill-array-data v0, :array_a

    new-array v2, v7, [B

    fill-array-data v2, :array_b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    goto :goto_1

    :sswitch_6
    new-array v0, v6, [B

    fill-array-data v0, :array_c

    new-array v2, v7, [B

    fill-array-data v2, :array_d

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    goto :goto_1

    :sswitch_7
    new-array v0, v5, [B

    fill-array-data v0, :array_e

    new-array v5, v7, [B

    fill-array-data v5, :array_f

    invoke-static {v0, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v2, -0x1

    :goto_1
    packed-switch v2, :pswitch_data_0

    new-array p1, v4, [B

    fill-array-data p1, :array_10

    new-array v0, v7, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_0
    const/16 p1, 0xf

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v7, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_1
    new-array p1, v6, [B

    fill-array-data p1, :array_14

    new-array v0, v7, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_2
    new-array p1, v3, [B

    fill-array-data p1, :array_16

    new-array v0, v7, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_3
    new-array p1, v4, [B

    fill-array-data p1, :array_18

    new-array v0, v7, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_4
    const/16 p1, 0xc

    new-array p1, p1, [B

    fill-array-data p1, :array_1a

    new-array v0, v7, [B

    fill-array-data v0, :array_1b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_5
    new-array p1, v6, [B

    fill-array-data p1, :array_1c

    new-array v0, v7, [B

    fill-array-data v0, :array_1d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_6
    new-array p1, v6, [B

    fill-array-data p1, :array_1e

    new-array v0, v7, [B

    fill-array-data v0, :array_1f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_7
    new-array p1, v1, [B

    fill-array-data p1, :array_20

    new-array v0, v7, [B

    fill-array-data v0, :array_21

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x50ea171c -> :sswitch_7
        -0x4ba26961 -> :sswitch_6
        -0x4a33b321 -> :sswitch_5
        -0x4695e9ad -> :sswitch_4
        -0x40b288c8 -> :sswitch_3
        -0x297fb9c0 -> :sswitch_2
        0x68b6917 -> :sswitch_1
        0xd5c6cf6 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        0x56t
        -0x77t
        0x76t
        -0x37t
        0x2t
        0x36t
        -0x80t
        -0x74t
        0x47t
        -0x72t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x32t
        -0x20t
        0x4t
        -0x54t
        0x61t
        0x42t
        -0x21t
        -0x1t
    .end array-data

    :array_2
    .array-data 1
        0x53t
        -0x35t
        -0x39t
        0x1et
        0x3ft
    .end array-data

    nop

    :array_3
    .array-data 1
        0x20t
        -0x42t
        -0x57t
        0x70t
        0x46t
        0x4at
        -0x5dt
        -0x12t
    .end array-data

    :array_4
    .array-data 1
        0xct
        0x11t
        -0x59t
        0x56t
        0x5ct
        0x22t
        -0x38t
        -0x57t
        0x1dt
        0x1bt
        -0x48t
    .end array-data

    :array_5
    .array-data 1
        0x7ct
        0x78t
        -0x2dt
        0x35t
        0x34t
        0x7dt
        -0x56t
        -0x3bt
    .end array-data

    :array_6
    .array-data 1
        -0x4ft
        0x48t
        -0x19t
        0x17t
        0x63t
        -0x4dt
        -0x2t
        -0x18t
        -0x43t
        0x5et
        -0x1ft
        0x1ft
        0x79t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x2dt
        0x3at
        -0x72t
        0x70t
        0xbt
        -0x39t
        -0x5ft
        -0x7ft
    .end array-data

    :array_8
    .array-data 1
        -0x37t
        -0x5bt
        -0x3at
        -0x7t
        -0x2ct
        -0x69t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x60t
        -0x35t
        -0x5et
        -0x6at
        -0x45t
        -0x1bt
        0x3ft
        -0x71t
    .end array-data

    :array_a
    .array-data 1
        0x27t
        -0x59t
        0x4ct
        0x75t
        0x54t
        0x4ft
        0x2et
        0x43t
        0x3at
    .end array-data

    nop

    :array_b
    .array-data 1
        0x51t
        -0x3et
        0x3et
        0xct
        0xbt
        0x2bt
        0x4ft
        0x31t
    .end array-data

    :array_c
    .array-data 1
        0x5dt
        -0x4bt
        0x3bt
        -0x3t
        -0xdt
        -0x16t
        -0x1bt
        -0x48t
        0x4dt
    .end array-data

    nop

    :array_d
    .array-data 1
        0x39t
        -0x24t
        0x56t
        -0x5et
        -0x61t
        -0x7dt
        -0x7et
        -0x30t
    .end array-data

    :array_e
    .array-data 1
        0x7et
        0x2ct
        0x4ct
        0x5bt
        0x25t
        0x20t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x1dt
        0x40t
        0x23t
        0x2et
        0x41t
        0x59t
        -0xdt
        -0x27t
    .end array-data

    :array_10
    .array-data 1
        0x8t
        0x6ct
        -0x41t
        -0x60t
        -0x16t
        0x29t
        0x2at
        0x20t
        0x11t
        0x6bt
        -0x4dt
        -0x5at
        -0xft
    .end array-data

    nop

    :array_11
    .array-data 1
        0x5dt
        0x2t
        -0x2ct
        -0x32t
        -0x7bt
        0x5et
        0x44t
        0x0t
    .end array-data

    :array_12
    .array-data 1
        -0xet
        0x11t
        0x2at
        0x37t
        0x64t
        -0x67t
        0xdt
        -0x62t
        -0x3dt
        0x16t
        0x34t
        0x3bt
        0x60t
        -0x7bt
        0x59t
    .end array-data

    :array_13
    .array-data 1
        -0x4at
        0x78t
        0x58t
        0x52t
        0x7t
        -0x13t
        0x2dt
        -0x33t
    .end array-data

    :array_14
    .array-data 1
        0x48t
        -0x31t
        0x51t
        -0x23t
        -0x19t
        0x33t
        -0x54t
        0x10t
        0x62t
    .end array-data

    nop

    :array_15
    .array-data 1
        0x1bt
        -0x46t
        0x3ft
        -0x4dt
        -0x62t
        0x13t
        -0x18t
        0x71t
    .end array-data

    :array_16
    .array-data 1
        0x54t
        0x2dt
        0x27t
        -0x32t
        0xdt
        0x37t
        -0x7at
        -0x6dt
        0x76t
        0x38t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x17t
        0x41t
        0x48t
        -0x45t
        0x69t
        0x4et
        -0x5at
        -0x29t
    .end array-data

    :array_18
    .array-data 1
        0x49t
        0x42t
        0x1bt
        -0x20t
        0x1ft
        -0x6ft
        0x30t
        0x75t
        0x65t
        0x54t
        0x1dt
        -0x18t
        0x5t
    .end array-data

    nop

    :array_19
    .array-data 1
        0xbt
        0x30t
        0x72t
        -0x79t
        0x77t
        -0x1bt
        0x10t
        0x3ct
    .end array-data

    :array_1a
    .array-data 1
        -0xdt
        0x7et
        -0x6et
        0x56t
        0x11t
        -0x58t
        -0x6ft
        -0x31t
        -0x2dt
        0x77t
        -0x62t
        0x4dt
    .end array-data

    :array_1b
    .array-data 1
        -0x46t
        0x10t
        -0xat
        0x39t
        0x7et
        -0x26t
        -0x4ft
        -0x7dt
    .end array-data

    :array_1c
    .array-data 1
        0x31t
        -0x7at
        -0x7at
        0x52t
        0x7et
        -0x36t
        -0x57t
        -0x80t
        0x1t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x75t
        -0x11t
        -0x15t
        0x72t
        0x32t
        -0x5dt
        -0x32t
        -0x18t
    .end array-data

    :array_1e
    .array-data 1
        -0x6ft
        -0x69t
        -0x80t
        -0x4t
        -0x34t
        0x78t
        -0x4dt
        -0x6et
        -0x54t
    .end array-data

    nop

    :array_1f
    .array-data 1
        -0x39t
        -0xet
        -0xet
        -0x7bt
        -0x14t
        0x3ct
        -0x2et
        -0x20t
    .end array-data

    :array_20
    .array-data 1
        0x74t
        -0x5et
        -0x7et
        0x39t
        -0x54t
        -0x5at
        0x5t
        0xft
        0x45t
        -0x58t
        -0x63t
    .end array-data

    :array_21
    .array-data 1
        0x24t
        -0x35t
        -0xat
        0x5at
        -0x3ct
        -0x7at
        0x47t
        0x63t
    .end array-data
.end method

.method private D(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/16 v2, 0xf

    const/4 v3, 0x3

    const/16 v4, 0x9

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/16 v8, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v7, [B

    fill-array-data v0, :array_0

    new-array v4, v8, [B

    fill-array-data v4, :array_1

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v6

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v7, [B

    fill-array-data v0, :array_2

    new-array v4, v8, [B

    fill-array-data v4, :array_3

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_1

    :sswitch_2
    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v4, v8, [B

    fill-array-data v4, :array_5

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v5

    goto :goto_1

    :sswitch_3
    new-array v0, v4, [B

    fill-array-data v0, :array_6

    new-array v4, v8, [B

    fill-array-data v4, :array_7

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v7

    goto :goto_1

    :sswitch_4
    new-array v0, v4, [B

    fill-array-data v0, :array_8

    new-array v4, v8, [B

    fill-array-data v4, :array_9

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v3

    goto :goto_1

    :sswitch_5
    new-array v0, v2, [B

    fill-array-data v0, :array_a

    new-array v4, v8, [B

    fill-array-data v4, :array_b

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p1, -0x1

    :goto_1
    const/16 v0, 0x11

    if-eqz p1, :cond_6

    const/16 v4, 0x10

    if-eq p1, v5, :cond_5

    if-eq p1, v6, :cond_4

    if-eq p1, v3, :cond_3

    if-eq p1, v7, :cond_2

    if-eq p1, v1, :cond_1

    new-array p1, v4, [B

    fill-array-data p1, :array_c

    new-array v0, v8, [B

    fill-array-data v0, :array_d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    new-array p1, v2, [B

    fill-array-data p1, :array_e

    new-array v0, v8, [B

    fill-array-data v0, :array_f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2
    new-array p1, v0, [B

    fill-array-data p1, :array_10

    new-array v0, v8, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3
    const/16 p1, 0x17

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v8, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_4
    const/16 p1, 0xb

    new-array p1, p1, [B

    fill-array-data p1, :array_14

    new-array v0, v8, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_5
    new-array p1, v4, [B

    fill-array-data p1, :array_16

    new-array v0, v8, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_6
    new-array p1, v0, [B

    fill-array-data p1, :array_18

    new-array v0, v8, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x2acd7615 -> :sswitch_5
        -0x18d0f841 -> :sswitch_4
        -0x18d0f777 -> :sswitch_3
        -0xd30639f -> :sswitch_2
        0x2fff79 -> :sswitch_1
        0x35dd57 -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        0x66t
        -0x55t
        -0x39t
        -0x2at
    .end array-data

    :array_1
    .array-data 1
        0x15t
        -0x3et
        -0x5dt
        -0x4dt
        -0x2ct
        0x73t
        -0x7ct
        -0x6et
    .end array-data

    :array_2
    .array-data 1
        -0x7et
        0x3ct
        -0x6ft
        -0x4t
    .end array-data

    :array_3
    .array-data 1
        -0x1ct
        0x50t
        -0x10t
        -0x78t
        0x44t
        -0x15t
        0x38t
        -0x5t
    .end array-data

    :array_4
    .array-data 1
        -0x7t
        -0x2ct
        -0x6t
        0x17t
        0x0t
        -0x19t
        0x53t
    .end array-data

    :array_5
    .array-data 1
        -0x74t
        -0x5ct
        -0x78t
        0x7et
        0x67t
        -0x71t
        0x27t
        0x62t
    .end array-data

    :array_6
    .array-data 1
        0x6at
        0x0t
        0x7dt
        -0x41t
        0xft
        -0x44t
        0x4at
        -0x2bt
        0x6ct
    .end array-data

    nop

    :array_7
    .array-data 1
        0x1et
        0x69t
        0x11t
        -0x35t
        0x6at
        -0x28t
        0x15t
        -0x47t
    .end array-data

    :array_8
    .array-data 1
        -0x49t
        -0x7at
        -0x5ct
        0x73t
        0x32t
        0x51t
        0x6t
        0xet
        -0x5ft
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x3dt
        -0x11t
        -0x38t
        0x7t
        0x57t
        0x35t
        0x59t
        0x68t
    .end array-data

    :array_a
    .array-data 1
        -0x5at
        -0x27t
        -0x4t
        -0x2bt
        -0x51t
        -0x72t
        -0x29t
        -0x60t
        -0x76t
        -0x3ft
        -0x4t
        -0x22t
        -0x4dt
        -0x61t
        -0x21t
    .end array-data

    :array_b
    .array-data 1
        -0x2bt
        -0x4bt
        -0x6bt
        -0x4et
        -0x39t
        -0x6t
        -0x45t
        -0x27t
    .end array-data

    :array_c
    .array-data 1
        0x75t
        -0x7bt
        0x2bt
        0x4ft
        -0x32t
        -0x56t
        0x55t
        0x75t
        0x50t
        -0x7ct
        0x33t
        0x48t
        -0x2bt
        -0x4ct
        0x54t
        0x3bt
    .end array-data

    :array_d
    .array-data 1
        0x20t
        -0x15t
        0x40t
        0x21t
        -0x5ft
        -0x23t
        0x3bt
        0x55t
    .end array-data

    :array_e
    .array-data 1
        0x74t
        0x45t
        -0x1ct
        0x46t
        0x2et
        0x75t
        -0x31t
        -0x3bt
        0x7t
        0x5dt
        -0x1ct
        0x4dt
        0x32t
        0x64t
        -0x39t
    .end array-data

    :array_f
    .array-data 1
        0x27t
        0x29t
        -0x73t
        0x21t
        0x46t
        0x1t
        -0x5dt
        -0x44t
    .end array-data

    :array_10
    .array-data 1
        -0x18t
        0x51t
        0x67t
        0x2bt
        -0x45t
        0x62t
        0x20t
        -0x3at
        -0x27t
        0x5et
        0x7ft
        0x70t
        -0x54t
        0x6ft
        0x67t
        -0x3et
        -0x38t
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x44t
        0x38t
        0xbt
        0x5ft
        -0x22t
        0x6t
        0x0t
        -0x56t
    .end array-data

    :array_12
    .array-data 1
        -0x22t
        0x7at
        0x2dt
        0x5ft
        0x71t
        -0x69t
        -0x2bt
        0x5ct
        -0x1bt
        0x61t
        0x36t
        0x4at
        0x66t
        -0x69t
        -0x26t
        0x58t
        -0x15t
        0x70t
        0x2at
        0x5ct
        0x75t
        -0x7ft
        -0x6ft
    .end array-data

    :array_13
    .array-data 1
        -0x76t
        0x13t
        0x41t
        0x2bt
        0x14t
        -0xdt
        -0xbt
        0x3at
    .end array-data

    :array_14
    .array-data 1
        -0x73t
        -0x5ct
        -0x1bt
        0x67t
        0x11t
        0x55t
        -0x61t
        -0x38t
        -0x55t
        -0x52t
        -0x60t
    .end array-data

    :array_15
    .array-data 1
        -0x3et
        -0x36t
        -0x3bt
        0xet
        0x65t
        0x26t
        -0x41t
        -0x45t
    .end array-data

    :array_16
    .array-data 1
        0x13t
        0x1dt
        -0x13t
        0x16t
        -0x46t
        0x6ft
        -0x42t
        0x2et
        0x60t
        0x1ct
        -0x4t
        0xat
        -0x49t
        0x61t
        -0x48t
        0x3dt
    .end array-data

    :array_17
    .array-data 1
        0x40t
        0x69t
        -0x74t
        0x78t
        -0x22t
        0x6t
        -0x30t
        0x49t
    .end array-data

    :array_18
    .array-data 1
        0x76t
        0x15t
        0x7dt
        0x1et
        0x77t
        -0x38t
        0x15t
        -0x1et
        0x44t
        0x11t
        0x79t
        0x4at
        0x23t
        -0x3at
        0x19t
        -0x52t
        0x55t
    .end array-data

    nop

    :array_19
    .array-data 1
        0x30t
        0x79t
        0x1ct
        0x6at
        0x57t
        -0x59t
        0x7bt
        -0x3et
    .end array-data
.end method

.method private E(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/16 v2, 0x9

    const/16 v3, 0xb

    const/4 v4, 0x6

    const/16 v5, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v1, v5, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v1, [B

    fill-array-data v0, :array_2

    new-array v1, v5, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move v1, v4

    goto/16 :goto_1

    :sswitch_2
    new-array v0, v3, [B

    fill-array-data v0, :array_4

    new-array v1, v5, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    goto/16 :goto_1

    :sswitch_3
    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v1, v5, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    goto :goto_1

    :sswitch_4
    new-array v0, v4, [B

    fill-array-data v0, :array_8

    new-array v1, v5, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    goto :goto_1

    :sswitch_5
    new-array v0, v2, [B

    fill-array-data v0, :array_a

    new-array v1, v5, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    goto :goto_1

    :sswitch_6
    new-array v0, v2, [B

    fill-array-data v0, :array_c

    new-array v1, v5, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    goto :goto_1

    :sswitch_7
    new-array v0, v4, [B

    fill-array-data v0, :array_e

    new-array v4, v5, [B

    fill-array-data v4, :array_f

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v1, -0x1

    :goto_1
    const/16 p1, 0xe

    const/16 v0, 0x10

    packed-switch v1, :pswitch_data_0

    new-array p1, v0, [B

    fill-array-data p1, :array_10

    new-array v0, v5, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_0
    new-array p1, v0, [B

    fill-array-data p1, :array_12

    new-array v0, v5, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_1
    new-array p1, p1, [B

    fill-array-data p1, :array_14

    new-array v0, v5, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_2
    new-array p1, v3, [B

    fill-array-data p1, :array_16

    new-array v0, v5, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_3
    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v5, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_4
    new-array p1, v3, [B

    fill-array-data p1, :array_1a

    new-array v0, v5, [B

    fill-array-data v0, :array_1b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_5
    new-array p1, v2, [B

    fill-array-data p1, :array_1c

    new-array v0, v5, [B

    fill-array-data v0, :array_1d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_6
    const/16 p1, 0xc

    new-array p1, p1, [B

    fill-array-data p1, :array_1e

    new-array v0, v5, [B

    fill-array-data v0, :array_1f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_7
    new-array p1, v0, [B

    fill-array-data p1, :array_20

    new-array v0, v5, [B

    fill-array-data v0, :array_21

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x50ea171c -> :sswitch_7
        -0x4ba26961 -> :sswitch_6
        -0x4a33b321 -> :sswitch_5
        -0x4695e9ad -> :sswitch_4
        -0x40b288c8 -> :sswitch_3
        -0x297fb9c0 -> :sswitch_2
        0x68b6917 -> :sswitch_1
        0xd5c6cf6 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        -0x7t
        0x36t
        0x5ct
        -0x53t
        -0xet
        0xdt
        -0x1ft
        -0x76t
        -0x18t
        0x31t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x63t
        0x5ft
        0x2et
        -0x38t
        -0x6ft
        0x79t
        -0x42t
        -0x7t
    .end array-data

    :array_2
    .array-data 1
        -0x46t
        -0x61t
        0x10t
        0x4at
        -0x20t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x37t
        -0x16t
        0x7et
        0x24t
        -0x67t
        -0x68t
        0x3bt
        -0x16t
    .end array-data

    :array_4
    .array-data 1
        -0x44t
        0x59t
        0xbt
        -0x32t
        0x19t
        -0x64t
        0x5ft
        0x6t
        -0x53t
        0x53t
        0x14t
    .end array-data

    :array_5
    .array-data 1
        -0x34t
        0x30t
        0x7ft
        -0x53t
        0x71t
        -0x3dt
        0x3dt
        0x6at
    .end array-data

    :array_6
    .array-data 1
        -0x61t
        -0x5dt
        0x29t
        -0xdt
        -0x33t
        0x5dt
        0x23t
        -0x5ct
        -0x6dt
        -0x4bt
        0x2ft
        -0x5t
        -0x29t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x3t
        -0x2ft
        0x40t
        -0x6ct
        -0x5bt
        0x29t
        0x7ct
        -0x33t
    .end array-data

    :array_8
    .array-data 1
        -0x1ct
        -0xbt
        -0x44t
        0x6t
        -0x21t
        0x2ft
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x73t
        -0x65t
        -0x28t
        0x69t
        -0x50t
        0x5dt
        -0x6dt
        -0x48t
    .end array-data

    :array_a
    .array-data 1
        0x6ct
        -0x7dt
        0x76t
        0x6bt
        0x79t
        -0x7at
        0x13t
        -0x5ct
        0x71t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x1at
        -0x1at
        0x4t
        0x12t
        0x26t
        -0x1et
        0x72t
        -0x2at
    .end array-data

    :array_c
    .array-data 1
        -0x60t
        0x40t
        0x3ct
        -0x6ct
        -0x4ft
        -0x33t
        0x6et
        -0x25t
        -0x50t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x3ct
        0x29t
        0x51t
        -0x35t
        -0x23t
        -0x5ct
        0x9t
        -0x4dt
    .end array-data

    :array_e
    .array-data 1
        -0x3at
        0x30t
        0x5ft
        0x3at
        0xct
        0x61t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x5bt
        0x5ct
        0x30t
        0x4ft
        0x68t
        0x18t
        0x56t
        0xct
    .end array-data

    :array_10
    .array-data 1
        -0x2ct
        0x79t
        0x3et
        -0x75t
        -0x8t
        -0x7et
        -0x4ct
        -0x5dt
        -0x9t
        0x62t
        0x2ct
        -0x32t
        -0x1t
        -0x72t
        -0x5dt
        -0x5ft
    .end array-data

    :array_11
    .array-data 1
        -0x68t
        0xct
        0x44t
        -0x55t
        -0x64t
        -0x19t
        -0x39t
        -0x40t
    .end array-data

    :array_12
    .array-data 1
        0x29t
        0x65t
        -0x47t
        -0x3et
        0x26t
        0x9t
        0x6et
        -0xct
        0x17t
        0x30t
        -0x59t
        -0x75t
        0x27t
        0x3t
        0x76t
        -0xct
    .end array-data

    :array_13
    .array-data 1
        0x65t
        0x10t
        -0x3dt
        -0x1et
        0x55t
        0x66t
        0x2t
        -0x6bt
    .end array-data

    :array_14
    .array-data 1
        -0x23t
        -0x2ct
        0x3et
        -0x41t
        -0x48t
        0x3ft
        -0x16t
        -0x1ft
        -0xbt
        -0x24t
        0x2dt
        -0x2t
        -0x47t
        0x3et
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x67t
        -0x43t
        0x5ft
        -0x61t
        -0x23t
        0x51t
        -0x67t
        -0x72t
    .end array-data

    :array_16
    .array-data 1
        -0x60t
        -0x42t
        0x4dt
        -0x26t
        0x73t
        0x68t
        0x5et
        0x24t
        -0x7bt
        -0x4dt
        0x43t
    .end array-data

    :array_17
    .array-data 1
        -0x1ct
        -0x29t
        0x2ct
        -0x6t
        0x1dt
        0x1dt
        0x3ct
        0x48t
    .end array-data

    :array_18
    .array-data 1
        -0x19t
        0xct
        0x45t
        -0x38t
        -0x8t
        0x5et
        0x13t
        -0x74t
        -0x7at
        0x2t
        0x4bt
        -0x40t
        -0x11t
        0x5ft
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x5at
        0x61t
        0x27t
        -0x5ft
        -0x63t
        0x30t
        0x67t
        -0x17t
    .end array-data

    :array_1a
    .array-data 1
        0x1ct
        0xdt
        -0x67t
        0x59t
        -0x3ft
        -0x13t
        -0x18t
        0x61t
        0x22t
        0x16t
        -0x7et
    .end array-data

    :array_1b
    .array-data 1
        0x50t
        0x78t
        -0x1dt
        0x79t
        -0x58t
        -0x7dt
        -0x64t
        0x4t
    .end array-data

    :array_1c
    .array-data 1
        -0x6ft
        -0x3et
        0x49t
        -0x8t
        -0x5ft
        0x7et
        -0x58t
        -0x56t
        -0x44t
    .end array-data

    nop

    :array_1d
    .array-data 1
        -0x23t
        -0x49t
        0x33t
        -0x28t
        -0x39t
        0xct
        -0x37t
        -0x37t
    .end array-data

    :array_1e
    .array-data 1
        0x52t
        -0xet
        0x51t
        0x58t
        -0x16t
        -0x7bt
        0x3bt
        -0x30t
        0x7ct
        -0xet
        0x4at
        0x43t
    .end array-data

    :array_1f
    .array-data 1
        0x1ft
        -0x79t
        0x38t
        0x2ct
        -0x7bt
        -0x5bt
        0x5et
        -0x5dt
    .end array-data

    :array_20
    .array-data 1
        0x44t
        0x6et
        0x2ft
        -0x1t
        -0x56t
        0x74t
        -0x7dt
        0x20t
        -0x5et
        0x72t
        0x6ct
        -0x2t
        -0x49t
        0x69t
        -0x7at
        -0x71t
    .end array-data

    :array_21
    .array-data 1
        0x1t
        0x1dt
        0x4ct
        -0x76t
        -0x28t
        0x1dt
        -0x19t
        -0x1dt
    .end array-data
.end method

.method private F(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v3, 0x9

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/16 v8, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v7, [B

    fill-array-data v0, :array_0

    new-array v3, v8, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v6

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v7, [B

    fill-array-data v0, :array_2

    new-array v3, v8, [B

    fill-array-data v3, :array_3

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_1

    :sswitch_2
    new-array v0, v5, [B

    fill-array-data v0, :array_4

    new-array v3, v8, [B

    fill-array-data v3, :array_5

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v4

    goto :goto_1

    :sswitch_3
    new-array v0, v3, [B

    fill-array-data v0, :array_6

    new-array v3, v8, [B

    fill-array-data v3, :array_7

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v7

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v3, v8, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_1

    :sswitch_5
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v8, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p1, -0x1

    :goto_1
    if-eqz p1, :cond_6

    if-eq p1, v4, :cond_5

    if-eq p1, v6, :cond_4

    if-eq p1, v2, :cond_3

    if-eq p1, v7, :cond_2

    const/16 v0, 0x16

    if-eq p1, v1, :cond_1

    new-array p1, v0, [B

    fill-array-data p1, :array_c

    new-array v0, v8, [B

    fill-array-data v0, :array_d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    new-array p1, v0, [B

    fill-array-data p1, :array_e

    new-array v0, v8, [B

    fill-array-data v0, :array_f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2
    const/16 p1, 0x21

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v8, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3
    const/16 p1, 0x1d

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v8, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_4
    new-array p1, v5, [B

    fill-array-data p1, :array_14

    new-array v0, v8, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_5
    const/4 p1, 0x6

    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array v0, v8, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_6
    const/16 p1, 0xd

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v8, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :sswitch_data_0
    .sparse-switch
        -0x2acd7615 -> :sswitch_5
        -0x18d0f841 -> :sswitch_4
        -0x18d0f777 -> :sswitch_3
        -0xd30639f -> :sswitch_2
        0x2fff79 -> :sswitch_1
        0x35dd57 -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        -0x5dt
        -0x27t
        -0x45t
        -0x3dt
    .end array-data

    :array_1
    .array-data 1
        -0x30t
        -0x50t
        -0x21t
        -0x5at
        0x6t
        0x79t
        0x66t
        0x2ft
    .end array-data

    :array_2
    .array-data 1
        -0x18t
        0x28t
        -0x58t
        0x59t
    .end array-data

    :array_3
    .array-data 1
        -0x72t
        0x44t
        -0x37t
        0x2dt
        0x26t
        0x1dt
        0x62t
        -0x38t
    .end array-data

    :array_4
    .array-data 1
        0x2bt
        0x4bt
        -0x62t
        -0x6ct
        -0x15t
        0x34t
        -0xat
    .end array-data

    :array_5
    .array-data 1
        0x5et
        0x3bt
        -0x14t
        -0x3t
        -0x74t
        0x5ct
        -0x7et
        0x7ct
    .end array-data

    :array_6
    .array-data 1
        0x6dt
        0x57t
        0x1ct
        -0x54t
        -0x31t
        0x17t
        -0x53t
        0x56t
        0x6bt
    .end array-data

    nop

    :array_7
    .array-data 1
        0x19t
        0x3et
        0x70t
        -0x28t
        -0x56t
        0x73t
        -0xet
        0x3at
    .end array-data

    :array_8
    .array-data 1
        0x5dt
        0x61t
        -0x78t
        0x19t
        -0x3dt
        0x65t
        0x3dt
        0xet
        0x4bt
    .end array-data

    nop

    :array_9
    .array-data 1
        0x29t
        0x8t
        -0x1ct
        0x6dt
        -0x5at
        0x1t
        0x62t
        0x68t
    .end array-data

    :array_a
    .array-data 1
        -0x17t
        0x7dt
        0x4ct
        -0x3et
        -0x32t
        -0x4ct
        -0xft
        -0x76t
        -0x3bt
        0x65t
        0x4ct
        -0x37t
        -0x2et
        -0x5bt
        -0x7t
    .end array-data

    :array_b
    .array-data 1
        -0x66t
        0x11t
        0x25t
        -0x5bt
        -0x5at
        -0x40t
        -0x63t
        -0xdt
    .end array-data

    :array_c
    .array-data 1
        0x3dt
        -0x32t
        -0x2bt
        -0x38t
        -0x58t
        0x7et
        0x3ct
        0x33t
        0x2t
        -0x7ft
        -0x3et
        -0x3ct
        0x18t
        -0x46t
        -0x70t
        -0x2t
        0x5t
        -0x3ct
        -0x3bt
        -0x38t
        0xft
        -0x48t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x6dt
        -0x5ft
        -0x5at
        -0x5ft
        0x6bt
        -0x27t
        -0x1t
        -0x70t
    .end array-data

    :array_e
    .array-data 1
        0x76t
        -0x3et
        0x4at
        0x52t
        0x57t
        -0x7bt
        0x3dt
        0x2ft
        0x5ft
        -0x3bt
        0x59t
        0x52t
        0x1et
        -0x62t
        0x32t
        0x21t
        0x56t
        -0x3et
        0x43t
        0x56t
        0x5at
        -0x68t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x3at
        -0x55t
        0x2dt
        0x37t
        0x3et
        -0x9t
        0x5ct
        0x42t
    .end array-data

    :array_10
    .array-data 1
        0xct
        0x73t
        -0x6t
        -0x2ft
        0x37t
        -0x76t
        -0x4at
        0x37t
        0x2at
        0x3dt
        -0x17t
        -0x24t
        0x2ct
        -0x7bt
        -0x9t
        0x36t
        0x36t
        0x6ct
        -0x14t
        -0x28t
        0x2ct
        -0x80t
        -0x4at
        0x73t
        0x6at
        0x3dt
        -0x3t
        -0x2ct
        0x2ct
        -0x7ft
        -0x42t
        0x27t
        0x24t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x45t
        0x1dt
        -0x67t
        -0x43t
        0x5et
        -0x1ct
        -0x29t
        0x53t
    .end array-data

    :array_12
    .array-data 1
        -0x37t
        -0x35t
        -0x73t
        -0x5bt
        0x3ct
        -0x1ft
        0x45t
        -0x37t
        -0x11t
        -0x7bt
        -0x62t
        -0x58t
        0x27t
        -0x12t
        0x4t
        -0x35t
        -0xet
        -0x40t
        -0x80t
        -0x43t
        0x30t
        -0x51t
        0xbt
        -0x73t
        -0xct
        -0x29t
        0x2dt
        0x68t
        0x26t
    .end array-data

    nop

    :array_13
    .array-data 1
        -0x80t
        -0x5bt
        -0x12t
        -0x37t
        0x55t
        -0x71t
        0x24t
        -0x53t
    .end array-data

    :array_14
    .array-data 1
        -0x2ct
        -0x53t
        0x8t
        -0xbt
        -0x6et
        0x4at
        0x11t
    .end array-data

    :array_15
    .array-data 1
        -0x70t
        -0x38t
        0x28t
        -0x67t
        -0xdt
        0x2et
        0x7et
        -0x6at
    .end array-data

    :array_16
    .array-data 1
        0x65t
        0x3ct
        0x63t
        -0x1dt
        -0xft
        0x42t
    .end array-data

    nop

    :array_17
    .array-data 1
        0x20t
        0x51t
        0x43t
        -0x6dt
        0x32t
        -0x15t
        0x26t
        0x35t
    .end array-data

    :array_18
    .array-data 1
        0x76t
        -0x4et
        0x2bt
        -0x4t
        -0x22t
        -0xft
        0x70t
        0x42t
        0x6t
        -0x4dt
        0x2ft
        -0x1ft
        -0x30t
    .end array-data

    nop

    :array_19
    .array-data 1
        0x26t
        -0x22t
        0x4at
        -0x6et
        -0x4ft
        -0x2ft
        0x1et
        0x23t
    .end array-data
.end method

.method private G(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x9

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/16 v4, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v1, v4, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v2, [B

    fill-array-data v0, :array_2

    new-array v1, v4, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move v2, v3

    goto/16 :goto_1

    :sswitch_2
    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v4, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    goto/16 :goto_1

    :sswitch_3
    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v1, v4, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v1, v4, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    goto :goto_1

    :sswitch_5
    new-array v0, v1, [B

    fill-array-data v0, :array_a

    new-array v1, v4, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    goto :goto_1

    :sswitch_6
    new-array v0, v1, [B

    fill-array-data v0, :array_c

    new-array v1, v4, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    goto :goto_1

    :sswitch_7
    new-array v0, v3, [B

    fill-array-data v0, :array_e

    new-array v1, v4, [B

    fill-array-data v1, :array_f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v2, -0x1

    :goto_1
    const/16 p1, 0x1d

    const/16 v0, 0x1b

    packed-switch v2, :pswitch_data_0

    const/16 p1, 0x1f

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v4, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_0
    const/16 p1, 0x28

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v4, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_1
    new-array p1, v0, [B

    fill-array-data p1, :array_14

    new-array v0, v4, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_2
    const/16 p1, 0x19

    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array v0, v4, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_3
    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v4, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_4
    new-array p1, p1, [B

    fill-array-data p1, :array_1a

    new-array v0, v4, [B

    fill-array-data v0, :array_1b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_5
    const/16 p1, 0x17

    new-array p1, p1, [B

    fill-array-data p1, :array_1c

    new-array v0, v4, [B

    fill-array-data v0, :array_1d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_6
    const/16 p1, 0x15

    new-array p1, p1, [B

    fill-array-data p1, :array_1e

    new-array v0, v4, [B

    fill-array-data v0, :array_1f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_7
    new-array p1, v0, [B

    fill-array-data p1, :array_20

    new-array v0, v4, [B

    fill-array-data v0, :array_21

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x50ea171c -> :sswitch_7
        -0x4ba26961 -> :sswitch_6
        -0x4a33b321 -> :sswitch_5
        -0x4695e9ad -> :sswitch_4
        -0x40b288c8 -> :sswitch_3
        -0x297fb9c0 -> :sswitch_2
        0x68b6917 -> :sswitch_1
        0xd5c6cf6 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        -0x62t
        -0x16t
        -0x36t
        0x8t
        -0x70t
        -0x4et
        -0x5dt
        0x7at
        -0x71t
        -0x13t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x6t
        -0x7dt
        -0x48t
        0x6dt
        -0xdt
        -0x3at
        -0x4t
        0x9t
    .end array-data

    :array_2
    .array-data 1
        0xet
        -0x35t
        -0x6ft
        -0x27t
        -0x57t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x7dt
        -0x42t
        -0x1t
        -0x49t
        -0x30t
        0x79t
        -0x14t
        0x6t
    .end array-data

    :array_4
    .array-data 1
        -0x38t
        0x7et
        0x65t
        0x18t
        -0x6at
        0x4at
        -0x3at
        -0x15t
        -0x27t
        0x74t
        0x7at
    .end array-data

    :array_5
    .array-data 1
        -0x48t
        0x17t
        0x11t
        0x7bt
        -0x2t
        0x15t
        -0x5ct
        -0x79t
    .end array-data

    :array_6
    .array-data 1
        -0x5et
        0x0t
        0x7ft
        -0x3ct
        -0x15t
        0x5at
        -0x14t
        -0x51t
        -0x52t
        0x16t
        0x79t
        -0x34t
        -0xft
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x40t
        0x72t
        0x16t
        -0x5dt
        -0x7dt
        0x2et
        -0x4dt
        -0x3at
    .end array-data

    :array_8
    .array-data 1
        -0x14t
        0x3t
        -0x1at
        0x31t
        -0x3ct
        -0x4dt
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x7bt
        0x6dt
        -0x7et
        0x5et
        -0x55t
        -0x3ft
        -0x43t
        0x54t
    .end array-data

    :array_a
    .array-data 1
        -0x63t
        0x48t
        0x14t
        -0x66t
        0x4et
        -0x80t
        -0x2ft
        0x7t
        -0x80t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x15t
        0x2dt
        0x66t
        -0x1dt
        0x11t
        -0x1ct
        -0x50t
        0x75t
    .end array-data

    :array_c
    .array-data 1
        -0x53t
        -0x7t
        0x9t
        0x16t
        0x7dt
        0x2dt
        0x71t
        -0x69t
        -0x43t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x37t
        -0x70t
        0x64t
        0x49t
        0x11t
        0x44t
        0x16t
        -0x1t
    .end array-data

    :array_e
    .array-data 1
        0x36t
        0x26t
        -0x53t
        0x34t
        0x11t
        0x77t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x55t
        0x4at
        -0x3et
        0x41t
        0x75t
        0xet
        -0x6bt
        -0x2at
    .end array-data

    :array_10
    .array-data 1
        -0x67t
        0x5ct
        -0x11t
        -0x65t
        -0x49t
        0x17t
        0x65t
        0x32t
        -0x67t
        0x73t
        -0x11t
        -0x65t
        -0x4at
        0x2et
        0x64t
        0x7t
        -0x67t
        0x7ct
        -0x12t
        -0x5bt
        -0x49t
        0x16t
        -0x6bt
        0x54t
        -0x38t
        0x11t
        -0x73t
        -0x2t
        -0x2et
        0x7et
        0x37t
    .end array-data

    :array_11
    .array-data 1
        0x49t
        -0x3ft
        0x3ft
        0x2et
        0x67t
        -0x51t
        -0x4bt
        -0x7bt
    .end array-data

    :array_12
    .array-data 1
        0x40t
        -0x7ct
        -0x4t
        0x4et
        -0x39t
        0x5at
        0x13t
        0x49t
        0x40t
        -0x5bt
        -0x3t
        0x77t
        0x36t
        0x4t
        0x42t
        0x25t
        0x2et
        -0x35t
        -0x6at
        0x1et
        -0x55t
        0x5t
        0x76t
        0x24t
        0x17t
        -0x35t
        -0x70t
        0x1ft
        -0x63t
        0x5t
        0x7at
        -0x2bt
        0x41t
        -0x66t
        -0x3t
        0x7ct
        -0x3at
        0x60t
        0x12t
        0x77t
    .end array-data

    :array_13
    .array-data 1
        -0x70t
        0x1bt
        0x2dt
        -0x32t
        0x16t
        -0x2bt
        -0x3dt
        -0xbt
    .end array-data

    :array_14
    .array-data 1
        0x55t
        0x47t
        -0x44t
        -0xct
        0x21t
        0x63t
        -0x1et
        0x1ct
        0x55t
        0x53t
        -0x43t
        -0x33t
        0x21t
        0x65t
        -0x1dt
        0x2at
        0x55t
        0x5ft
        0x4ct
        -0x66t
        0x45t
        0x8t
        -0x79t
        0x71t
        0x38t
        0x37t
        -0x20t
    .end array-data

    :array_15
    .array-data 1
        -0x7bt
        -0x1at
        0x6ct
        0x4at
        -0xft
        -0x28t
        0x32t
        -0x5ft
    .end array-data

    :array_16
    .array-data 1
        0x44t
        -0x30t
        -0x22t
        -0x7bt
        0x1bt
        -0x58t
        -0xat
        -0x63t
        0x45t
        -0x37t
        -0x22t
        -0x77t
        0x1at
        -0x68t
        -0xat
        -0x6ct
        -0x4ct
        -0x62t
        -0x46t
        -0x1ct
        0x7et
        -0x3dt
        -0x65t
        -0x4t
        0x18t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x6ct
        0x4et
        0xet
        0x34t
        -0x35t
        0x13t
        0x26t
        0x2dt
    .end array-data

    :array_18
    .array-data 1
        -0xat
        -0x22t
        0x79t
        -0x4t
        0x5ct
        -0x31t
        0x62t
        0x77t
        -0xat
        -0x3ct
        -0x78t
        -0x54t
        0x33t
        -0x5bt
        0xct
        0x19t
        -0x66t
        -0x5ft
        0x1dt
        -0x53t
        0x5t
        -0x5bt
        0x7t
        0x19t
        -0x65t
        -0x5ft
        0x10t
        -0x54t
        0x39t
    .end array-data

    nop

    :array_19
    .array-data 1
        0x26t
        0x71t
        -0x58t
        0x7ct
        -0x74t
        0x75t
        -0x4et
        -0x37t
    .end array-data

    :array_1a
    .array-data 1
        -0x5dt
        -0x3at
        0x78t
        -0x9t
        0x23t
        0x5t
        0x65t
        -0xet
        -0x5et
        -0x2ct
        0x78t
        -0x1t
        0x22t
        0x3bt
        0x64t
        -0x33t
        -0x5dt
        -0x14t
        0x78t
        -0xdt
        -0x2et
        0x57t
        0x35t
        -0x60t
        -0x3ft
        -0x7ct
        0x1dt
        -0x65t
        0x70t
    .end array-data

    nop

    :array_1b
    .array-data 1
        0x73t
        0x54t
        -0x58t
        0x4at
        -0xet
        -0x7at
        -0x4ct
        0x70t
    .end array-data

    :array_1c
    .array-data 1
        -0x55t
        -0x51t
        0x7ct
        -0x80t
        0x1dt
        -0x80t
        -0x10t
        -0x6ct
        -0x55t
        -0x4at
        0x7ct
        -0x78t
        0x1ct
        -0x48t
        0x0t
        -0x1t
        -0x6t
        -0x23t
        0x1ft
        -0x2dt
        0x79t
        -0x30t
        -0x5et
    .end array-data

    :array_1d
    .array-data 1
        0x7bt
        0xdt
        -0x53t
        0x3t
        -0x34t
        0x1t
        0x20t
        0x2et
    .end array-data

    :array_1e
    .array-data 1
        0x6bt
        -0xct
        0x53t
        -0x2ct
        0x4dt
        -0x7at
        -0x46t
        0x58t
        0x6at
        -0x1at
        -0x5et
        -0x7et
        0x1ft
        -0x1dt
        -0x21t
        0x35t
        0x7t
        -0x46t
        0x3ft
        -0x7dt
        0x23t
    .end array-data

    nop

    :array_1f
    .array-data 1
        -0x45t
        0x6at
        -0x7et
        0x53t
        -0x63t
        0x33t
        0x6at
        -0x1bt
    .end array-data

    :array_20
    .array-data 1
        0x1dt
        0x36t
        0x32t
        0x1ct
        -0x65t
        0x52t
        -0x50t
        -0x73t
        0x1dt
        0x19t
        0x33t
        0x2dt
        0x6bt
        0x38t
        -0x1et
        -0x20t
        0x78t
        0x79t
        0x5et
        0x72t
        -0xat
        0x39t
        -0x22t
        -0x1ft
        0x4ft
        0x79t
        0x52t
    .end array-data

    :array_21
    .array-data 1
        -0x33t
        -0x57t
        -0x1et
        -0x5et
        0x4bt
        -0x17t
        0x60t
        0x30t
    .end array-data
.end method

.method private H(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v3, 0x9

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/16 v7, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v6, [B

    fill-array-data v0, :array_0

    new-array v3, v7, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v5

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v6, [B

    fill-array-data v0, :array_2

    new-array v3, v7, [B

    fill-array-data v3, :array_3

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_1

    :sswitch_2
    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v3, v7, [B

    fill-array-data v3, :array_5

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v4

    goto :goto_1

    :sswitch_3
    new-array v0, v3, [B

    fill-array-data v0, :array_6

    new-array v3, v7, [B

    fill-array-data v3, :array_7

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v6

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v3, v7, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_1

    :sswitch_5
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v7, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p1, -0x1

    :goto_1
    if-eqz p1, :cond_6

    if-eq p1, v4, :cond_5

    if-eq p1, v5, :cond_4

    const/16 v0, 0x2a

    if-eq p1, v2, :cond_3

    if-eq p1, v6, :cond_2

    if-eq p1, v1, :cond_1

    const/16 p1, 0x29

    new-array p1, p1, [B

    fill-array-data p1, :array_c

    new-array v0, v7, [B

    fill-array-data v0, :array_d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    const/16 p1, 0x1d

    new-array p1, p1, [B

    fill-array-data p1, :array_e

    new-array v0, v7, [B

    fill-array-data v0, :array_f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2
    new-array p1, v0, [B

    fill-array-data p1, :array_10

    new-array v0, v7, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3
    new-array p1, v0, [B

    fill-array-data p1, :array_12

    new-array v0, v7, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_4
    const/16 p1, 0xd

    new-array p1, p1, [B

    fill-array-data p1, :array_14

    new-array v0, v7, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_5
    const/16 p1, 0x21

    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array v0, v7, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_6
    const/16 p1, 0x1a

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v7, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x2acd7615 -> :sswitch_5
        -0x18d0f841 -> :sswitch_4
        -0x18d0f777 -> :sswitch_3
        -0xd30639f -> :sswitch_2
        0x2fff79 -> :sswitch_1
        0x35dd57 -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        0x63t
        -0x7ct
        0x7dt
        -0x20t
    .end array-data

    :array_1
    .array-data 1
        0x10t
        -0x13t
        0x19t
        -0x7bt
        0x21t
        0xft
        -0x75t
        -0x64t
    .end array-data

    :array_2
    .array-data 1
        0x60t
        -0x47t
        -0x54t
        -0x24t
    .end array-data

    :array_3
    .array-data 1
        0x6t
        -0x2bt
        -0x33t
        -0x58t
        -0x16t
        0x3ct
        -0x33t
        -0x43t
    .end array-data

    :array_4
    .array-data 1
        -0x6et
        -0x64t
        -0x60t
        0x5ft
        -0x61t
        -0x71t
        0x3ct
    .end array-data

    :array_5
    .array-data 1
        -0x19t
        -0x14t
        -0x2et
        0x36t
        -0x8t
        -0x19t
        0x48t
        0x16t
    .end array-data

    :array_6
    .array-data 1
        0x3bt
        -0x21t
        0x73t
        0x3t
        -0x7at
        -0x50t
        -0x43t
        0x41t
        0x3dt
    .end array-data

    nop

    :array_7
    .array-data 1
        0x4ft
        -0x4at
        0x1ft
        0x77t
        -0x1dt
        -0x2ct
        -0x1et
        0x2dt
    .end array-data

    :array_8
    .array-data 1
        0x44t
        0x49t
        -0x5ct
        0x44t
        0x47t
        0x61t
        0x6bt
        0x62t
        0x52t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x30t
        0x20t
        -0x38t
        0x30t
        0x22t
        0x5t
        0x34t
        0x4t
    .end array-data

    :array_a
    .array-data 1
        0x18t
        -0x2at
        0x4at
        -0xet
        0x2et
        -0x8t
        0x76t
        0x3t
        0x34t
        -0x32t
        0x4at
        -0x7t
        0x32t
        -0x17t
        0x7et
    .end array-data

    :array_b
    .array-data 1
        0x6bt
        -0x46t
        0x23t
        -0x6bt
        0x46t
        -0x74t
        0x1at
        0x7at
    .end array-data

    :array_c
    .array-data 1
        -0x53t
        -0x27t
        0x74t
        -0x4t
        0x5dt
        -0x57t
        0x47t
        0x5t
        -0x53t
        -0xat
        0x74t
        -0x4t
        0x5ct
        -0x70t
        0x46t
        0x30t
        -0x53t
        -0x7t
        0x74t
        -0x9t
        0x5dt
        -0x5ct
        -0x49t
        0x62t
        -0x3et
        -0x6ct
        0x1at
        -0x67t
        0x36t
        -0x3ft
        0x29t
        0x62t
        -0x35t
        -0x6ct
        0x11t
        -0x67t
        0x30t
        -0x3ft
        0x2ft
        0x62t
        -0x38t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x7dt
        0x44t
        -0x5ct
        0x49t
        -0x73t
        0x11t
        -0x69t
        -0x4et
    .end array-data

    :array_e
    .array-data 1
        -0x42t
        0x50t
        -0x51t
        0x0t
        -0x76t
        -0x59t
        0x56t
        0x15t
        -0x42t
        0x4bt
        -0x51t
        0xbt
        0x7at
        -0x3et
        0x3bt
        0x76t
        -0x22t
        0x21t
        -0x3bt
        0x6bt
        -0x1ft
        -0x3et
        0x38t
        0x76t
        -0x2dt
        0x20t
        -0x12t
        0x6bt
        -0x19t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x6et
        -0xft
        0x7ft
        -0x45t
        0x5at
        0x12t
        -0x7at
        -0x5at
    .end array-data

    :array_10
    .array-data 1
        0x5et
        -0x12t
        0x73t
        -0x63t
        -0x61t
        -0xbt
        -0x15t
        -0x1dt
        0x5et
        -0x33t
        0x73t
        -0x70t
        -0x62t
        -0x22t
        -0x15t
        -0x1bt
        -0x52t
        -0x5dt
        0x11t
        -0x3t
        -0xct
        -0x61t
        -0x72t
        -0x78t
        0x3ct
        -0x5dt
        0x1dt
        0xdt
        0x60t
        0x6ft
        -0x15t
        -0x16t
        0x5et
        -0x34t
        0x72t
        -0x53t
        -0x61t
        -0x1t
        -0x15t
        -0x16t
        0x5et
        -0x33t
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x72t
        0x73t
        -0x5dt
        0x2dt
        0x4ft
        0x4ft
        0x3bt
        0x58t
    .end array-data

    :array_12
    .array-data 1
        0x79t
        -0x2bt
        0xat
        -0x62t
        0x55t
        -0x63t
        0x2ft
        0x72t
        0x79t
        -0xat
        0xat
        -0x6dt
        0x54t
        -0x4at
        0x2ft
        0x74t
        -0x77t
        -0x68t
        0x68t
        -0x2t
        0x3at
        -0x9t
        0x4at
        0x18t
        0x29t
        -0x68t
        0x6ft
        -0x2t
        0x31t
        0x7t
        -0x30t
        -0x17t
        0x79t
        -0xbt
        0xat
        -0x62t
        0x55t
        -0x70t
        0x2ft
        0x79t
        0x79t
        -0x4t
    .end array-data

    nop

    :array_13
    .array-data 1
        -0x57t
        0x48t
        -0x26t
        0x2et
        -0x7bt
        0x27t
        -0x1t
        -0x37t
    .end array-data

    :array_14
    .array-data 1
        0xct
        0x13t
        -0x3ft
        0x68t
        -0x2at
        -0x5ft
        0x70t
        -0x3et
        0x62t
        0x5et
        -0x55t
        0x9t
        0x75t
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x24t
        -0x72t
        0x11t
        -0x28t
        -0xat
        0x71t
        -0x3ft
        0x12t
    .end array-data

    :array_16
    .array-data 1
        0x5at
        -0x1ft
        0x3ft
        0x14t
        0x3et
        -0x1t
        -0x2et
        -0x45t
        0x5bt
        -0x3et
        -0x32t
        0x46t
        0x5ct
        -0x6ft
        -0x49t
        -0x2et
        0xat
        -0x6ft
        0x6ct
        0x46t
        0x56t
        -0x6ft
        -0x48t
        -0x2dt
        0x3at
        -0x70t
        0x55t
        0x47t
        0x62t
        -0x6ft
        -0x41t
        -0x2dt
        0x34t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x76t
        0x40t
        -0x12t
        -0x6at
        -0x12t
        0x41t
        0x2t
        0x3t
    .end array-data

    :array_18
    .array-data 1
        0x9t
        -0x32t
        0x73t
        -0x4et
        0x7ct
        -0x6ct
        0x32t
        0x3at
        0x8t
        -0x29t
        -0x7dt
        -0x29t
        0x11t
        -0xet
        0x52t
        -0x5et
        0x8t
        -0x2ct
        0x72t
        -0x7bt
        0x7ct
        -0x64t
        0x32t
        0x39t
        0x9t
        -0x20t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x27t
        0x55t
        -0x5dt
        0x7t
        -0x54t
        0x22t
        -0x1et
        -0x7et
    .end array-data
.end method

.method private I(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/16 v2, 0xa

    const/16 v3, 0x9

    const/4 v4, 0x6

    const/16 v5, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v2, [B

    fill-array-data v0, :array_0

    new-array v1, v5, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v1, [B

    fill-array-data v0, :array_2

    new-array v1, v5, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move v1, v4

    goto/16 :goto_1

    :sswitch_2
    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v5, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    goto/16 :goto_1

    :sswitch_3
    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v1, v5, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    goto :goto_1

    :sswitch_4
    new-array v0, v4, [B

    fill-array-data v0, :array_8

    new-array v1, v5, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    goto :goto_1

    :sswitch_5
    new-array v0, v3, [B

    fill-array-data v0, :array_a

    new-array v1, v5, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    goto :goto_1

    :sswitch_6
    new-array v0, v3, [B

    fill-array-data v0, :array_c

    new-array v1, v5, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    goto :goto_1

    :sswitch_7
    new-array v0, v4, [B

    fill-array-data v0, :array_e

    new-array v4, v5, [B

    fill-array-data v4, :array_f

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v1, -0x1

    :goto_1
    const/16 p1, 0xf

    const/16 v0, 0xc

    packed-switch v1, :pswitch_data_0

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v5, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_0
    const/16 p1, 0x11

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v5, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_1
    new-array p1, v0, [B

    fill-array-data p1, :array_14

    new-array v0, v5, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_2
    new-array p1, v0, [B

    fill-array-data p1, :array_16

    new-array v0, v5, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_3
    const/16 p1, 0x12

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v5, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_4
    new-array p1, v0, [B

    fill-array-data p1, :array_1a

    new-array v0, v5, [B

    fill-array-data v0, :array_1b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_5
    new-array p1, v3, [B

    fill-array-data p1, :array_1c

    new-array v0, v5, [B

    fill-array-data v0, :array_1d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_6
    new-array p1, v2, [B

    fill-array-data p1, :array_1e

    new-array v0, v5, [B

    fill-array-data v0, :array_1f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_7
    new-array p1, p1, [B

    fill-array-data p1, :array_20

    new-array v0, v5, [B

    fill-array-data v0, :array_21

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x50ea171c -> :sswitch_7
        -0x4ba26961 -> :sswitch_6
        -0x4a33b321 -> :sswitch_5
        -0x4695e9ad -> :sswitch_4
        -0x40b288c8 -> :sswitch_3
        -0x297fb9c0 -> :sswitch_2
        0x68b6917 -> :sswitch_1
        0xd5c6cf6 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        0x29t
        0x33t
        -0x79t
        -0x22t
        0x12t
        0x1dt
        -0x63t
        0x5ct
        0x38t
        0x34t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x4dt
        0x5at
        -0xbt
        -0x45t
        0x71t
        0x69t
        -0x3et
        0x2ft
    .end array-data

    :array_2
    .array-data 1
        -0x5ct
        0x4t
        0x31t
        0x1dt
        0xft
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x29t
        0x71t
        0x5ft
        0x73t
        0x76t
        -0x4bt
        0x69t
        0x73t
    .end array-data

    :array_4
    .array-data 1
        0x5ft
        -0x5et
        -0x26t
        -0x2at
        -0x79t
        -0xbt
        -0x10t
        -0x15t
        0x4et
        -0x58t
        -0x3bt
    .end array-data

    :array_5
    .array-data 1
        0x2ft
        -0x35t
        -0x52t
        -0x4bt
        -0x11t
        -0x56t
        -0x6et
        -0x79t
    .end array-data

    :array_6
    .array-data 1
        0x54t
        0x78t
        0x63t
        0x1et
        -0x61t
        -0x57t
        -0x7dt
        -0x70t
        0x58t
        0x6et
        0x65t
        0x16t
        -0x7bt
    .end array-data

    nop

    :array_7
    .array-data 1
        0x36t
        0xat
        0xat
        0x79t
        -0x9t
        -0x23t
        -0x24t
        -0x7t
    .end array-data

    :array_8
    .array-data 1
        -0x56t
        0x57t
        0x60t
        0x3ft
        0x0t
        -0x7bt
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x3dt
        0x39t
        0x4t
        0x50t
        0x6ft
        -0x9t
        0x13t
        0x59t
    .end array-data

    :array_a
    .array-data 1
        -0x56t
        0xct
        0x17t
        -0x17t
        0x7t
        0x14t
        -0x8t
        -0x4t
        -0x49t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x24t
        0x69t
        0x65t
        -0x70t
        0x58t
        0x70t
        -0x67t
        -0x72t
    .end array-data

    :array_c
    .array-data 1
        0x5dt
        0x12t
        0x40t
        -0x55t
        0x16t
        -0x6et
        -0x20t
        0x53t
        0x4dt
    .end array-data

    nop

    :array_d
    .array-data 1
        0x39t
        0x7bt
        0x2dt
        -0xct
        0x7at
        -0x5t
        -0x79t
        0x3bt
    .end array-data

    :array_e
    .array-data 1
        0x79t
        0x7et
        0x2t
        0x6dt
        0x1et
        -0x70t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x1at
        0x12t
        0x6dt
        0x18t
        0x7at
        -0x17t
        -0x7ct
        -0x5ft
    .end array-data

    :array_10
    .array-data 1
        0x53t
        -0x64t
        0x59t
        0x70t
        -0x42t
        0x37t
        0x58t
        0x68t
        0x70t
        -0x79t
        0x4ct
        0x33t
        -0x4dt
        0x36t
        0x4at
    .end array-data

    :array_11
    .array-data 1
        0x1ft
        -0x17t
        0x23t
        0x50t
        -0x26t
        0x52t
        0x2bt
        0xbt
    .end array-data

    :array_12
    .array-data 1
        -0x4et
        -0x26t
        -0x28t
        0x49t
        0x5dt
        -0x25t
        0x1ct
        0x6ft
        -0x74t
        -0x71t
        -0x3at
        0x0t
        0x5ct
        -0x2ft
        0x13t
        0x7at
        -0x61t
    .end array-data

    nop

    :array_13
    .array-data 1
        -0x2t
        -0x51t
        -0x5et
        0x69t
        0x2et
        -0x4ct
        0x70t
        0xet
    .end array-data

    :array_14
    .array-data 1
        0x52t
        -0x5t
        -0x14t
        0x6at
        0x3dt
        -0x61t
        0x9t
        0x1ft
        0x73t
        0x59t
        0x25t
        0x64t
    .end array-data

    :array_15
    .array-data 1
        0x16t
        0x38t
        0x41t
        0xbt
        0x1dt
        -0x14t
        0x66t
        0x73t
    .end array-data

    :array_16
    .array-data 1
        0x7ft
        -0x5bt
        0x36t
        0x11t
        0x44t
        0x79t
        -0x57t
        -0x8t
        0x57t
        0x7t
        -0x1t
        0x1ft
    .end array-data

    :array_17
    .array-data 1
        0x3bt
        0x66t
        -0x65t
        0x70t
        0x64t
        0x17t
        -0x24t
        -0x66t
    .end array-data

    :array_18
    .array-data 1
        0x5bt
        -0x46t
        0x4et
        0x75t
        0x37t
        0x5ft
        0x4at
        -0x25t
        0x32t
        -0x4at
        0x48t
        0x79t
        0x29t
        0x5at
        0x44t
        -0x39t
        0x66t
        -0x4ft
    .end array-data

    nop

    :array_19
    .array-data 1
        0x12t
        -0x2ct
        0x3at
        0x10t
        0x45t
        0x36t
        0x25t
        -0x57t
    .end array-data

    :array_1a
    .array-data 1
        -0x1bt
        -0x22t
        0x2ct
        -0x3dt
        -0x76t
        -0x16t
        -0x6ft
        -0x3at
        -0x25t
        -0x3et
        0x39t
        -0x6ft
    .end array-data

    :array_1b
    .array-data 1
        -0x57t
        -0x55t
        0x56t
        -0x1dt
        -0x1dt
        -0x7ct
        -0x1bt
        -0x5dt
    .end array-data

    :array_1c
    .array-data 1
        -0x42t
        0x7dt
        0x71t
        0x22t
        0x4ct
        -0x3dt
        -0x3dt
        0x37t
        -0x69t
    .end array-data

    nop

    :array_1d
    .array-data 1
        -0xet
        0x8t
        0xbt
        0x2t
        0x38t
        -0x5at
        -0x53t
        0x42t
    .end array-data

    :array_1e
    .array-data 1
        0x4bt
        0x19t
        -0x54t
        -0x7at
        -0x13t
        0x5t
        -0x42t
        0x2ft
        0x74t
        0x3t
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x6t
        0x6ct
        -0x2bt
        -0x5at
        -0x7et
        0x76t
        -0x23t
        0x5at
    .end array-data

    :array_20
    .array-data 1
        -0x7ct
        -0xbt
        0x13t
        0x47t
        -0x5dt
        -0xft
        -0xet
        0x65t
        -0x51t
        -0x5at
        0x4t
        0x5dt
        -0x5bt
        -0x7t
        -0x6t
    .end array-data

    :array_21
    .array-data 1
        -0x35t
        -0x7at
        0x70t
        0x32t
        -0x2ft
        -0x68t
        -0x6at
        0x4t
    .end array-data
.end method

.method private J(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v3, 0x9

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/16 v8, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v7, [B

    fill-array-data v0, :array_0

    new-array v3, v8, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v6

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v7, [B

    fill-array-data v0, :array_2

    new-array v3, v8, [B

    fill-array-data v3, :array_3

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_1

    :sswitch_2
    new-array v0, v5, [B

    fill-array-data v0, :array_4

    new-array v3, v8, [B

    fill-array-data v3, :array_5

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v4

    goto :goto_1

    :sswitch_3
    new-array v0, v3, [B

    fill-array-data v0, :array_6

    new-array v3, v8, [B

    fill-array-data v3, :array_7

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v7

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v3, v8, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_1

    :sswitch_5
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v8, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p1, -0x1

    :goto_1
    if-eqz p1, :cond_6

    if-eq p1, v4, :cond_5

    if-eq p1, v6, :cond_4

    if-eq p1, v2, :cond_3

    if-eq p1, v7, :cond_2

    const/16 v0, 0x15

    if-eq p1, v1, :cond_1

    new-array p1, v0, [B

    fill-array-data p1, :array_c

    new-array v0, v8, [B

    fill-array-data v0, :array_d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    new-array p1, v0, [B

    fill-array-data p1, :array_e

    new-array v0, v8, [B

    fill-array-data v0, :array_f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2
    const/16 p1, 0x24

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v8, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3
    const/16 p1, 0x1f

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v8, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_4
    new-array p1, v5, [B

    fill-array-data p1, :array_14

    new-array v0, v8, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_5
    const/4 p1, 0x6

    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array v0, v8, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_6
    const/16 p1, 0x13

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v8, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :sswitch_data_0
    .sparse-switch
        -0x2acd7615 -> :sswitch_5
        -0x18d0f841 -> :sswitch_4
        -0x18d0f777 -> :sswitch_3
        -0xd30639f -> :sswitch_2
        0x2fff79 -> :sswitch_1
        0x35dd57 -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        0x5bt
        -0x67t
        0x48t
        -0x7bt
    .end array-data

    :array_1
    .array-data 1
        0x28t
        -0x10t
        0x2ct
        -0x20t
        -0x3dt
        0x51t
        -0x39t
        -0x30t
    .end array-data

    :array_2
    .array-data 1
        -0x53t
        0x10t
        0xbt
        -0xdt
    .end array-data

    :array_3
    .array-data 1
        -0x35t
        0x7ct
        0x6at
        -0x79t
        -0x70t
        -0x2ft
        0x1at
        0x2at
    .end array-data

    :array_4
    .array-data 1
        -0x60t
        -0x68t
        -0x34t
        -0x62t
        -0x7at
        0x41t
        0x76t
    .end array-data

    :array_5
    .array-data 1
        -0x2bt
        -0x18t
        -0x42t
        -0x9t
        -0x1ft
        0x29t
        0x2t
        -0x6t
    .end array-data

    :array_6
    .array-data 1
        0x22t
        -0x77t
        -0x75t
        0x78t
        -0x55t
        -0x66t
        -0x30t
        -0x42t
        0x24t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x56t
        -0x20t
        -0x19t
        0xct
        -0x32t
        -0x2t
        -0x71t
        -0x2et
    .end array-data

    :array_8
    .array-data 1
        -0x3ct
        -0x5et
        0x55t
        0x1bt
        0x28t
        0x4ct
        -0x19t
        -0x21t
        -0x2et
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x50t
        -0x35t
        0x39t
        0x6ft
        0x4dt
        0x28t
        -0x48t
        -0x47t
    .end array-data

    :array_a
    .array-data 1
        0x8t
        0x30t
        -0x2t
        -0x49t
        -0x53t
        -0x4bt
        -0x36t
        0x6at
        0x24t
        0x28t
        -0x2t
        -0x44t
        -0x4ft
        -0x5ct
        -0x3et
    .end array-data

    :array_b
    .array-data 1
        0x7bt
        0x5ct
        -0x69t
        -0x30t
        -0x3bt
        -0x3ft
        -0x5at
        0x13t
    .end array-data

    :array_c
    .array-data 1
        -0x45t
        0x24t
        -0xct
        -0x57t
        0x40t
        0x56t
        -0x6ft
        -0x40t
        -0x7bt
        0x6bt
        -0x1dt
        -0x5bt
        0x50t
        0x5ct
        0x3dt
        0x1dt
        -0x7ct
        0x28t
        -0x12t
        -0x5ct
        0x42t
    .end array-data

    nop

    :array_d
    .array-data 1
        -0x15t
        0x4bt
        -0x79t
        -0x40t
        0x23t
        0x3ft
        0x52t
        0x73t
    .end array-data

    :array_e
    .array-data 1
        -0x15t
        0x1at
        0x2bt
        0x7et
        -0x6ct
        0xbt
        0x4dt
        0x44t
        -0x37t
        0x7t
        0x29t
        0x3bt
        -0x71t
        0x4t
        0x43t
        0x4dt
        -0x32t
        0x1dt
        0x2dt
        0x7ft
        -0x77t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x59t
        0x73t
        0x4ct
        0x1bt
        -0x1at
        0x6at
        0x20t
        0x21t
    .end array-data

    :array_10
    .array-data 1
        -0x31t
        0x65t
        0x47t
        0x23t
        -0x5at
        0x62t
        0x68t
        -0x17t
        -0x17t
        0x2bt
        0x4ct
        0x2et
        -0x54t
        0x65t
        0x68t
        -0x53t
        -0x16t
        0x6at
        0x4t
        0x26t
        -0x4bt
        0x7dt
        0x7ct
        -0x1ct
        -0x1dt
        0x79t
        0x40t
        0x2et
        -0x20t
        0x68t
        0x6ct
        -0x1t
        -0x1dt
        0x68t
        0x4ct
        0x2et
    .end array-data

    :array_11
    .array-data 1
        -0x7at
        0xbt
        0x24t
        0x4ft
        -0x31t
        0xct
        0x9t
        -0x73t
    .end array-data

    :array_12
    .array-data 1
        0x7t
        0x43t
        0x40t
        -0x63t
        0x28t
        -0x2ft
        -0x3et
        0x38t
        0x21t
        0xdt
        0x4bt
        -0x70t
        0x22t
        -0x2at
        -0x3et
        0x7ct
        0x2ft
        0x49t
        0x46t
        -0x63t
        0x20t
        -0x2ft
        -0x29t
        0x39t
        0x61t
        0x4ct
        0x57t
        -0x7dt
        -0x7et
        0x1et
        -0x30t
    .end array-data

    :array_13
    .array-data 1
        0x4et
        0x2dt
        0x23t
        -0xft
        0x41t
        -0x41t
        -0x5dt
        0x5ct
    .end array-data

    :array_14
    .array-data 1
        -0x69t
        -0x6ct
        0x58t
        0x68t
        -0x6ft
        -0x48t
        0x68t
    .end array-data

    :array_15
    .array-data 1
        -0x2dt
        -0xft
        0x78t
        0x4t
        -0x10t
        -0x24t
        0x7t
        0x48t
    .end array-data

    :array_16
    .array-data 1
        0xbt
        -0x52t
        -0x77t
        -0x17t
        0x7dt
        0x7bt
    .end array-data

    nop

    :array_17
    .array-data 1
        0x4ft
        -0x35t
        -0x57t
        -0x67t
        0x14t
        0x1et
        0x7bt
        -0x1t
    .end array-data

    :array_18
    .array-data 1
        -0x2at
        0x48t
        -0x5bt
        -0x76t
        -0x65t
        0x4ct
        -0x11t
        0x58t
        -0x1ct
        0x56t
        -0x5ft
        -0x3ct
        -0x68t
        0xdt
        -0x44t
        0x5at
        -0x1dt
        0x57t
        -0x5bt
    .end array-data

    :array_19
    .array-data 1
        -0x7at
        0x24t
        -0x3ct
        -0x1ct
        -0xct
        0x6ct
        -0x64t
        0x37t
    .end array-data
.end method

.method private K(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x9

    const/16 v2, 0xd

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/16 v5, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v1, v5, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v3, [B

    fill-array-data v0, :array_2

    new-array v1, v5, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move v3, v4

    goto/16 :goto_1

    :sswitch_2
    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v5, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    goto/16 :goto_1

    :sswitch_3
    new-array v0, v2, [B

    fill-array-data v0, :array_6

    new-array v1, v5, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    goto :goto_1

    :sswitch_4
    new-array v0, v4, [B

    fill-array-data v0, :array_8

    new-array v1, v5, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    goto :goto_1

    :sswitch_5
    new-array v0, v1, [B

    fill-array-data v0, :array_a

    new-array v1, v5, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    goto :goto_1

    :sswitch_6
    new-array v0, v1, [B

    fill-array-data v0, :array_c

    new-array v1, v5, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    goto :goto_1

    :sswitch_7
    new-array v0, v4, [B

    fill-array-data v0, :array_e

    new-array v1, v5, [B

    fill-array-data v1, :array_f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v3, -0x1

    :goto_1
    const/16 p1, 0xc

    const/16 v0, 0xe

    packed-switch v3, :pswitch_data_0

    const/16 p1, 0x12

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v5, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_0
    const/16 p1, 0x1c

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v5, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_1
    new-array p1, v0, [B

    fill-array-data p1, :array_14

    new-array v0, v5, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_2
    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array v0, v5, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_3
    const/16 p1, 0x10

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v5, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_4
    const/16 p1, 0x17

    new-array p1, p1, [B

    fill-array-data p1, :array_1a

    new-array v0, v5, [B

    fill-array-data v0, :array_1b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_5
    new-array p1, p1, [B

    fill-array-data p1, :array_1c

    new-array v0, v5, [B

    fill-array-data v0, :array_1d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_6
    new-array p1, v0, [B

    fill-array-data p1, :array_1e

    new-array v0, v5, [B

    fill-array-data v0, :array_1f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_7
    new-array p1, v2, [B

    fill-array-data p1, :array_20

    new-array v0, v5, [B

    fill-array-data v0, :array_21

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x50ea171c -> :sswitch_7
        -0x4ba26961 -> :sswitch_6
        -0x4a33b321 -> :sswitch_5
        -0x4695e9ad -> :sswitch_4
        -0x40b288c8 -> :sswitch_3
        -0x297fb9c0 -> :sswitch_2
        0x68b6917 -> :sswitch_1
        0xd5c6cf6 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        -0x4ft
        -0x58t
        -0x35t
        -0x56t
        -0x69t
        -0x1bt
        -0x2dt
        0x8t
        -0x60t
        -0x51t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x2bt
        -0x3ft
        -0x47t
        -0x31t
        -0xct
        -0x6ft
        -0x74t
        0x7bt
    .end array-data

    :array_2
    .array-data 1
        -0x35t
        0x6t
        -0x13t
        0x32t
        -0x6dt
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x48t
        0x73t
        -0x7dt
        0x5ct
        -0x16t
        0x6ct
        0x1t
        0x15t
    .end array-data

    :array_4
    .array-data 1
        -0x4ct
        0x6et
        0x1ct
        -0x3at
        -0x34t
        -0x6ct
        0x5et
        -0x25t
        -0x5bt
        0x64t
        0x3t
    .end array-data

    :array_5
    .array-data 1
        -0x3ct
        0x7t
        0x68t
        -0x5bt
        -0x5ct
        -0x35t
        0x3ct
        -0x49t
    .end array-data

    :array_6
    .array-data 1
        0x64t
        -0x50t
        0x43t
        0x11t
        0x40t
        -0x33t
        0x4et
        -0x34t
        0x68t
        -0x5at
        0x45t
        0x19t
        0x5at
    .end array-data

    nop

    :array_7
    .array-data 1
        0x6t
        -0x3et
        0x2at
        0x76t
        0x28t
        -0x47t
        0x11t
        -0x5bt
    .end array-data

    :array_8
    .array-data 1
        -0x33t
        0x2dt
        -0x47t
        0x57t
        0x38t
        0xbt
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x5ct
        0x43t
        -0x23t
        0x38t
        0x57t
        0x79t
        0x35t
        0x58t
    .end array-data

    :array_a
    .array-data 1
        0x51t
        0x57t
        -0x4et
        -0x41t
        0x11t
        0x15t
        0x1bt
        -0x20t
        0x4ct
    .end array-data

    nop

    :array_b
    .array-data 1
        0x27t
        0x32t
        -0x40t
        -0x3at
        0x4et
        0x71t
        0x7at
        -0x6et
    .end array-data

    :array_c
    .array-data 1
        -0x6at
        0x31t
        0x1ct
        0x3at
        -0x7t
        -0x2ft
        -0xct
        0x72t
        -0x7at
    .end array-data

    nop

    :array_d
    .array-data 1
        -0xet
        0x58t
        0x71t
        0x65t
        -0x6bt
        -0x48t
        -0x6dt
        0x1at
    .end array-data

    :array_e
    .array-data 1
        0x8t
        -0x11t
        -0x7ct
        -0x75t
        -0x5dt
        0x34t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x6bt
        -0x7dt
        -0x15t
        -0x2t
        -0x39t
        0x4dt
        0x19t
        -0x6dt
    .end array-data

    :array_10
    .array-data 1
        -0x76t
        0x37t
        -0x1bt
        -0x6ct
        0x1at
        0x7at
        0x5et
        -0x24t
        -0x53t
        0x30t
        -0x57t
        0x39t
        -0x3bt
        -0x2et
        -0x5ct
        0x61t
        0x79t
        0x35t
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x38t
        0x5et
        -0x77t
        -0x3t
        0x74t
        0x17t
        0x3bt
        -0x5bt
    .end array-data

    :array_12
    .array-data 1
        0x3et
        0x62t
        0x50t
        0x38t
        0x38t
        -0x2ct
        0x4dt
        -0x10t
        0x14t
        0x2dt
        -0xdt
        0x64t
        -0xat
        -0x31t
        0x4ct
        0x54t
        -0x1bt
        0x2dt
        0x50t
        0x16t
        -0x71t
        0x3et
        -0x13t
        0x20t
        -0x42t
        -0x6et
        0x50t
        0x16t
    .end array-data

    :array_13
    .array-data 1
        0x7at
        0xdt
        -0x6ct
        -0x59t
        0x4at
        -0x5ft
        0x29t
        -0x6ft
    .end array-data

    :array_14
    .array-data 1
        -0x80t
        -0x1ct
        0x46t
        0x53t
        -0x74t
        -0x6ct
        -0x12t
        0x26t
        -0x52t
        0x7t
        -0x63t
        -0x2t
        0x55t
        0x3ft
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x39t
        0x27t
        -0x6t
        0x3dt
        -0x17t
        0x51t
        0x71t
        0x4at
    .end array-data

    :array_16
    .array-data 1
        0x7et
        -0x11t
        0x7dt
        -0x71t
        -0x5et
        -0x26t
        -0x40t
        -0x28t
        0x5bt
        0x59t
        -0x53t
        -0x6ct
    .end array-data

    :array_17
    .array-data 1
        0x3ct
        -0x66t
        0x11t
        -0x6t
        -0x2at
        -0x4at
        -0x4bt
        -0x8t
    .end array-data

    :array_18
    .array-data 1
        -0x66t
        0x2at
        0x4at
        -0x70t
        -0x44t
        -0x12t
        -0x18t
        0x70t
        0x9t
        -0x14t
        0x18t
        -0x6ft
        -0x48t
        -0x12t
        -0x57t
        0x77t
    .end array-data

    :array_19
    .array-data 1
        -0x36t
        0x4bt
        0x38t
        -0x4t
        -0x23t
        -0x7bt
        -0x38t
        0x19t
    .end array-data

    :array_1a
    .array-data 1
        0x78t
        -0x66t
        0x32t
        0x3dt
        -0x7ct
        -0x3t
        -0x14t
        -0x55t
        0x52t
        -0x69t
        0x23t
        0x32t
        -0x38t
        -0x3t
        -0x14t
        0x4et
        -0x54t
        0x3ft
        -0xdt
        -0x68t
        0x77t
        -0x3t
        -0x14t
    .end array-data

    :array_1b
    .array-data 1
        0x33t
        -0x5t
        0x42t
        0x5ct
        -0x18t
        0x39t
        0x5dt
        -0x75t
    .end array-data

    :array_1c
    .array-data 1
        -0x49t
        0x23t
        0x14t
        0x3ct
        -0x48t
        -0x23t
        -0x6dt
        -0x47t
        0x64t
        -0x78t
        0x60t
        -0x38t
    .end array-data

    :array_1d
    .array-data 1
        -0x5t
        0x4ct
        -0x2ft
        -0x5dt
        -0x68t
        0x19t
        0x22t
        0x7ct
    .end array-data

    :array_1e
    .array-data 1
        -0x29t
        -0x19t
        0x2et
        -0x6et
        0x5et
        -0x3t
        -0x44t
        0xat
        0x75t
        0xet
        0x2dt
        0x3dt
        -0x31t
        -0x3t
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x14t
        0x60t
        0x41t
        -0x7t
        0x7et
        -0x6at
        -0x23t
        0x78t
    .end array-data

    :array_20
    .array-data 1
        0x71t
        0x12t
        -0x3dt
        -0x68t
        0x7ct
        -0x39t
        0x48t
        0x70t
        0x4bt
        0x1ft
        0x6at
        0x9t
        0x7ct
    .end array-data

    nop

    :array_21
    .array-data 1
        0x25t
        0x73t
        -0x52t
        -0x48t
        0x17t
        -0x5at
        0x3at
        0x11t
    .end array-data
.end method

.method private L(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v3, 0x9

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/16 v7, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v6, [B

    fill-array-data v0, :array_0

    new-array v3, v7, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v5

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v6, [B

    fill-array-data v0, :array_2

    new-array v3, v7, [B

    fill-array-data v3, :array_3

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_1

    :sswitch_2
    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v3, v7, [B

    fill-array-data v3, :array_5

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v4

    goto :goto_1

    :sswitch_3
    new-array v0, v3, [B

    fill-array-data v0, :array_6

    new-array v3, v7, [B

    fill-array-data v3, :array_7

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v6

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v3, v7, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_1

    :sswitch_5
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v7, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p1, -0x1

    :goto_1
    if-eqz p1, :cond_6

    if-eq p1, v4, :cond_5

    if-eq p1, v5, :cond_4

    if-eq p1, v2, :cond_3

    if-eq p1, v6, :cond_2

    if-eq p1, v1, :cond_1

    const/16 p1, 0x10

    new-array p1, p1, [B

    fill-array-data p1, :array_c

    new-array v0, v7, [B

    fill-array-data v0, :array_d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    const/16 p1, 0x12

    new-array p1, p1, [B

    fill-array-data p1, :array_e

    new-array v0, v7, [B

    fill-array-data v0, :array_f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2
    const/16 p1, 0x16

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v7, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3
    const/16 p1, 0x17

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v7, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_4
    const/16 p1, 0xe

    new-array p1, p1, [B

    fill-array-data p1, :array_14

    new-array v0, v7, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_5
    const/16 p1, 0xb

    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array v0, v7, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_6
    const/16 p1, 0x1a

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v7, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x2acd7615 -> :sswitch_5
        -0x18d0f841 -> :sswitch_4
        -0x18d0f777 -> :sswitch_3
        -0xd30639f -> :sswitch_2
        0x2fff79 -> :sswitch_1
        0x35dd57 -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        0x1t
        0x67t
        -0x22t
        -0xdt
    .end array-data

    :array_1
    .array-data 1
        0x72t
        0xet
        -0x46t
        -0x6at
        0x65t
        0x71t
        0x27t
        0x62t
    .end array-data

    :array_2
    .array-data 1
        0x6ct
        0x28t
        -0x40t
        0x29t
    .end array-data

    :array_3
    .array-data 1
        0xat
        0x44t
        -0x5ft
        0x5dt
        -0x16t
        0x58t
        0x78t
        0xet
    .end array-data

    :array_4
    .array-data 1
        -0x20t
        -0x5bt
        -0x9t
        -0x15t
        -0x27t
        0x7ct
        0x4ft
    .end array-data

    :array_5
    .array-data 1
        -0x6bt
        -0x2bt
        -0x7bt
        -0x7et
        -0x42t
        0x14t
        0x3bt
        0x8t
    .end array-data

    :array_6
    .array-data 1
        -0x63t
        -0x2at
        -0x3at
        -0x35t
        0x52t
        -0xbt
        0x15t
        -0x51t
        -0x65t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x17t
        -0x41t
        -0x56t
        -0x41t
        0x37t
        -0x6ft
        0x4at
        -0x3dt
    .end array-data

    :array_8
    .array-data 1
        0x3bt
        0x3dt
        -0x5dt
        0x0t
        -0x2at
        -0x56t
        0x34t
        -0x3ct
        0x2dt
    .end array-data

    nop

    :array_9
    .array-data 1
        0x4ft
        0x54t
        -0x31t
        0x74t
        -0x4dt
        -0x32t
        0x6bt
        -0x5et
    .end array-data

    :array_a
    .array-data 1
        0x19t
        -0x32t
        0x45t
        -0x77t
        -0x4bt
        -0x4bt
        -0x71t
        -0x2et
        0x35t
        -0x2at
        0x45t
        -0x7et
        -0x57t
        -0x5ct
        -0x79t
    .end array-data

    :array_b
    .array-data 1
        0x6at
        -0x5et
        0x2ct
        -0x12t
        -0x23t
        -0x3ft
        -0x1dt
        -0x55t
    .end array-data

    :array_c
    .array-data 1
        0x1t
        -0x6dt
        -0x73t
        0x4et
        0x23t
        0xbt
        0x14t
        -0x31t
        0x26t
        -0x6ct
        -0x3ft
        0x4ct
        0x22t
        0x8t
        0x4t
        -0x25t
    .end array-data

    :array_d
    .array-data 1
        0x43t
        -0x6t
        -0x1ft
        0x27t
        0x4dt
        0x66t
        0x71t
        -0x4at
    .end array-data

    :array_e
    .array-data 1
        0x29t
        0x41t
        0x7t
        0x29t
        0x3ct
        -0x59t
        0x3bt
        -0x3ft
        0x41t
        0x45t
        -0x5bt
        -0x21t
        0x33t
        0x8t
        -0xft
        -0x33t
        -0x5ct
        -0x41t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x61t
        0x20t
        0x61t
        0x40t
        0x5at
        0x64t
        -0x64t
        -0x5ct
    .end array-data

    :array_10
    .array-data 1
        0xat
        0x65t
        -0x25t
        0x7at
        -0x4ft
        -0x47t
        -0x5dt
        -0x39t
        0x38t
        -0x32t
        0x28t
        0x7at
        -0x4ft
        -0xdt
        0x47t
        0x2bt
        0x30t
        0x66t
        -0x26t
        0x72t
        0x54t
        0x9t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x59t
        0xat
        -0x49t
        0x1bt
        -0x6ft
        -0x6at
        -0x7dt
        -0x4ct
    .end array-data

    :array_12
    .array-data 1
        0x10t
        -0x24t
        -0x70t
        -0x31t
        0x74t
        0x23t
        0x7t
        -0x26t
        -0x5ft
        0x21t
        -0x61t
        -0x2dt
        0x35t
        0x2ct
        0x42t
        0x7ft
        0x4ct
        0x23t
        -0x6et
        -0x39t
        0x3dt
        -0x37t
        -0x48t
    .end array-data

    :array_13
    .array-data 1
        -0x2dt
        0x4at
        -0x2t
        -0x56t
        0x54t
        0xct
        0x27t
        -0x45t
    .end array-data

    :array_14
    .array-data 1
        -0x46t
        -0x41t
        0x60t
        0x6et
        0x62t
        0x32t
        0x62t
        0x50t
        -0x7bt
        0x1at
        -0x41t
        0x20t
        0x72t
        0x32t
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x1dt
        -0x22t
        0xet
        0x4et
        0x16t
        0x53t
        0x10t
        0x31t
    .end array-data

    :array_16
    .array-data 1
        -0x40t
        -0x35t
        0x58t
        -0x3t
        -0x65t
        0x61t
        -0x50t
        0x3ct
        -0x3t
        -0x33t
        0x41t
    .end array-data

    :array_17
    .array-data 1
        -0x7ct
        -0x5et
        0x33t
        -0x23t
        -0x1t
        0x14t
        -0x3et
        0x49t
    .end array-data

    :array_18
    .array-data 1
        -0x6bt
        0x6dt
        -0x7ft
        -0x70t
        -0x37t
        -0x52t
        0x5bt
        0x79t
        0x1bt
        -0x50t
        -0x78t
        -0x2ft
        -0x37t
        -0x56t
        0x9t
        0x71t
        -0x43t
        -0x37t
        0x6dt
        -0x7bt
        -0x27t
        -0x43t
        0x12t
        0x71t
        -0x44t
        0x65t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x28t
        0xct
        -0xet
        -0xft
        -0x50t
        -0x31t
        0x7bt
        0x1dt
    .end array-data
.end method

.method private M()V
    .locals 7

    .line 1
    const/4 v0, 0x6

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->j:Landroid/view/WindowManager;

    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->k:Landroid/widget/Button;

    if-nez v0, :cond_2

    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->k:Landroid/widget/Button;

    const-string v1, " "

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->k:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->k:Landroid/widget/Button;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    sget-object v0, Lcom/icontrol/protector/AccessServices;->v:Landroid/view/WindowManager;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/AccessServices;->w:Landroid/view/WindowManager$LayoutParams;

    if-eqz v0, :cond_0

    const/16 v0, 0x7f0

    :goto_0
    move v4, v0

    goto :goto_1

    :catch_0
    move-exception v0

    goto :goto_3

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    const/16 v0, 0x7f6

    goto :goto_0

    :cond_1
    const/16 v0, 0x7d2

    goto :goto_0

    :goto_1
    new-instance v0, Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x1

    const/4 v3, 0x1

    const v5, 0x280008

    const/4 v6, -0x3

    move-object v1, v0

    invoke-direct/range {v1 .. v6}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->l:Landroid/view/WindowManager$LayoutParams;

    const v1, 0x800035

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/16 v1, 0x1e

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    const/16 v1, 0x32

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    :cond_2
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->k:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v0

    if-nez v0, :cond_4

    sget-object v0, Lcom/icontrol/protector/AccessServices;->v:Landroid/view/WindowManager;

    if-eqz v0, :cond_3

    sget-object v0, Lcom/icontrol/protector/AccessServices;->w:Landroid/view/WindowManager$LayoutParams;

    if-eqz v0, :cond_3

    sget-object v0, Lcom/icontrol/protector/AccessServices;->v:Landroid/view/WindowManager;

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices;->k:Landroid/widget/Button;

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices;->l:Landroid/view/WindowManager$LayoutParams;

    :goto_2
    invoke-interface {v0, v1, v2}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_4

    :cond_3
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->j:Landroid/view/WindowManager;

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices;->k:Landroid/widget/Button;

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices;->l:Landroid/view/WindowManager$LayoutParams;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_4
    :goto_4
    return-void

    nop

    :array_0
    .array-data 1
        -0x2et
        -0x18t
        -0x1at
        0x54t
        -0x21t
        -0x3ft
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x5bt
        -0x7ft
        -0x78t
        0x30t
        -0x50t
        -0x4at
        -0x48t
        -0x3ft
    .end array-data
.end method

.method private static a(Landroid/content/Context;)V
    .locals 3

    .line 1
    const-class v0, Lcom/icontrol/protector/LiveChat;

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v1

    if-nez v1, :cond_1

    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v0, v2, :cond_0

    invoke-static {p0, v1}, Lntidisestablish/neumonoul/floccinaucinih/p1;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_1
    :goto_0
    return-void
.end method

.method private b(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/oq;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->a(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    const/4 v1, 0x1

    invoke-static {p0, v0, p1, v1}, Lntidisestablish/neumonoul/floccinaucinih/v90;->a(Lcom/icontrol/protector/WorkServices;ILandroid/app/Notification;I)V

    goto :goto_0

    :cond_0
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    :goto_0
    return-void
.end method

.method static synthetic c(Lcom/icontrol/protector/WorkServices;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcom/icontrol/protector/WorkServices;->f:J

    return-wide v0
.end method

.method static synthetic d(Lcom/icontrol/protector/WorkServices;J)J
    .locals 0

    .line 1
    iput-wide p1, p0, Lcom/icontrol/protector/WorkServices;->f:J

    return-wide p1
.end method

.method static synthetic e(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->y(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic f(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->B(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic g(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->L(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic h(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->F(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic i(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->H(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic j(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->J(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic k(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->D(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic l(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-static {p0}, Lcom/icontrol/protector/WorkServices;->a(Landroid/content/Context;)V

    return-void
.end method

.method static synthetic m()Landroid/os/PowerManager$WakeLock;
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    return-object v0
.end method

.method static synthetic n(Landroid/os/PowerManager$WakeLock;)Landroid/os/PowerManager$WakeLock;
    .locals 0

    .line 1
    sput-object p0, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    return-object p0
.end method

.method static synthetic o(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->A(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic p(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->K(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic q(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->E(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic r(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic s(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->I(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic t(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->C(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic u(Lcom/icontrol/protector/WorkServices;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcom/icontrol/protector/WorkServices;->e:J

    return-wide v0
.end method

.method static synthetic v(Lcom/icontrol/protector/WorkServices;J)J
    .locals 0

    .line 1
    iput-wide p1, p0, Lcom/icontrol/protector/WorkServices;->e:J

    return-wide p1
.end method

.method static synthetic w(Lcom/icontrol/protector/WorkServices;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->z(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private x()V
    .locals 4

    .line 1
    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/SensorManager;

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->b:Landroid/hardware/SensorManager;

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    move-result-object v0

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->c:Landroid/hardware/Sensor;

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    :try_start_0
    new-instance v0, Lcom/icontrol/protector/WorkServices$a;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/WorkServices$a;-><init>(Lcom/icontrol/protector/WorkServices;)V

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->d:Landroid/hardware/SensorEventListener;

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices;->b:Landroid/hardware/SensorManager;

    iget-object v3, p0, Lcom/icontrol/protector/WorkServices;->c:Landroid/hardware/Sensor;

    invoke-virtual {v2, v0, v3, v1}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->b:Landroid/hardware/SensorManager;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    move-result-object v0

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->g:Landroid/hardware/Sensor;

    if-eqz v0, :cond_1

    new-instance v0, Lcom/icontrol/protector/WorkServices$b;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/WorkServices$b;-><init>(Lcom/icontrol/protector/WorkServices;)V

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->h:Landroid/hardware/SensorEventListener;

    iget-object v2, p0, Lcom/icontrol/protector/WorkServices;->b:Landroid/hardware/SensorManager;

    iget-object v3, p0, Lcom/icontrol/protector/WorkServices;->g:Landroid/hardware/Sensor;

    invoke-virtual {v2, v0, v3, v1}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z

    :cond_1
    return-void

    nop

    :array_0
    .array-data 1
        0x2dt
        0x6bt
        -0x52t
        -0x6t
        0x22t
        -0x32t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x5et
        0xet
        -0x40t
        -0x77t
        0x4dt
        -0x44t
        -0x79t
        -0x30t
    .end array-data
.end method

.method private y(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x9

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/16 v4, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    new-array v1, v4, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v2, [B

    fill-array-data v0, :array_2

    new-array v1, v4, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move v2, v3

    goto/16 :goto_1

    :sswitch_2
    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v4, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    goto/16 :goto_1

    :sswitch_3
    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v1, v4, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v1, v4, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    goto :goto_1

    :sswitch_5
    new-array v0, v1, [B

    fill-array-data v0, :array_a

    new-array v1, v4, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    goto :goto_1

    :sswitch_6
    new-array v0, v1, [B

    fill-array-data v0, :array_c

    new-array v1, v4, [B

    fill-array-data v1, :array_d

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    goto :goto_1

    :sswitch_7
    new-array v0, v3, [B

    fill-array-data v0, :array_e

    new-array v1, v4, [B

    fill-array-data v1, :array_f

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v2, -0x1

    :goto_1
    const/16 p1, 0xf

    const/16 v0, 0x11

    packed-switch v2, :pswitch_data_0

    const/16 p1, 0x1e

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v4, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_0
    const/16 p1, 0x20

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v4, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_1
    new-array p1, p1, [B

    fill-array-data p1, :array_14

    new-array v0, v4, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_2
    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array v0, v4, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_3
    new-array p1, v0, [B

    fill-array-data p1, :array_18

    new-array v0, v4, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_4
    const/16 p1, 0x17

    new-array p1, p1, [B

    fill-array-data p1, :array_1a

    new-array v0, v4, [B

    fill-array-data v0, :array_1b

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_5
    const/16 p1, 0x15

    new-array p1, p1, [B

    fill-array-data p1, :array_1c

    new-array v0, v4, [B

    fill-array-data v0, :array_1d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_6
    new-array p1, v0, [B

    fill-array-data p1, :array_1e

    new-array v0, v4, [B

    fill-array-data v0, :array_1f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_7
    new-array p1, v0, [B

    fill-array-data p1, :array_20

    new-array v0, v4, [B

    fill-array-data v0, :array_21

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x50ea171c -> :sswitch_7
        -0x4ba26961 -> :sswitch_6
        -0x4a33b321 -> :sswitch_5
        -0x4695e9ad -> :sswitch_4
        -0x40b288c8 -> :sswitch_3
        -0x297fb9c0 -> :sswitch_2
        0x68b6917 -> :sswitch_1
        0xd5c6cf6 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :array_0
    .array-data 1
        -0x56t
        0x58t
        -0x29t
        -0x39t
        0x58t
        -0x74t
        0x5at
        0x0t
        -0x45t
        0x5ft
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x32t
        0x31t
        -0x5bt
        -0x5et
        0x3bt
        -0x8t
        0x5t
        0x73t
    .end array-data

    :array_2
    .array-data 1
        0x6et
        -0x25t
        -0x34t
        0x32t
        -0x48t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x1dt
        -0x52t
        -0x5et
        0x5ct
        -0x3ft
        0x25t
        0x37t
        0x15t
    .end array-data

    :array_4
    .array-data 1
        0x6et
        0x14t
        0x3ct
        -0x1et
        0xat
        0x16t
        0x3t
        -0x16t
        0x7ft
        0x1et
        0x23t
    .end array-data

    :array_5
    .array-data 1
        0x1et
        0x7dt
        0x48t
        -0x7ft
        0x62t
        0x49t
        0x61t
        -0x7at
    .end array-data

    :array_6
    .array-data 1
        0x15t
        -0x64t
        0x55t
        0x4ft
        0x23t
        -0x5et
        0x73t
        -0x1et
        0x19t
        -0x76t
        0x53t
        0x47t
        0x39t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x77t
        -0x12t
        0x3ct
        0x28t
        0x4bt
        -0x2at
        0x2ct
        -0x75t
    .end array-data

    :array_8
    .array-data 1
        0x75t
        0x3et
        0x14t
        0x64t
        -0x75t
        -0x69t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x1ct
        0x50t
        0x70t
        0xbt
        -0x1ct
        -0x1bt
        -0x30t
        0xet
    .end array-data

    :array_a
    .array-data 1
        0x53t
        -0x1ft
        0x6t
        -0x52t
        0x11t
        0x21t
        0x7ct
        0x22t
        0x4et
    .end array-data

    nop

    :array_b
    .array-data 1
        0x25t
        -0x7ct
        0x74t
        -0x29t
        0x4et
        0x45t
        0x1dt
        0x50t
    .end array-data

    :array_c
    .array-data 1
        0x7t
        0x30t
        -0x3bt
        -0x45t
        -0x4et
        0x31t
        -0x1et
        -0x19t
        0x17t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x63t
        0x59t
        -0x58t
        -0x1ct
        -0x22t
        0x58t
        -0x7bt
        -0x71t
    .end array-data

    :array_e
    .array-data 1
        -0x69t
        -0xbt
        -0x6et
        -0x63t
        -0xet
        0x9t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0xct
        -0x67t
        -0x3t
        -0x18t
        -0x6at
        0x70t
        0x6t
        -0x1et
    .end array-data

    :array_10
    .array-data 1
        0x19t
        0x5at
        -0x43t
        0x67t
        0x6at
        0x7et
        0x17t
        0x3at
        0x19t
        0x56t
        0x45t
        0x9t
        0x8t
        0x0t
        0x45t
        0x43t
        0x70t
        -0x21t
        -0x44t
        0x54t
        0x6at
        0x60t
        0x17t
        0x2at
        0x18t
        0x77t
        -0x44t
        0x50t
        0x6at
        0x70t
    .end array-data

    nop

    :array_11
    .array-data 1
        -0x3ft
        -0x1t
        0x65t
        -0x2ft
        -0x4et
        -0x27t
        -0x31t
        -0x65t
    .end array-data

    :array_12
    .array-data 1
        0x71t
        -0x51t
        0x6t
        0x65t
        -0x71t
        0xat
        0x24t
        -0x2at
        0xet
        -0x40t
        0x5bt
        0x35t
        -0x1dt
        0x72t
        -0x7ft
        -0x2at
        0x1at
        0x39t
        0x7t
        0x4at
        -0x72t
        0x2ft
        -0x23t
        -0x75t
        0x71t
        -0x4ft
        0x7t
        0x4at
        -0x71t
        0x1ft
        -0x24t
        -0x41t
    .end array-data

    :array_13
    .array-data 1
        -0x57t
        0x19t
        -0x21t
        -0x13t
        0x57t
        -0x55t
        0x4t
        0xet
    .end array-data

    :array_14
    .array-data 1
        -0x2dt
        -0x5at
        0x24t
        0x76t
        -0x6dt
        0x1ft
        -0xct
        0x56t
        -0x71t
        -0xct
        0x49t
        0x27t
        -0x31t
        0x42t
        0x67t
    .end array-data

    :array_15
    .array-data 1
        0xat
        0x2ct
        -0x3t
        -0x2t
        0x4at
        -0x66t
        -0x2ct
        -0x71t
    .end array-data

    :array_16
    .array-data 1
        -0x2bt
        0x1ft
        -0x64t
        -0x46t
        0xat
        -0x3dt
        0x6t
        -0x27t
        -0x4at
        0x4dt
        -0x1et
        -0x16t
        0x75t
        -0x61t
        -0x5dt
    .end array-data

    :array_17
    .array-data 1
        0xct
        -0x6bt
        0x45t
        0x32t
        -0x2dt
        0x46t
        0x26t
        0x1t
    .end array-data

    :array_18
    .array-data 1
        -0x6at
        -0x45t
        -0x6at
        -0x8t
        0x61t
        -0x70t
        -0x70t
        0x47t
        0x6et
        -0x33t
        -0x35t
        -0x79t
        0xdt
        -0x1at
        -0x8t
        0x1at
        -0x34t
    .end array-data

    nop

    :array_19
    .array-data 1
        0x4et
        0x14t
        0x4et
        0x5ft
        -0x47t
        0x3et
        0x49t
        -0x3dt
    .end array-data

    :array_1a
    .array-data 1
        0x47t
        -0x2dt
        0x72t
        0x46t
        0x2t
        0x8t
        -0xat
        -0x1ct
        0x47t
        -0x21t
        -0x76t
        0x28t
        0x75t
        0x77t
        -0x77t
        -0x63t
        0x31t
        -0x51t
        0x2et
        0x29t
        0x50t
        0x77t
        -0x79t
    .end array-data

    :array_1b
    .array-data 1
        -0x61t
        0x76t
        -0x56t
        -0x10t
        -0x26t
        -0x51t
        0x2et
        0x45t
    .end array-data

    :array_1c
    .array-data 1
        -0xct
        0x5ft
        0x73t
        0x6ct
        0x12t
        -0x44t
        -0x5et
        0x3bt
        -0xct
        0x53t
        -0x75t
        0x2t
        0x64t
        -0x3dt
        -0x23t
        0x43t
        -0x53t
        0x22t
        0x1t
        0x2t
        0x63t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x2ct
        -0x6t
        -0x55t
        -0x26t
        -0x36t
        0x1bt
        0x7at
        -0x66t
    .end array-data

    :array_1e
    .array-data 1
        -0x69t
        -0x3at
        0xft
        -0x2ft
        -0x45t
        0x61t
        -0x49t
        0x19t
        0x6et
        -0x65t
        0x7bt
        -0x4ft
        -0x33t
        0x3ct
        -0x1bt
        0x44t
        -0x17t
    .end array-data

    nop

    :array_1f
    .array-data 1
        0x4et
        0x43t
        -0x29t
        0x69t
        0x62t
        -0x1bt
        0x6et
        -0x64t
    .end array-data

    :array_20
    .array-data 1
        -0x51t
        0x5bt
        0x31t
        0x77t
        0x8t
        -0x46t
        -0x4dt
        -0x69t
        0x57t
        0x3bt
        0x47t
        0x2bt
        0x77t
        -0x3ct
        -0x11t
        -0x36t
        -0x3ct
    .end array-data

    nop

    :array_21
    .array-data 1
        0x77t
        -0x1dt
        -0x18t
        -0xdt
        -0x30t
        0x1dt
        0x6at
        0x12t
    .end array-data
.end method

.method private z(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v3, 0x9

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/16 v7, 0x8

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    new-array v0, v6, [B

    fill-array-data v0, :array_0

    new-array v3, v7, [B

    fill-array-data v3, :array_1

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v5

    goto/16 :goto_1

    :sswitch_1
    new-array v0, v6, [B

    fill-array-data v0, :array_2

    new-array v3, v7, [B

    fill-array-data v3, :array_3

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_1

    :sswitch_2
    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v3, v7, [B

    fill-array-data v3, :array_5

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v4

    goto :goto_1

    :sswitch_3
    new-array v0, v3, [B

    fill-array-data v0, :array_6

    new-array v3, v7, [B

    fill-array-data v3, :array_7

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v6

    goto :goto_1

    :sswitch_4
    new-array v0, v3, [B

    fill-array-data v0, :array_8

    new-array v3, v7, [B

    fill-array-data v3, :array_9

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_1

    :sswitch_5
    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v3, v7, [B

    fill-array-data v3, :array_b

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p1, -0x1

    :goto_1
    if-eqz p1, :cond_6

    const/16 v0, 0x15

    if-eq p1, v4, :cond_5

    if-eq p1, v5, :cond_4

    if-eq p1, v2, :cond_3

    if-eq p1, v6, :cond_2

    if-eq p1, v1, :cond_1

    const/16 p1, 0x18

    new-array p1, p1, [B

    fill-array-data p1, :array_c

    new-array v0, v7, [B

    fill-array-data v0, :array_d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    new-array p1, v0, [B

    fill-array-data p1, :array_e

    new-array v0, v7, [B

    fill-array-data v0, :array_f

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2
    const/16 p1, 0x24

    new-array p1, p1, [B

    fill-array-data p1, :array_10

    new-array v0, v7, [B

    fill-array-data v0, :array_11

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3
    const/16 p1, 0x22

    new-array p1, p1, [B

    fill-array-data p1, :array_12

    new-array v0, v7, [B

    fill-array-data v0, :array_13

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_4
    const/16 p1, 0x11

    new-array p1, p1, [B

    fill-array-data p1, :array_14

    new-array v0, v7, [B

    fill-array-data v0, :array_15

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_5
    new-array p1, v0, [B

    fill-array-data p1, :array_16

    new-array v0, v7, [B

    fill-array-data v0, :array_17

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_6
    const/16 p1, 0x1e

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v0, v7, [B

    fill-array-data v0, :array_19

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x2acd7615 -> :sswitch_5
        -0x18d0f841 -> :sswitch_4
        -0x18d0f777 -> :sswitch_3
        -0xd30639f -> :sswitch_2
        0x2fff79 -> :sswitch_1
        0x35dd57 -> :sswitch_0
    .end sparse-switch

    :array_0
    .array-data 1
        0x71t
        0x12t
        0x5t
        -0x5t
    .end array-data

    :array_1
    .array-data 1
        0x2t
        0x7bt
        0x61t
        -0x62t
        0x12t
        0x38t
        -0x15t
        0x66t
    .end array-data

    :array_2
    .array-data 1
        0xat
        0x6bt
        -0x78t
        0x49t
    .end array-data

    :array_3
    .array-data 1
        0x6ct
        0x7t
        -0x17t
        0x3dt
        -0x32t
        -0x49t
        0x29t
        -0x7et
    .end array-data

    :array_4
    .array-data 1
        -0x7dt
        -0x71t
        -0x42t
        0x6at
        0x64t
        -0x53t
        -0x31t
    .end array-data

    :array_5
    .array-data 1
        -0xat
        -0x1t
        -0x34t
        0x3t
        0x3t
        -0x3bt
        -0x45t
        -0x73t
    .end array-data

    :array_6
    .array-data 1
        -0x10t
        0x35t
        -0x8t
        0x78t
        0x36t
        -0x4t
        -0x4bt
        0x6t
        -0xat
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x7ct
        0x5ct
        -0x6ct
        0xct
        0x53t
        -0x68t
        -0x16t
        0x6at
    .end array-data

    :array_8
    .array-data 1
        -0x1at
        0x57t
        0x1dt
        -0x41t
        0xft
        -0x7dt
        0x32t
        -0x34t
        -0x10t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x6et
        0x3et
        0x71t
        -0x35t
        0x6at
        -0x19t
        0x6dt
        -0x56t
    .end array-data

    :array_a
    .array-data 1
        -0x7ft
        -0x79t
        -0x5dt
        -0x59t
        -0x40t
        -0x30t
        0x54t
        0x51t
        -0x53t
        -0x61t
        -0x5dt
        -0x54t
        -0x24t
        -0x3ft
        0x5ct
    .end array-data

    :array_b
    .array-data 1
        -0xet
        -0x15t
        -0x36t
        -0x40t
        -0x58t
        -0x5ct
        0x38t
        0x28t
    .end array-data

    :array_c
    .array-data 1
        0x7t
        -0x5t
        0x4at
        -0x6ct
        0x6ft
        -0x3dt
        0x6dt
        -0x76t
        0x64t
        -0x56t
        0x18t
        -0x6t
        0x6t
        0x5at
        -0x6ct
        -0x29t
        0x6t
        -0x36t
        0x4at
        -0x6dt
        0x6et
        -0xet
        -0x6ct
        -0x2dt
    .end array-data

    :array_d
    .array-data 1
        -0x22t
        0x73t
        -0x6et
        0x22t
        -0x49t
        0x7at
        0x4dt
        0x52t
    .end array-data

    :array_e
    .array-data 1
        -0x52t
        -0x46t
        0xft
        -0x36t
        -0x38t
        -0x5ct
        0x36t
        -0x45t
        0x57t
        -0x1at
        0x55t
        -0x4ct
        -0x6ct
        -0x25t
        0x65t
        -0x1at
        -0xdt
        -0x19t
        0x70t
        -0x4ct
        -0x65t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x77t
        0x3ft
        -0x29t
        0x6dt
        0x10t
        0x2t
        -0x11t
        0x3ft
    .end array-data

    :array_10
    .array-data 1
        -0x13t
        -0x5ft
        0x1t
        -0x7at
        0x5at
        -0x3ct
        0x6bt
        -0x7ct
        0x14t
        -0x3t
        0x5dt
        -0x8t
        0x6t
        -0x45t
        0x38t
        -0x28t
        -0x79t
        -0x4t
        0x7et
        -0x7t
        0x33t
        0x42t
        -0x63t
        0x20t
        -0x14t
        -0x7dt
        0x0t
        -0x5bt
        0x5bt
        -0x18t
        0x6bt
        -0x7bt
        -0x13t
        -0x52t
        0x0t
        -0x59t
    .end array-data

    :array_11
    .array-data 1
        0x34t
        0x24t
        -0x27t
        0x21t
        -0x7et
        0x62t
        -0x4et
        0x0t
    .end array-data

    :array_12
    .array-data 1
        -0x4t
        0xdt
        0x1at
        -0x43t
        0x70t
        -0x78t
        -0xdt
        0x55t
        0x5t
        0x51t
        0x46t
        -0x3dt
        0x2ct
        -0xat
        -0x77t
        0x8t
        -0x60t
        0x50t
        0x65t
        -0x3dt
        0x2dt
        0xet
        0x5t
        -0xft
        -0x4t
        0xct
        0x1bt
        -0x62t
        0x70t
        -0x80t
        -0xdt
        0x55t
        -0x4t
        0x9t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x25t
        -0x78t
        -0x3et
        0x1at
        -0x58t
        0x2et
        0x2at
        -0x2ft
    .end array-data

    :array_14
    .array-data 1
        0x10t
        0x1t
        0x1t
        -0x2ft
        -0xet
        0x2dt
        0x5bt
        -0x34t
        0x64t
        0x60t
        0x7ft
        -0x74t
        -0x53t
        0x7ct
        -0x2dt
        -0x33t
        0x4ft
    .end array-data

    nop

    :array_15
    .array-data 1
        -0x38t
        -0x48t
        -0x28t
        0x55t
        0x2bt
        -0x5ct
        0x7bt
        0x14t
    .end array-data

    :array_16
    .array-data 1
        0x44t
        0x57t
        -0xdt
        0xat
        0x3ft
        -0x1et
        -0x31t
        -0x58t
        -0x43t
        0x7t
        -0x6et
        0x74t
        0x63t
        -0x47t
        -0x62t
        -0xft
        0x32t
        0x6t
        -0x5ft
        0x75t
        0x41t
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x63t
        -0x21t
        0x2bt
        -0x53t
        -0x1at
        0x60t
        0x16t
        0x29t
    .end array-data

    :array_18
    .array-data 1
        0x73t
        0x22t
        0x10t
        -0x5dt
        -0xct
        0x8t
        -0x20t
        -0x11t
        -0x76t
        0x7ft
        0x71t
        -0x37t
        -0x58t
        0x66t
        -0x4ft
        0x62t
        0x72t
        0x0t
        0x11t
        -0x6ct
        -0xct
        0x8t
        -0x20t
        -0x1bt
        0x73t
        0x2ft
        0x11t
        -0x6ct
        -0xct
        0x16t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x56t
        -0x59t
        -0x38t
        0x10t
        0x2ct
        -0x41t
        0x38t
        0x42t
    .end array-data
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 12

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/y1;->a(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/WorkServices;->b(Landroid/content/Context;)V

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/k10;

    invoke-direct {v0, p0}, Lntidisestablish/neumonoul/floccinaucinih/k10;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->i:Lntidisestablish/neumonoul/floccinaucinih/k10;

    sget-object v0, Lcom/icontrol/protector/WorkServices;->p:Ljava/util/concurrent/locks/ReentrantLock;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    sput-object v0, Lcom/icontrol/protector/WorkServices;->p:Ljava/util/concurrent/locks/ReentrantLock;

    :cond_0
    :try_start_0
    sget-object v0, Lcom/icontrol/protector/My_Configs;->Tracking_Data_str:Ljava/lang/String;

    const/4 v1, 0x1

    new-array v2, v1, [B

    const/16 v3, -0x3e

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, 0x8

    new-array v5, v3, [B

    fill-array-data v5, :array_0

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Lcom/icontrol/protector/My_Configs;->Tracking_Data_str:Ljava/lang/String;

    const/4 v2, 0x6

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    new-array v5, v3, [B

    fill-array-data v5, :array_2

    invoke-static {v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->X:Ljava/lang/String;

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v0, v2, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    sget-object v0, Lcom/icontrol/protector/My_Configs;->Tracking_Data_str:Ljava/lang/String;

    const/4 v2, 0x2

    new-array v5, v2, [B

    fill-array-data v5, :array_3

    new-array v6, v3, [B

    fill-array-data v6, :array_4

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v5, v0

    move v6, v4

    :goto_0
    if-ge v6, v5, :cond_3

    aget-object v7, v0, v6

    new-instance v8, Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v7

    const/4 v9, 0x5

    new-array v10, v9, [B

    fill-array-data v10, :array_5

    new-array v11, v3, [B

    fill-array-data v11, :array_6

    invoke-static {v10, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v8, v7, v10}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_1

    new-array v7, v9, [B

    fill-array-data v7, :array_7

    new-array v9, v3, [B

    fill-array-data v9, :array_8

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_1

    const/4 v7, 0x7

    new-array v7, v7, [B

    fill-array-data v7, :array_9

    new-array v9, v3, [B

    fill-array-data v9, :array_a

    invoke-static {v7, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    aget-object v8, v7, v4

    aget-object v9, v7, v1

    aget-object v7, v7, v2

    invoke-static {v8, v9}, Lcom/icontrol/protector/a;->g(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v8, v7}, Lcom/icontrol/protector/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v8}, Lcom/icontrol/protector/a;->f(Ljava/lang/String;)V

    :cond_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->X:Ljava/lang/String;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    :cond_3
    invoke-direct {p0}, Lcom/icontrol/protector/WorkServices;->x()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void

    nop

    :array_0
    .array-data 1
        -0x42t
        0x59t
        0x7et
        0x34t
        -0x38t
        -0x19t
        -0x54t
        0x72t
    .end array-data

    :array_1
    .array-data 1
        0x39t
        -0x66t
        -0x1t
        0x5at
        -0x7ct
        0x62t
    .end array-data

    nop

    :array_2
    .array-data 1
        0x5ct
        -0x9t
        -0x71t
        0x2et
        -0x3t
        0x1et
        -0xat
        0x71t
    .end array-data

    :array_3
    .array-data 1
        0xdt
        0x77t
    .end array-data

    nop

    :array_4
    .array-data 1
        0x51t
        0xbt
        0x5et
        0x19t
        -0x80t
        0x46t
        0x5ct
        0x10t
    .end array-data

    :array_5
    .array-data 1
        -0x64t
        -0x67t
        0x9t
        -0x24t
        0x29t
    .end array-data

    nop

    :array_6
    .array-data 1
        -0x37t
        -0x33t
        0x4ft
        -0xft
        0x11t
        -0x3ft
        -0x2t
        -0x21t
    .end array-data

    :array_7
    .array-data 1
        -0x4t
        -0x5ct
        0x5bt
        0x11t
        0x26t
    .end array-data

    nop

    :array_8
    .array-data 1
        -0x59t
        -0x68t
        0x28t
        0x2ft
        0x7bt
        -0x4ft
        -0x39t
        -0x7ct
    .end array-data

    :array_9
    .array-data 1
        0x11t
        -0x59t
        -0x39t
        -0x4et
        0x1at
        0x78t
        -0x70t
    .end array-data

    :array_a
    .array-data 1
        0x4dt
        -0x4t
        -0x5t
        -0x3ft
        0x24t
        0x24t
        -0x33t
        -0x3ft
    .end array-data
.end method

.method public onDestroy()V
    .locals 7

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->i:Lntidisestablish/neumonoul/floccinaucinih/k10;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/k10;->b()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->i:Lntidisestablish/neumonoul/floccinaucinih/k10;

    :cond_0
    sget-object v0, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_1
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->b:Landroid/hardware/SensorManager;

    if-eqz v0, :cond_2

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices;->h:Landroid/hardware/SensorEventListener;

    if-eqz v1, :cond_2

    invoke-virtual {v0, v1}, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener;)V

    :cond_2
    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->b:Landroid/hardware/SensorManager;

    if-eqz v0, :cond_3

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices;->c:Landroid/hardware/Sensor;

    if-eqz v1, :cond_3

    iget-object v1, p0, Lcom/icontrol/protector/WorkServices;->d:Landroid/hardware/SensorEventListener;

    invoke-virtual {v0, v1}, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener;)V

    :cond_3
    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/icontrol/protector/WorkServices;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/q8;->a(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v1

    if-nez v1, :cond_5

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v1, v3, :cond_4

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/w90;->a(Lcom/icontrol/protector/WorkServices;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_4
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_5
    :goto_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const-wide/16 v5, 0x3a98

    add-long/2addr v3, v5

    invoke-static {v0, v2, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/y1;->b(Landroid/content/Context;Ljava/lang/Class;J)V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/icontrol/protector/WorkServices;->b(Landroid/content/Context;)V

    invoke-static {p1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result p2

    if-eqz p2, :cond_0

    invoke-direct {p0}, Lcom/icontrol/protector/WorkServices;->M()V

    :cond_0
    :try_start_0
    iget-object p2, p0, Lcom/icontrol/protector/WorkServices;->i:Lntidisestablish/neumonoul/floccinaucinih/k10;

    if-nez p2, :cond_1

    new-instance p2, Lntidisestablish/neumonoul/floccinaucinih/k10;

    invoke-direct {p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/k10;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/icontrol/protector/WorkServices;->i:Lntidisestablish/neumonoul/floccinaucinih/k10;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    const/4 p2, 0x5

    const/4 p3, 0x0

    const/4 v0, 0x1

    :try_start_1
    new-array p2, p2, [B

    fill-array-data p2, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {p2, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/os/PowerManager;

    sget-object v2, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    if-nez v2, :cond_3

    sget-object v2, Lcom/icontrol/protector/My_Configs;->Prevent_sleep:Ljava/lang/String;

    new-array v3, v0, [B

    const/16 v4, 0x22

    aput-byte v4, v3, p3

    new-array v4, v1, [B

    fill-array-data v4, :array_2

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    new-array v2, v0, [B

    const/16 v3, -0x64

    aput-byte v3, v2, p3

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const v2, 0x3000001a

    invoke-virtual {p2, v2, v1}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object p2

    :goto_0
    sput-object p2, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    goto :goto_1

    :cond_2
    sget-object v1, Lcom/icontrol/protector/WorkServices;->n:Ljava/lang/String;

    const v2, 0x20000001

    invoke-virtual {p2, v2, v1}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object p2

    goto :goto_0

    :cond_3
    :goto_1
    sget-object p2, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    if-eqz p2, :cond_4

    invoke-virtual {p2}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result p2

    if-nez p2, :cond_4

    sget-object p2, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {p2}, Landroid/os/PowerManager$WakeLock;->acquire()V

    :cond_4
    sget-object p2, Lcom/icontrol/protector/WorkServices;->p:Ljava/util/concurrent/locks/ReentrantLock;

    if-nez p2, :cond_5

    new-instance p2, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {p2}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    sput-object p2, Lcom/icontrol/protector/WorkServices;->p:Ljava/util/concurrent/locks/ReentrantLock;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_5
    :try_start_2
    invoke-direct {p0}, Lcom/icontrol/protector/WorkServices;->x()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    new-instance p2, Lcom/icontrol/protector/WorkServices$d;

    invoke-direct {p2}, Lcom/icontrol/protector/WorkServices$d;-><init>()V

    new-array v1, v0, [Landroid/content/Context;

    aput-object p1, v1, p3

    invoke-virtual {p2, v1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return v0

    :array_0
    .array-data 1
        0x29t
        -0x76t
        0x64t
        0x7ft
        0x5at
    .end array-data

    nop

    :array_1
    .array-data 1
        0x59t
        -0x1bt
        0x13t
        0x1at
        0x28t
        0x5t
        -0x5bt
        -0x3at
    .end array-data

    :array_2
    .array-data 1
        0x13t
        0x64t
        -0x4ct
        -0xet
        0x37t
        0x5et
        -0xbt
        0x30t
    .end array-data

    :array_3
    .array-data 1
        -0x5at
        -0x3ft
        -0x55t
        0x74t
        -0x38t
        0x2dt
        -0x3bt
        -0x26t
    .end array-data
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .locals 8

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0x3a98

    add-long/2addr v1, v3

    const-class v3, Lcom/icontrol/protector/WorkServices;

    invoke-static {v0, v3, v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/y1;->b(Landroid/content/Context;Ljava/lang/Class;J)V

    iget-object v0, p0, Lcom/icontrol/protector/WorkServices;->i:Lntidisestablish/neumonoul/floccinaucinih/k10;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/k10;->b()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/icontrol/protector/WorkServices;->i:Lntidisestablish/neumonoul/floccinaucinih/k10;

    :cond_0
    sget-object v0, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/icontrol/protector/WorkServices;->m:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_1
    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x1

    const/high16 v5, 0xc000000

    invoke-static {v2, v4, v0, v5}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_0

    const/16 v5, 0x8

    new-array v5, v5, [B

    fill-array-data v5, :array_1

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/AlarmManager;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const-wide/16 v6, 0x3e8

    add-long/2addr v4, v6

    const/4 v6, 0x3

    invoke-virtual {v2, v6, v4, v5, v0}, Landroid/app/AlarmManager;->set(IJLandroid/app/PendingIntent;)V

    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v0, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_2

    invoke-static {p0, v0}, Lntidisestablish/neumonoul/floccinaucinih/w90;->a(Lcom/icontrol/protector/WorkServices;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    :cond_2
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :goto_0
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    return-void

    :array_0
    .array-data 1
        0x5at
        -0x33t
        0x8t
        0x6ft
        0x30t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x3bt
        -0x5ft
        0x69t
        0x1dt
        0x5dt
        -0xct
        0x7at
        -0x41t
    .end array-data
.end method
