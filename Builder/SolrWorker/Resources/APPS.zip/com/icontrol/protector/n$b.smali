.class Lcom/icontrol/protector/n$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/n;->Y(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;

.field final synthetic f:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/n$b;->e:Landroid/content/Context;

    iput-object p2, p0, Lcom/icontrol/protector/n$b;->f:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/n$b;->e:Landroid/content/Context;

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v2, v2, [B

    fill-array-data v2, :array_3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/icontrol/protector/n$b;->f:Ljava/lang/String;

    invoke-static {v1, v2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void

    :array_0
    .array-data 1
        -0x34t
        -0x75t
        -0x17t
        -0x80t
        0x7ft
        0x7t
        0x58t
        0xct
        -0x35t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x51t
        -0x19t
        -0x80t
        -0x10t
        0x1dt
        0x68t
        0x39t
        0x7et
    .end array-data

    :array_2
    .array-data 1
        0x4et
        -0x7ct
        0x33t
        0x2at
        -0x17t
        -0x78t
        -0x58t
        0x7bt
        0x53t
        -0x71t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x3at
        -0x1ft
        0x4bt
        0x5et
        -0x3at
        -0x8t
        -0x3ct
        0x1at
    .end array-data
.end method
