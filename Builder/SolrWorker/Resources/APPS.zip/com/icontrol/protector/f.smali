.class public final synthetic Lcom/icontrol/protector/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic e:Landroid/content/Context;

.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic h:Lntidisestablish/neumonoul/floccinaucinih/m70;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/m70;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/icontrol/protector/f;->e:Landroid/content/Context;

    iput-object p2, p0, Lcom/icontrol/protector/f;->f:Ljava/lang/String;

    iput-object p3, p0, Lcom/icontrol/protector/f;->g:Ljava/lang/String;

    iput-object p4, p0, Lcom/icontrol/protector/f;->h:Lntidisestablish/neumonoul/floccinaucinih/m70;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget-object v0, p0, Lcom/icontrol/protector/f;->e:Landroid/content/Context;

    iget-object v1, p0, Lcom/icontrol/protector/f;->f:Ljava/lang/String;

    iget-object v2, p0, Lcom/icontrol/protector/f;->g:Ljava/lang/String;

    iget-object v3, p0, Lcom/icontrol/protector/f;->h:Lntidisestablish/neumonoul/floccinaucinih/m70;

    invoke-static {v0, v1, v2, v3}, Lcom/icontrol/protector/LiveChat$c;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/m70;)V

    return-void
.end method
