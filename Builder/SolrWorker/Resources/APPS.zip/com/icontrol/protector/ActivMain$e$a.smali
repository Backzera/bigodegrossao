.class Lcom/icontrol/protector/ActivMain$e$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/ActivMain$e;->onJsAlert(Landroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;Landroid/webkit/JsResult;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/webkit/JsResult;

.field final synthetic b:Lcom/icontrol/protector/ActivMain$e;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/ActivMain$e;Landroid/webkit/JsResult;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/ActivMain$e$a;->b:Lcom/icontrol/protector/ActivMain$e;

    iput-object p2, p0, Lcom/icontrol/protector/ActivMain$e$a;->a:Landroid/webkit/JsResult;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    iget-object p1, p0, Lcom/icontrol/protector/ActivMain$e$a;->a:Landroid/webkit/JsResult;

    invoke-virtual {p1}, Landroid/webkit/JsResult;->confirm()V

    return-void
.end method
