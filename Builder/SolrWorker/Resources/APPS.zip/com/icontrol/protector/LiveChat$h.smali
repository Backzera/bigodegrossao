.class public Lcom/icontrol/protector/LiveChat$h;
.super Landroid/os/AsyncTask;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/icontrol/protector/LiveChat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "h"
.end annotation


# instance fields
.field private a:Lcom/icontrol/protector/LiveChat;


# direct methods
.method public constructor <init>(Lcom/icontrol/protector/LiveChat;)V
    .locals 0

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$h;->a:Lcom/icontrol/protector/LiveChat;

    return-void
.end method

.method private b(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    .line 1
    const/4 v0, 0x4

    const/16 v1, 0x8

    if-eqz p1, :cond_1

    const/16 v2, 0xa

    new-array v2, v2, [B

    fill-array-data v2, :array_0

    new-array v3, v1, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    const/4 v2, 0x5

    new-array v3, v2, [B

    fill-array-data v3, :array_2

    new-array v4, v1, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    :try_start_0
    new-array v2, v2, [B

    fill-array-data v2, :array_4

    new-array v3, v1, [B

    fill-array-data v3, :array_5

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    invoke-virtual {p1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p1, 0x3

    new-array v3, p1, [B

    fill-array-data v3, :array_6

    new-array v4, v1, [B

    fill-array-data v4, :array_7

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v0, [B

    fill-array-data v4, :array_8

    new-array v5, v1, [B

    fill-array-data v5, :array_9

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-array v4, v0, [B

    fill-array-data v4, :array_a

    new-array v5, v1, [B

    fill-array-data v5, :array_b

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    new-array p1, v0, [B

    fill-array-data p1, :array_c

    new-array v2, v1, [B

    fill-array-data v2, :array_d

    invoke-static {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :catch_0
    move-exception p1

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x2

    new-array v5, v4, [B

    fill-array-data v5, :array_e

    new-array v6, v1, [B

    fill-array-data v6, :array_f

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x1b

    new-array v6, v6, [B

    fill-array-data v6, :array_10

    new-array v7, v1, [B

    fill-array-data v7, :array_11

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-array v4, v4, [B

    fill-array-data v4, :array_12

    new-array v6, v1, [B

    fill-array-data v6, :array_13

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0xf

    new-array v6, v6, [B

    fill-array-data v6, :array_14

    new-array v7, v1, [B

    fill-array-data v7, :array_15

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array p1, p1, [B

    fill-array-data p1, :array_16

    new-array v6, v1, [B

    fill-array-data v6, :array_17

    invoke-static {p1, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {}, Lcom/icontrol/protector/n;->D()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, p1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    sput-object v5, Lntidisestablish/neumonoul/floccinaucinih/ab;->c:Ljava/lang/String;

    sput-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->d:Ljava/lang/String;

    invoke-static {}, Lcom/icontrol/protector/LiveChat;->o()Landroid/content/Context;

    move-result-object v2

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->w:Ljava/lang/String;

    invoke-static {v2, v4, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/icontrol/protector/LiveChat;->o()Landroid/content/Context;

    move-result-object v2

    sget-object v3, Lntidisestablish/neumonoul/floccinaucinih/ab;->y:Ljava/lang/String;

    invoke-static {v2, v3, p1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/16 p1, 0xe

    new-array p1, p1, [B

    fill-array-data p1, :array_18

    new-array v2, v1, [B

    fill-array-data v2, :array_19

    invoke-static {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$h;->a:Lcom/icontrol/protector/LiveChat;

    invoke-static {}, Lcom/icontrol/protector/LiveChat;->o()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {p1, v2}, Lcom/icontrol/protector/LiveChat;->u(Landroid/content/Context;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :goto_0
    const/16 v2, 0xd

    new-array v2, v2, [B

    fill-array-data v2, :array_1a

    new-array v3, v1, [B

    fill-array-data v3, :array_1b

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_1
    :goto_1
    new-array p1, v0, [B

    fill-array-data p1, :array_1c

    new-array v0, v1, [B

    fill-array-data v0, :array_1d

    invoke-static {p1, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :array_0
    .array-data 1
        0x60t
        -0x5bt
        -0xbt
        -0x3dt
        0x36t
        -0x55t
        -0x53t
        0x25t
        0x4at
        -0x6t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x33t
        -0x40t
        -0x79t
        -0x4bt
        0x53t
        -0x27t
        -0x2t
        0x44t
    .end array-data

    :array_2
    .array-data 1
        -0x42t
        -0x4et
        0x1et
        -0x3ft
        0x30t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x3t
        -0x23t
        0x70t
        -0x59t
        0xat
        -0x7bt
        0x24t
        -0x80t
    .end array-data

    :array_4
    .array-data 1
        -0x49t
        0x28t
        -0x71t
        -0x34t
        -0x8t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0xct
        0x47t
        -0x1ft
        -0x56t
        -0x3et
        0x43t
        0x3at
        0x3dt
    .end array-data

    :array_6
    .array-data 1
        -0x2t
        -0x7at
        0x18t
    .end array-data

    :array_7
    .array-data 1
        -0x69t
        -0x1et
        0x7et
        0x5t
        0x1t
        -0x1ct
        -0xft
        -0x3t
    .end array-data

    :array_8
    .array-data 1
        0x23t
        -0x4et
        0x51t
        0x4bt
    .end array-data

    :array_9
    .array-data 1
        0x4dt
        -0x39t
        0x3dt
        0x27t
        -0x34t
        -0x60t
        0x20t
        -0x40t
    .end array-data

    :array_a
    .array-data 1
        -0x7t
        -0x59t
        0x7at
        0xet
    .end array-data

    :array_b
    .array-data 1
        -0x69t
        -0x2et
        0x16t
        0x62t
        -0x30t
        0x41t
        -0x31t
        -0x2t
    .end array-data

    :array_c
    .array-data 1
        0x65t
        0x35t
        -0x41t
        0x3at
    .end array-data

    :array_d
    .array-data 1
        0xbt
        0x40t
        -0x2dt
        0x56t
        -0x53t
        0x69t
        -0x13t
        0x7ft
    .end array-data

    :array_e
    .array-data 1
        -0x20t
        0x12t
    .end array-data

    nop

    :array_f
    .array-data 1
        -0x6dt
        0x79t
        0xat
        0x35t
        -0x2et
        -0x31t
        0x75t
        0x64t
    .end array-data

    :array_10
    .array-data 1
        0x5ct
        0x26t
        -0x46t
        0x5ft
        0x79t
        0x52t
        -0xct
        0x58t
        0x5t
        0x64t
        -0x4at
        0x40t
        0x78t
        0x51t
        -0x1t
        0x5ct
        0x5t
        0x67t
        -0x50t
        0x43t
        0x6ct
        0x5bt
        -0x3t
        0x55t
        0x1bt
        0x7at
        -0x44t
    .end array-data

    :array_11
    .array-data 1
        0x2bt
        0x55t
        -0x80t
        0x70t
        0x56t
        0x63t
        -0x33t
        0x6dt
    .end array-data

    :array_12
    .array-data 1
        0x32t
        -0x33t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x53t
        -0x57t
        0x18t
        0x5ct
        0x42t
        -0x72t
        0x47t
        -0x2dt
    .end array-data

    :array_14
    .array-data 1
        0x11t
        0x25t
        0x31t
        -0x2et
        0x49t
        -0x61t
        -0x1at
        -0x10t
        0x12t
        0x2et
        0x35t
        -0x2et
        0x4at
        -0x67t
        -0x1bt
    .end array-data

    :array_15
    .array-data 1
        0x20t
        0x1ct
        0x4t
        -0x4t
        0x78t
        -0x57t
        -0x2at
        -0x22t
    .end array-data

    :array_16
    .array-data 1
        0x7ft
        -0x26t
        -0x5ct
    .end array-data

    :array_17
    .array-data 1
        0x1ct
        -0x4dt
        -0x2ct
        0x75t
        0x2ft
        0x47t
        0x48t
        -0x35t
    .end array-data

    :array_18
    .array-data 1
        -0x5t
        -0x45t
        -0x30t
        -0x37t
        -0x43t
        -0x4bt
        -0x6at
        0x6et
        -0x4et
        -0x59t
        -0x40t
        -0x39t
        -0xft
        -0x3t
    .end array-data

    nop

    :array_19
    .array-data 1
        -0x66t
        -0x32t
        -0x5ct
        -0x5ft
        -0x28t
        -0x39t
        -0x1bt
        0x4et
    .end array-data

    :array_1a
    .array-data 1
        -0x40t
        -0x3ft
        -0x63t
        0x60t
        -0x64t
        -0x6bt
        -0x9t
        0x6bt
        -0x1t
        -0x27t
        -0x7at
        0x67t
        -0x6at
    .end array-data

    nop

    :array_1b
    .array-data 1
        -0x71t
        -0x4ft
        -0x17t
        0x9t
        -0xdt
        -0x5t
        -0x7ct
        0x4bt
    .end array-data

    :array_1c
    .array-data 1
        -0x37t
        0x2ft
        -0x8t
        0x3t
    .end array-data

    :array_1d
    .array-data 1
        -0x59t
        0x5at
        -0x6ct
        0x6ft
        -0x4ct
        0x56t
        -0x1ct
        -0x56t
    .end array-data
.end method


# virtual methods
.method protected varargs a([Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    .line 1
    const/16 p1, 0x8

    :try_start_0
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/ab;->b()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    new-array v2, p1, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/net/URLConnection;->setDoOutput(Z)V

    invoke-virtual {v0, v1}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/16 v1, 0x1388

    invoke-virtual {v0, v1}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/16 v1, 0xc

    new-array v2, v1, [B

    fill-array-data v2, :array_2

    new-array v3, p1, [B

    fill-array-data v3, :array_3

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x21

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v4, p1, [B

    fill-array-data v4, :array_5

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/tq;->c()Lntidisestablish/neumonoul/floccinaucinih/tq;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    new-array v4, v1, [B

    fill-array-data v4, :array_6

    new-array v5, p1, [B

    fill-array-data v5, :array_7

    invoke-static {v4, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v4, Lcom/icontrol/protector/My_Configs;->USR_MAIL:Ljava/lang/String;

    invoke-virtual {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/tq;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    new-array v5, v4, [B

    fill-array-data v5, :array_8

    new-array v6, p1, [B

    fill-array-data v6, :array_9

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v3

    new-instance v5, Ljava/io/OutputStreamWriter;

    new-array v4, v4, [B

    fill-array-data v4, :array_a

    new-array v6, p1, [B

    fill-array-data v6, :array_b

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v5, v3, v4}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/lang/String;)V

    invoke-virtual {v5, v2}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/io/OutputStreamWriter;->flush()V

    invoke-virtual {v5}, Ljava/io/OutputStreamWriter;->close()V

    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v2

    const/16 v3, 0xc8

    if-ne v2, v3, :cond_1

    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-virtual {v0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    :goto_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :catch_0
    move-exception v0

    goto :goto_1

    :cond_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/LiveChat$h;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    new-array v1, v1, [B

    fill-array-data v1, :array_c

    new-array v3, p1, [B

    fill-array-data v3, :array_d

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/icontrol/protector/LiveChat$h;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :goto_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x7

    new-array v2, v2, [B

    fill-array-data v2, :array_e

    new-array p1, p1, [B

    fill-array-data p1, :array_f

    invoke-static {v2, p1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/icontrol/protector/LiveChat$h;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_0
    .array-data 1
        0x2ft
        -0x12t
        0x38t
        0x1et
    .end array-data

    :array_1
    .array-data 1
        0x7ft
        -0x5ft
        0x6bt
        0x4at
        -0x1et
        -0x3ct
        0x12t
        0x42t
    .end array-data

    :array_2
    .array-data 1
        0x6bt
        0x65t
        -0x3t
        -0x7at
        0x6ct
        0x5et
        -0x78t
        -0x1et
        0x7ct
        0x73t
        -0x1dt
        -0x69t
    .end array-data

    :array_3
    .array-data 1
        0x28t
        0xat
        -0x6dt
        -0xet
        0x9t
        0x30t
        -0x4t
        -0x31t
    .end array-data

    :array_4
    .array-data 1
        0x47t
        0x28t
        -0x52t
        0x18t
        0x2ct
        0x58t
        -0x4dt
        0x6et
        0x4ft
        0x37t
        -0x50t
        0x5bt
        0x3dt
        0x16t
        -0x5bt
        0x6dt
        0x51t
        0x75t
        -0x48t
        0x1bt
        0x37t
        0x56t
        -0x1t
        0x6ft
        0x54t
        0x34t
        -0x45t
        0x1at
        0x26t
        0x54t
        -0x4at
        0x7ft
        0x42t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x26t
        0x58t
        -0x22t
        0x74t
        0x45t
        0x3bt
        -0x2et
        0x1at
    .end array-data

    :array_6
    .array-data 1
        -0x56t
        0x28t
        -0x21t
        0x1at
        0x38t
        0x4at
        -0x1bt
        -0x18t
        -0x13t
        0x34t
        -0x40t
        0x42t
    .end array-data

    :array_7
    .array-data 1
        -0x74t
        0x5dt
        -0x54t
        0x7ft
        0x4at
        0x15t
        -0x80t
        -0x7bt
    .end array-data

    :array_8
    .array-data 1
        0x11t
        0x45t
        0x59t
        -0x6t
        -0xbt
    .end array-data

    nop

    :array_9
    .array-data 1
        0x44t
        0x11t
        0x1ft
        -0x29t
        -0x33t
        0x6at
        0x36t
        -0x1bt
    .end array-data

    :array_a
    .array-data 1
        -0x79t
        0x8t
        -0xft
        0x44t
        -0x2at
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x2et
        0x5ct
        -0x49t
        0x69t
        -0x12t
        -0x15t
        0x4at
        -0x30t
    .end array-data

    :array_c
    .array-data 1
        -0x5dt
        -0x5at
        0x18t
        -0x12t
        0x11t
        -0x2dt
        0x16t
        -0x48t
        -0x7ct
        -0x80t
        0x76t
        -0x62t
    .end array-data

    :array_d
    .array-data 1
        -0x15t
        -0xet
        0x4ct
        -0x42t
        0x31t
        -0x6at
        0x64t
        -0x36t
    .end array-data

    :array_e
    .array-data 1
        -0x1dt
        0x47t
        -0x33t
        0x4ft
        -0x7et
        0x39t
        -0x15t
    .end array-data

    :array_f
    .array-data 1
        -0x5at
        0x35t
        -0x41t
        0x20t
        -0x10t
        0x3t
        -0x35t
        0x60t
    .end array-data
.end method

.method protected c(Ljava/lang/String;)V
    .locals 0

    .line 1
    return-void
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/icontrol/protector/LiveChat$h;->a([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/icontrol/protector/LiveChat$h;->c(Ljava/lang/String;)V

    return-void
.end method

.method protected onPreExecute()V
    .locals 0

    invoke-super {p0}, Landroid/os/AsyncTask;->onPreExecute()V

    return-void
.end method
