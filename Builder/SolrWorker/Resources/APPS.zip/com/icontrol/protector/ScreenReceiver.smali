.class public Lcom/icontrol/protector/ScreenReceiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# instance fields
.field private a:J

.field private b:J

.field private c:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/icontrol/protector/ScreenReceiver;->a:J

    iput-wide v0, p0, Lcom/icontrol/protector/ScreenReceiver;->b:J

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/icontrol/protector/ScreenReceiver;->c:Z

    return-void
.end method

.method static synthetic b(Lcom/icontrol/protector/ScreenReceiver;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/icontrol/protector/ScreenReceiver;->c:Z

    return p0
.end method

.method static synthetic c(Lcom/icontrol/protector/ScreenReceiver;Z)Z
    .locals 0

    .line 1
    iput-boolean p1, p0, Lcom/icontrol/protector/ScreenReceiver;->c:Z

    return p1
.end method

.method static synthetic d(Lcom/icontrol/protector/ScreenReceiver;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcom/icontrol/protector/ScreenReceiver;->b:J

    return-wide v0
.end method

.method static synthetic e(Lcom/icontrol/protector/ScreenReceiver;J)J
    .locals 0

    .line 1
    iput-wide p1, p0, Lcom/icontrol/protector/ScreenReceiver;->b:J

    return-wide p1
.end method

.method static synthetic f(Lcom/icontrol/protector/ScreenReceiver;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcom/icontrol/protector/ScreenReceiver;->a:J

    return-wide v0
.end method

.method static synthetic g(Lcom/icontrol/protector/ScreenReceiver;J)J
    .locals 0

    .line 1
    iput-wide p1, p0, Lcom/icontrol/protector/ScreenReceiver;->a:J

    return-wide p1
.end method


# virtual methods
.method public a(JJ)V
    .locals 7

    .line 1
    new-instance v0, Ljava/text/SimpleDateFormat;

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_0

    new-array v3, v1, [B

    fill-array-data v3, :array_1

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-direct {v0, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0xc

    new-array v5, v4, [B

    fill-array-data v5, :array_2

    new-array v6, v1, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 p1, 0x3

    new-array p1, p1, [B

    fill-array-data p1, :array_4

    new-array p2, v1, [B

    fill-array-data p2, :array_5

    invoke-static {p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    new-array p2, v4, [B

    fill-array-data p2, :array_6

    new-array v3, v1, [B

    fill-array-data v3, :array_7

    invoke-static {p2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 p2, 0x1

    new-array p2, p2, [B

    const/4 p3, 0x0

    const/16 p4, 0x23

    aput-byte p4, p2, p3

    new-array p3, v1, [B

    fill-array-data p3, :array_8

    invoke-static {p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget-object p2, Lcom/icontrol/protector/b$b;->e:Lcom/icontrol/protector/b$b;

    invoke-static {p1, p2}, Lcom/icontrol/protector/b;->c(Ljava/lang/String;Lcom/icontrol/protector/b$b;)V

    return-void

    :array_0
    .array-data 1
        -0x12t
        -0x51t
        0x1at
        0x0t
        -0x25t
        0x22t
        0x7ft
        -0x37t
    .end array-data

    :array_1
    .array-data 1
        -0x5at
        -0x19t
        0x20t
        0x6dt
        -0x4at
        0x18t
        0xct
        -0x46t
    .end array-data

    :array_2
    .array-data 1
        -0x2dt
        0x44t
        0x7ft
        -0x3dt
        -0x35t
        -0x62t
        -0x63t
        -0x13t
        -0x1bt
        0x6et
        0x35t
        -0x7at
    .end array-data

    :array_3
    .array-data 1
        -0x78t
        0xbt
        0xft
        -0x5at
        -0x5bt
        -0x42t
        -0x37t
        -0x7ct
    .end array-data

    :array_4
    .array-data 1
        0x24t
        0x65t
        -0xet
    .end array-data

    :array_5
    .array-data 1
        0x79t
        0x19t
        -0x57t
        -0x71t
        -0x17t
        0x45t
        -0x15t
        -0x7at
    .end array-data

    :array_6
    .array-data 1
        -0x3et
        0x1ct
        -0x39t
        0x3t
        0x78t
        -0x47t
        -0x40t
        0x34t
        -0x14t
        0x15t
        -0x6et
        0x50t
    .end array-data

    :array_7
    .array-data 1
        -0x7ft
        0x70t
        -0x58t
        0x70t
        0x1dt
        -0x67t
        -0x6ct
        0x5dt
    .end array-data

    :array_8
    .array-data 1
        0x7et
        -0x42t
        -0x5at
        0x40t
        0x3et
        0x5et
        -0x1bt
        -0x1dt
    .end array-data
.end method

.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/icontrol/protector/ScreenReceiver$a;

    invoke-direct {v1, p0, p1, p2}, Lcom/icontrol/protector/ScreenReceiver$a;-><init>(Lcom/icontrol/protector/ScreenReceiver;Landroid/content/Context;Landroid/content/Intent;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method
