.class public Lcom/icontrol/protector/Startme;
.super Landroid/app/Activity;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v0, 0x2

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const-string v3, ""

    invoke-static {p1, v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_1

    invoke-static {p1}, Lcom/icontrol/protector/n;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/16 v4, 0xa

    if-ge v3, v4, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x9

    const/16 v4, 0x10

    invoke-static {v1, v4}, Lcom/icontrol/protector/n;->W(II)I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_0
    new-array v3, v2, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v3, v2, [B

    fill-array-data v3, :array_5

    invoke-static {v0, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    const/4 v1, 0x4

    new-array v3, v1, [B

    fill-array-data v3, :array_6

    new-array v4, v2, [B

    fill-array-data v4, :array_7

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    iget v4, v0, Landroid/graphics/Point;->x:I

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {p1, v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    new-array v1, v1, [B

    fill-array-data v1, :array_8

    new-array v2, v2, [B

    fill-array-data v2, :array_9

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget v0, v0, Landroid/graphics/Point;->y:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/sq;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->requestWindowFeature(I)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x400

    invoke-virtual {p1, v0, v0}, Landroid/view/Window;->setFlags(II)V

    new-instance p1, Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lcom/icontrol/protector/Splasher;

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v0, 0x10000000

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :goto_0
    return-void

    nop

    :array_0
    .array-data 1
        -0x3et
        -0x1dt
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x75t
        -0x59t
        0x74t
        0x5ct
        -0xet
        -0x41t
        -0x6bt
        -0x5et
    .end array-data

    :array_2
    .array-data 1
        -0x1ft
        -0x37t
        0x22t
        0x50t
        -0x16t
        -0x1ft
        0x46t
        -0x1ct
    .end array-data

    :array_3
    .array-data 1
        -0x5et
        -0x45t
        0x47t
        0x31t
        -0x62t
        -0x7ct
        0xft
        -0x60t
    .end array-data

    :array_4
    .array-data 1
        0x1at
        -0xdt
    .end array-data

    nop

    :array_5
    .array-data 1
        0x53t
        -0x49t
        -0x27t
        -0xbt
        0x12t
        -0x31t
        -0x41t
        0x7dt
    .end array-data

    :array_6
    .array-data 1
        -0x31t
        -0x45t
        0x68t
        0x2ct
    .end array-data

    :array_7
    .array-data 1
        -0x68t
        -0x38t
        0xbt
        0x5et
        0x68t
        -0x39t
        -0x50t
        0x4at
    .end array-data

    :array_8
    .array-data 1
        0x0t
        -0x71t
        -0x6bt
        -0x4dt
    .end array-data

    :array_9
    .array-data 1
        0x48t
        -0x4t
        -0xat
        -0x3ft
        0x4et
        -0x6ft
        -0x7et
        -0x4ft
    .end array-data
.end method
