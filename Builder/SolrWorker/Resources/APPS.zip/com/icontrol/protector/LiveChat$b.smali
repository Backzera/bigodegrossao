.class Lcom/icontrol/protector/LiveChat$b;
.super Lntidisestablish/neumonoul/floccinaucinih/o70;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/LiveChat;->h(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field a:Z

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Lntidisestablish/neumonoul/floccinaucinih/ks;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lntidisestablish/neumonoul/floccinaucinih/ks;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/icontrol/protector/LiveChat$b;->b:Landroid/content/Context;

    iput-object p2, p0, Lcom/icontrol/protector/LiveChat$b;->c:Ljava/lang/String;

    iput-object p3, p0, Lcom/icontrol/protector/LiveChat$b;->d:Ljava/lang/String;

    iput-object p4, p0, Lcom/icontrol/protector/LiveChat$b;->e:Ljava/lang/String;

    iput-object p5, p0, Lcom/icontrol/protector/LiveChat$b;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/o70;-><init>()V

    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/icontrol/protector/LiveChat$b;->a:Z

    return-void
.end method

.method static synthetic g(Lcom/icontrol/protector/LiveChat$b;Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/ks;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/LiveChat$b;->h(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/ks;)V

    return-void
.end method

.method private h(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/ks;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    :try_start_0
    iput-boolean v0, p0, Lcom/icontrol/protector/LiveChat$b;->a:Z

    if-eqz p1, :cond_0

    invoke-interface {p1}, Lntidisestablish/neumonoul/floccinaucinih/m70;->a()V

    :cond_0
    if-eqz p2, :cond_1

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->a()V

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->l()Lntidisestablish/neumonoul/floccinaucinih/da;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/da;->a()V

    invoke-virtual {p2}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    return-void
.end method


# virtual methods
.method public a(Lntidisestablish/neumonoul/floccinaucinih/m70;ILjava/lang/String;)V
    .locals 0

    .line 1
    iget-object p1, p0, Lcom/icontrol/protector/LiveChat$b;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ks;->o()Lntidisestablish/neumonoul/floccinaucinih/ce;

    move-result-object p1

    invoke-virtual {p1}, Lntidisestablish/neumonoul/floccinaucinih/ce;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    return-void
.end method

.method public c(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/Throwable;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V
    .locals 5

    .line 1
    invoke-super {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/o70;->d(Lntidisestablish/neumonoul/floccinaucinih/m70;Ljava/lang/String;)V

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x4

    new-array v1, p2, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array p2, p2, [B

    fill-array-data p2, :array_4

    new-array v1, v2, [B

    fill-array-data v1, :array_5

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_0

    const/16 p2, 0x13

    new-array p2, p2, [B

    fill-array-data p2, :array_6

    new-array v1, v2, [B

    fill-array-data v1, :array_7

    invoke-static {p2, v1}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_1

    :cond_0
    iget-object p2, p0, Lcom/icontrol/protector/LiveChat$b;->f:Lntidisestablish/neumonoul/floccinaucinih/ks;

    invoke-direct {p0, p1, p2}, Lcom/icontrol/protector/LiveChat$b;->h(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/ks;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    return-void

    :array_0
    .array-data 1
        0x38t
        0x10t
        0x27t
        -0x67t
    .end array-data

    :array_1
    .array-data 1
        0x4ct
        0x69t
        0x57t
        -0x4t
        0x76t
        -0x52t
        0x1t
        0x6ct
    .end array-data

    :array_2
    .array-data 1
        0x34t
        -0x66t
        0x13t
        -0x7bt
        0x6t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x51t
        -0x9t
        0x63t
        -0xft
        0x7ft
        0x47t
        -0xdt
        0x6t
    .end array-data

    :array_4
    .array-data 1
        0x1ct
        -0x2t
        0x76t
        0x24t
    .end array-data

    :array_5
    .array-data 1
        0x6ft
        -0x76t
        0x19t
        0x54t
        -0x12t
        0x61t
        -0x54t
        0x2bt
    .end array-data

    :array_6
    .array-data 1
        -0x32t
        0x42t
        -0x3et
        -0x7dt
        -0x6t
        0xft
        0x6et
        0x32t
        -0xet
        0x56t
        -0x3at
        -0x6et
        -0x52t
        0x6t
        0x62t
        0x23t
        -0x2t
        0x5ft
        -0x30t
    .end array-data

    :array_7
    .array-data 1
        -0x65t
        0x2ct
        -0x5dt
        -0xat
        -0x72t
        0x67t
        0x1t
        0x40t
    .end array-data
.end method

.method public f(Lntidisestablish/neumonoul/floccinaucinih/m70;Lntidisestablish/neumonoul/floccinaucinih/dy;)V
    .locals 0

    .line 1
    new-instance p2, Lcom/icontrol/protector/LiveChat$b$a;

    invoke-direct {p2, p0, p1}, Lcom/icontrol/protector/LiveChat$b$a;-><init>(Lcom/icontrol/protector/LiveChat$b;Lntidisestablish/neumonoul/floccinaucinih/m70;)V

    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    return-void
.end method
