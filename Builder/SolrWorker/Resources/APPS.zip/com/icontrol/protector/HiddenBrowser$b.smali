.class Lcom/icontrol/protector/HiddenBrowser$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/HiddenBrowser;->o([Ljava/lang/String;Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Lcom/icontrol/protector/HiddenBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/HiddenBrowser;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$b;->f:Lcom/icontrol/protector/HiddenBrowser;

    iput-object p2, p0, Lcom/icontrol/protector/HiddenBrowser$b;->e:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$b;->f:Lcom/icontrol/protector/HiddenBrowser;

    invoke-static {v0}, Lcom/icontrol/protector/HiddenBrowser;->d(Lcom/icontrol/protector/HiddenBrowser;)Landroid/webkit/WebView;

    move-result-object v0

    iget-object v1, p0, Lcom/icontrol/protector/HiddenBrowser$b;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method
