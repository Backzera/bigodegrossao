.class Lcom/icontrol/protector/HiddenBrowser$e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/icontrol/protector/HiddenBrowser;->o([Ljava/lang/String;Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic e:I

.field final synthetic f:I

.field final synthetic g:Lcom/icontrol/protector/HiddenBrowser;


# direct methods
.method constructor <init>(Lcom/icontrol/protector/HiddenBrowser;II)V
    .locals 0

    iput-object p1, p0, Lcom/icontrol/protector/HiddenBrowser$e;->g:Lcom/icontrol/protector/HiddenBrowser;

    iput p2, p0, Lcom/icontrol/protector/HiddenBrowser$e;->e:I

    iput p3, p0, Lcom/icontrol/protector/HiddenBrowser$e;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    :try_start_0
    iget-object v0, p0, Lcom/icontrol/protector/HiddenBrowser$e;->g:Lcom/icontrol/protector/HiddenBrowser;

    iget v1, p0, Lcom/icontrol/protector/HiddenBrowser$e;->e:I

    int-to-float v1, v1

    iget v2, p0, Lcom/icontrol/protector/HiddenBrowser$e;->f:I

    int-to-float v2, v2

    invoke-static {v0, v1, v2}, Lcom/icontrol/protector/HiddenBrowser;->e(Lcom/icontrol/protector/HiddenBrowser;FF)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method
