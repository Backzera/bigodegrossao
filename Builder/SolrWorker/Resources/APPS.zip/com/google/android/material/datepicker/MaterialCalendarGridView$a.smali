.class Lcom/google/android/material/datepicker/MaterialCalendarGridView$a;
.super Lntidisestablish/neumonoul/floccinaucinih/k0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/MaterialCalendarGridView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Lcom/google/android/material/datepicker/MaterialCalendarGridView;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/MaterialCalendarGridView;)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/material/datepicker/MaterialCalendarGridView$a;->d:Lcom/google/android/material/datepicker/MaterialCalendarGridView;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/k0;-><init>()V

    return-void
.end method


# virtual methods
.method public g(Landroid/view/View;Lntidisestablish/neumonoul/floccinaucinih/h1;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/k0;->g(Landroid/view/View;Lntidisestablish/neumonoul/floccinaucinih/h1;)V

    const/4 p1, 0x0

    invoke-virtual {p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/h1;->Z(Ljava/lang/Object;)V

    return-void
.end method
