.class final Lcom/google/android/material/timepicker/c$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/timepicker/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/google/android/material/timepicker/c;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/android/material/timepicker/c;

    invoke-direct {v0, p1}, Lcom/google/android/material/timepicker/c;-><init>(Landroid/os/Parcel;)V

    return-object v0
.end method

.method public b(I)[Lcom/google/android/material/timepicker/c;
    .locals 0

    .line 1
    new-array p1, p1, [Lcom/google/android/material/timepicker/c;

    return-object p1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Lcom/google/android/material/timepicker/c$a;->a(Landroid/os/Parcel;)Lcom/google/android/material/timepicker/c;

    move-result-object p1

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1}, Lcom/google/android/material/timepicker/c$a;->b(I)[Lcom/google/android/material/timepicker/c;

    move-result-object p1

    return-object p1
.end method
