.class Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButtonToggleGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation


# static fields
.field private static final e:Lntidisestablish/neumonoul/floccinaucinih/nb;


# instance fields
.field a:Lntidisestablish/neumonoul/floccinaucinih/nb;

.field b:Lntidisestablish/neumonoul/floccinaucinih/nb;

.field c:Lntidisestablish/neumonoul/floccinaucinih/nb;

.field d:Lntidisestablish/neumonoul/floccinaucinih/nb;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lntidisestablish/neumonoul/floccinaucinih/g;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/g;-><init>(F)V

    sput-object v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->e:Lntidisestablish/neumonoul/floccinaucinih/nb;

    return-void
.end method

.method constructor <init>(Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->a:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iput-object p3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->b:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iput-object p4, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->c:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iput-object p2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->d:Lntidisestablish/neumonoul/floccinaucinih/nb;

    return-void
.end method

.method public static a(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
    .locals 3

    .line 1
    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    sget-object v1, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->e:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->d:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iget-object p0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->c:Lntidisestablish/neumonoul/floccinaucinih/nb;

    invoke-direct {v0, v1, v2, v1, p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;-><init>(Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;)V

    return-object v0
.end method

.method public static b(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;Landroid/view/View;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
    .locals 0

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/f70;->d(Landroid/view/View;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->c(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    move-result-object p0

    goto :goto_0

    :cond_0
    invoke-static {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->d(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public static c(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
    .locals 3

    .line 1
    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->a:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iget-object p0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->d:Lntidisestablish/neumonoul/floccinaucinih/nb;

    sget-object v2, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->e:Lntidisestablish/neumonoul/floccinaucinih/nb;

    invoke-direct {v0, v1, p0, v2, v2}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;-><init>(Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;)V

    return-object v0
.end method

.method public static d(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
    .locals 3

    .line 1
    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    sget-object v1, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->e:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->b:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iget-object p0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->c:Lntidisestablish/neumonoul/floccinaucinih/nb;

    invoke-direct {v0, v1, v1, v2, p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;-><init>(Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;)V

    return-object v0
.end method

.method public static e(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;Landroid/view/View;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
    .locals 0

    .line 1
    invoke-static {p1}, Lntidisestablish/neumonoul/floccinaucinih/f70;->d(Landroid/view/View;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->d(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    move-result-object p0

    goto :goto_0

    :cond_0
    invoke-static {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->c(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public static f(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
    .locals 3

    .line 1
    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->a:Lntidisestablish/neumonoul/floccinaucinih/nb;

    sget-object v2, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->e:Lntidisestablish/neumonoul/floccinaucinih/nb;

    iget-object p0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->b:Lntidisestablish/neumonoul/floccinaucinih/nb;

    invoke-direct {v0, v1, v2, p0, v2}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;-><init>(Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;Lntidisestablish/neumonoul/floccinaucinih/nb;)V

    return-object v0
.end method
