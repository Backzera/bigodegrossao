.class public abstract Lcom/google/android/material/bottomappbar/BottomAppBar;
.super Landroidx/appcompat/widget/Toolbar;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;
    }
.end annotation


# static fields
.field private static final P:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget v0, Lntidisestablish/neumonoul/floccinaucinih/ew;->e:I

    sput v0, Lcom/google/android/material/bottomappbar/BottomAppBar;->P:I

    return-void
.end method

.method static synthetic I(Lcom/google/android/material/bottomappbar/BottomAppBar;)V
    .locals 0

    .line 1
    const/4 p0, 0x0

    throw p0
.end method

.method static synthetic J(Lcom/google/android/material/bottomappbar/BottomAppBar;)Landroid/view/View;
    .locals 0

    .line 1
    const/4 p0, 0x0

    throw p0
.end method
