.class public abstract Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
.super Lntidisestablish/neumonoul/floccinaucinih/h70;
.source "SourceFile"

# interfaces
.implements Lntidisestablish/neumonoul/floccinaucinih/bg;
.implements Lntidisestablish/neumonoul/floccinaucinih/l00;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;,
        Lcom/google/android/material/floatingactionbutton/FloatingActionButton$Behavior;
    }
.end annotation
