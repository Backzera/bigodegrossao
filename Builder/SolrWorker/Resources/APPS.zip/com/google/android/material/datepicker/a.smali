.class public abstract Lcom/google/android/material/datepicker/a;
.super Lntidisestablish/neumonoul/floccinaucinih/ud;
.source "SourceFile"


# static fields
.field static final c:Ljava/lang/Object;

.field static final d:Ljava/lang/Object;

.field static final e:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "CONFIRM_BUTTON_TAG"

    sput-object v0, Lcom/google/android/material/datepicker/a;->c:Ljava/lang/Object;

    const-string v0, "CANCEL_BUTTON_TAG"

    sput-object v0, Lcom/google/android/material/datepicker/a;->d:Ljava/lang/Object;

    const-string v0, "TOGGLE_BUTTON_TAG"

    sput-object v0, Lcom/google/android/material/datepicker/a;->e:Ljava/lang/Object;

    return-void
.end method

.method static a(Landroid/content/Context;)Z
    .locals 1

    .line 1
    const v0, 0x101020d

    invoke-static {p0, v0}, Lcom/google/android/material/datepicker/a;->c(Landroid/content/Context;I)Z

    move-result p0

    return p0
.end method

.method static b(Landroid/content/Context;)Z
    .locals 1

    .line 1
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/fv;->r:I

    invoke-static {p0, v0}, Lcom/google/android/material/datepicker/a;->c(Landroid/content/Context;I)Z

    move-result p0

    return p0
.end method

.method static c(Landroid/content/Context;I)Z
    .locals 2

    .line 1
    sget v0, Lntidisestablish/neumonoul/floccinaucinih/fv;->o:I

    const-class v1, Lntidisestablish/neumonoul/floccinaucinih/uo;

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v0, v1}, Lntidisestablish/neumonoul/floccinaucinih/to;->c(Landroid/content/Context;ILjava/lang/String;)I

    move-result v0

    filled-new-array {p1}, [I

    move-result-object p1

    invoke-virtual {p0, v0, p1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object p0

    const/4 p1, 0x0

    invoke-virtual {p0, p1, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    return p1
.end method
