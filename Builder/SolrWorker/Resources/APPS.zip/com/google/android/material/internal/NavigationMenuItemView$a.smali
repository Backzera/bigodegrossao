.class Lcom/google/android/material/internal/NavigationMenuItemView$a;
.super Lntidisestablish/neumonoul/floccinaucinih/k0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/NavigationMenuItemView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Lcom/google/android/material/internal/NavigationMenuItemView;


# direct methods
.method constructor <init>(Lcom/google/android/material/internal/NavigationMenuItemView;)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/material/internal/NavigationMenuItemView$a;->d:Lcom/google/android/material/internal/NavigationMenuItemView;

    invoke-direct {p0}, Lntidisestablish/neumonoul/floccinaucinih/k0;-><init>()V

    return-void
.end method


# virtual methods
.method public g(Landroid/view/View;Lntidisestablish/neumonoul/floccinaucinih/h1;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Lntidisestablish/neumonoul/floccinaucinih/k0;->g(Landroid/view/View;Lntidisestablish/neumonoul/floccinaucinih/h1;)V

    iget-object p1, p0, Lcom/google/android/material/internal/NavigationMenuItemView$a;->d:Lcom/google/android/material/internal/NavigationMenuItemView;

    iget-boolean p1, p1, Lcom/google/android/material/internal/NavigationMenuItemView;->y:Z

    invoke-virtual {p2, p1}, Lntidisestablish/neumonoul/floccinaucinih/h1;->V(Z)V

    return-void
.end method
