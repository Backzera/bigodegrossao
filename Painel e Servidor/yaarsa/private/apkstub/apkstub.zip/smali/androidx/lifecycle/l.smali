.class public abstract Landroidx/lifecycle/l;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;

.field public static final b:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;

.field public static final c:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Landroidx/lifecycle/l$b;

    .line 2
    .line 3
    invoke-direct {v0}, Landroidx/lifecycle/l$b;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Landroidx/lifecycle/l;->a:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;

    .line 7
    .line 8
    new-instance v0, Landroidx/lifecycle/l$c;

    .line 9
    .line 10
    invoke-direct {v0}, Landroidx/lifecycle/l$c;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, Landroidx/lifecycle/l;->b:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;

    .line 14
    .line 15
    new-instance v0, Landroidx/lifecycle/l$a;

    .line 16
    .line 17
    invoke-direct {v0}, Landroidx/lifecycle/l$a;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v0, Landroidx/lifecycle/l;->c:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;

    .line 21
    .line 22
    return-void
.end method

.method public static final a(Lunityfslma/alfabeta/cosmicplan/wonderland/n40;)V
    .locals 4

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-interface {p0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ar;->f()Landroidx/lifecycle/d;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0}, Landroidx/lifecycle/d;->b()Landroidx/lifecycle/d$b;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget-object v1, Landroidx/lifecycle/d$b;->f:Landroidx/lifecycle/d$b;

    .line 15
    .line 16
    if-eq v0, v1, :cond_1

    .line 17
    .line 18
    sget-object v1, Landroidx/lifecycle/d$b;->g:Landroidx/lifecycle/d$b;

    .line 19
    .line 20
    if-ne v0, v1, :cond_0

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 24
    .line 25
    const-string v0, "Failed requirement."

    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    throw p0

    .line 35
    :cond_1
    :goto_0
    invoke-interface {p0}, Lunityfslma/alfabeta/cosmicplan/wonderland/n40;->b()Landroidx/savedstate/a;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    const-string v1, "androidx.lifecycle.internal.SavedStateHandlesProvider"

    .line 40
    .line 41
    invoke-virtual {v0, v1}, Landroidx/savedstate/a;->c(Ljava/lang/String;)Landroidx/savedstate/a$c;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    if-nez v0, :cond_2

    .line 46
    .line 47
    new-instance v0, Lunityfslma/alfabeta/cosmicplan/wonderland/j40;

    .line 48
    .line 49
    invoke-interface {p0}, Lunityfslma/alfabeta/cosmicplan/wonderland/n40;->b()Landroidx/savedstate/a;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    move-object v3, p0

    .line 54
    check-cast v3, Lunityfslma/alfabeta/cosmicplan/wonderland/se0;

    .line 55
    .line 56
    invoke-direct {v0, v2, v3}, Lunityfslma/alfabeta/cosmicplan/wonderland/j40;-><init>(Landroidx/savedstate/a;Lunityfslma/alfabeta/cosmicplan/wonderland/se0;)V

    .line 57
    .line 58
    .line 59
    invoke-interface {p0}, Lunityfslma/alfabeta/cosmicplan/wonderland/n40;->b()Landroidx/savedstate/a;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    invoke-virtual {v2, v1, v0}, Landroidx/savedstate/a;->h(Ljava/lang/String;Landroidx/savedstate/a$c;)V

    .line 64
    .line 65
    .line 66
    invoke-interface {p0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ar;->f()Landroidx/lifecycle/d;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    new-instance v1, Landroidx/lifecycle/SavedStateHandleAttacher;

    .line 71
    .line 72
    invoke-direct {v1, v0}, Landroidx/lifecycle/SavedStateHandleAttacher;-><init>(Lunityfslma/alfabeta/cosmicplan/wonderland/j40;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0, v1}, Landroidx/lifecycle/d;->a(Lunityfslma/alfabeta/cosmicplan/wonderland/zq;)V

    .line 76
    .line 77
    .line 78
    :cond_2
    return-void
.end method

.method public static final b(Lunityfslma/alfabeta/cosmicplan/wonderland/se0;)Lunityfslma/alfabeta/cosmicplan/wonderland/k40;
    .locals 4

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Lunityfslma/alfabeta/cosmicplan/wonderland/oo;

    .line 7
    .line 8
    invoke-direct {v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/oo;-><init>()V

    .line 9
    .line 10
    .line 11
    sget-object v1, Landroidx/lifecycle/l$d;->f:Landroidx/lifecycle/l$d;

    .line 12
    .line 13
    const-class v2, Lunityfslma/alfabeta/cosmicplan/wonderland/k40;

    .line 14
    .line 15
    invoke-static {v2}, Lunityfslma/alfabeta/cosmicplan/wonderland/m20;->b(Ljava/lang/Class;)Lunityfslma/alfabeta/cosmicplan/wonderland/lq;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    invoke-virtual {v0, v3, v1}, Lunityfslma/alfabeta/cosmicplan/wonderland/oo;->a(Lunityfslma/alfabeta/cosmicplan/wonderland/lq;Lunityfslma/alfabeta/cosmicplan/wonderland/rl;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/oo;->b()Landroidx/lifecycle/o$b;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    new-instance v1, Landroidx/lifecycle/o;

    .line 27
    .line 28
    invoke-direct {v1, p0, v0}, Landroidx/lifecycle/o;-><init>(Lunityfslma/alfabeta/cosmicplan/wonderland/se0;Landroidx/lifecycle/o$b;)V

    .line 29
    .line 30
    .line 31
    const-string p0, "androidx.lifecycle.internal.SavedStateHandlesVM"

    .line 32
    .line 33
    invoke-virtual {v1, p0, v2}, Landroidx/lifecycle/o;->b(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/n;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    check-cast p0, Lunityfslma/alfabeta/cosmicplan/wonderland/k40;

    .line 38
    .line 39
    return-object p0
.end method
