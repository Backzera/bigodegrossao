.class Landroidx/fragment/app/j$a;
.super Lunityfslma/alfabeta/cosmicplan/wonderland/vw;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Landroidx/fragment/app/j;


# direct methods
.method constructor <init>(Landroidx/fragment/app/j;Z)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/fragment/app/j$a;->d:Landroidx/fragment/app/j;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lunityfslma/alfabeta/cosmicplan/wonderland/vw;-><init>(Z)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public d()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/j$a;->d:Landroidx/fragment/app/j;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/fragment/app/j;->p0()V

    .line 4
    .line 5
    .line 6
    return-void
.end method
