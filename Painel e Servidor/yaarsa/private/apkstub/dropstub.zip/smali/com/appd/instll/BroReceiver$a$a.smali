.class Lcom/appd/instll/BroReceiver$a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/appd/instll/BroReceiver$a;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/appd/instll/BroReceiver$a;


# direct methods
.method constructor <init>(Lcom/appd/instll/BroReceiver$a;)V
    .locals 0

    iput-object p1, p0, Lcom/appd/instll/BroReceiver$a$a;->a:Lcom/appd/instll/BroReceiver$a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 12

    iget-object v0, p0, Lcom/appd/instll/BroReceiver$a$a;->a:Lcom/appd/instll/BroReceiver$a;

    iget-object v0, v0, Lcom/appd/instll/BroReceiver$a;->b:Landroid/content/Context;

    sget-object v1, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/k7;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x29

    const/16 v1, 0x1a

    const/high16 v2, 0x800000

    const/high16 v3, 0x10000000

    const/4 v4, 0x3

    const/16 v5, 0x8

    :try_start_0
    new-instance v6, Landroid/content/Intent;

    invoke-direct {v6}, Landroid/content/Intent;-><init>()V

    new-instance v7, Landroid/content/ComponentName;

    sget-object v8, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v10, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v4, [B

    fill-array-data v10, :array_0

    new-array v11, v5, [B

    fill-array-data v11, :array_1

    invoke-static {v10, v11}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v7, v8, v9}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    invoke-virtual {v6, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v6, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    new-array v7, v1, [B

    fill-array-data v7, :array_2

    new-array v8, v5, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    new-array v7, v0, [B

    fill-array-data v7, :array_4

    new-array v8, v5, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    iget-object v7, p0, Lcom/appd/instll/BroReceiver$a$a;->a:Lcom/appd/instll/BroReceiver$a;

    iget-object v7, v7, Lcom/appd/instll/BroReceiver$a;->b:Landroid/content/Context;

    invoke-virtual {v7, v6}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    new-instance v6, Landroid/content/Intent;

    invoke-direct {v6}, Landroid/content/Intent;-><init>()V

    new-instance v7, Landroid/content/ComponentName;

    sget-object v8, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v10, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v4, v4, [B

    fill-array-data v4, :array_6

    new-array v10, v5, [B

    fill-array-data v10, :array_7

    invoke-static {v4, v10}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v7, v8, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    invoke-virtual {v6, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v6, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    new-array v1, v1, [B

    fill-array-data v1, :array_8

    new-array v2, v5, [B

    fill-array-data v2, :array_9

    invoke-static {v1, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v1, v5, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    iget-object v0, p0, Lcom/appd/instll/BroReceiver$a$a;->a:Lcom/appd/instll/BroReceiver$a;

    iget-object v0, v0, Lcom/appd/instll/BroReceiver$a;->b:Landroid/content/Context;

    invoke-virtual {v0, v6}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_0
    return-void

    :array_0
    .array-data 1
        -0x2bt
        -0x14t
        -0x32t
    .end array-data

    :array_1
    .array-data 1
        -0x5t
        -0x53t
        -0x1t
        0x58t
        -0x22t
        -0x75t
        -0x72t
        -0x44t
    .end array-data

    :array_2
    .array-data 1
        -0x5t
        0x3t
        0x1et
        -0x2t
        -0x67t
        -0x47t
        -0x1at
        0x74t
        -0xdt
        0x3t
        0xet
        -0x17t
        -0x68t
        -0x5ct
        -0x54t
        0x3bt
        -0x7t
        0x19t
        0x13t
        -0x1dt
        -0x68t
        -0x2t
        -0x31t
        0x1bt
        -0x2dt
        0x23t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x66t
        0x6dt
        0x7at
        -0x74t
        -0xat
        -0x30t
        -0x7et
        0x5at
    .end array-data

    :array_4
    .array-data 1
        -0x74t
        -0x8t
        -0x70t
        -0x73t
        -0x7ct
        0x4dt
        0x79t
        0x1et
        -0x7ct
        -0x8t
        -0x80t
        -0x66t
        -0x7bt
        0x50t
        0x33t
        0x53t
        -0x74t
        -0x1et
        -0x6ft
        -0x68t
        -0x7ct
        0x56t
        0x64t
        0x1et
        -0x5ft
        -0x2dt
        -0x4bt
        -0x4ft
        -0x57t
        0x65t
        0x5et
        0x7bt
        -0x4et
        -0x26t
        -0x4bt
        -0x56t
        -0x5bt
        0x67t
        0x55t
        0x75t
        -0x41t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x13t
        -0x6at
        -0xct
        -0x1t
        -0x15t
        0x24t
        0x1dt
        0x30t
    .end array-data

    :array_6
    .array-data 1
        -0x40t
        0x1ct
        -0x56t
    .end array-data

    :array_7
    .array-data 1
        -0x12t
        0x5dt
        -0x68t
        0x6t
        -0x4ft
        -0x3ft
        -0x2et
        0x9t
    .end array-data

    :array_8
    .array-data 1
        -0x1bt
        0x17t
        0x3at
        0x44t
        0x17t
        -0xbt
        0x5dt
        0x3at
        -0x13t
        0x17t
        0x2at
        0x53t
        0x16t
        -0x18t
        0x17t
        0x75t
        -0x19t
        0xdt
        0x37t
        0x59t
        0x16t
        -0x4et
        0x74t
        0x55t
        -0x33t
        0x37t
    .end array-data

    nop

    :array_9
    .array-data 1
        -0x7ct
        0x79t
        0x5et
        0x36t
        0x78t
        -0x64t
        0x39t
        0x14t
    .end array-data

    :array_a
    .array-data 1
        0x7at
        0x2ft
        0x45t
        -0x63t
        0x22t
        0x66t
        -0x63t
        0x5et
        0x72t
        0x2ft
        0x55t
        -0x76t
        0x23t
        0x7bt
        -0x29t
        0x13t
        0x7at
        0x35t
        0x44t
        -0x78t
        0x22t
        0x7dt
        -0x80t
        0x5et
        0x57t
        0x4t
        0x60t
        -0x5ft
        0xft
        0x4et
        -0x46t
        0x3bt
        0x44t
        0xdt
        0x60t
        -0x46t
        0x3t
        0x4ct
        -0x4ft
        0x35t
        0x49t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x1bt
        0x41t
        0x21t
        -0x11t
        0x4dt
        0xft
        -0x7t
        0x70t
    .end array-data
.end method
