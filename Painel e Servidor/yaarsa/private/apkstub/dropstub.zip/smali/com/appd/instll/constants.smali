.class public Lcom/appd/instll/constants;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static trid:Ljava/lang/String; = "[T_ID]"


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
