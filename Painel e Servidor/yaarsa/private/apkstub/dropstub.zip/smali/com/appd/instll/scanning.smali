.class public Lcom/appd/instll/scanning;
.super Landroid/app/Service;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static synthetic a()V
    .locals 0

    .line 1
    invoke-static {}, Lcom/appd/instll/scanning;->b()V

    return-void
.end method

.method private static synthetic b()V
    .locals 4

    .line 1
    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x5

    const/16 v2, 0x8

    if-ge v0, v1, :cond_0

    new-array v1, v2, [B

    fill-array-data v1, :array_0

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x11

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v2, v2, [B

    fill-array-data v2, :array_3

    invoke-static {v3, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-wide/16 v1, 0x1f4

    :try_start_0
    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    new-array v0, v2, [B

    fill-array-data v0, :array_4

    new-array v1, v2, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v1, v2, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x57t
        0x4dt
        -0x5t
        0x33t
        0x35t
        0x4et
        0x66t
        -0x15t
    .end array-data

    :array_1
    .array-data 1
        0x24t
        0x2et
        -0x66t
        0x5dt
        0x5bt
        0x27t
        0x8t
        -0x74t
    .end array-data

    :array_2
    .array-data 1
        -0x4dt
        -0x6dt
        -0x7dt
        0x71t
        -0x7bt
        0x37t
        -0xet
        -0x41t
        -0x32t
        -0x22t
        -0x34t
        0x3ft
        -0x7et
        0x2at
        -0x7t
        -0x4bt
        -0x40t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x20t
        -0x10t
        -0x1et
        0x1ft
        -0x15t
        0x5et
        -0x64t
        -0x28t
    .end array-data

    :array_4
    .array-data 1
        -0x62t
        -0x52t
        -0x39t
        -0x3dt
        -0x7ft
        -0x44t
        -0x6et
        0x5ft
    .end array-data

    :array_5
    .array-data 1
        -0x13t
        -0x33t
        -0x5at
        -0x53t
        -0x11t
        -0x2bt
        -0x4t
        0x38t
    .end array-data

    :array_6
    .array-data 1
        0x74t
        0x33t
        -0xct
        0x40t
        0x27t
        -0x53t
        0x78t
        0x21t
        0x57t
        0x3ct
        -0x10t
        0x5at
        0x62t
    .end array-data

    nop

    :array_7
    .array-data 1
        0x27t
        0x50t
        -0x6bt
        0x2et
        0x7t
        -0x32t
        0x17t
        0x4ct
    .end array-data
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 3

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    new-array v2, v0, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 v1, 0x1c

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {v1, v0}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        -0x52t
        0x42t
        0x25t
        0x2ct
        0x2ft
        0x39t
        0x25t
        0x43t
    .end array-data

    :array_1
    .array-data 1
        -0x23t
        0x21t
        0x44t
        0x42t
        0x41t
        0x50t
        0x4bt
        0x24t
    .end array-data

    :array_2
    .array-data 1
        0x6at
        0x28t
        -0x70t
        0x54t
        -0xdt
        -0x3ct
        0x7ft
        0x57t
        0x19t
        0x18t
        -0x6ct
        0x48t
        -0x15t
        -0x3ct
        0x72t
        0x55t
        0x19t
        0x22t
        -0x61t
        0x53t
        -0x17t
        -0x3ct
        0x70t
        0x5ct
        0x50t
        0x31t
        -0x6ct
        0x5et
    .end array-data

    :array_3
    .array-data 1
        0x39t
        0x4bt
        -0xft
        0x3at
        -0x63t
        -0x53t
        0x11t
        0x30t
    .end array-data
.end method

.method public onDestroy()V
    .locals 3

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    new-array v2, v0, [B

    fill-array-data v2, :array_1

    invoke-static {v1, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 v1, 0x1b

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {v1, v0}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void

    :array_0
    .array-data 1
        -0x38t
        -0x3ct
        0x28t
        -0x4t
        -0x5bt
        0x17t
        0xdt
        0x57t
    .end array-data

    :array_1
    .array-data 1
        -0x45t
        -0x59t
        0x49t
        -0x6et
        -0x35t
        0x7et
        0x63t
        0x30t
    .end array-data

    :array_2
    .array-data 1
        0x1t
        -0x2dt
        0x63t
        -0x55t
        0x4t
        0x64t
        -0x13t
        0x59t
        0x72t
        -0x1dt
        0x67t
        -0x49t
        0x1ct
        0x64t
        -0x20t
        0x5bt
        0x72t
        -0x3ct
        0x67t
        -0x49t
        0x7t
        0x64t
        -0x13t
        0x5ft
        0x26t
        -0x2bt
        0x66t
    .end array-data

    :array_3
    .array-data 1
        0x52t
        -0x50t
        0x2t
        -0x3bt
        0x6at
        0xdt
        -0x7dt
        0x3et
    .end array-data
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    const/16 p1, 0x8

    new-array p2, p1, [B

    fill-array-data p2, :array_0

    new-array p3, p1, [B

    fill-array-data p3, :array_1

    invoke-static {p2, p3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 p2, 0x10

    new-array p2, p2, [B

    fill-array-data p2, :array_2

    new-array p1, p1, [B

    fill-array-data p1, :array_3

    invoke-static {p2, p1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    new-instance p1, Ljava/lang/Thread;

    new-instance p2, Lconfimanag/scanutil/alfagamma/transper/j7;

    invoke-direct {p2}, Lconfimanag/scanutil/alfagamma/transper/j7;-><init>()V

    invoke-direct {p1, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    const/4 p1, 0x2

    return p1

    nop

    :array_0
    .array-data 1
        0x4bt
        0x7bt
        0x5dt
        0xft
        0x65t
        -0x6et
        -0x4t
        -0x2ct
    .end array-data

    :array_1
    .array-data 1
        0x38t
        0x18t
        0x3ct
        0x61t
        0xbt
        -0x5t
        -0x6et
        -0x4dt
    .end array-data

    :array_2
    .array-data 1
        0x3bt
        -0x5at
        0x14t
        0x0t
        0x14t
        0x3at
        0x36t
        -0x44t
        0x48t
        -0x4at
        0x1t
        0xft
        0x8t
        0x27t
        0x3dt
        -0x41t
    .end array-data

    :array_3
    .array-data 1
        0x68t
        -0x3bt
        0x75t
        0x6et
        0x7at
        0x53t
        0x58t
        -0x25t
    .end array-data
.end method
