.class public final synthetic Lcom/appd/instll/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/appd/instll/splash$b;


# direct methods
.method public synthetic constructor <init>(Lcom/appd/instll/splash$b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/appd/instll/b;->a:Lcom/appd/instll/splash$b;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/appd/instll/b;->a:Lcom/appd/instll/splash$b;

    invoke-static {v0}, Lcom/appd/instll/splash$b;->b(Lcom/appd/instll/splash$b;)V

    return-void
.end method
