.class public abstract Lconfimanag/scanutil/alfagamma/transper/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lconfimanag/scanutil/alfagamma/transper/a;",
            ">;"
        }
    .end annotation
.end field

.field public static final b:Lconfimanag/scanutil/alfagamma/transper/a;


# instance fields
.field private final a:Landroid/os/Parcelable;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/a$a;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/a$a;-><init>()V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/a;->b:Lconfimanag/scanutil/alfagamma/transper/a;

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/a$b;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/a$b;-><init>()V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/a;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a;->a:Landroid/os/Parcelable;

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/a;->b:Lconfimanag/scanutil/alfagamma/transper/a;

    :goto_0
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a;->a:Landroid/os/Parcelable;

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcelable;)V
    .locals 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_1

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/a;->b:Lconfimanag/scanutil/alfagamma/transper/a;

    if-eq p1, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a;->a:Landroid/os/Parcelable;

    return-void

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "superState must not be null"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method synthetic constructor <init>(Lconfimanag/scanutil/alfagamma/transper/a$a;)V
    .locals 0

    .line 4
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Landroid/os/Parcelable;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a;->a:Landroid/os/Parcelable;

    return-object v0
.end method

.method public describeContents()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a;->a:Landroid/os/Parcelable;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    return-void
.end method
