.class public Lconfimanag/scanutil/alfagamma/transper/w0;
.super Landroidx/constraintlayout/widget/a;
.source "SourceFile"


# instance fields
.field private h:I

.field private i:I

.field private j:Lconfimanag/scanutil/alfagamma/transper/x0;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Landroidx/constraintlayout/widget/a;-><init>(Landroid/content/Context;)V

    const/16 p1, 0x8

    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method protected b(Landroid/util/AttributeSet;)V
    .locals 6

    .line 1
    invoke-super {p0, p1}, Landroidx/constraintlayout/widget/a;->b(Landroid/util/AttributeSet;)V

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/x0;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/x0;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->j:Lconfimanag/scanutil/alfagamma/transper/x0;

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/q4;->a:[I

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_2

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v3

    sget v4, Lconfimanag/scanutil/alfagamma/transper/q4;->h:I

    if-ne v3, v4, :cond_0

    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    invoke-virtual {p0, v3}, Lconfimanag/scanutil/alfagamma/transper/w0;->setType(I)V

    goto :goto_1

    :cond_0
    sget v4, Lconfimanag/scanutil/alfagamma/transper/q4;->g:I

    if-ne v3, v4, :cond_1

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->j:Lconfimanag/scanutil/alfagamma/transper/x0;

    const/4 v5, 0x1

    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v3

    invoke-virtual {v4, v3}, Lconfimanag/scanutil/alfagamma/transper/x0;->K0(Z)V

    :cond_1
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->j:Lconfimanag/scanutil/alfagamma/transper/x0;

    iput-object p1, p0, Landroidx/constraintlayout/widget/a;->e:Lconfimanag/scanutil/alfagamma/transper/h2;

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/a;->f()V

    return-void
.end method

.method public getType()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->h:I

    return v0
.end method

.method public setAllowsGoneWidget(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->j:Lconfimanag/scanutil/alfagamma/transper/x0;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/x0;->K0(Z)V

    return-void
.end method

.method public setType(I)V
    .locals 4

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->h:I

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->i:I

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Configuration;->getLayoutDirection()I

    move-result p1

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-ne v3, p1, :cond_1

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->h:I

    if-ne p1, v2, :cond_0

    :goto_0
    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->i:I

    goto :goto_2

    :cond_0
    if-ne p1, v1, :cond_3

    :goto_1
    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->i:I

    goto :goto_2

    :cond_1
    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->h:I

    if-ne p1, v2, :cond_2

    goto :goto_1

    :cond_2
    if-ne p1, v1, :cond_3

    goto :goto_0

    :cond_3
    :goto_2
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->j:Lconfimanag/scanutil/alfagamma/transper/x0;

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/w0;->i:I

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/x0;->L0(I)V

    return-void
.end method
