.class public interface abstract Lconfimanag/scanutil/alfagamma/transper/u5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/MenuItem;


# virtual methods
.method public abstract setAlphabeticShortcut(CI)Landroid/view/MenuItem;
.end method

.method public abstract setContentDescription(Ljava/lang/CharSequence;)Lconfimanag/scanutil/alfagamma/transper/u5;
.end method

.method public abstract setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
.end method

.method public abstract setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
.end method

.method public abstract setNumericShortcut(CI)Landroid/view/MenuItem;
.end method

.method public abstract setTooltipText(Ljava/lang/CharSequence;)Lconfimanag/scanutil/alfagamma/transper/u5;
.end method
