.class public abstract Lconfimanag/scanutil/alfagamma/transper/o6;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Lconfimanag/scanutil/alfagamma/transper/t6;

.field private static final b:Lconfimanag/scanutil/alfagamma/transper/r2;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/s6;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/s6;-><init>()V

    :goto_0
    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/o6;->a:Lconfimanag/scanutil/alfagamma/transper/t6;

    goto :goto_1

    :cond_0
    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/r6;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/r6;-><init>()V

    goto :goto_0

    :cond_1
    const/16 v1, 0x18

    if-lt v0, v1, :cond_2

    invoke-static {}, Lconfimanag/scanutil/alfagamma/transper/q6;->j()Z

    move-result v0

    if-eqz v0, :cond_2

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/q6;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/q6;-><init>()V

    goto :goto_0

    :cond_2
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/p6;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/p6;-><init>()V

    goto :goto_0

    :goto_1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/r2;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/r2;-><init>(I)V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/o6;->b:Lconfimanag/scanutil/alfagamma/transper/r2;

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/os/CancellationSignal;[Lconfimanag/scanutil/alfagamma/transper/a2$f;I)Landroid/graphics/Typeface;
    .locals 1

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/o6;->a:Lconfimanag/scanutil/alfagamma/transper/t6;

    invoke-virtual {v0, p0, p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/t6;->b(Landroid/content/Context;Landroid/os/CancellationSignal;[Lconfimanag/scanutil/alfagamma/transper/a2$f;I)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/z1$a;Landroid/content/res/Resources;IILconfimanag/scanutil/alfagamma/transper/y4$a;Landroid/os/Handler;Z)Landroid/graphics/Typeface;
    .locals 7

    .line 1
    instance-of v1, p1, Lconfimanag/scanutil/alfagamma/transper/z1$d;

    if-eqz v1, :cond_3

    move-object v0, p1

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/z1$d;

    const/4 v1, 0x0

    const/4 v4, 0x1

    if-eqz p7, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/z1$d;->a()I

    move-result v5

    if-nez v5, :cond_0

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    if-nez p5, :cond_0

    :goto_0
    if-eqz p7, :cond_2

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/z1$d;->c()I

    move-result v1

    move v5, v1

    goto :goto_1

    :cond_2
    const/4 v1, -0x1

    const/4 v5, -0x1

    :goto_1
    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/z1$d;->b()Lconfimanag/scanutil/alfagamma/transper/y1;

    move-result-object v1

    move-object v0, p0

    move-object v2, p5

    move-object v3, p6

    move v6, p4

    invoke-static/range {v0 .. v6}, Lconfimanag/scanutil/alfagamma/transper/a2;->g(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;Lconfimanag/scanutil/alfagamma/transper/y4$a;Landroid/os/Handler;ZII)Landroid/graphics/Typeface;

    move-result-object v0

    goto :goto_2

    :cond_3
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/o6;->a:Lconfimanag/scanutil/alfagamma/transper/t6;

    move-object v0, p1

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/z1$b;

    invoke-virtual {v1, p0, v0, p2, p4}, Lconfimanag/scanutil/alfagamma/transper/t6;->a(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/z1$b;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;

    move-result-object v0

    if-eqz p5, :cond_5

    if-eqz v0, :cond_4

    invoke-virtual {p5, v0, p6}, Lconfimanag/scanutil/alfagamma/transper/y4$a;->b(Landroid/graphics/Typeface;Landroid/os/Handler;)V

    goto :goto_2

    :cond_4
    const/4 v1, -0x3

    invoke-virtual {p5, v1, p6}, Lconfimanag/scanutil/alfagamma/transper/y4$a;->a(ILandroid/os/Handler;)V

    :cond_5
    :goto_2
    if-eqz v0, :cond_6

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/o6;->b:Lconfimanag/scanutil/alfagamma/transper/r2;

    invoke-static {p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/o6;->d(Landroid/content/res/Resources;II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2, v0}, Lconfimanag/scanutil/alfagamma/transper/r2;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    return-object v0
.end method

.method public static c(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;
    .locals 6

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/o6;->a:Lconfimanag/scanutil/alfagamma/transper/t6;

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move v5, p4

    invoke-virtual/range {v0 .. v5}, Lconfimanag/scanutil/alfagamma/transper/t6;->d(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-static {p1, p2, p4}, Lconfimanag/scanutil/alfagamma/transper/o6;->d(Landroid/content/res/Resources;II)Ljava/lang/String;

    move-result-object p1

    sget-object p2, Lconfimanag/scanutil/alfagamma/transper/o6;->b:Lconfimanag/scanutil/alfagamma/transper/r2;

    invoke-virtual {p2, p1, p0}, Lconfimanag/scanutil/alfagamma/transper/r2;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-object p0
.end method

.method private static d(Landroid/content/res/Resources;II)Ljava/lang/String;
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getResourcePackageName(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "-"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static e(Landroid/content/res/Resources;II)Landroid/graphics/Typeface;
    .locals 1

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/o6;->b:Lconfimanag/scanutil/alfagamma/transper/r2;

    invoke-static {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/o6;->d(Landroid/content/res/Resources;II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Lconfimanag/scanutil/alfagamma/transper/r2;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Typeface;

    return-object p0
.end method
