.class public Lconfimanag/scanutil/alfagamma/transper/l;
.super Lconfimanag/scanutil/alfagamma/transper/o5;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/l$f;,
        Lconfimanag/scanutil/alfagamma/transper/l$c;,
        Lconfimanag/scanutil/alfagamma/transper/l$d;,
        Lconfimanag/scanutil/alfagamma/transper/l$e;,
        Lconfimanag/scanutil/alfagamma/transper/l$b;,
        Lconfimanag/scanutil/alfagamma/transper/l$g;
    }
.end annotation


# instance fields
.field private q:Lconfimanag/scanutil/alfagamma/transper/l$c;

.field private r:Lconfimanag/scanutil/alfagamma/transper/l$g;

.field private s:I

.field private t:I

.field private u:Z


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, v0, v0}, Lconfimanag/scanutil/alfagamma/transper/l;-><init>(Lconfimanag/scanutil/alfagamma/transper/l$c;Landroid/content/res/Resources;)V

    return-void
.end method

.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/l$c;Landroid/content/res/Resources;)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/o5;-><init>(Lconfimanag/scanutil/alfagamma/transper/o5$a;)V

    const/4 v0, -0x1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->s:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->t:I

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/l$c;

    invoke-direct {v0, p1, p0, p2}, Lconfimanag/scanutil/alfagamma/transper/l$c;-><init>(Lconfimanag/scanutil/alfagamma/transper/l$c;Lconfimanag/scanutil/alfagamma/transper/l;Landroid/content/res/Resources;)V

    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/l;->h(Lconfimanag/scanutil/alfagamma/transper/s1$c;)V

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/l;->onStateChange([I)Z

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/l;->jumpToCurrentState()V

    return-void
.end method

.method public static l(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Lconfimanag/scanutil/alfagamma/transper/l;
    .locals 8

    .line 1
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "animated-selector"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/l;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/l;-><init>()V

    move-object v2, v0

    move-object v3, p0

    move-object v4, p1

    move-object v5, p2

    move-object v6, p3

    move-object v7, p4

    invoke-virtual/range {v2 .. v7}, Lconfimanag/scanutil/alfagamma/transper/l;->m(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    return-object v0

    :cond_0
    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ": invalid animated-selector tag "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private n(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 5

    .line 1
    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v0

    const/4 v1, 0x1

    add-int/2addr v0, v1

    :cond_0
    :goto_0
    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v2

    if-eq v2, v1, :cond_5

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v3

    if-ge v3, v0, :cond_1

    const/4 v4, 0x3

    if-eq v2, v4, :cond_5

    :cond_1
    const/4 v4, 0x2

    if-eq v2, v4, :cond_2

    goto :goto_0

    :cond_2
    if-le v3, v0, :cond_3

    goto :goto_0

    :cond_3
    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "item"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-direct/range {p0 .. p5}, Lconfimanag/scanutil/alfagamma/transper/l;->p(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)I

    goto :goto_0

    :cond_4
    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "transition"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-direct/range {p0 .. p5}, Lconfimanag/scanutil/alfagamma/transper/l;->q(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)I

    goto :goto_0

    :cond_5
    return-void
.end method

.method private o()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/l;->onStateChange([I)Z

    return-void
.end method

.method private p(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)I
    .locals 4

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/s4;->L:[I

    invoke-static {p2, p5, p4, v0}, Lconfimanag/scanutil/alfagamma/transper/n6;->i(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->M:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    sget v2, Lconfimanag/scanutil/alfagamma/transper/s4;->N:I

    const/4 v3, -0x1

    invoke-virtual {v0, v2, v3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    if-lez v2, :cond_0

    invoke-static {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/y;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    invoke-virtual {p0, p4}, Lconfimanag/scanutil/alfagamma/transper/o5;->j(Landroid/util/AttributeSet;)[I

    move-result-object v0

    const-string v2, ": <item> tag requires a \'drawable\' attribute or child tag defining a drawable"

    if-nez p1, :cond_4

    :goto_1
    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result p1

    const/4 v3, 0x4

    if-ne p1, v3, :cond_1

    goto :goto_1

    :cond_1
    const/4 v3, 0x2

    if-ne p1, v3, :cond_3

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object p1

    const-string v3, "vector"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-static {p2, p3, p4, p5}, Lconfimanag/scanutil/alfagamma/transper/w6;->c(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Lconfimanag/scanutil/alfagamma/transper/w6;

    move-result-object p1

    goto :goto_2

    :cond_2
    invoke-static {p2, p3, p4, p5}, Landroid/graphics/drawable/Drawable;->createFromXmlInner(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_2

    :cond_3
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    :goto_2
    if-eqz p1, :cond_5

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/l;->q:Lconfimanag/scanutil/alfagamma/transper/l$c;

    invoke-virtual {p2, v0, p1, v1}, Lconfimanag/scanutil/alfagamma/transper/l$c;->B([ILandroid/graphics/drawable/Drawable;I)I

    move-result p1

    return p1

    :cond_5
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private q(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)I
    .locals 7

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/s4;->O:[I

    invoke-static {p2, p5, p4, v0}, Lconfimanag/scanutil/alfagamma/transper/n6;->i(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->R:I

    const/4 v2, -0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    sget v3, Lconfimanag/scanutil/alfagamma/transper/s4;->Q:I

    invoke-virtual {v0, v3, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v3

    sget v4, Lconfimanag/scanutil/alfagamma/transper/s4;->P:I

    invoke-virtual {v0, v4, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    if-lez v4, :cond_0

    invoke-static {p1, v4}, Lconfimanag/scanutil/alfagamma/transper/y;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    :goto_0
    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->S:I

    const/4 v6, 0x0

    invoke-virtual {v0, v5, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v5

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const-string v0, ": <transition> tag requires a \'drawable\' attribute or child tag defining a drawable"

    if-nez v4, :cond_4

    :goto_1
    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v4

    const/4 v6, 0x4

    if-ne v4, v6, :cond_1

    goto :goto_1

    :cond_1
    const/4 v6, 0x2

    if-ne v4, v6, :cond_3

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v4

    const-string v6, "animated-vector"

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-static {p1, p2, p3, p4, p5}, Lconfimanag/scanutil/alfagamma/transper/m;->a(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Lconfimanag/scanutil/alfagamma/transper/m;

    move-result-object v4

    goto :goto_2

    :cond_2
    invoke-static {p2, p3, p4, p5}, Landroid/graphics/drawable/Drawable;->createFromXmlInner(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    goto :goto_2

    :cond_3
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    :goto_2
    if-eqz v4, :cond_6

    if-eq v1, v2, :cond_5

    if-eq v3, v2, :cond_5

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l;->q:Lconfimanag/scanutil/alfagamma/transper/l$c;

    invoke-virtual {p1, v1, v3, v4, v5}, Lconfimanag/scanutil/alfagamma/transper/l$c;->C(IILandroid/graphics/drawable/Drawable;Z)I

    move-result p1

    return p1

    :cond_5
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p3, ": <transition> tag requires \'fromId\' & \'toId\' attributes"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_6
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private r(I)Z
    .locals 9

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->r:Lconfimanag/scanutil/alfagamma/transper/l$g;

    const/4 v1, 0x1

    if-eqz v0, :cond_2

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/l;->s:I

    if-ne p1, v2, :cond_0

    return v1

    :cond_0
    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/l;->t:I

    if-ne p1, v2, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/l$g;->a()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/l$g;->b()V

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->t:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->s:I

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/l;->t:I

    return v1

    :cond_1
    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/l;->s:I

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/l$g;->d()V

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->c()I

    move-result v2

    :goto_0
    const/4 v0, 0x0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->r:Lconfimanag/scanutil/alfagamma/transper/l$g;

    const/4 v0, -0x1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->t:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->s:I

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->q:Lconfimanag/scanutil/alfagamma/transper/l$c;

    invoke-virtual {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/l$c;->E(I)I

    move-result v3

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/l$c;->E(I)I

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_7

    if-nez v3, :cond_3

    goto :goto_2

    :cond_3
    invoke-virtual {v0, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/l$c;->G(II)I

    move-result v6

    if-gez v6, :cond_4

    return v5

    :cond_4
    invoke-virtual {v0, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/l$c;->I(II)Z

    move-result v7

    invoke-virtual {p0, v6}, Lconfimanag/scanutil/alfagamma/transper/s1;->g(I)Z

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/l;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v6

    instance-of v8, v6, Landroid/graphics/drawable/AnimationDrawable;

    if-eqz v8, :cond_5

    invoke-virtual {v0, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/l$c;->H(II)Z

    move-result v0

    new-instance v3, Lconfimanag/scanutil/alfagamma/transper/l$e;

    check-cast v6, Landroid/graphics/drawable/AnimationDrawable;

    invoke-direct {v3, v6, v0, v7}, Lconfimanag/scanutil/alfagamma/transper/l$e;-><init>(Landroid/graphics/drawable/AnimationDrawable;ZZ)V

    goto :goto_1

    :cond_5
    instance-of v0, v6, Lconfimanag/scanutil/alfagamma/transper/m;

    if-eqz v0, :cond_6

    new-instance v3, Lconfimanag/scanutil/alfagamma/transper/l$d;

    check-cast v6, Lconfimanag/scanutil/alfagamma/transper/m;

    invoke-direct {v3, v6}, Lconfimanag/scanutil/alfagamma/transper/l$d;-><init>(Lconfimanag/scanutil/alfagamma/transper/m;)V

    goto :goto_1

    :cond_6
    instance-of v0, v6, Landroid/graphics/drawable/Animatable;

    if-eqz v0, :cond_7

    new-instance v3, Lconfimanag/scanutil/alfagamma/transper/l$b;

    check-cast v6, Landroid/graphics/drawable/Animatable;

    invoke-direct {v3, v6}, Lconfimanag/scanutil/alfagamma/transper/l$b;-><init>(Landroid/graphics/drawable/Animatable;)V

    :goto_1
    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/l$g;->c()V

    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/l;->r:Lconfimanag/scanutil/alfagamma/transper/l$g;

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/l;->t:I

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/l;->s:I

    return v1

    :cond_7
    :goto_2
    return v5
.end method

.method private s(Landroid/content/res/TypedArray;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->q:Lconfimanag/scanutil/alfagamma/transper/l$c;

    iget v1, v0, Lconfimanag/scanutil/alfagamma/transper/s1$c;->d:I

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v2

    or-int/2addr v1, v2

    iput v1, v0, Lconfimanag/scanutil/alfagamma/transper/s1$c;->d:I

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->H:I

    iget-boolean v2, v0, Lconfimanag/scanutil/alfagamma/transper/s1$c;->i:Z

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/s1$c;->x(Z)V

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->I:I

    iget-boolean v2, v0, Lconfimanag/scanutil/alfagamma/transper/s1$c;->l:Z

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/s1$c;->t(Z)V

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->J:I

    iget v2, v0, Lconfimanag/scanutil/alfagamma/transper/s1$c;->A:I

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/s1$c;->u(I)V

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->K:I

    iget v2, v0, Lconfimanag/scanutil/alfagamma/transper/s1$c;->B:I

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/s1$c;->v(I)V

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->F:I

    iget-boolean v0, v0, Lconfimanag/scanutil/alfagamma/transper/s1$c;->x:Z

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/l;->setDither(Z)V

    return-void
.end method


# virtual methods
.method public bridge synthetic applyTheme(Landroid/content/res/Resources$Theme;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/o5;->applyTheme(Landroid/content/res/Resources$Theme;)V

    return-void
.end method

.method bridge synthetic b()Lconfimanag/scanutil/alfagamma/transper/s1$c;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/l;->k()Lconfimanag/scanutil/alfagamma/transper/l$c;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic canApplyTheme()Z
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->canApplyTheme()Z

    move-result v0

    return v0
.end method

.method public bridge synthetic draw(Landroid/graphics/Canvas;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->draw(Landroid/graphics/Canvas;)V

    return-void
.end method

.method public bridge synthetic getAlpha()I
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->getAlpha()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getChangingConfigurations()I
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->getChangingConfigurations()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getCurrent()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic getHotspotBounds(Landroid/graphics/Rect;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->getHotspotBounds(Landroid/graphics/Rect;)V

    return-void
.end method

.method public bridge synthetic getIntrinsicHeight()I
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->getIntrinsicHeight()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getIntrinsicWidth()I
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->getIntrinsicWidth()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getMinimumHeight()I
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->getMinimumHeight()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getMinimumWidth()I
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->getMinimumWidth()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getOpacity()I
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->getOpacity()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getOutline(Landroid/graphics/Outline;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->getOutline(Landroid/graphics/Outline;)V

    return-void
.end method

.method public bridge synthetic getPadding(Landroid/graphics/Rect;)Z
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->getPadding(Landroid/graphics/Rect;)Z

    move-result p1

    return p1
.end method

.method protected h(Lconfimanag/scanutil/alfagamma/transper/s1$c;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/o5;->h(Lconfimanag/scanutil/alfagamma/transper/s1$c;)V

    instance-of v0, p1, Lconfimanag/scanutil/alfagamma/transper/l$c;

    if-eqz v0, :cond_0

    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/l$c;

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l;->q:Lconfimanag/scanutil/alfagamma/transper/l$c;

    :cond_0
    return-void
.end method

.method public bridge synthetic invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public bridge synthetic isAutoMirrored()Z
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->isAutoMirrored()Z

    move-result v0

    return v0
.end method

.method public isStateful()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    return v0
.end method

.method public jumpToCurrentState()V
    .locals 1

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->jumpToCurrentState()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->r:Lconfimanag/scanutil/alfagamma/transper/l$g;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/l$g;->d()V

    const/4 v0, 0x0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->r:Lconfimanag/scanutil/alfagamma/transper/l$g;

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->s:I

    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/s1;->g(I)Z

    const/4 v0, -0x1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->s:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->t:I

    :cond_0
    return-void
.end method

.method k()Lconfimanag/scanutil/alfagamma/transper/l$c;
    .locals 3

    .line 1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/l$c;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/l;->q:Lconfimanag/scanutil/alfagamma/transper/l$c;

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2}, Lconfimanag/scanutil/alfagamma/transper/l$c;-><init>(Lconfimanag/scanutil/alfagamma/transper/l$c;Lconfimanag/scanutil/alfagamma/transper/l;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method public m(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 3

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/s4;->E:[I

    invoke-static {p2, p5, p4, v0}, Lconfimanag/scanutil/alfagamma/transper/n6;->i(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->G:I

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    invoke-virtual {p0, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/l;->setVisible(ZZ)Z

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/l;->s(Landroid/content/res/TypedArray;)V

    invoke-virtual {p0, p2}, Lconfimanag/scanutil/alfagamma/transper/s1;->i(Landroid/content/res/Resources;)V

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    invoke-direct/range {p0 .. p5}, Lconfimanag/scanutil/alfagamma/transper/l;->n(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/l;->o()V

    return-void
.end method

.method public mutate()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->u:Z

    if-nez v0, :cond_0

    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/o5;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-ne v0, p0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->q:Lconfimanag/scanutil/alfagamma/transper/l$c;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/l$c;->r()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->u:Z

    :cond_0
    return-object p0
.end method

.method public bridge synthetic onLayoutDirectionChanged(I)Z
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->onLayoutDirectionChanged(I)Z

    move-result p1

    return p1
.end method

.method protected onStateChange([I)Z
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l;->q:Lconfimanag/scanutil/alfagamma/transper/l$c;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/l$c;->F([I)I

    move-result v0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/s1;->c()I

    move-result v1

    if-eq v0, v1, :cond_1

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/l;->r(I)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/s1;->g(I)Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/l;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    or-int/2addr v0, p1

    :cond_2
    return v0
.end method

.method public bridge synthetic scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/s1;->scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V

    return-void
.end method

.method public bridge synthetic setAlpha(I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->setAlpha(I)V

    return-void
.end method

.method public bridge synthetic setAutoMirrored(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->setAutoMirrored(Z)V

    return-void
.end method

.method public bridge synthetic setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->setColorFilter(Landroid/graphics/ColorFilter;)V

    return-void
.end method

.method public bridge synthetic setDither(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->setDither(Z)V

    return-void
.end method

.method public bridge synthetic setHotspot(FF)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/s1;->setHotspot(FF)V

    return-void
.end method

.method public bridge synthetic setHotspotBounds(IIII)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/s1;->setHotspotBounds(IIII)V

    return-void
.end method

.method public bridge synthetic setTintList(Landroid/content/res/ColorStateList;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->setTintList(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public bridge synthetic setTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s1;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    return-void
.end method

.method public setVisible(ZZ)Z
    .locals 2

    .line 1
    invoke-super {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/s1;->setVisible(ZZ)Z

    move-result v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/l;->r:Lconfimanag/scanutil/alfagamma/transper/l$g;

    if-eqz v1, :cond_2

    if-nez v0, :cond_0

    if-eqz p2, :cond_2

    :cond_0
    if-eqz p1, :cond_1

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/l$g;->c()V

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/l;->jumpToCurrentState()V

    :cond_2
    :goto_0
    return v0
.end method

.method public bridge synthetic unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/s1;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V

    return-void
.end method
