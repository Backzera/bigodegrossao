.class public abstract Lconfimanag/scanutil/alfagamma/transper/i4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:I = 0x7f040014

.field public static b:I = 0x7f040015

.field public static c:I = 0x7f040016

.field public static d:I = 0x7f040017

.field public static e:I = 0x7f040018

.field public static f:I = 0x7f040019
