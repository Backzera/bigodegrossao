.class Lconfimanag/scanutil/alfagamma/transper/l1$b;
.super Landroid/database/DataSetObserver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/l1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/l1;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/l1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l1$b;->a:Lconfimanag/scanutil/alfagamma/transper/l1;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    return-void
.end method


# virtual methods
.method public onChanged()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l1$b;->a:Lconfimanag/scanutil/alfagamma/transper/l1;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lconfimanag/scanutil/alfagamma/transper/l1;->b:Z

    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    return-void
.end method

.method public onInvalidated()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l1$b;->a:Lconfimanag/scanutil/alfagamma/transper/l1;

    const/4 v1, 0x0

    iput-boolean v1, v0, Lconfimanag/scanutil/alfagamma/transper/l1;->b:Z

    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetInvalidated()V

    return-void
.end method
