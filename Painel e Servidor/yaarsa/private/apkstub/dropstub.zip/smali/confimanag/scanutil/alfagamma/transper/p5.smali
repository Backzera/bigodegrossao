.class public abstract Lconfimanag/scanutil/alfagamma/transper/p5;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Lconfimanag/scanutil/alfagamma/transper/q5;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/q5;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/q5;-><init>()V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/p5;->a:Lconfimanag/scanutil/alfagamma/transper/q5;

    return-void
.end method

.method public static a([B[B)Ljava/lang/String;
    .locals 1

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/p5;->a:Lconfimanag/scanutil/alfagamma/transper/q5;

    invoke-virtual {v0, p0, p1}, Lconfimanag/scanutil/alfagamma/transper/q5;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
