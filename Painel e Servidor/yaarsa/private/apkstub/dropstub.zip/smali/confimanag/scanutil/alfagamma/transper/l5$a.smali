.class Lconfimanag/scanutil/alfagamma/transper/l5$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/l5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field private a:Lconfimanag/scanutil/alfagamma/transper/f1;

.field private b:Lconfimanag/scanutil/alfagamma/transper/f1;

.field private c:I

.field private d:Lconfimanag/scanutil/alfagamma/transper/f1$c;

.field private e:I


# direct methods
.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/f1;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->a:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->b:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->c:I

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->h()Lconfimanag/scanutil/alfagamma/transper/f1$c;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->d:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->c()I

    move-result p1

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->e:I

    return-void
.end method


# virtual methods
.method public a(Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->a:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->j()Lconfimanag/scanutil/alfagamma/transper/f1$d;

    move-result-object v0

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object p1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->b:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->c:I

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->d:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->e:I

    invoke-virtual {p1, v0, v1, v2, v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->b(Lconfimanag/scanutil/alfagamma/transper/f1;ILconfimanag/scanutil/alfagamma/transper/f1$c;I)Z

    return-void
.end method

.method public b(Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->a:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->j()Lconfimanag/scanutil/alfagamma/transper/f1$d;

    move-result-object v0

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object p1

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->a:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object p1

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->b:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->a:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result p1

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->c:I

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->a:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->h()Lconfimanag/scanutil/alfagamma/transper/f1$c;

    move-result-object p1

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->d:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->a:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->c()I

    move-result p1

    :goto_0
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->e:I

    goto :goto_1

    :cond_0
    const/4 p1, 0x0

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->b:Lconfimanag/scanutil/alfagamma/transper/f1;

    const/4 p1, 0x0

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->c:I

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/f1$c;->b:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5$a;->d:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    goto :goto_0

    :goto_1
    return-void
.end method
