.class public Lconfimanag/scanutil/alfagamma/transper/i1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/util/List;

.field b:I

.field c:I

.field public d:Z

.field public final e:[I

.field f:Ljava/util/List;

.field g:Ljava/util/List;

.field h:Ljava/util/HashSet;

.field i:Ljava/util/HashSet;

.field j:Ljava/util/List;

.field k:Ljava/util/List;


# direct methods
.method constructor <init>(Ljava/util/List;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->b:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->c:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->d:Z

    filled-new-array {v0, v0}, [I

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->e:[I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->f:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->g:Ljava/util/List;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->h:Ljava/util/HashSet;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->i:Ljava/util/HashSet;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->j:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->k:Ljava/util/List;

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->a:Ljava/util/List;

    return-void
.end method

.method constructor <init>(Ljava/util/List;Z)V
    .locals 2

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->b:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->c:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->d:Z

    filled-new-array {v0, v0}, [I

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->e:[I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->f:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->g:Ljava/util/List;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->h:Ljava/util/HashSet;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->i:Ljava/util/HashSet;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->j:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->k:Ljava/util/List;

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->a:Ljava/util/List;

    iput-boolean p2, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->d:Z

    return-void
.end method

.method private e(Ljava/util/ArrayList;Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 5

    .line 1
    iget-boolean v0, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->k0:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v0, 0x1

    iput-boolean v0, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->k0:Z

    invoke-virtual {p2}, Lconfimanag/scanutil/alfagamma/transper/g1;->L()Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    :cond_1
    instance-of v0, p2, Lconfimanag/scanutil/alfagamma/transper/h2;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    move-object v0, p2

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/h2;

    iget v2, v0, Lconfimanag/scanutil/alfagamma/transper/h2;->w0:I

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_2

    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/h2;->v0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    aget-object v4, v4, v3

    invoke-direct {p0, p1, v4}, Lconfimanag/scanutil/alfagamma/transper/i1;->e(Ljava/util/ArrayList;Lconfimanag/scanutil/alfagamma/transper/g1;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    iget-object v0, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    array-length v0, v0

    :goto_1
    if-ge v1, v0, :cond_4

    iget-object v2, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v2, v2, v1

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v2, :cond_3

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-virtual {p2}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v3

    if-eq v2, v3, :cond_3

    invoke-direct {p0, p1, v2}, Lconfimanag/scanutil/alfagamma/transper/i1;->e(Ljava/util/ArrayList;Lconfimanag/scanutil/alfagamma/transper/g1;)V

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_4
    return-void
.end method

.method private f(Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 6

    .line 1
    iget-boolean v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->i0:Z

    if-eqz v0, :cond_f

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->L()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    :goto_0
    if-eqz v3, :cond_2

    goto :goto_1

    :cond_2
    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    :goto_1
    if-eqz v0, :cond_5

    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-boolean v5, v4, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    if-nez v5, :cond_3

    invoke-direct {p0, v4}, Lconfimanag/scanutil/alfagamma/transper/i1;->f(Lconfimanag/scanutil/alfagamma/transper/g1;)V

    :cond_3
    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/f1$d;->d:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v4, v5, :cond_4

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v4, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v0

    add-int/2addr v4, v0

    goto :goto_2

    :cond_4
    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/f1$d;->b:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v4, v5, :cond_5

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v4, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    goto :goto_2

    :cond_5
    const/4 v4, 0x0

    :goto_2
    if-eqz v3, :cond_6

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v0

    sub-int/2addr v4, v0

    goto :goto_3

    :cond_6
    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v3

    add-int/2addr v0, v3

    add-int/2addr v4, v0

    :goto_3
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v0

    sub-int v0, v4, v0

    invoke-virtual {p1, v0, v4}, Lconfimanag/scanutil/alfagamma/transper/g1;->f0(II)V

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v0, :cond_8

    iget-object v2, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-boolean v3, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    if-nez v3, :cond_7

    invoke-direct {p0, v2}, Lconfimanag/scanutil/alfagamma/transper/i1;->f(Lconfimanag/scanutil/alfagamma/transper/g1;)V

    :cond_7
    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v2, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    add-int/2addr v2, v0

    iget v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    sub-int/2addr v2, v0

    iget v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    add-int/2addr v0, v2

    invoke-virtual {p1, v2, v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->t0(II)V

    iput-boolean v1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    return-void

    :cond_8
    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v0, :cond_9

    const/4 v2, 0x1

    :cond_9
    if-eqz v2, :cond_a

    goto :goto_4

    :cond_a
    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    :goto_4
    if-eqz v0, :cond_d

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-boolean v5, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    if-nez v5, :cond_b

    invoke-direct {p0, v3}, Lconfimanag/scanutil/alfagamma/transper/i1;->f(Lconfimanag/scanutil/alfagamma/transper/g1;)V

    :cond_b
    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v3, v5, :cond_c

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v0

    add-int v4, v3, v0

    goto :goto_5

    :cond_c
    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/f1$d;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v3, v5, :cond_d

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v4, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    :cond_d
    :goto_5
    if-eqz v2, :cond_e

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v0

    sub-int/2addr v4, v0

    goto :goto_6

    :cond_e
    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v2

    add-int/2addr v0, v2

    add-int/2addr v4, v0

    :goto_6
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v0

    sub-int v0, v4, v0

    invoke-virtual {p1, v0, v4}, Lconfimanag/scanutil/alfagamma/transper/g1;->t0(II)V

    iput-boolean v1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    :cond_f
    return-void
.end method


# virtual methods
.method a(Lconfimanag/scanutil/alfagamma/transper/g1;I)V
    .locals 1

    .line 1
    if-nez p2, :cond_0

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->h:Ljava/util/HashSet;

    :goto_0
    invoke-virtual {p2, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    const/4 v0, 0x1

    if-ne p2, v0, :cond_1

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->i:Ljava/util/HashSet;

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public b(I)Ljava/util/List;
    .locals 1

    .line 1
    if-nez p1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->f:Ljava/util/List;

    return-object p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->g:Ljava/util/List;

    return-object p1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method c(I)Ljava/util/Set;
    .locals 1

    .line 1
    if-nez p1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->h:Ljava/util/HashSet;

    return-object p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->i:Ljava/util/HashSet;

    return-object p1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method d()Ljava/util/List;
    .locals 4

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->j:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->j:Ljava/util/List;

    return-object v0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->a:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_2

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->a:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-boolean v3, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->i0:Z

    if-nez v3, :cond_1

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->j:Ljava/util/List;

    check-cast v3, Ljava/util/ArrayList;

    invoke-direct {p0, v3, v2}, Lconfimanag/scanutil/alfagamma/transper/i1;->e(Ljava/util/ArrayList;Lconfimanag/scanutil/alfagamma/transper/g1;)V

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->k:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->k:Ljava/util/List;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->a:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->k:Ljava/util/List;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->j:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->j:Ljava/util/List;

    return-object v0
.end method

.method g()V
    .locals 3

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->k:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/i1;->k:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-direct {p0, v2}, Lconfimanag/scanutil/alfagamma/transper/i1;->f(Lconfimanag/scanutil/alfagamma/transper/g1;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method
