.class public abstract Lconfimanag/scanutil/alfagamma/transper/p4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:I = 0x7f0b0004
