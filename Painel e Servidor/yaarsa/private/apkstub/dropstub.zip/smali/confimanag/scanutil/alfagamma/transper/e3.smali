.class public Lconfimanag/scanutil/alfagamma/transper/e3;
.super Lconfimanag/scanutil/alfagamma/transper/n2;
.source "SourceFile"

# interfaces
.implements Lconfimanag/scanutil/alfagamma/transper/b3;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/e3$a;
    }
.end annotation


# static fields
.field private static M:Ljava/lang/reflect/Method;


# instance fields
.field private L:Lconfimanag/scanutil/alfagamma/transper/b3;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    :try_start_0
    const-class v0, Landroid/widget/PopupWindow;

    const-string v1, "setTouchModal"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Class;

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/e3;->M:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/n2;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    return-void
.end method


# virtual methods
.method public F(Ljava/lang/Object;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    check-cast p1, Landroid/transition/Transition;

    invoke-static {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/d3;->a(Landroid/widget/PopupWindow;Landroid/transition/Transition;)V

    :cond_0
    return-void
.end method

.method public G(Ljava/lang/Object;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    check-cast p1, Landroid/transition/Transition;

    invoke-static {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/c3;->a(Landroid/widget/PopupWindow;Landroid/transition/Transition;)V

    :cond_0
    return-void
.end method

.method public H(Lconfimanag/scanutil/alfagamma/transper/b3;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/e3;->L:Lconfimanag/scanutil/alfagamma/transper/b3;

    return-void
.end method

.method public I(Z)V
    .locals 4

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/e3;->M:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_0

    :try_start_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v3, 0x0

    aput-object p1, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public a(Landroidx/appcompat/view/menu/d;Landroid/view/MenuItem;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/e3;->L:Lconfimanag/scanutil/alfagamma/transper/b3;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/b3;->a(Landroidx/appcompat/view/menu/d;Landroid/view/MenuItem;)V

    :cond_0
    return-void
.end method

.method public d(Landroidx/appcompat/view/menu/d;Landroid/view/MenuItem;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/e3;->L:Lconfimanag/scanutil/alfagamma/transper/b3;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/b3;->d(Landroidx/appcompat/view/menu/d;Landroid/view/MenuItem;)V

    :cond_0
    return-void
.end method

.method h(Landroid/content/Context;Z)Lconfimanag/scanutil/alfagamma/transper/v1;
    .locals 1

    .line 1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/e3$a;

    invoke-direct {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/e3$a;-><init>(Landroid/content/Context;Z)V

    invoke-virtual {v0, p0}, Lconfimanag/scanutil/alfagamma/transper/e3$a;->setHoverListener(Lconfimanag/scanutil/alfagamma/transper/b3;)V

    return-object v0
.end method
