.class Lconfimanag/scanutil/alfagamma/transper/s5$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/s5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field private A:Ljava/lang/CharSequence;

.field private B:Ljava/lang/CharSequence;

.field private C:Landroid/content/res/ColorStateList;

.field private D:Landroid/graphics/PorterDuff$Mode;

.field final synthetic E:Lconfimanag/scanutil/alfagamma/transper/s5;

.field private a:Landroid/view/Menu;

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:Z

.field private g:Z

.field private h:Z

.field private i:I

.field private j:I

.field private k:Ljava/lang/CharSequence;

.field private l:Ljava/lang/CharSequence;

.field private m:I

.field private n:C

.field private o:I

.field private p:C

.field private q:I

.field private r:I

.field private s:Z

.field private t:Z

.field private u:Z

.field private v:I

.field private w:I

.field private x:Ljava/lang/String;

.field private y:Ljava/lang/String;

.field private z:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/s5;Landroid/view/Menu;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->E:Lconfimanag/scanutil/alfagamma/transper/s5;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->C:Landroid/content/res/ColorStateList;

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->D:Landroid/graphics/PorterDuff$Mode;

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->a:Landroid/view/Menu;

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/s5$b;->h()V

    return-void
.end method

.method private c(Ljava/lang/String;)C
    .locals 1

    .line 1
    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result p1

    return p1
.end method

.method private e(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    :try_start_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->E:Lconfimanag/scanutil/alfagamma/transper/s5;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/s5;->c:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object p2

    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {p2, p3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Cannot instantiate class: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 p1, 0x0

    return-object p1
.end method

.method private i(Landroid/view/MenuItem;)V
    .locals 5

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->s:Z

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->t:Z

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->u:Z

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->r:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lt v1, v3, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setCheckable(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->l:Ljava/lang/CharSequence;

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->m:I

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->v:I

    if-ltz v0, :cond_1

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setShowAsAction(I)V

    :cond_1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->z:Ljava/lang/String;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->E:Lconfimanag/scanutil/alfagamma/transper/s5;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/s5;->c:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    if-nez v0, :cond_2

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/s5$a;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->E:Lconfimanag/scanutil/alfagamma/transper/s5;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/s5;->b()Ljava/lang/Object;

    move-result-object v1

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->z:Ljava/lang/String;

    invoke-direct {v0, v1, v4}, Lconfimanag/scanutil/alfagamma/transper/s5$a;-><init>(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    goto :goto_1

    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "The android:onClick attribute cannot be used within a restricted context"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    :goto_1
    instance-of v0, p1, Landroidx/appcompat/view/menu/e;

    if-eqz v0, :cond_4

    move-object v1, p1

    check-cast v1, Landroidx/appcompat/view/menu/e;

    :cond_4
    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->r:I

    const/4 v4, 0x2

    if-lt v1, v4, :cond_5

    if-eqz v0, :cond_5

    move-object v0, p1

    check-cast v0, Landroidx/appcompat/view/menu/e;

    invoke-virtual {v0, v3}, Landroidx/appcompat/view/menu/e;->s(Z)V

    :cond_5
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->x:Ljava/lang/String;

    if-eqz v0, :cond_6

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/s5;->e:[Ljava/lang/Class;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->E:Lconfimanag/scanutil/alfagamma/transper/s5;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/s5;->a:[Ljava/lang/Object;

    invoke-direct {p0, v0, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/s5$b;->e(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;

    const/4 v2, 0x1

    :cond_6
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->w:I

    if-lez v0, :cond_7

    if-nez v2, :cond_7

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setActionView(I)Landroid/view/MenuItem;

    :cond_7
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->A:Ljava/lang/CharSequence;

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/a3;->b(Landroid/view/MenuItem;Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->B:Ljava/lang/CharSequence;

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/a3;->f(Landroid/view/MenuItem;Ljava/lang/CharSequence;)V

    iget-char v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->n:C

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->o:I

    invoke-static {p1, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/a3;->a(Landroid/view/MenuItem;CI)V

    iget-char v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->p:C

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->q:I

    invoke-static {p1, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/a3;->e(Landroid/view/MenuItem;CI)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->D:Landroid/graphics/PorterDuff$Mode;

    if-eqz v0, :cond_8

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/a3;->d(Landroid/view/MenuItem;Landroid/graphics/PorterDuff$Mode;)V

    :cond_8
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->C:Landroid/content/res/ColorStateList;

    if-eqz v0, :cond_9

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/a3;->c(Landroid/view/MenuItem;Landroid/content/res/ColorStateList;)V

    :cond_9
    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    .line 1
    const/4 v0, 0x1

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->h:Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->a:Landroid/view/Menu;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->b:I

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->i:I

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->j:I

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->k:Ljava/lang/CharSequence;

    invoke-interface {v0, v1, v2, v3, v4}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/s5$b;->i(Landroid/view/MenuItem;)V

    return-void
.end method

.method public b()Landroid/view/SubMenu;
    .locals 5

    .line 1
    const/4 v0, 0x1

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->h:Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->a:Landroid/view/Menu;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->b:I

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->i:I

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->j:I

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->k:Ljava/lang/CharSequence;

    invoke-interface {v0, v1, v2, v3, v4}, Landroid/view/Menu;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/SubMenu;->getItem()Landroid/view/MenuItem;

    move-result-object v1

    invoke-direct {p0, v1}, Lconfimanag/scanutil/alfagamma/transper/s5$b;->i(Landroid/view/MenuItem;)V

    return-object v0
.end method

.method public d()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->h:Z

    return v0
.end method

.method public f(Landroid/util/AttributeSet;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->E:Lconfimanag/scanutil/alfagamma/transper/s5;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/s5;->c:Landroid/content/Context;

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/s4;->R0:[I

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->T0:I

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->b:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->V0:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->c:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->W0:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->d:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->X0:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->e:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->U0:I

    const/4 v1, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->f:Z

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->S0:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->g:Z

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method

.method public g(Landroid/util/AttributeSet;)V
    .locals 5

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->E:Lconfimanag/scanutil/alfagamma/transper/s5;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/s5;->c:Landroid/content/Context;

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/s4;->Y0:[I

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->b1:I

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->i:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->e1:I

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->c:I

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    sget v2, Lconfimanag/scanutil/alfagamma/transper/s4;->f1:I

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->d:I

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    const/high16 v3, -0x10000

    and-int/2addr v0, v3

    const v3, 0xffff

    and-int/2addr v2, v3

    or-int/2addr v0, v2

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->j:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->g1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->k:Ljava/lang/CharSequence;

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->h1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->l:Ljava/lang/CharSequence;

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->Z0:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->m:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->i1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/s5$b;->c(Ljava/lang/String;)C

    move-result v0

    iput-char v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->n:C

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->p1:I

    const/16 v2, 0x1000

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->o:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->j1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/s5$b;->c(Ljava/lang/String;)C

    move-result v0

    iput-char v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->p:C

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->t1:I

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->q:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->k1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    if-eqz v0, :cond_0

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->k1:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    :goto_0
    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->r:I

    goto :goto_1

    :cond_0
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->e:I

    goto :goto_0

    :goto_1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->c1:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->s:Z

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->d1:I

    iget-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->f:Z

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->t:Z

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->a1:I

    iget-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->g:Z

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->u:Z

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->u1:I

    const/4 v2, -0x1

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->v:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->l1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->z:Ljava/lang/String;

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->m1:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->w:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->o1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->x:Ljava/lang/String;

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->n1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->y:Ljava/lang/String;

    if-eqz v0, :cond_1

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->w:I

    if-nez v3, :cond_1

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->x:Ljava/lang/String;

    if-nez v3, :cond_1

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/s5;->f:[Ljava/lang/Class;

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->E:Lconfimanag/scanutil/alfagamma/transper/s5;

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/s5;->b:[Ljava/lang/Object;

    invoke-direct {p0, v0, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/s5$b;->e(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/t5;->a(Ljava/lang/Object;)V

    :cond_1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->q1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->A:Ljava/lang/CharSequence;

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->v1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->B:Ljava/lang/CharSequence;

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->s1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->s1:I

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->D:Landroid/graphics/PorterDuff$Mode;

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/t1;->d(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->D:Landroid/graphics/PorterDuff$Mode;

    goto :goto_2

    :cond_2
    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->D:Landroid/graphics/PorterDuff$Mode;

    :goto_2
    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->r1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    if-eqz v0, :cond_3

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->r1:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->C:Landroid/content/res/ColorStateList;

    goto :goto_3

    :cond_3
    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->C:Landroid/content/res/ColorStateList;

    :goto_3
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->h:Z

    return-void
.end method

.method public h()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->b:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->c:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->d:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->e:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->f:Z

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/s5$b;->g:Z

    return-void
.end method
