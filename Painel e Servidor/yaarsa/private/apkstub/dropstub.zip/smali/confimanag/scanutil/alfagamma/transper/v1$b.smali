.class Lconfimanag/scanutil/alfagamma/transper/v1$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/v1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/v1;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/v1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/v1$b;->a:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/v1$b;->a:Lconfimanag/scanutil/alfagamma/transper/v1;

    const/4 v1, 0x0

    iput-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/v1;->n:Lconfimanag/scanutil/alfagamma/transper/v1$b;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public b()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/v1$b;->a:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v0, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public run()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/v1$b;->a:Lconfimanag/scanutil/alfagamma/transper/v1;

    const/4 v1, 0x0

    iput-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/v1;->n:Lconfimanag/scanutil/alfagamma/transper/v1$b;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/v1;->drawableStateChanged()V

    return-void
.end method
