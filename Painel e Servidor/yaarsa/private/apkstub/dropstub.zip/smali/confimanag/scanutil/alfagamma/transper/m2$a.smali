.class interface abstract Lconfimanag/scanutil/alfagamma/transper/m2$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/m2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lconfimanag/scanutil/alfagamma/transper/m5;)V
.end method

.method public abstract b(Lconfimanag/scanutil/alfagamma/transper/m2;[Z)Lconfimanag/scanutil/alfagamma/transper/m5;
.end method

.method public abstract c(Lconfimanag/scanutil/alfagamma/transper/m2$a;)V
.end method

.method public abstract clear()V
.end method

.method public abstract getKey()Lconfimanag/scanutil/alfagamma/transper/m5;
.end method
