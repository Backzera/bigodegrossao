.class public Lconfimanag/scanutil/alfagamma/transper/s0;
.super Lconfimanag/scanutil/alfagamma/transper/k5;
.source "SourceFile"

# interfaces
.implements Ljava/util/Map;


# instance fields
.field h:Lconfimanag/scanutil/alfagamma/transper/s2;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/k5;-><init>()V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/k5;-><init>(I)V

    return-void
.end method

.method private m()Lconfimanag/scanutil/alfagamma/transper/s2;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0;->h:Lconfimanag/scanutil/alfagamma/transper/s2;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/s0$a;

    invoke-direct {v0, p0}, Lconfimanag/scanutil/alfagamma/transper/s0$a;-><init>(Lconfimanag/scanutil/alfagamma/transper/s0;)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0;->h:Lconfimanag/scanutil/alfagamma/transper/s2;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0;->h:Lconfimanag/scanutil/alfagamma/transper/s2;

    return-object v0
.end method


# virtual methods
.method public entrySet()Ljava/util/Set;
    .locals 1

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/s0;->m()Lconfimanag/scanutil/alfagamma/transper/s2;

    move-result-object v0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/s2;->l()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public keySet()Ljava/util/Set;
    .locals 1

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/s0;->m()Lconfimanag/scanutil/alfagamma/transper/s2;

    move-result-object v0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/s2;->m()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public putAll(Ljava/util/Map;)V
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/k5;->c:I

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/k5;->c(I)V

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/k5;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    return-void
.end method

.method public values()Ljava/util/Collection;
    .locals 1

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/s0;->m()Lconfimanag/scanutil/alfagamma/transper/s2;

    move-result-object v0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/s2;->n()Ljava/util/Collection;

    move-result-object v0

    return-object v0
.end method
