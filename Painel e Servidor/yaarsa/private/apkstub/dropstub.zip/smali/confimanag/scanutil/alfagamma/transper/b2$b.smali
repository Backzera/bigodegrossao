.class Lconfimanag/scanutil/alfagamma/transper/b2$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/b2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/b2;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/b2;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/b2$b;->a:Lconfimanag/scanutil/alfagamma/transper/b2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b2$b;->a:Lconfimanag/scanutil/alfagamma/transper/b2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/b2;->e()V

    return-void
.end method
