.class Lconfimanag/scanutil/alfagamma/transper/n2$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/n2;->f()I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/n2;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$a;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$a;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/n2;->j()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$a;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/n2;->e()V

    :cond_0
    return-void
.end method
