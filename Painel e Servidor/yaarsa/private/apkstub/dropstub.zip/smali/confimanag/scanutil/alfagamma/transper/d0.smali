.class public Lconfimanag/scanutil/alfagamma/transper/d0;
.super Landroid/widget/TextView;
.source "SourceFile"

# interfaces
.implements Lconfimanag/scanutil/alfagamma/transper/v0;


# instance fields
.field private final b:Lconfimanag/scanutil/alfagamma/transper/q;

.field private final c:Lconfimanag/scanutil/alfagamma/transper/c0;

.field private d:Ljava/util/concurrent/Future;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lconfimanag/scanutil/alfagamma/transper/d0;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 2
    const v0, 0x1010084

    invoke-direct {p0, p1, p2, v0}, Lconfimanag/scanutil/alfagamma/transper/d0;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 3
    invoke-static {p1}, Lconfimanag/scanutil/alfagamma/transper/f6;->b(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/q;

    invoke-direct {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/q;-><init>(Landroid/view/View;)V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    invoke-virtual {p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/q;->e(Landroid/util/AttributeSet;I)V

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/c0;

    invoke-direct {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/c0;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    invoke-virtual {p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/c0;->k(Landroid/util/AttributeSet;I)V

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/c0;->b()V

    return-void
.end method

.method private e()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->d:Ljava/util/concurrent/Future;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    :try_start_0
    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->d:Ljava/util/concurrent/Future;

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/t5;->a(Ljava/lang/Object;)V

    invoke-static {p0, v1}, Lconfimanag/scanutil/alfagamma/transper/c6;->i(Landroid/widget/TextView;Lconfimanag/scanutil/alfagamma/transper/e4;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method


# virtual methods
.method protected drawableStateChanged()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/TextView;->drawableStateChanged()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->b()V

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/c0;->b()V

    :cond_1
    return-void
.end method

.method public getAutoSizeMaxTextSize()I
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v0, :cond_0

    invoke-super {p0}, Landroid/widget/TextView;->getAutoSizeMaxTextSize()I

    move-result v0

    return v0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/c0;->e()I

    move-result v0

    return v0

    :cond_1
    const/4 v0, -0x1

    return v0
.end method

.method public getAutoSizeMinTextSize()I
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v0, :cond_0

    invoke-super {p0}, Landroid/widget/TextView;->getAutoSizeMinTextSize()I

    move-result v0

    return v0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/c0;->f()I

    move-result v0

    return v0

    :cond_1
    const/4 v0, -0x1

    return v0
.end method

.method public getAutoSizeStepGranularity()I
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v0, :cond_0

    invoke-super {p0}, Landroid/widget/TextView;->getAutoSizeStepGranularity()I

    move-result v0

    return v0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/c0;->g()I

    move-result v0

    return v0

    :cond_1
    const/4 v0, -0x1

    return v0
.end method

.method public getAutoSizeTextAvailableSizes()[I
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v0, :cond_0

    invoke-super {p0}, Landroid/widget/TextView;->getAutoSizeTextAvailableSizes()[I

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/c0;->h()[I

    move-result-object v0

    return-object v0

    :cond_1
    const/4 v0, 0x0

    new-array v0, v0, [I

    return-object v0
.end method

.method public getAutoSizeTextType()I
    .locals 3

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-super {p0}, Landroid/widget/TextView;->getAutoSizeTextType()I

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1

    :cond_1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/c0;->i()I

    move-result v0

    return v0

    :cond_2
    return v1
.end method

.method public getFirstBaselineToTopHeight()I
    .locals 1

    .line 1
    invoke-static {p0}, Lconfimanag/scanutil/alfagamma/transper/c6;->a(Landroid/widget/TextView;)I

    move-result v0

    return v0
.end method

.method public getLastBaselineToBottomHeight()I
    .locals 1

    .line 1
    invoke-static {p0}, Lconfimanag/scanutil/alfagamma/transper/c6;->b(Landroid/widget/TextView;)I

    move-result v0

    return v0
.end method

.method public getSupportBackgroundTintList()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->c()Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public getSupportBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->d()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public getText()Ljava/lang/CharSequence;
    .locals 1

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/d0;->e()V

    invoke-super {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    return-object v0
.end method

.method public getTextMetricsParamsCompat()Lconfimanag/scanutil/alfagamma/transper/e4$a;
    .locals 1

    .line 1
    invoke-static {p0}, Lconfimanag/scanutil/alfagamma/transper/c6;->e(Landroid/widget/TextView;)Lconfimanag/scanutil/alfagamma/transper/e4$a;

    move-result-object v0

    return-object v0
.end method

.method public onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    move-result-object v0

    invoke-static {v0, p1, p0}, Lconfimanag/scanutil/alfagamma/transper/s;->a(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;Landroid/view/View;)Landroid/view/inputmethod/InputConnection;

    move-result-object p1

    return-object p1
.end method

.method protected onLayout(ZIIII)V
    .locals 6

    .line 1
    invoke-super/range {p0 .. p5}, Landroid/widget/TextView;->onLayout(ZIIII)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Lconfimanag/scanutil/alfagamma/transper/c0;->m(ZIIII)V

    :cond_0
    return-void
.end method

.method protected onMeasure(II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/d0;->e()V

    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->onMeasure(II)V

    return-void
.end method

.method protected onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->onTextChanged(Ljava/lang/CharSequence;III)V

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz p1, :cond_0

    sget-boolean p2, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-nez p2, :cond_0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/c0;->j()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/c0;->c()V

    :cond_0
    return-void
.end method

.method public setAutoSizeTextTypeUniformWithConfiguration(IIII)V
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p1, p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/c0;->p(IIII)V

    :cond_1
    :goto_0
    return-void
.end method

.method public setAutoSizeTextTypeUniformWithPresetSizes([II)V
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithPresetSizes([II)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/c0;->q([II)V

    :cond_1
    :goto_0
    return-void
.end method

.method public setAutoSizeTextTypeWithDefaults(I)V
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1}, Landroid/widget/TextView;->setAutoSizeTextTypeWithDefaults(I)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/c0;->r(I)V

    :cond_1
    :goto_0
    return-void
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->f(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method

.method public setBackgroundResource(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->g(I)V

    :cond_0
    return-void
.end method

.method public setCustomSelectionActionModeCallback(Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/c6;->k(Landroid/widget/TextView;Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/widget/TextView;->setCustomSelectionActionModeCallback(Landroid/view/ActionMode$Callback;)V

    return-void
.end method

.method public setFirstBaselineToTopHeight(I)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_0

    invoke-super {p0, p1}, Landroid/widget/TextView;->setFirstBaselineToTopHeight(I)V

    goto :goto_0

    :cond_0
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/c6;->f(Landroid/widget/TextView;I)V

    :goto_0
    return-void
.end method

.method public setLastBaselineToBottomHeight(I)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_0

    invoke-super {p0, p1}, Landroid/widget/TextView;->setLastBaselineToBottomHeight(I)V

    goto :goto_0

    :cond_0
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/c6;->g(Landroid/widget/TextView;I)V

    :goto_0
    return-void
.end method

.method public setLineHeight(I)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/c6;->h(Landroid/widget/TextView;I)V

    return-void
.end method

.method public setPrecomputedText(Lconfimanag/scanutil/alfagamma/transper/e4;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/c6;->i(Landroid/widget/TextView;Lconfimanag/scanutil/alfagamma/transper/e4;)V

    return-void
.end method

.method public setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->i(Landroid/content/res/ColorStateList;)V

    :cond_0
    return-void
.end method

.method public setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->j(Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    return-void
.end method

.method public setTextAppearance(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->setTextAppearance(Landroid/content/Context;I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/c0;->n(Landroid/content/Context;I)V

    :cond_0
    return-void
.end method

.method public setTextFuture(Ljava/util/concurrent/Future;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Future<",
            "Lconfimanag/scanutil/alfagamma/transper/e4;",
            ">;)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->d:Ljava/util/concurrent/Future;

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setTextMetricsParamsCompat(Lconfimanag/scanutil/alfagamma/transper/e4$a;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/c6;->j(Landroid/widget/TextView;Lconfimanag/scanutil/alfagamma/transper/e4$a;)V

    return-void
.end method

.method public setTextSize(IF)V
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->setTextSize(IF)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/d0;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/c0;->s(IF)V

    :cond_1
    :goto_0
    return-void
.end method
