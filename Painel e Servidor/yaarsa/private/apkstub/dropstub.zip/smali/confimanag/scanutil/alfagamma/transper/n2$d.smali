.class Lconfimanag/scanutil/alfagamma/transper/n2$d;
.super Landroid/database/DataSetObserver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/n2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "d"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/n2;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$d;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    return-void
.end method


# virtual methods
.method public onChanged()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$d;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/n2;->b()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$d;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/n2;->e()V

    :cond_0
    return-void
.end method

.method public onInvalidated()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$d;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/n2;->i()V

    return-void
.end method
