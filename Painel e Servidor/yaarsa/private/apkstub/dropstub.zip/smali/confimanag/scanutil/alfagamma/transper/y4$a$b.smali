.class Lconfimanag/scanutil/alfagamma/transper/y4$a$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/y4$a;->a(ILandroid/os/Handler;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lconfimanag/scanutil/alfagamma/transper/y4$a;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/y4$a;I)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/y4$a$b;->b:Lconfimanag/scanutil/alfagamma/transper/y4$a;

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/y4$a$b;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/y4$a$b;->b:Lconfimanag/scanutil/alfagamma/transper/y4$a;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/y4$a$b;->a:I

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/y4$a;->c(I)V

    return-void
.end method
