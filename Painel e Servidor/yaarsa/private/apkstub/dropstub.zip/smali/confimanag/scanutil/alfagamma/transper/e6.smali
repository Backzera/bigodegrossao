.class public interface abstract Lconfimanag/scanutil/alfagamma/transper/e6;
.super Ljava/lang/Object;
.source "SourceFile"
