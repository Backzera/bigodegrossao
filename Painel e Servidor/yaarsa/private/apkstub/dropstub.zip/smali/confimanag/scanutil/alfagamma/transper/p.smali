.class public abstract Lconfimanag/scanutil/alfagamma/transper/p;
.super Landroid/widget/AutoCompleteTextView;
.source "SourceFile"


# static fields
.field private static final d:[I


# instance fields
.field private final b:Lconfimanag/scanutil/alfagamma/transper/q;

.field private final c:Lconfimanag/scanutil/alfagamma/transper/c0;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const v0, 0x1010176

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/p;->d:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    .line 1
    invoke-static {p1}, Lconfimanag/scanutil/alfagamma/transper/f6;->b(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/AutoCompleteTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/p;->d:[I

    const/4 v1, 0x0

    invoke-static {p1, p2, v0, p3, v1}, Lconfimanag/scanutil/alfagamma/transper/i6;->r(Landroid/content/Context;Landroid/util/AttributeSet;[III)Lconfimanag/scanutil/alfagamma/transper/i6;

    move-result-object p1

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/i6;->f(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/i6;->s()V

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/q;

    invoke-direct {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/q;-><init>(Landroid/view/View;)V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/p;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    invoke-virtual {p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/q;->e(Landroid/util/AttributeSet;I)V

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/c0;

    invoke-direct {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/c0;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/p;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    invoke-virtual {p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/c0;->k(Landroid/util/AttributeSet;I)V

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/c0;->b()V

    return-void
.end method


# virtual methods
.method protected drawableStateChanged()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/AutoCompleteTextView;->drawableStateChanged()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->b()V

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/c0;->b()V

    :cond_1
    return-void
.end method

.method public getSupportBackgroundTintList()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->c()Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public getSupportBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->d()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    move-result-object v0

    invoke-static {v0, p1, p0}, Lconfimanag/scanutil/alfagamma/transper/s;->a(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;Landroid/view/View;)Landroid/view/inputmethod/InputConnection;

    move-result-object p1

    return-object p1
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->f(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method

.method public setBackgroundResource(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->setBackgroundResource(I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->g(I)V

    :cond_0
    return-void
.end method

.method public setCustomSelectionActionModeCallback(Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/c6;->k(Landroid/widget/TextView;Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->setCustomSelectionActionModeCallback(Landroid/view/ActionMode$Callback;)V

    return-void
.end method

.method public setDropDownBackgroundResource(I)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/y;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->i(Landroid/content/res/ColorStateList;)V

    :cond_0
    return-void
.end method

.method public setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->j(Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    return-void
.end method

.method public setTextAppearance(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/AutoCompleteTextView;->setTextAppearance(Landroid/content/Context;I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/p;->c:Lconfimanag/scanutil/alfagamma/transper/c0;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/c0;->n(Landroid/content/Context;I)V

    :cond_0
    return-void
.end method
