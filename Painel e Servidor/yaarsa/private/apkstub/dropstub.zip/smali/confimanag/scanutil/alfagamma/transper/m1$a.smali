.class interface abstract Lconfimanag/scanutil/alfagamma/transper/m1$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/m1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Landroid/database/Cursor;)Ljava/lang/CharSequence;
.end method

.method public abstract b()Landroid/database/Cursor;
.end method

.method public abstract c(Landroid/database/Cursor;)V
.end method

.method public abstract d(Ljava/lang/CharSequence;)Landroid/database/Cursor;
.end method
