.class public interface abstract Lconfimanag/scanutil/alfagamma/transper/b3;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroidx/appcompat/view/menu/d;Landroid/view/MenuItem;)V
.end method

.method public abstract d(Landroidx/appcompat/view/menu/d;Landroid/view/MenuItem;)V
.end method
