.class public Lconfimanag/scanutil/alfagamma/transper/t;
.super Landroid/widget/ImageButton;
.source "SourceFile"


# instance fields
.field private final b:Lconfimanag/scanutil/alfagamma/transper/q;

.field private final c:Lconfimanag/scanutil/alfagamma/transper/u;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 1
    invoke-static {p1}, Lconfimanag/scanutil/alfagamma/transper/f6;->b(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/q;

    invoke-direct {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/q;-><init>(Landroid/view/View;)V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/t;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    invoke-virtual {p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/q;->e(Landroid/util/AttributeSet;I)V

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/u;

    invoke-direct {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/u;-><init>(Landroid/widget/ImageView;)V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    invoke-virtual {p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/u;->f(Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method protected drawableStateChanged()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/ImageButton;->drawableStateChanged()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->b()V

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u;->b()V

    :cond_1
    return-void
.end method

.method public getSupportBackgroundTintList()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->c()Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public getSupportBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/q;->d()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public getSupportImageTintList()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u;->c()Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public getSupportImageTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u;->d()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public hasOverlappingRendering()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u;->e()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-super {p0}, Landroid/widget/ImageButton;->hasOverlappingRendering()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->f(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method

.method public setBackgroundResource(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setBackgroundResource(I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->g(I)V

    :cond_0
    return-void
.end method

.method public setImageBitmap(Landroid/graphics/Bitmap;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setImageBitmap(Landroid/graphics/Bitmap;)V

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/u;->b()V

    :cond_0
    return-void
.end method

.method public setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/u;->b()V

    :cond_0
    return-void
.end method

.method public setImageResource(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/u;->g(I)V

    return-void
.end method

.method public setImageURI(Landroid/net/Uri;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setImageURI(Landroid/net/Uri;)V

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/u;->b()V

    :cond_0
    return-void
.end method

.method public setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->i(Landroid/content/res/ColorStateList;)V

    :cond_0
    return-void
.end method

.method public setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->b:Lconfimanag/scanutil/alfagamma/transper/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/q;->j(Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    return-void
.end method

.method public setSupportImageTintList(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/u;->h(Landroid/content/res/ColorStateList;)V

    :cond_0
    return-void
.end method

.method public setSupportImageTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/t;->c:Lconfimanag/scanutil/alfagamma/transper/u;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/u;->i(Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    return-void
.end method
