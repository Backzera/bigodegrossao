.class public abstract Lconfimanag/scanutil/alfagamma/transper/a3;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/view/MenuItem;CI)V
    .locals 2

    .line 1
    instance-of v0, p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    if-eqz v0, :cond_0

    check-cast p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    invoke-interface {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/u5;->setAlphabeticShortcut(CI)Landroid/view/MenuItem;

    goto :goto_0

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    invoke-static {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/z2;->a(Landroid/view/MenuItem;CI)Landroid/view/MenuItem;

    :cond_1
    :goto_0
    return-void
.end method

.method public static b(Landroid/view/MenuItem;Ljava/lang/CharSequence;)V
    .locals 2

    .line 1
    instance-of v0, p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    if-eqz v0, :cond_0

    check-cast p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    invoke-interface {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/u5;->setContentDescription(Ljava/lang/CharSequence;)Lconfimanag/scanutil/alfagamma/transper/u5;

    goto :goto_0

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/x2;->a(Landroid/view/MenuItem;Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    :cond_1
    :goto_0
    return-void
.end method

.method public static c(Landroid/view/MenuItem;Landroid/content/res/ColorStateList;)V
    .locals 2

    .line 1
    instance-of v0, p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    if-eqz v0, :cond_0

    check-cast p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    invoke-interface {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/u5;->setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    goto :goto_0

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/w2;->a(Landroid/view/MenuItem;Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    :cond_1
    :goto_0
    return-void
.end method

.method public static d(Landroid/view/MenuItem;Landroid/graphics/PorterDuff$Mode;)V
    .locals 2

    .line 1
    instance-of v0, p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    if-eqz v0, :cond_0

    check-cast p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    invoke-interface {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/u5;->setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    goto :goto_0

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/v2;->a(Landroid/view/MenuItem;Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    :cond_1
    :goto_0
    return-void
.end method

.method public static e(Landroid/view/MenuItem;CI)V
    .locals 2

    .line 1
    instance-of v0, p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    if-eqz v0, :cond_0

    check-cast p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    invoke-interface {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/u5;->setNumericShortcut(CI)Landroid/view/MenuItem;

    goto :goto_0

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    invoke-static {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/y2;->a(Landroid/view/MenuItem;CI)Landroid/view/MenuItem;

    :cond_1
    :goto_0
    return-void
.end method

.method public static f(Landroid/view/MenuItem;Ljava/lang/CharSequence;)V
    .locals 2

    .line 1
    instance-of v0, p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    if-eqz v0, :cond_0

    check-cast p0, Lconfimanag/scanutil/alfagamma/transper/u5;

    invoke-interface {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/u5;->setTooltipText(Ljava/lang/CharSequence;)Lconfimanag/scanutil/alfagamma/transper/u5;

    goto :goto_0

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_1

    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/u2;->a(Landroid/view/MenuItem;Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    :cond_1
    :goto_0
    return-void
.end method
