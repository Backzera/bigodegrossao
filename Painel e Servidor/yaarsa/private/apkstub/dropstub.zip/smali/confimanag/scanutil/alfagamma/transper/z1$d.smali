.class public final Lconfimanag/scanutil/alfagamma/transper/z1$d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lconfimanag/scanutil/alfagamma/transper/z1$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/z1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field private final a:Lconfimanag/scanutil/alfagamma/transper/y1;

.field private final b:I

.field private final c:I


# direct methods
.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/y1;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/z1$d;->a:Lconfimanag/scanutil/alfagamma/transper/y1;

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/z1$d;->c:I

    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/z1$d;->b:I

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/z1$d;->c:I

    return v0
.end method

.method public b()Lconfimanag/scanutil/alfagamma/transper/y1;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/z1$d;->a:Lconfimanag/scanutil/alfagamma/transper/y1;

    return-object v0
.end method

.method public c()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/z1$d;->b:I

    return v0
.end method
