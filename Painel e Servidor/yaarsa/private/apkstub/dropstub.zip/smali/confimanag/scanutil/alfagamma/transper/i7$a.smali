.class Lconfimanag/scanutil/alfagamma/transper/i7$a;
.super Lconfimanag/scanutil/alfagamma/transper/h7$a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/i7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/h7$a;Landroid/content/res/Resources;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/h7$a;-><init>(Lconfimanag/scanutil/alfagamma/transper/h7$a;Landroid/content/res/Resources;)V

    return-void
.end method


# virtual methods
.method public newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/i7;

    invoke-direct {v0, p0, p1}, Lconfimanag/scanutil/alfagamma/transper/i7;-><init>(Lconfimanag/scanutil/alfagamma/transper/h7$a;Landroid/content/res/Resources;)V

    return-object v0
.end method
