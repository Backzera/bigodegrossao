.class public abstract Lconfimanag/scanutil/alfagamma/transper/k3;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static a:[Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const/4 v0, 0x3

    new-array v0, v0, [Z

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/k3;->a:[Z

    return-void
.end method

.method static a(ILconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 16

    .line 1
    move-object/from16 v0, p1

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->H0()V

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget-object v2, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v2

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v3

    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v4}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v4

    const/16 v5, 0x8

    and-int/lit8 v6, p0, 0x8

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-ne v6, v5, :cond_0

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    :goto_0
    iget-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v9, v9, v7

    sget-object v10, Lconfimanag/scanutil/alfagamma/transper/g1$b;->c:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v9, v10, :cond_1

    invoke-static {v0, v7}, Lconfimanag/scanutil/alfagamma/transper/k3;->d(Lconfimanag/scanutil/alfagamma/transper/g1;I)Z

    move-result v9

    if-eqz v9, :cond_1

    const/4 v9, 0x1

    goto :goto_1

    :cond_1
    const/4 v9, 0x0

    :goto_1
    iget v11, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    const/4 v13, 0x4

    const/4 v14, 0x0

    const/4 v15, -0x1

    const/4 v12, 0x2

    if-eq v11, v13, :cond_11

    iget v11, v3, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    if-eq v11, v13, :cond_11

    iget-object v11, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v11, v11, v7

    sget-object v7, Lconfimanag/scanutil/alfagamma/transper/g1$b;->a:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-eq v11, v7, :cond_a

    if-eqz v9, :cond_2

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v7

    if-ne v7, v5, :cond_2

    goto/16 :goto_6

    :cond_2
    if-eqz v9, :cond_11

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v7

    invoke-virtual {v1, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v3, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    iget-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v9, :cond_4

    iget-object v11, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v11, v11, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v11, :cond_4

    if-eqz v6, :cond_3

    :goto_2
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v7

    invoke-virtual {v3, v1, v8, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->j(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    goto/16 :goto_7

    :cond_3
    :goto_3
    invoke-virtual {v3, v1, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    goto/16 :goto_7

    :cond_4
    if-eqz v9, :cond_5

    iget-object v11, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v11, v11, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v11, :cond_5

    if-eqz v6, :cond_3

    goto :goto_2

    :cond_5
    if-nez v9, :cond_7

    iget-object v11, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v11, v11, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v11, :cond_7

    if-eqz v6, :cond_6

    :goto_4
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v7

    invoke-virtual {v1, v3, v15, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->j(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    goto/16 :goto_7

    :cond_6
    :goto_5
    neg-int v7, v7

    invoke-virtual {v1, v3, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    goto/16 :goto_7

    :cond_7
    if-eqz v9, :cond_11

    iget-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v9, :cond_11

    if-eqz v6, :cond_8

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v9

    invoke-virtual {v9, v1}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v9

    invoke-virtual {v9, v3}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    :cond_8
    iget v9, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    cmpl-float v9, v9, v14

    if-nez v9, :cond_9

    const/4 v9, 0x3

    invoke-virtual {v1, v9}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v3, v9}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v1, v3, v14}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    invoke-virtual {v3, v1, v14}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    goto/16 :goto_7

    :cond_9
    invoke-virtual {v1, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v3, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    neg-int v9, v7

    int-to-float v9, v9

    invoke-virtual {v1, v3, v9}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    int-to-float v9, v7

    invoke-virtual {v3, v1, v9}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    invoke-virtual {v0, v7}, Lconfimanag/scanutil/alfagamma/transper/g1;->y0(I)V

    goto/16 :goto_7

    :cond_a
    :goto_6
    iget-object v7, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v7, v7, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v7, :cond_c

    iget-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v9, :cond_c

    invoke-virtual {v1, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v3, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    if-eqz v6, :cond_b

    goto/16 :goto_2

    :cond_b
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v7

    goto/16 :goto_3

    :cond_c
    if-eqz v7, :cond_d

    iget-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v9, :cond_d

    invoke-virtual {v1, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v3, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    if-eqz v6, :cond_b

    goto/16 :goto_2

    :cond_d
    if-nez v7, :cond_f

    iget-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v9, :cond_f

    invoke-virtual {v1, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v3, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v7

    neg-int v7, v7

    invoke-virtual {v1, v3, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    if-eqz v6, :cond_e

    goto/16 :goto_4

    :cond_e
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v7

    goto/16 :goto_5

    :cond_f
    if-eqz v7, :cond_11

    iget-object v7, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v7, v7, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v7, :cond_11

    invoke-virtual {v1, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v3, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    if-eqz v6, :cond_10

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v7

    invoke-virtual {v7, v1}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v7

    invoke-virtual {v7, v3}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v7

    invoke-virtual {v1, v3, v15, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->o(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v7

    invoke-virtual {v3, v1, v8, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->o(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    goto :goto_7

    :cond_10
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v7

    neg-int v7, v7

    int-to-float v7, v7

    invoke-virtual {v1, v3, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v3, v1, v7}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    :cond_11
    :goto_7
    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v1, v1, v8

    if-ne v1, v10, :cond_12

    invoke-static {v0, v8}, Lconfimanag/scanutil/alfagamma/transper/k3;->d(Lconfimanag/scanutil/alfagamma/transper/g1;I)Z

    move-result v1

    if-eqz v1, :cond_12

    const/4 v7, 0x1

    goto :goto_8

    :cond_12
    const/4 v7, 0x0

    :goto_8
    iget v1, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    if-eq v1, v13, :cond_23

    iget v1, v4, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    if-eq v1, v13, :cond_23

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v1, v1, v8

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/g1$b;->a:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-eq v1, v3, :cond_1b

    if-eqz v7, :cond_13

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v1

    if-ne v1, v5, :cond_13

    goto/16 :goto_b

    :cond_13
    if-eqz v7, :cond_23

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v1

    invoke-virtual {v2, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v4, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v3, :cond_15

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v5, v5, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v5, :cond_15

    if-eqz v6, :cond_14

    :goto_9
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v0

    invoke-virtual {v4, v2, v8, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->j(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    goto/16 :goto_10

    :cond_14
    invoke-virtual {v4, v2, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    goto/16 :goto_10

    :cond_15
    if-eqz v3, :cond_16

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v5, v5, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v5, :cond_16

    if-eqz v6, :cond_14

    goto :goto_9

    :cond_16
    if-nez v3, :cond_18

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v5, v5, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v5, :cond_18

    if-eqz v6, :cond_17

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v0

    invoke-virtual {v2, v4, v15, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->j(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    goto/16 :goto_10

    :cond_17
    neg-int v0, v1

    invoke-virtual {v2, v4, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    goto/16 :goto_10

    :cond_18
    if-eqz v3, :cond_23

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v3, :cond_23

    if-eqz v6, :cond_19

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v3

    invoke-virtual {v3, v2}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v3

    invoke-virtual {v3, v4}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    :cond_19
    iget v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    cmpl-float v3, v3, v14

    if-nez v3, :cond_1a

    const/4 v3, 0x3

    invoke-virtual {v2, v3}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v4, v3}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v2, v4, v14}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    invoke-virtual {v4, v2, v14}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    goto/16 :goto_10

    :cond_1a
    invoke-virtual {v2, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v4, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    neg-int v3, v1

    int-to-float v3, v3

    invoke-virtual {v2, v4, v3}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    int-to-float v3, v1

    invoke-virtual {v4, v2, v3}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/g1;->b0(I)V

    iget v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    if-lez v1, :cond_23

    :goto_a
    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    invoke-virtual {v1, v8, v2, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    goto/16 :goto_10

    :cond_1b
    :goto_b
    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v1, :cond_1d

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v3, :cond_1d

    invoke-virtual {v2, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v4, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    if-eqz v6, :cond_1c

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v1

    invoke-virtual {v4, v2, v8, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->j(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    goto :goto_c

    :cond_1c
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v1

    invoke-virtual {v4, v2, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    :goto_c
    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v3, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v3, :cond_23

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    invoke-virtual {v1, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    neg-int v0, v0

    invoke-virtual {v2, v8, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    goto/16 :goto_10

    :cond_1d
    if-eqz v1, :cond_1f

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v3, :cond_1f

    invoke-virtual {v2, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v4, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    if-eqz v6, :cond_1e

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v1

    invoke-virtual {v4, v2, v8, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->j(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    goto :goto_d

    :cond_1e
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v1

    invoke-virtual {v4, v2, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    :goto_d
    iget v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    if-lez v1, :cond_23

    goto :goto_a

    :cond_1f
    if-nez v1, :cond_21

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v3, :cond_21

    invoke-virtual {v2, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v4, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    if-eqz v6, :cond_20

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v1

    invoke-virtual {v2, v4, v15, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->j(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    goto :goto_e

    :cond_20
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {v2, v4, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    :goto_e
    iget v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    if-lez v1, :cond_23

    goto/16 :goto_a

    :cond_21
    if-eqz v1, :cond_23

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v1, :cond_23

    invoke-virtual {v2, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    invoke-virtual {v4, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->p(I)V

    if-eqz v6, :cond_22

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v1

    invoke-virtual {v2, v4, v15, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->o(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v1

    invoke-virtual {v4, v2, v8, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->o(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->w()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v1

    invoke-virtual {v1, v2}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->x()Lconfimanag/scanutil/alfagamma/transper/v4;

    move-result-object v1

    invoke-virtual {v1, v4}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    goto :goto_f

    :cond_22
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v1

    neg-int v1, v1

    int-to-float v1, v1

    invoke-virtual {v2, v4, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v4, v2, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    :goto_f
    iget v1, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    if-lez v1, :cond_23

    goto/16 :goto_a

    :cond_23
    :goto_10
    return-void
.end method

.method static b(Lconfimanag/scanutil/alfagamma/transper/h1;Lconfimanag/scanutil/alfagamma/transper/m2;IILconfimanag/scanutil/alfagamma/transper/a1;)Z
    .locals 21

    .line 1
    move-object/from16 v0, p1

    move/from16 v1, p2

    move-object/from16 v2, p4

    iget-object v3, v2, Lconfimanag/scanutil/alfagamma/transper/a1;->a:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v4, v2, Lconfimanag/scanutil/alfagamma/transper/a1;->c:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v5, v2, Lconfimanag/scanutil/alfagamma/transper/a1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v6, v2, Lconfimanag/scanutil/alfagamma/transper/a1;->d:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v7, v2, Lconfimanag/scanutil/alfagamma/transper/a1;->e:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/a1;->k:F

    move-object/from16 v8, p0

    iget-object v8, v8, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v8, v8, v1

    sget-object v8, Lconfimanag/scanutil/alfagamma/transper/g1$b;->a:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-nez v1, :cond_3

    iget v7, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->l0:I

    if-nez v7, :cond_0

    const/4 v11, 0x1

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    :goto_0
    if-ne v7, v9, :cond_1

    const/4 v12, 0x1

    goto :goto_1

    :cond_1
    const/4 v12, 0x0

    :goto_1
    if-ne v7, v8, :cond_2

    :goto_2
    const/4 v7, 0x1

    goto :goto_5

    :cond_2
    const/4 v7, 0x0

    goto :goto_5

    :cond_3
    iget v7, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->m0:I

    if-nez v7, :cond_4

    const/4 v11, 0x1

    goto :goto_3

    :cond_4
    const/4 v11, 0x0

    :goto_3
    if-ne v7, v9, :cond_5

    const/4 v12, 0x1

    goto :goto_4

    :cond_5
    const/4 v12, 0x0

    :goto_4
    if-ne v7, v8, :cond_2

    goto :goto_2

    :goto_5
    move-object v14, v3

    const/4 v9, 0x0

    const/4 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    :goto_6
    const/16 v8, 0x8

    if-nez v13, :cond_14

    invoke-virtual {v14}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v10

    if-eq v10, v8, :cond_9

    add-int/lit8 v15, v15, 0x1

    if-nez v1, :cond_6

    invoke-virtual {v14}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v10

    :goto_7
    int-to-float v10, v10

    add-float v16, v16, v10

    goto :goto_8

    :cond_6
    invoke-virtual {v14}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v10

    goto :goto_7

    :goto_8
    if-eq v14, v5, :cond_7

    iget-object v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v10, v10, p3

    invoke-virtual {v10}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v10

    int-to-float v10, v10

    add-float v16, v16, v10

    :cond_7
    if-eq v14, v6, :cond_8

    iget-object v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    add-int/lit8 v19, p3, 0x1

    aget-object v10, v10, v19

    invoke-virtual {v10}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v10

    int-to-float v10, v10

    add-float v16, v16, v10

    :cond_8
    iget-object v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v10, v10, p3

    invoke-virtual {v10}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v10

    int-to-float v10, v10

    add-float v17, v17, v10

    iget-object v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    add-int/lit8 v19, p3, 0x1

    aget-object v10, v10, v19

    invoke-virtual {v10}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v10

    int-to-float v10, v10

    add-float v17, v17, v10

    :cond_9
    iget-object v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v10, v10, p3

    invoke-virtual {v14}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v10

    if-eq v10, v8, :cond_10

    iget-object v8, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v8, v8, v1

    sget-object v10, Lconfimanag/scanutil/alfagamma/transper/g1$b;->c:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v8, v10, :cond_10

    add-int/lit8 v9, v9, 0x1

    if-nez v1, :cond_c

    iget v8, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->e:I

    if-eqz v8, :cond_a

    const/4 v8, 0x0

    return v8

    :cond_a
    const/4 v8, 0x0

    iget v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->h:I

    if-nez v10, :cond_b

    iget v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->i:I

    if-eqz v10, :cond_e

    :cond_b
    return v8

    :cond_c
    const/4 v8, 0x0

    iget v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->f:I

    if-eqz v10, :cond_d

    return v8

    :cond_d
    iget v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    if-nez v10, :cond_f

    iget v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->l:I

    if-eqz v10, :cond_e

    goto :goto_9

    :cond_e
    iget v10, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    const/16 v18, 0x0

    cmpl-float v10, v10, v18

    if-eqz v10, :cond_10

    :cond_f
    :goto_9
    return v8

    :cond_10
    iget-object v8, v14, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    add-int/lit8 v10, p3, 0x1

    aget-object v8, v8, v10

    iget-object v8, v8, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v8, :cond_12

    iget-object v8, v8, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v10, v8, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v10, v10, p3

    iget-object v10, v10, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v10, :cond_12

    iget-object v10, v10, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-eq v10, v14, :cond_11

    goto :goto_a

    :cond_11
    move-object v10, v8

    goto :goto_b

    :cond_12
    :goto_a
    const/4 v10, 0x0

    :goto_b
    if-eqz v10, :cond_13

    move-object v14, v10

    goto/16 :goto_6

    :cond_13
    const/4 v13, 0x1

    goto/16 :goto_6

    :cond_14
    iget-object v10, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v10, v10, p3

    invoke-virtual {v10}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v10

    iget-object v13, v4, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    add-int/lit8 v19, p3, 0x1

    aget-object v13, v13, v19

    invoke-virtual {v13}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v13

    iget-object v8, v10, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eqz v8, :cond_15

    move-object/from16 v20, v3

    iget-object v3, v13, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-nez v3, :cond_16

    :cond_15
    const/4 v0, 0x0

    goto/16 :goto_21

    :cond_16
    iget v8, v8, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    const/4 v0, 0x1

    if-ne v8, v0, :cond_17

    iget v3, v3, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-eq v3, v0, :cond_18

    :cond_17
    const/4 v0, 0x0

    goto/16 :goto_21

    :cond_18
    if-lez v9, :cond_19

    if-eq v9, v15, :cond_19

    const/4 v0, 0x0

    return v0

    :cond_19
    if-nez v7, :cond_1b

    if-nez v11, :cond_1b

    if-eqz v12, :cond_1a

    goto :goto_c

    :cond_1a
    const/4 v0, 0x0

    goto :goto_e

    :cond_1b
    :goto_c
    if-eqz v5, :cond_1c

    iget-object v0, v5, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v0, v0, p3

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v0

    int-to-float v0, v0

    goto :goto_d

    :cond_1c
    const/4 v0, 0x0

    :goto_d
    if-eqz v6, :cond_1d

    iget-object v3, v6, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v3, v3, v19

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v3

    int-to-float v3, v3

    add-float/2addr v0, v3

    :cond_1d
    :goto_e
    iget-object v3, v10, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v3, v3, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget-object v6, v13, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v6, v6, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    cmpg-float v8, v3, v6

    if-gez v8, :cond_1e

    sub-float/2addr v6, v3

    :goto_f
    sub-float v6, v6, v16

    goto :goto_10

    :cond_1e
    sub-float v6, v3, v6

    goto :goto_f

    :goto_10
    if-lez v9, :cond_26

    if-ne v9, v15, :cond_26

    invoke-virtual {v14}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v0

    if-eqz v0, :cond_1f

    invoke-virtual {v14}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v0

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v0, v0, v1

    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v5, :cond_1f

    const/4 v0, 0x0

    return v0

    :cond_1f
    add-float v6, v6, v16

    sub-float v6, v6, v17

    move v0, v3

    move-object/from16 v3, v20

    :goto_11
    if-eqz v3, :cond_25

    sget v5, Lconfimanag/scanutil/alfagamma/transper/m2;->r:I

    iget-object v5, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->r0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    aget-object v5, v5, v1

    if-nez v5, :cond_21

    if-ne v3, v4, :cond_20

    goto :goto_12

    :cond_20
    move-object/from16 v8, p1

    goto :goto_14

    :cond_21
    :goto_12
    int-to-float v7, v9

    div-float v18, v6, v7

    const/4 v7, 0x0

    cmpl-float v8, v2, v7

    if-lez v8, :cond_23

    iget-object v7, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->p0:[F

    aget v7, v7, v1

    const/high16 v8, -0x40800000    # -1.0f

    cmpl-float v8, v7, v8

    if-nez v8, :cond_22

    const/16 v18, 0x0

    goto :goto_13

    :cond_22
    mul-float v7, v7, v6

    div-float v18, v7, v2

    :cond_23
    :goto_13
    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v7

    const/16 v8, 0x8

    if-ne v7, v8, :cond_24

    const/16 v18, 0x0

    :cond_24
    iget-object v7, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v7, v7, p3

    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v7

    int-to-float v7, v7

    add-float/2addr v0, v7

    iget-object v7, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v7, v7, p3

    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v7

    iget-object v8, v10, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    invoke-virtual {v7, v8, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->l(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    iget-object v7, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v7, v7, v19

    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v7

    iget-object v8, v10, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    add-float v0, v0, v18

    invoke-virtual {v7, v8, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->l(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    iget-object v7, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v7, v7, p3

    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v7

    move-object/from16 v8, p1

    invoke-virtual {v7, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    iget-object v7, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v7, v7, v19

    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v7

    invoke-virtual {v7, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v3, v3, v19

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v3

    int-to-float v3, v3

    add-float/2addr v0, v3

    :goto_14
    move-object v3, v5

    goto :goto_11

    :cond_25
    const/4 v0, 0x1

    return v0

    :cond_26
    move-object/from16 v8, p1

    const/4 v2, 0x0

    cmpg-float v2, v6, v2

    if-gez v2, :cond_27

    const/4 v7, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    :cond_27
    if-eqz v7, :cond_2c

    sub-float/2addr v6, v0

    move-object/from16 v2, v20

    invoke-virtual {v2, v1}, Lconfimanag/scanutil/alfagamma/transper/g1;->k(I)F

    move-result v0

    mul-float v6, v6, v0

    add-float/2addr v3, v6

    move v0, v3

    :cond_28
    :goto_15
    move-object v3, v2

    if-eqz v3, :cond_2b

    sget v2, Lconfimanag/scanutil/alfagamma/transper/m2;->r:I

    iget-object v2, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->r0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    aget-object v2, v2, v1

    if-nez v2, :cond_29

    if-ne v3, v4, :cond_28

    :cond_29
    if-nez v1, :cond_2a

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v5

    :goto_16
    int-to-float v5, v5

    goto :goto_17

    :cond_2a
    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v5

    goto :goto_16

    :goto_17
    iget-object v6, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v6, v6, p3

    invoke-virtual {v6}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v6

    int-to-float v6, v6

    add-float/2addr v0, v6

    iget-object v6, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v6, v6, p3

    invoke-virtual {v6}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v6

    iget-object v7, v10, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    invoke-virtual {v6, v7, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->l(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    iget-object v6, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v6, v6, v19

    invoke-virtual {v6}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v6

    iget-object v7, v10, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    add-float/2addr v0, v5

    invoke-virtual {v6, v7, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->l(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    iget-object v5, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v5, v5, p3

    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v5

    invoke-virtual {v5, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    iget-object v5, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v5, v5, v19

    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v5

    invoke-virtual {v5, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v3, v3, v19

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v3

    int-to-float v3, v3

    add-float/2addr v0, v3

    goto :goto_15

    :cond_2b
    const/4 v0, 0x1

    goto/16 :goto_21

    :cond_2c
    move-object/from16 v2, v20

    if-nez v11, :cond_2d

    if-eqz v12, :cond_2b

    :cond_2d
    if-eqz v11, :cond_2e

    :goto_18
    sub-float/2addr v6, v0

    goto :goto_19

    :cond_2e
    if-eqz v12, :cond_2f

    goto :goto_18

    :cond_2f
    :goto_19
    add-int/lit8 v0, v15, 0x1

    int-to-float v0, v0

    div-float v0, v6, v0

    if-eqz v12, :cond_31

    const/4 v7, 0x1

    if-le v15, v7, :cond_30

    add-int/lit8 v0, v15, -0x1

    int-to-float v0, v0

    :goto_1a
    div-float v0, v6, v0

    goto :goto_1b

    :cond_30
    const/high16 v0, 0x40000000    # 2.0f

    goto :goto_1a

    :cond_31
    :goto_1b
    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v6

    const/16 v7, 0x8

    if-eq v6, v7, :cond_32

    add-float v6, v3, v0

    goto :goto_1c

    :cond_32
    move v6, v3

    :goto_1c
    if-eqz v12, :cond_33

    const/4 v7, 0x1

    if-le v15, v7, :cond_33

    iget-object v6, v5, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v6, v6, p3

    invoke-virtual {v6}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v6

    int-to-float v6, v6

    add-float/2addr v6, v3

    :cond_33
    if-eqz v11, :cond_34

    if-eqz v5, :cond_34

    iget-object v3, v5, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v3, v3, p3

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v3

    int-to-float v3, v3

    add-float/2addr v6, v3

    :cond_34
    :goto_1d
    move-object v3, v2

    if-eqz v3, :cond_2b

    sget v2, Lconfimanag/scanutil/alfagamma/transper/m2;->r:I

    iget-object v2, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->r0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    aget-object v2, v2, v1

    if-nez v2, :cond_36

    if-ne v3, v4, :cond_35

    goto :goto_1e

    :cond_35
    const/16 v7, 0x8

    goto :goto_1d

    :cond_36
    :goto_1e
    if-nez v1, :cond_37

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v7

    :goto_1f
    int-to-float v7, v7

    goto :goto_20

    :cond_37
    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v7

    goto :goto_1f

    :goto_20
    if-eq v3, v5, :cond_38

    iget-object v9, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v9, v9, p3

    invoke-virtual {v9}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v9

    int-to-float v9, v9

    add-float/2addr v6, v9

    :cond_38
    iget-object v9, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v9, v9, p3

    invoke-virtual {v9}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v9

    iget-object v11, v10, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    invoke-virtual {v9, v11, v6}, Lconfimanag/scanutil/alfagamma/transper/u4;->l(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    iget-object v9, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v9, v9, v19

    invoke-virtual {v9}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v9

    iget-object v11, v10, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    add-float v12, v6, v7

    invoke-virtual {v9, v11, v12}, Lconfimanag/scanutil/alfagamma/transper/u4;->l(Lconfimanag/scanutil/alfagamma/transper/u4;F)V

    iget-object v9, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v9, v9, p3

    invoke-virtual {v9}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v9

    invoke-virtual {v9, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    iget-object v9, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v9, v9, v19

    invoke-virtual {v9}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v9

    invoke-virtual {v9, v8}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v3, v3, v19

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v3

    int-to-float v3, v3

    add-float/2addr v7, v3

    add-float/2addr v6, v7

    if-eqz v2, :cond_35

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v3

    const/16 v7, 0x8

    if-eq v3, v7, :cond_34

    add-float/2addr v6, v0

    goto :goto_1d

    :goto_21
    return v0
.end method

.method static c(Lconfimanag/scanutil/alfagamma/transper/h1;Lconfimanag/scanutil/alfagamma/transper/m2;Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 6

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v3, 0x2

    if-eq v0, v2, :cond_0

    iget-object v0, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v0, v0, v1

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/g1$b;->d:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v1, :cond_0

    iget-object v0, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v1

    iget-object v4, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget v4, v4, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    sub-int/2addr v1, v4

    iget-object v4, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v5

    iput-object v5, v4, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v4, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v5

    iput-object v5, v4, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v4, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    invoke-virtual {p1, v4, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->f(Lconfimanag/scanutil/alfagamma/transper/m5;I)V

    iget-object v4, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    invoke-virtual {p1, v4, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->f(Lconfimanag/scanutil/alfagamma/transper/m5;I)V

    iput v3, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->a:I

    invoke-virtual {p2, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/g1;->f0(II)V

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    if-eq v0, v2, :cond_3

    iget-object v0, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v0, v0, v1

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/g1$b;->d:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v1, :cond_3

    iget-object v0, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result p0

    iget-object v1, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    sub-int/2addr p0, v1

    iget-object v1, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v2

    iput-object v2, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v1, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v2

    iput-object v2, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v1, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    invoke-virtual {p1, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->f(Lconfimanag/scanutil/alfagamma/transper/m5;I)V

    iget-object v1, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    invoke-virtual {p1, v1, p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->f(Lconfimanag/scanutil/alfagamma/transper/m5;I)V

    iget v1, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    if-gtz v1, :cond_1

    invoke-virtual {p2}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v1

    const/16 v2, 0x8

    if-ne v1, v2, :cond_2

    :cond_1
    iget-object v1, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v2

    iput-object v2, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v1, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget v2, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    add-int/2addr v2, v0

    invoke-virtual {p1, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->f(Lconfimanag/scanutil/alfagamma/transper/m5;I)V

    :cond_2
    iput v3, p2, Lconfimanag/scanutil/alfagamma/transper/g1;->b:I

    invoke-virtual {p2, v0, p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->t0(II)V

    :cond_3
    return-void
.end method

.method private static d(Lconfimanag/scanutil/alfagamma/transper/g1;I)Z
    .locals 5

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v1, v0, p1

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/g1$b;->c:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v3, 0x0

    if-eq v1, v2, :cond_0

    return v3

    :cond_0
    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    const/4 v2, 0x0

    const/4 v4, 0x1

    cmpl-float v1, v1, v2

    if-eqz v1, :cond_2

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    :goto_0
    aget-object p0, v0, v4

    return v3

    :cond_2
    if-nez p1, :cond_5

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e:I

    if-eqz p1, :cond_3

    return v3

    :cond_3
    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->h:I

    if-nez p1, :cond_4

    iget p0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->i:I

    if-eqz p0, :cond_7

    :cond_4
    return v3

    :cond_5
    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f:I

    if-eqz p1, :cond_6

    return v3

    :cond_6
    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    if-nez p1, :cond_8

    iget p0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->l:I

    if-eqz p0, :cond_7

    goto :goto_1

    :cond_7
    return v4

    :cond_8
    :goto_1
    return v3
.end method

.method static e(Lconfimanag/scanutil/alfagamma/transper/g1;II)V
    .locals 4

    .line 1
    mul-int/lit8 v0, p1, 0x2

    add-int/lit8 v1, v0, 0x1

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v2

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v3

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v3

    iput-object v3, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v2

    int-to-float p2, p2

    iput p2, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object p2, p2, v0

    invoke-virtual {p2}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object p2

    const/4 v2, 0x1

    iput v2, p2, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object p2, p2, v1

    invoke-virtual {p2}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object p2

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v0, v3, v0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iput-object v0, p2, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object p2, p2, v1

    invoke-virtual {p2}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object p2

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->t(I)I

    move-result p1

    int-to-float p1, p1

    iput p1, p2, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget-object p0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object p0, p0, v1

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object p0

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    return-void
.end method
