.class Lconfimanag/scanutil/alfagamma/transper/n2$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/n2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "c"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/n2;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$c;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$c;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/n2;->g()V

    return-void
.end method
