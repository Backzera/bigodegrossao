.class Lconfimanag/scanutil/alfagamma/transper/l1$a;
.super Landroid/database/ContentObserver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/l1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/l1;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/l1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l1$a;->a:Lconfimanag/scanutil/alfagamma/transper/l1;

    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    invoke-direct {p0, p1}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    return-void
.end method


# virtual methods
.method public deliverSelfNotifications()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    return v0
.end method

.method public onChange(Z)V
    .locals 0

    .line 1
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l1$a;->a:Lconfimanag/scanutil/alfagamma/transper/l1;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/l1;->i()V

    return-void
.end method
