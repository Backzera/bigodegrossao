.class public abstract Lconfimanag/scanutil/alfagamma/transper/i;
.super Ljava/lang/Object;
.source "SourceFile"
