.class Lconfimanag/scanutil/alfagamma/transper/h6;
.super Lconfimanag/scanutil/alfagamma/transper/z4;
.source "SourceFile"


# instance fields
.field private final b:Ljava/lang/ref/WeakReference;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/content/res/Resources;)V
    .locals 0

    .line 1
    invoke-direct {p0, p2}, Lconfimanag/scanutil/alfagamma/transper/z4;-><init>(Landroid/content/res/Resources;)V

    new-instance p2, Ljava/lang/ref/WeakReference;

    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/h6;->b:Ljava/lang/ref/WeakReference;

    return-void
.end method


# virtual methods
.method public getDrawable(I)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/z4;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/h6;->b:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Context;

    if-eqz v0, :cond_0

    if-eqz v1, :cond_0

    invoke-static {}, Lconfimanag/scanutil/alfagamma/transper/r;->n()Lconfimanag/scanutil/alfagamma/transper/r;

    invoke-static {v1, p1, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->C(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Z

    :cond_0
    return-object v0
.end method
