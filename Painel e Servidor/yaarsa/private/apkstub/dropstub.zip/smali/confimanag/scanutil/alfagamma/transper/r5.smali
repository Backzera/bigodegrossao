.class public interface abstract Lconfimanag/scanutil/alfagamma/transper/r5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/Menu;
