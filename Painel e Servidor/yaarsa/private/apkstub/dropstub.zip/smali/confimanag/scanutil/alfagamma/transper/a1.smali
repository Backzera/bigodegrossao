.class public Lconfimanag/scanutil/alfagamma/transper/a1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field protected a:Lconfimanag/scanutil/alfagamma/transper/g1;

.field protected b:Lconfimanag/scanutil/alfagamma/transper/g1;

.field protected c:Lconfimanag/scanutil/alfagamma/transper/g1;

.field protected d:Lconfimanag/scanutil/alfagamma/transper/g1;

.field protected e:Lconfimanag/scanutil/alfagamma/transper/g1;

.field protected f:Lconfimanag/scanutil/alfagamma/transper/g1;

.field protected g:Lconfimanag/scanutil/alfagamma/transper/g1;

.field protected h:Ljava/util/ArrayList;

.field protected i:I

.field protected j:I

.field protected k:F

.field private l:I

.field private m:Z

.field protected n:Z

.field protected o:Z

.field protected p:Z

.field private q:Z


# direct methods
.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/g1;IZ)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->k:F

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->a:Lconfimanag/scanutil/alfagamma/transper/g1;

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->l:I

    iput-boolean p3, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->m:Z

    return-void
.end method

.method private b()V
    .locals 12

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->l:I

    const/4 v1, 0x2

    mul-int/lit8 v0, v0, 0x2

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->a:Lconfimanag/scanutil/alfagamma/transper/g1;

    const/4 v3, 0x0

    move-object v4, v2

    const/4 v5, 0x0

    :goto_0
    const/4 v6, 0x1

    if-nez v5, :cond_d

    iget v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->i:I

    add-int/2addr v7, v6

    iput v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->i:I

    iget-object v7, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->r0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v8, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->l:I

    const/4 v9, 0x0

    aput-object v9, v7, v8

    iget-object v7, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->q0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    aput-object v9, v7, v8

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v7

    const/16 v8, 0x8

    if-eq v7, v8, :cond_8

    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-nez v7, :cond_0

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    :cond_0
    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->d:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v7, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    iget v8, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->l:I

    aget-object v7, v7, v8

    sget-object v10, Lconfimanag/scanutil/alfagamma/transper/g1$b;->c:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v7, v10, :cond_8

    iget-object v7, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->g:[I

    aget v7, v7, v8

    if-eqz v7, :cond_1

    const/4 v10, 0x3

    if-eq v7, v10, :cond_1

    if-ne v7, v1, :cond_8

    :cond_1
    iget v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->j:I

    add-int/2addr v7, v6

    iput v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->j:I

    iget-object v7, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->p0:[F

    aget v7, v7, v8

    const/4 v10, 0x0

    cmpl-float v11, v7, v10

    if-lez v11, :cond_2

    iget v11, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->k:F

    add-float/2addr v11, v7

    iput v11, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->k:F

    :cond_2
    invoke-static {v2, v8}, Lconfimanag/scanutil/alfagamma/transper/a1;->c(Lconfimanag/scanutil/alfagamma/transper/g1;I)Z

    move-result v8

    if-eqz v8, :cond_5

    cmpg-float v7, v7, v10

    if-gez v7, :cond_3

    iput-boolean v6, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->n:Z

    goto :goto_1

    :cond_3
    iput-boolean v6, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->o:Z

    :goto_1
    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->h:Ljava/util/ArrayList;

    if-nez v7, :cond_4

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    iput-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->h:Ljava/util/ArrayList;

    :cond_4
    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->h:Ljava/util/ArrayList;

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->f:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-nez v7, :cond_6

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->f:Lconfimanag/scanutil/alfagamma/transper/g1;

    :cond_6
    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->g:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-eqz v7, :cond_7

    iget-object v7, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->q0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v8, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->l:I

    aput-object v2, v7, v8

    :cond_7
    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->g:Lconfimanag/scanutil/alfagamma/transper/g1;

    :cond_8
    if-eq v4, v2, :cond_9

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/g1;->r0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v7, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->l:I

    aput-object v2, v4, v7

    :cond_9
    iget-object v4, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    add-int/lit8 v7, v0, 0x1

    aget-object v4, v4, v7

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v4, :cond_b

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v7, v4, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v7, v7, v0

    iget-object v7, v7, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v7, :cond_b

    iget-object v7, v7, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-eq v7, v2, :cond_a

    goto :goto_2

    :cond_a
    move-object v9, v4

    :cond_b
    :goto_2
    if-eqz v9, :cond_c

    goto :goto_3

    :cond_c
    move-object v9, v2

    const/4 v5, 0x1

    :goto_3
    move-object v4, v2

    move-object v2, v9

    goto/16 :goto_0

    :cond_d
    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->c:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->l:I

    if-nez v0, :cond_e

    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->m:Z

    if-eqz v0, :cond_e

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->e:Lconfimanag/scanutil/alfagamma/transper/g1;

    goto :goto_4

    :cond_e
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->a:Lconfimanag/scanutil/alfagamma/transper/g1;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->e:Lconfimanag/scanutil/alfagamma/transper/g1;

    :goto_4
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->o:Z

    if-eqz v0, :cond_f

    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->n:Z

    if-eqz v0, :cond_f

    const/4 v3, 0x1

    :cond_f
    iput-boolean v3, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->p:Z

    return-void
.end method

.method private static c(Lconfimanag/scanutil/alfagamma/transper/g1;I)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v0

    const/16 v1, 0x8

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v0, v0, p1

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/g1$b;->c:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v1, :cond_1

    iget-object p0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->g:[I

    aget p0, p0, p1

    if-eqz p0, :cond_0

    const/4 p1, 0x3

    if-ne p0, p1, :cond_1

    :cond_0
    const/4 p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public a()V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->q:Z

    if-nez v0, :cond_0

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/a1;->b()V

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/a1;->q:Z

    return-void
.end method
