.class final Lconfimanag/scanutil/alfagamma/transper/a2$g;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/a2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "g"
.end annotation


# instance fields
.field final a:Landroid/graphics/Typeface;

.field final b:I


# direct methods
.method constructor <init>(Landroid/graphics/Typeface;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$g;->a:Landroid/graphics/Typeface;

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/a2$g;->b:I

    return-void
.end method
