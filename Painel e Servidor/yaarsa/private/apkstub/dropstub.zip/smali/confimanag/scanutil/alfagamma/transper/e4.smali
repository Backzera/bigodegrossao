.class public abstract Lconfimanag/scanutil/alfagamma/transper/e4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/text/Spannable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/e4$a;
    }
.end annotation
