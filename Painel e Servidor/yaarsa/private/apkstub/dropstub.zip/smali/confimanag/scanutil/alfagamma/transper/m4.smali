.class public abstract Lconfimanag/scanutil/alfagamma/transper/m4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static A:I = 0x7f07008b

.field public static B:I = 0x7f07008f

.field public static a:I = 0x7f070006

.field public static b:I = 0x7f070007

.field public static c:I = 0x7f070008

.field public static d:I = 0x7f07000b

.field public static e:I = 0x7f07000c

.field public static f:I = 0x7f07000e

.field public static g:I = 0x7f070023

.field public static h:I = 0x7f07002d

.field public static i:I = 0x7f07002e

.field public static j:I = 0x7f070030

.field public static k:I = 0x7f070036

.field public static l:I = 0x7f07003f

.field public static m:I = 0x7f070050

.field public static n:I = 0x7f070069

.field public static o:I = 0x7f07006a

.field public static p:I = 0x7f07006b

.field public static q:I = 0x7f07006c

.field public static r:I = 0x7f07006d

.field public static s:I = 0x7f07006e

.field public static t:I = 0x7f07006f

.field public static u:I = 0x7f070070

.field public static v:I = 0x7f070072

.field public static w:I = 0x7f070076

.field public static x:I = 0x7f070077

.field public static y:I = 0x7f07007f

.field public static z:I = 0x7f070080
