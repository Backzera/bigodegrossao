.class final Lconfimanag/scanutil/alfagamma/transper/a2$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/a2;->g(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;Lconfimanag/scanutil/alfagamma/transper/y4$a;Landroid/os/Handler;ZII)Landroid/graphics/Typeface;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lconfimanag/scanutil/alfagamma/transper/y1;

.field final synthetic c:I

.field final synthetic d:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;ILjava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$a;->a:Landroid/content/Context;

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/a2$a;->b:Lconfimanag/scanutil/alfagamma/transper/y1;

    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/a2$a;->c:I

    iput-object p4, p0, Lconfimanag/scanutil/alfagamma/transper/a2$a;->d:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lconfimanag/scanutil/alfagamma/transper/a2$g;
    .locals 4

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a2$a;->a:Landroid/content/Context;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$a;->b:Lconfimanag/scanutil/alfagamma/transper/y1;

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/a2$a;->c:I

    invoke-static {v0, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/a2;->f(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;I)Lconfimanag/scanutil/alfagamma/transper/a2$g;

    move-result-object v0

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/a2$g;->a:Landroid/graphics/Typeface;

    if-eqz v1, :cond_0

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/a2;->a:Lconfimanag/scanutil/alfagamma/transper/r2;

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/a2$a;->d:Ljava/lang/String;

    invoke-virtual {v2, v3, v1}, Lconfimanag/scanutil/alfagamma/transper/r2;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/a2$a;->a()Lconfimanag/scanutil/alfagamma/transper/a2$g;

    move-result-object v0

    return-object v0
.end method
