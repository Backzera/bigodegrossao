.class public abstract Lconfimanag/scanutil/alfagamma/transper/l4;
.super Ljava/lang/Object;
.source "SourceFile"
