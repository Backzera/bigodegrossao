.class public Lconfimanag/scanutil/alfagamma/transper/g2;
.super Lconfimanag/scanutil/alfagamma/transper/g1;
.source "SourceFile"


# instance fields
.field private A0:Z

.field private B0:I

.field private C0:Lconfimanag/scanutil/alfagamma/transper/t4;

.field private D0:I

.field protected v0:F

.field protected w0:I

.field protected x0:I

.field private y0:Lconfimanag/scanutil/alfagamma/transper/f1;

.field private z0:I


# direct methods
.method public constructor <init>()V
    .locals 4

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;-><init>()V

    const/high16 v0, -0x40800000    # -1.0f

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    const/4 v0, -0x1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->A0:Z

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->B0:I

    new-instance v1, Lconfimanag/scanutil/alfagamma/transper/t4;

    invoke-direct {v1}, Lconfimanag/scanutil/alfagamma/transper/t4;-><init>()V

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->C0:Lconfimanag/scanutil/alfagamma/transper/t4;

    const/16 v1, 0x8

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->D0:I

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    array-length v1, v1

    :goto_0
    if-ge v0, v1, :cond_0

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    aput-object v3, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public G0(Lconfimanag/scanutil/alfagamma/transper/m2;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->y(Ljava/lang/Object;)I

    move-result p1

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_1

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->C0(I)V

    invoke-virtual {p0, v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->D0(I)V

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object p1

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result p1

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->b0(I)V

    invoke-virtual {p0, v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->y0(I)V

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->C0(I)V

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D0(I)V

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object p1

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result p1

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->y0(I)V

    invoke-virtual {p0, v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->b0(I)V

    :goto_0
    return-void
.end method

.method public I0()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    return v0
.end method

.method public J0(I)V
    .locals 2

    .line 1
    const/4 v0, -0x1

    if-le p1, v0, :cond_0

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    :cond_0
    return-void
.end method

.method public K0(I)V
    .locals 2

    .line 1
    const/4 v0, -0x1

    if-le p1, v0, :cond_0

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    :cond_0
    return-void
.end method

.method public L0(F)V
    .locals 1

    .line 1
    const/high16 v0, -0x40800000    # -1.0f

    cmpl-float v0, p1, v0

    if-lez v0, :cond_0

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    const/4 p1, -0x1

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    :cond_0
    return-void
.end method

.method public M0(I)V
    .locals 3

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    :goto_0
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    goto :goto_1

    :cond_1
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    goto :goto_0

    :goto_1
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    array-length p1, p1

    const/4 v0, 0x0

    :goto_2
    if-ge v0, p1, :cond_2

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_2
    return-void
.end method

.method public b(Lconfimanag/scanutil/alfagamma/transper/m2;)V
    .locals 9

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v0

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/h1;

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/f1$d;->b:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v1

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/f1$d;->d:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v2

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_1

    iget-object v3, v3, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v3, v3, v5

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v3, v6, :cond_1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    :goto_0
    iget v6, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    if-nez v6, :cond_3

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/f1$d;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v1

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v2

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-eqz v0, :cond_2

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v0, v0, v4

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v3, :cond_2

    goto :goto_1

    :cond_2
    const/4 v4, 0x0

    :goto_1
    move v3, v4

    :cond_3
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    const/4 v4, 0x6

    const/4 v6, -0x1

    const/4 v7, 0x5

    if-eq v0, v6, :cond_4

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    iget v6, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    invoke-virtual {p1, v0, v1, v6, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    if-eqz v3, :cond_6

    invoke-virtual {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    invoke-virtual {p1, v1, v0, v5, v7}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    goto :goto_2

    :cond_4
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    if-eq v0, v6, :cond_5

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    invoke-virtual {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v2

    iget v6, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    neg-int v6, v6

    invoke-virtual {p1, v0, v2, v6, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    if-eqz v3, :cond_6

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    invoke-virtual {p1, v0, v1, v5, v7}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    invoke-virtual {p1, v2, v0, v5, v7}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    goto :goto_2

    :cond_5
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    const/high16 v3, -0x40800000    # -1.0f

    cmpl-float v0, v0, v3

    if-eqz v0, :cond_6

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v4

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v5

    invoke-virtual {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v6

    iget v7, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    iget-boolean v8, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->A0:Z

    move-object v3, p1

    invoke-static/range {v3 .. v8}, Lconfimanag/scanutil/alfagamma/transper/m2;->t(Lconfimanag/scanutil/alfagamma/transper/m2;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;FZ)Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    :cond_6
    :goto_2
    return-void
.end method

.method public c()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    return v0
.end method

.method public d(I)V
    .locals 6

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g2;->I0()I

    move-result v0

    const/high16 v1, -0x40800000    # -1.0f

    const/4 v2, -0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ne v0, v4, :cond_3

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object v5, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v5

    invoke-virtual {v0, v4, v5, v3}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object v5, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v5

    invoke-virtual {v0, v4, v5, v3}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    if-eq v0, v2, :cond_1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object v1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    invoke-virtual {v0, v4, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    :goto_0
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object p1

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    :goto_1
    invoke-virtual {v0, v4, p1, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    goto/16 :goto_4

    :cond_1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    if-eq v0, v2, :cond_2

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object v1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    neg-int v2, v2

    invoke-virtual {v0, v4, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    :goto_2
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object p1

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    neg-int v1, v1

    goto :goto_1

    :cond_2
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->s()Lconfimanag/scanutil/alfagamma/transper/g1$b;

    move-result-object v0

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/g1$b;->a:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v1, :cond_6

    iget v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    int-to-float v0, v0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    mul-float v0, v0, v1

    float-to-int v0, v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget-object v2, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v2

    invoke-virtual {v1, v4, v2, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    :goto_3
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object p1

    invoke-virtual {v1, v4, p1, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    goto/16 :goto_4

    :cond_3
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object v5, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v5

    invoke-virtual {v0, v4, v5, v3}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object v5, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v5

    invoke-virtual {v0, v4, v5, v3}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    if-eq v0, v2, :cond_4

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object v1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->w0:I

    invoke-virtual {v0, v4, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    goto/16 :goto_0

    :cond_4
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    if-eq v0, v2, :cond_5

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object v1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->x0:I

    neg-int v2, v2

    invoke-virtual {v0, v4, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    goto/16 :goto_2

    :cond_5
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->B()Lconfimanag/scanutil/alfagamma/transper/g1$b;

    move-result-object v0

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/g1$b;->a:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v1, :cond_6

    iget v0, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    int-to-float v0, v0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->v0:F

    mul-float v0, v0, v1

    float-to-int v0, v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget-object v2, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v2

    invoke-virtual {v1, v4, v2, v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    goto/16 :goto_3

    :cond_6
    :goto_4
    return-void
.end method

.method public h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;
    .locals 2

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/g2$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    const/4 p1, 0x0

    return-object p1

    :pswitch_1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    if-nez v0, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :pswitch_2
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->z0:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g2;->y0:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :cond_0
    :goto_0
    new-instance v0, Ljava/lang/AssertionError;

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public i()Ljava/util/ArrayList;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    return-object v0
.end method
