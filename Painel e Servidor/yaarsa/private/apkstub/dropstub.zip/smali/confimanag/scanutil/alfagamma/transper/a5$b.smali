.class Lconfimanag/scanutil/alfagamma/transper/a5$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/a5;->d(Ljava/util/concurrent/Callable;Lconfimanag/scanutil/alfagamma/transper/a5$d;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/concurrent/Callable;

.field final synthetic b:Landroid/os/Handler;

.field final synthetic c:Lconfimanag/scanutil/alfagamma/transper/a5$d;

.field final synthetic d:Lconfimanag/scanutil/alfagamma/transper/a5;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/a5;Ljava/util/concurrent/Callable;Landroid/os/Handler;Lconfimanag/scanutil/alfagamma/transper/a5$d;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b;->d:Lconfimanag/scanutil/alfagamma/transper/a5;

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b;->a:Ljava/util/concurrent/Callable;

    iput-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b;->b:Landroid/os/Handler;

    iput-object p4, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b;->c:Lconfimanag/scanutil/alfagamma/transper/a5$d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 1
    :try_start_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b;->a:Ljava/util/concurrent/Callable;

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b;->b:Landroid/os/Handler;

    new-instance v2, Lconfimanag/scanutil/alfagamma/transper/a5$b$a;

    invoke-direct {v2, p0, v0}, Lconfimanag/scanutil/alfagamma/transper/a5$b$a;-><init>(Lconfimanag/scanutil/alfagamma/transper/a5$b;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
