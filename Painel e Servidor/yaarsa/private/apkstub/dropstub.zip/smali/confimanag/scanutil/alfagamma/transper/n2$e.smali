.class Lconfimanag/scanutil/alfagamma/transper/n2$e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AbsListView$OnScrollListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/n2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "e"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/n2;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$e;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onScroll(Landroid/widget/AbsListView;III)V
    .locals 0

    .line 1
    return-void
.end method

.method public onScrollStateChanged(Landroid/widget/AbsListView;I)V
    .locals 0

    .line 1
    const/4 p1, 0x1

    if-ne p2, p1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$e;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/n2;->n()Z

    move-result p1

    if-nez p1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$e;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {p1}, Landroid/widget/PopupWindow;->getContentView()Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$e;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget-object p2, p1, Lconfimanag/scanutil/alfagamma/transper/n2;->D:Landroid/os/Handler;

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/n2;->y:Lconfimanag/scanutil/alfagamma/transper/n2$g;

    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$e;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/n2;->y:Lconfimanag/scanutil/alfagamma/transper/n2$g;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/n2$g;->run()V

    :cond_0
    return-void
.end method
