.class Lconfimanag/scanutil/alfagamma/transper/l6$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/l6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/l6;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/l6;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l6$b;->a:Lconfimanag/scanutil/alfagamma/transper/l6;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l6$b;->a:Lconfimanag/scanutil/alfagamma/transper/l6;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/l6;->c()V

    return-void
.end method
