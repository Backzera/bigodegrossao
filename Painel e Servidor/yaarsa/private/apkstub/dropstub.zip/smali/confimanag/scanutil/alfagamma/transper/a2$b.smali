.class final Lconfimanag/scanutil/alfagamma/transper/a2$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lconfimanag/scanutil/alfagamma/transper/a5$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/a2;->g(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;Lconfimanag/scanutil/alfagamma/transper/y4$a;Landroid/os/Handler;ZII)Landroid/graphics/Typeface;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/y4$a;

.field final synthetic b:Landroid/os/Handler;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/y4$a;Landroid/os/Handler;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$b;->a:Lconfimanag/scanutil/alfagamma/transper/y4$a;

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/a2$b;->b:Landroid/os/Handler;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/a2$g;

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/a2$b;->b(Lconfimanag/scanutil/alfagamma/transper/a2$g;)V

    return-void
.end method

.method public b(Lconfimanag/scanutil/alfagamma/transper/a2$g;)V
    .locals 2

    .line 1
    if-nez p1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$b;->a:Lconfimanag/scanutil/alfagamma/transper/y4$a;

    const/4 v0, 0x1

    :goto_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$b;->b:Landroid/os/Handler;

    invoke-virtual {p1, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/y4$a;->a(ILandroid/os/Handler;)V

    goto :goto_1

    :cond_0
    iget v0, p1, Lconfimanag/scanutil/alfagamma/transper/a2$g;->b:I

    if-nez v0, :cond_1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a2$b;->a:Lconfimanag/scanutil/alfagamma/transper/y4$a;

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/a2$g;->a:Landroid/graphics/Typeface;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$b;->b:Landroid/os/Handler;

    invoke-virtual {v0, p1, v1}, Lconfimanag/scanutil/alfagamma/transper/y4$a;->b(Landroid/graphics/Typeface;Landroid/os/Handler;)V

    goto :goto_1

    :cond_1
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$b;->a:Lconfimanag/scanutil/alfagamma/transper/y4$a;

    goto :goto_0

    :goto_1
    return-void
.end method
