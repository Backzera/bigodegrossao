.class public interface abstract Lconfimanag/scanutil/alfagamma/transper/x1;
.super Ljava/lang/Object;
.source "SourceFile"
