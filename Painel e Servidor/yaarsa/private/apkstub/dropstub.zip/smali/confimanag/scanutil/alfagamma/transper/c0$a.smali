.class Lconfimanag/scanutil/alfagamma/transper/c0$a;
.super Lconfimanag/scanutil/alfagamma/transper/y4$a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/c0;->u(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/i6;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/ref/WeakReference;

.field final synthetic b:Lconfimanag/scanutil/alfagamma/transper/c0;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/c0;Ljava/lang/ref/WeakReference;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/c0$a;->b:Lconfimanag/scanutil/alfagamma/transper/c0;

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/c0$a;->a:Ljava/lang/ref/WeakReference;

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/y4$a;-><init>()V

    return-void
.end method


# virtual methods
.method public c(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public d(Landroid/graphics/Typeface;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0$a;->b:Lconfimanag/scanutil/alfagamma/transper/c0;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/c0$a;->a:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0, v1, p1}, Lconfimanag/scanutil/alfagamma/transper/c0;->l(Ljava/lang/ref/WeakReference;Landroid/graphics/Typeface;)V

    return-void
.end method
