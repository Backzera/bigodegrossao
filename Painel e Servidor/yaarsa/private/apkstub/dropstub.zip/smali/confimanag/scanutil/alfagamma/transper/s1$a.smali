.class Lconfimanag/scanutil/alfagamma/transper/s1$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/s1;->g(I)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/s1;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/s1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/s1$a;->a:Lconfimanag/scanutil/alfagamma/transper/s1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s1$a;->a:Lconfimanag/scanutil/alfagamma/transper/s1;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/s1;->a(Z)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s1$a;->a:Lconfimanag/scanutil/alfagamma/transper/s1;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method
