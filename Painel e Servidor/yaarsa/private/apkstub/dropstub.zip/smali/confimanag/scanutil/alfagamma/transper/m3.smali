.class interface abstract Lconfimanag/scanutil/alfagamma/transper/m3;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a([Ljava/lang/Object;I)V
.end method

.method public abstract b(Ljava/lang/Object;)Z
.end method

.method public abstract c()Ljava/lang/Object;
.end method
