.class public abstract Lconfimanag/scanutil/alfagamma/transper/j4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:I = 0x7f050016

.field public static b:I = 0x7f050017

.field public static c:I = 0x7f050029

.field public static d:I = 0x7f05002a

.field public static e:I = 0x7f050033

.field public static f:I = 0x7f050034

.field public static g:I = 0x7f05006d

.field public static h:I = 0x7f05006e

.field public static i:I = 0x7f050070

.field public static j:I = 0x7f050071
