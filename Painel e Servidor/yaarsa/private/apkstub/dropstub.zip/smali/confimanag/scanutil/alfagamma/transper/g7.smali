.class public interface abstract Lconfimanag/scanutil/alfagamma/transper/g7;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Landroid/graphics/drawable/Drawable;
.end method
